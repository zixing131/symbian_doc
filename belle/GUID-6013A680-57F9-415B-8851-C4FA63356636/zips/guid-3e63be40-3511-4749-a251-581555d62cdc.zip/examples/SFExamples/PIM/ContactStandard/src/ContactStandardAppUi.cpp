// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactStandard.rsg>

#include "ContactStandardAppUi.h"
#include "ContactStandardMainView.h"
#include "ContactWrite.h"
#include "ContactStandard.hrh"
#include <S32MEM.H> // for descriptor-backed streams.

void CContactStandardAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactStandardMainView::NewL(ClientRect());

	iContactWriter = CContactWrite::NewL();
	}
	
CContactStandardAppUi::~CContactStandardAppUi()
	{
	delete iContactWriter;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
	}

void CContactStandardAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactStandard:
			{
			CContactDatabase& cntDb = iContactWriter->CntDatabase();
			TContactItemId cntId = cntDb.OwnCardId();
			// this is just one easy way to get a TContactItemId.
			// the \PIM\PopulateContact sample code would have created
			// an own card

			if (KNullContactId != cntId)
				{
				// let's make a descriptor-backed stream.
				// 4Kb should be enough to hold most picture-free contact cards.
				HBufC8* buffer = HBufC8::NewLC(4096);
				TPtr8 bufferPtr = buffer->Des();

				RDesWriteStream writeStream(bufferPtr);
				TRAPD(error, iContactWriter->ExportContactL(cntId, writeStream));
				writeStream.Close();

				// report error on the Label control
				if (KErrNone == error)
					{
					// make a read stream to re-import the contact
					// from the descriptor

					RDesReadStream readStream(*buffer);
					TRAP(error, iContactWriter->ImportContactL(readStream));
					readStream.Close();

					if (KErrNone == error)
						{
						_LIT(KSuccess, "It Worked!");
						/**
						 * NOTE : this won't actually duplicate the
						 * 		  own card because only one exists at
						 * 		  a time.
						 */
						iMainView->SetTextL(KSuccess());
						}
					}
				if (KErrNone != error)
					{
					_LIT(KErrorMsg, "Symbian Error Code = %D");
					TBuf<32> errorBuf;
					errorBuf.Format(KErrorMsg(), error);
					iMainView->SetTextL(errorBuf);
					}
				CleanupStack::PopAndDestroy(buffer);
				}
			else
				{
				_LIT(KNotFound, "No Own Card");
				iMainView->SetTextL(KNotFound());
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactStandardAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
