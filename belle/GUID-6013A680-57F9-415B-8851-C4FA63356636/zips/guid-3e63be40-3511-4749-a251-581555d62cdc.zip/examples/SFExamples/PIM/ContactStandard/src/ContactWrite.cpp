// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactWrite.h"

CContactWrite* CContactWrite::NewL()
	{
	CContactWrite* self = new (ELeave) CContactWrite();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactWrite::~CContactWrite()
	{
	delete iCntDb;
	}

void CContactWrite::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	}

CContactDatabase& CContactWrite::CntDatabase()
	{
	return *iCntDb;
	}

void CContactWrite::ExportContactL(TContactItemId aCntId,RWriteStream& aOutput)
	{
	// this only works with a collection of contact ids.
	CContactIdArray* array = CContactIdArray::NewLC();
	array->AddL(aCntId); 
	TUid uid;
	uid.iUid = KVersitEntityUidVCard;
	iCntDb->ExportSelectedContactsL(uid,*array,aOutput,CContactDatabase::EDefault);
	CleanupStack::PopAndDestroy(array);
	}

void CContactWrite::ImportContactL(RReadStream& aInput)
	{
	TBool success;
	CArrayPtr<CContactItem>* importedContacts = iCntDb->ImportContactsL(
			TUid::Uid(KVersitEntityUidVCard),aInput,success,
			CContactDatabase::EImportSingleContact |
				CContactDatabase::EIncludeX | CContactDatabase::ETTFormat);
	// use the cleanupstack if you intend to do something here.
	delete importedContacts->At(0);
	delete importedContacts;
	}

// End of File
