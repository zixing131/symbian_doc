// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __ContactSortAPPUI_H_
#define __ContactSortAPPUI_H_

#include <aknappui.h>

class CContactSortMainView;
class CContactRead;

class CContactSortAppUi : public CAknAppUi
    {
public:

	void ConstructL();
	~CContactSortAppUi();

	void HandleCommandL(TInt aCommand);
	
#ifdef __SERIES60_3X__
	void HandleResourceChangeL(TInt aType);
#endif

private:

	CContactSortMainView* iMainView;
	CContactRead* iContactReader;

	};

#endif // __ContactSortAPPUI_H_

// End of File
