// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactSort.rsg>

#include "ContactSortAppUi.h"
#include "ContactSortMainView.h"
#include "ContactRead.h"
#include "ContactSort.hrh"

void CContactSortAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactSortMainView::NewL(ClientRect());

	iContactReader = CContactRead::NewL();
	}
	
CContactSortAppUi::~CContactSortAppUi()
    {
    delete iContactReader;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CContactSortAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactSort:
			{
			// \PIM\PopulateContact should have created at least 3 cards
			// with both first names and last names.
			CContactIdArray* result = NULL;
			TRAPD(error, result = iContactReader->SortByNameL());
			// report result on the Label control
			if (KErrNone == error)
				{
				CleanupStack::PushL(result);
				TBuf<256> textBuf;
				_LIT(KPrefix, "success :");
				_LIT(KNoName, "NoName");
				textBuf.Append(KPrefix());
				for (TInt ii = 0; ii < result->Count() && ii < 3; ++ii)
					{
					CDesCArray* last = iContactReader->ReadTextFieldL((*result)[ii], KUidContactFieldFamilyName);
					CleanupStack::PushL(last);
					CDesCArray* first = iContactReader->ReadTextFieldL((*result)[ii], KUidContactFieldGivenName);
					if (last->Count() > 0)
						textBuf.Append(last->MdcaPoint(0));
					else
						textBuf.Append(KNoName());
					if (first->Count() > 0)
						textBuf.Append(first->MdcaPoint(0));
					else
						textBuf.Append(KNoName());
					delete first;
					CleanupStack::PopAndDestroy(last);
					}
				CleanupStack::PopAndDestroy(result);
				iMainView->SetTextL(textBuf);
				}
			else
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactSortAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
