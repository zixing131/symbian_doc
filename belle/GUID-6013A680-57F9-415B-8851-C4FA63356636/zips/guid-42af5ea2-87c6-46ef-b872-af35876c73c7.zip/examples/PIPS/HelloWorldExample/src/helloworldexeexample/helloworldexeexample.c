/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



/* This example is a simple PIPS STDEXE application. It loads the DLL and calls its exported function. 
The application implements the dynamic lookup by name mechanism of the exported function using the libdl APIs.
*/

// Include files.
#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>

/**
Waits for key press event.  
*/
void PressAKey()
	{
	fflush(stdout);
	getchar();
	}
/**
Get and display the most recent error that occurred due to any of the dynamic lookup routines.
@return EXIT_FAILURE Returns the failure code.
*/
int DisplayErrorMessage()
	{
	// Obtain the last error occurred using the libdl API, dlerror().
	const char *q = dlerror();
	
	// Prints the error message.
	printf("%s",q);
	PressAKey();
		
	// returns the failure code.
	return EXIT_FAILURE;
	}

int main()
{
	int result;
	
	// Handle to load the dynamic library.
	void* handleToDll;
	
	typedef void (*PrintHelloWorldFunction)(void);
	PrintHelloWorldFunction PrintHelloWorld;
	
	// Contains name of the DLL file.
	char dllFileName[] = "helloworlddllexample.dll";

	/**
	Loads the DLL using the libdl API dlopen(), to gain access to the symbols in it.
	It takes two parameters: the name of the DLL file and the mode in which it has to be loaded.
	This returns a NULL, if it fails for any reason.Otherwise, it returns a descriptor.
	*/
	handleToDll = dlopen(dllFileName, RTLD_LAZY);
	
	// Check the descriptor value.If it is null, the error message is printed.
	if (!handleToDll)
		{
		DisplayErrorMessage();
		}
	
	// Print the message to start the example application.
	printf(" Press enter key to step through the example application\n");
	PressAKey();

	/**
	Locates the symbol using the libdl API, dlsym(). 
	It takes the handle returned by the dlopen() function and the symbol name to find.
	This returns the address binding of the symbol, PrintHelloWorld if successful. Otherwise, it returns NULL.
	*/
	PrintHelloWorld = (PrintHelloWorldFunction)dlsym(handleToDll, "PrintHelloWorld");   
	
	// Check the symbol address value. If this is null, the error message is printed.
	if(!PrintHelloWorld)
		{
		DisplayErrorMessage();
		}

	// Call the loaded DLL's exported function.
	PrintHelloWorld();

	/**
	Remove the dlopen-ed handle from the cache, maintained by dlopen(), using libdl API, dlclose().
	It takes the handle returned by the dlopen() function to decrement the reference count associated with the DLL.
	When the reference count reaches zero, the DLL is unloaded from the process address space.
	This API returns 0 if successful, otherwise it returns -1.
	*/
	result= dlclose(handleToDll);
	
	// Check the return value. If this is -1, the error message is printed.
	if(result == -1)
		{
		DisplayErrorMessage();
		}
	
	// Print the message to exit from the example application.
	printf(" Press enter key to exit from the example application");
	PressAKey();
	
	// returns the success code.
	return EXIT_SUCCESS;
}



