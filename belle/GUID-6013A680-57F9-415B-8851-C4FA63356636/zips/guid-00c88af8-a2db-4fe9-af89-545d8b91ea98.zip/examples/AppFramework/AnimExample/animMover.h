/*
Copyright (c) 2006-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#ifndef __ANIMMOVER_H__
#define __ANIMMOVER_H__

#include <e32std.h>
#include <spriteanimation.h>
#include <basicanimation.h>
#include <math.h>

const TInt KXDeflectionIncrement = 5;
const TInt KXDeflectionTerminalValue = 475;
const TInt KYDeflectionOffset = 125;
const TInt KYDeflectionMultiplier = 12;

const TInt KAnimExBasicInitPosX = 300;
const TInt KAnimExBasicInitPosY = 100;
const TInt KAnimExSpriteInitPosX = 60;
const TInt KAnimExSpriteInitPosY = 70;	
	

// Basic Animation Mover
class CSpriteAnimMover : public CActive
	{
public:
	CSpriteAnimMover( TInt aPriority, TInt aMicroSeconds, CSpriteAnimation* aSpriteAnim );
	~CSpriteAnimMover();
	
	
	
protected:		
	void DoCancel();	
	void RunL();
		
private:
	RTimer iTimer;
	TInt iMicroSeconds;
	CSpriteAnimation* iSpriteAnim; // Caller owns.
	TInt iX;
	TInt iY;	
	
	};


// Sprite Animation Mover
class CBasicAnimMover : public CActive
	{
public:
	CBasicAnimMover( TInt aPriority, TInt aMicroSeconds, CBasicAnimation* aBasicAnim );
	~CBasicAnimMover();
		
protected:		
	void DoCancel();	
	void RunL();
		
private:
	RTimer iTimer;
	TInt iMicroSeconds;
	CBasicAnimation* iBasicAnim; // Caller owns.
	TInt iX;
	TInt iY;
	};
	
#endif // __ANIMMOVER_H__
