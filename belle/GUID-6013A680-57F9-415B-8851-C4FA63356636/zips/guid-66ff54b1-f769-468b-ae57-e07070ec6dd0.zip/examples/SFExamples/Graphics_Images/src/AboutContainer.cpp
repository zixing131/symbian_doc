/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/
#include <eiklabel.h>
#include <eikenv.h>
#include <eikrted.h> 

	#include <aknutils.h> 


#include "AboutContainer.h"

#include "TextControl.h"

// static text used with the scrolling text control
_LIT(KTxLongText	,"This is could be very long text for copyright notices,it does not need to fit the screen since it is made scrolling with a timer.");

_LIT(KTxTitle		,"Images Example");
_LIT(KTxLine1		,"version 1.00");
_LIT(KTxLine2		,"Copyright 2007");
_LIT(KTxLine3		,"no rights reserved");

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAboutContainer* CAboutContainer::NewL( const TRect& aRect )
	{
	CAboutContainer* self = CAboutContainer::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAboutContainer* CAboutContainer::NewLC( const TRect& aRect )
	{
	CAboutContainer* self = new ( ELeave ) CAboutContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAboutContainer::~CAboutContainer()
	{
	delete iTextControl;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CAboutContainer::ConstructL( const TRect& aRect )
	{
	CreateWindowL();
	SetRect( aRect );
	
	//construct the scrolling text control
	iTextControl = CTextControl::NewL(KTxLongText);
  	
  	// text control is non-window owning, thus we need to set 
  	// this containers windor as a container window for it
  	iTextControl->SetContainerWindowL(*this);
  	
  	TRect smallerRect(iTextRect);
  	smallerRect.Shrink(4,4);
  	// and give the reduced area as a rect for the control
	iTextControl->SetRect(smallerRect);
	
	ActivateL();
	}

/*
-----------------------------------------------------------------------------
normal CCoeControl function used to tell system how many 
controls this container has 
-----------------------------------------------------------------------------
*/ 
TInt CAboutContainer::CountComponentControls() const
	{
	if(iTextControl)
		{   
		return 1;
		}
	else
		{
		return 0;
		}
	}

/*
-----------------------------------------------------------------------------
normal CCoeControl function used to give pointers 
to the controls inside this container 
-----------------------------------------------------------------------------
*/ 
CCoeControl* CAboutContainer::ComponentControl( TInt /*aIndex */) const
	{
	return iTextControl;
	}
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CAboutContainer::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
	
	TRect myRect(Rect());
	
	// clear the area with default brush (solid white)
	gc.Clear(myRect);
	
	// make rect smaller and draw borders with default pen(solid black)
	myRect.Shrink(2,2);
	gc.DrawRect(myRect);
	
	// make sure we don't draw on the area for the text control
	myRect.iBr.iY = iTextRect.iTl.iY;
	
	TInt totalHNeed = (CEikonEnv::Static()->TitleFont()->HeightInPixels() + (CEikonEnv::Static()->LegendFont()->HeightInPixels() * 3));
	
	TInt gapp = ((myRect.Height() - totalHNeed) / 7);
	
	// set rects initially with total rect, so we get X values ok.
	TRect titleRect(myRect);
	TRect lineRect1(myRect);
	TRect lineRect2(myRect);
	TRect lineRect3(myRect);
	
	// then calculate the Y values
	titleRect.iTl.iY = titleRect.iTl.iY + (2 * gapp);
	titleRect.iBr.iY = (titleRect.iTl.iY  + CEikonEnv::Static()->TitleFont()->HeightInPixels());
	
	// title has 2 gaps before and after
	lineRect1.iTl.iY = titleRect.iBr.iY + (2 * gapp);
	lineRect1.iBr.iY = (lineRect1.iTl.iY  + CEikonEnv::Static()->LegendFont()->HeightInPixels());

	// and rest of the lines have only one gap each
	lineRect2.iTl.iY = lineRect1.iBr.iY + gapp;
	lineRect2.iBr.iY = (lineRect2.iTl.iY  + CEikonEnv::Static()->LegendFont()->HeightInPixels());

	lineRect3.iTl.iY = lineRect2.iBr.iY + gapp;
	lineRect3.iBr.iY = (lineRect3.iTl.iY  + CEikonEnv::Static()->LegendFont()->HeightInPixels());

	// set font for the title
	gc.UseFont(CEikonEnv::Static()->TitleFont());

	gc.DrawText(KTxTitle,titleRect,CEikonEnv::Static()->TitleFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	
	// set font for the lines, this will Discard the title font
	gc.UseFont(CEikonEnv::Static()->LegendFont());
	
	gc.DrawText(KTxLine1,lineRect1,CEikonEnv::Static()->LegendFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	gc.DrawText(KTxLine2,lineRect2,CEikonEnv::Static()->LegendFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	gc.DrawText(KTxLine3,lineRect3,CEikonEnv::Static()->LegendFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	
	// and finally let the system know that we are done with the font
	gc.DiscardFont();
	}



/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CAboutContainer::HandleResourceChange(TInt aType)
	{
	TRect rect;

    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{    // get new main panel rect and set it
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}

/*
-----------------------------------------------------------------------------
system calls this function when the size for the container has been chnaged
-----------------------------------------------------------------------------
*/ 
void CAboutContainer::SizeChanged()
	{

	TInt fHight = AknLayoutUtils::FontFromId(EAknLogicalFontSecondaryFont)->HeightInPixels();


	// calculate the text controls hight to be twice the font hight
	TInt textHeight = (fHight * 2);

	// initialize control rects as container rect
	iTextRect = Rect();
	
	// then count the actual Y values (height, and vertical position)
	iTextRect.iTl.iY = (iTextRect.iBr.iY - textHeight);

	if(iTextControl)
		{	// if tect control was made earlier, set the new rect for it
		
		TRect smallerRect(iTextRect);
  		smallerRect.Shrink(4,4);
		iTextControl->SetRect(smallerRect);
		}
 	}
 

	
// End of File
