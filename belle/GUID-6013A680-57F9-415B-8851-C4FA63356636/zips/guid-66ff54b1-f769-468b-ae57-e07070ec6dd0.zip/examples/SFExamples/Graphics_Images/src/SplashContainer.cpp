/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/
#include <EIKENV.H>
#include <EIKAPPUI.H>
#include <e32std.h>
#include <APGICNFL.H>
#include <APGCLI.H>

#include "SplashContainer.h"
#include <AknUtils.h>


// interval used with timer to update the progress bar
const TInt KUpdateInterval = 100000; 
// max number of progress steps.
const TInt KUpdateMaxCount = 20;

_LIT(KTxTitle		,"Images Example");
_LIT(KTxLine1		,"version 1.00");

// CMySplashContainer
//
/* 
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/
CMySplashContainer* CMySplashContainer::NewL(MSplachScreenCallBack&	aCallBack)
    {
    CMySplashContainer* self = new(ELeave)CMySplashContainer(aCallBack);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/
CMySplashContainer::~CMySplashContainer()
	{
    if (iProgressTimer)
    	{
        iProgressTimer->Cancel(); // remember to cancel timer before deleting it
    	}
    	
    delete iProgressTimer;
	delete iBgContext;
	}  

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/
CMySplashContainer::CMySplashContainer(MSplachScreenCallBack&	aCallBack)
:iCallBack(aCallBack)
	{ 
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/

void CMySplashContainer::ConstructL(void)
    {
    CreateWindowL();


	// make first with no size at all, 
	// SetRect() will cause SizeChanged() to be called
	// and the real size & position is set in there
	
	// KAknsIIDQsnBgAreaMain tells system which skin we wish to use
	iBgContext = CAknsBasicBackgroundControlContext::NewL(KAknsIIDQsnBgAreaMain,TRect(0,0,1,1), ETrue);
	// Setting rect will cause SizeChanged to be called
	// and iBgContext size & position is updated accordingly.
	SetRect(CEikonEnv::Static()->EikAppUi()->ClientRect());
	
	ActivateL();	
	DrawNow();

	// reset progress counter
	iProgressCount = 0;
	// and start periodi timer for showing the progress
	iProgressTimer = CPeriodic::NewL(CActive::EPriorityStandard);
	iProgressTimer->Start(KUpdateInterval, KUpdateInterval, TCallBack(DoProgressL, this));
	}

/*
-----------------------------------------------------------------------------
system calls this function when the size for the container has been chnaged
-----------------------------------------------------------------------------
*/
void CMySplashContainer::SizeChanged()
	{
	if ( iBgContext )
		{
		// set the rect as TRect(0,0,Width,Height)
		iBgContext->SetRect(Rect());

		if ( &Window() )
			{	// set the position in the full screen
			// so system knows which area of the selected skin is used with this container
			iBgContext->SetParentPos( PositionRelativeToScreen() );
			}
		}

	}


/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CMySplashContainer::HandleResourceChange(TInt aType)
	{
    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{  	
    	// get new main panel rect and set it
    	TRect rect;
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}

/*
-----------------------------------------------------------------------------
Skins require containers to provide this function
-----------------------------------------------------------------------------
*/
TTypeUid::Ptr CMySplashContainer::MopSupplyObject(TTypeUid aId)
	{	
	if (iBgContext)
		{	
		return MAknsControlContext::SupplyMopObject(aId, iBgContext );
		}
	
	return CCoeControl::MopSupplyObject(aId);
	}

 

/*
-------------------------------------------------------------------------------
progress timer callback function
-------------------------------------------------------------------------------
*/	
TInt CMySplashContainer::DoProgressL(TAny* aPtr)
	{
	CMySplashContainer* self = static_cast<CMySplashContainer*>(aPtr);

	// increase the value & draw it to the screen
	self->iProgressCount++;
	self->DrawNow();
	
    if (self->iProgressCount > KUpdateMaxCount)
    	{	// if we got to the max value, we tell the owner that we are done
        self->iCallBack.SplashTimeIsUpL();
    	}
    
	return KErrNone;
	}
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/
void CMySplashContainer::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	
   
  	// draw background skin first.
  	MAknsSkinInstance* skin = AknsUtils::SkinInstance();
	AknsDrawUtils::Background( skin, iBgContext, this, gc, Rect() );


	TRect myRect(Rect());

	TInt totalHNeed = (CEikonEnv::Static()->LegendFont()->HeightInPixels() + (CEikonEnv::Static()->TitleFont()->HeightInPixels() * 2));
	
	TInt gapp = ((myRect.Height() - totalHNeed) / 7);
	
	// set rects initially with total rect, so we get X values ok.
	TRect titleRect(myRect);
	TRect lineRect1(myRect);
	
	// then calculate the Y values
	titleRect.iTl.iY = titleRect.iTl.iY + (2 * gapp);
	titleRect.iBr.iY = (titleRect.iTl.iY  + CEikonEnv::Static()->TitleFont()->HeightInPixels());
	
	// title has 2 gaps before and after
	lineRect1.iTl.iY = titleRect.iBr.iY + (2 * gapp);
	lineRect1.iBr.iY = (lineRect1.iTl.iY  + CEikonEnv::Static()->LegendFont()->HeightInPixels());

	// set font for the title
	gc.UseFont(CEikonEnv::Static()->TitleFont());

	gc.DrawText(KTxTitle,titleRect,CEikonEnv::Static()->TitleFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	
	// set font for the lines, this will Discard the title font
	gc.UseFont(CEikonEnv::Static()->LegendFont());
	
	gc.DrawText(KTxLine1,lineRect1,CEikonEnv::Static()->LegendFont()->AscentInPixels(), CGraphicsContext::ECenter, 0);
	
	// and finally let the system know that we are done with the font
	gc.DiscardFont();

	// calculate position for the progress bar
	TInt wGap = (Rect().Width() / 5);
	
	TRect progressRect((Rect().iTl.iX + wGap),0,(Rect().iBr.iX - wGap),0);
	
	progressRect.iTl.iY = (lineRect1.iBr.iY + (2 * gapp));
	progressRect.iBr.iY = (progressRect.iTl.iY + CEikonEnv::Static()->TitleFont()->HeightInPixels());
	
	// draw the progress background
	gc.SetPenColor(KRgbBlack);
	// Brish to Null, thus progress bar rect is transparent
	gc.SetBrushStyle(CGraphicsContext::ENullBrush);
	// draw the bounding rect for the progress bar
	gc.DrawRect(progressRect);
	
	// calculate the progress bar size
	TInt progressSize = ((progressRect.Width() * iProgressCount) / KUpdateMaxCount);
	progressRect.iBr.iX = (progressRect.iTl.iX + progressSize);
	
	// draw the progress
	gc.SetBrushColor(KRgbGreen);
	// brush set to solid to get the background of the progress bar visible
	gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
	gc.DrawRect(progressRect);
	
	// set brush to NULL so it wont efect any other drawing later on
	gc.SetBrushStyle(CGraphicsContext::ENullBrush);
	}

