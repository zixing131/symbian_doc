/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include "Image_Reader.h"





/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImage_Reader* CImage_Reader::NewL(MImageReaderCallBack& aCallBack,const TDesC& aFileName)
	{
	CImage_Reader* self = CImage_Reader::NewLC(aCallBack,aFileName);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImage_Reader* CImage_Reader::NewLC(MImageReaderCallBack& aCallBack,const TDesC& aFileName)
	{
	CImage_Reader* self = new ( ELeave ) CImage_Reader(aCallBack);
	CleanupStack::PushL( self );
	self->ConstructL(aFileName);
	return self;
	}
	
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImage_Reader::CImage_Reader(MImageReaderCallBack& aCallBack)
:CActive(EPriorityNormal),iCallBack(aCallBack)
    {
    }
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImage_Reader::~CImage_Reader()
{
	Cancel();
	delete iImageDecoder;
	delete iFrameImg;
	iFsSession.Close();
}

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CImage_Reader::ConstructL(const TDesC& aFileName)
	{
	CActiveScheduler::Add(this);
	
	User::LeaveIfError(iFsSession.Connect());
	
	TBuf8<255> imageType;
	
//	TInt errVal = GetFileType(aFileName,imageType);// check the file's MIME type
	
	TInt errVal(KErrNone);
	TRAP(errVal,CImageDecoder::GetMimeTypeFileL(iFsSession,aFileName,imageType));
	
	if(errVal == KErrNone)
		{
		// image decoder user for reading the image file to a bitmap
		iImageDecoder = CImageDecoder::FileNewL(iFsSession,aFileName,imageType);
		if(iImageDecoder->FrameCount() > 0)// check that we have image(s) in the file
			{
			iFrameImg = new(ELeave)CFbsBitmap();
			iFrameImg->Create(iImageDecoder->FrameInfo(0).iOverallSizeInPixels,iImageDecoder->FrameInfo(0).iFrameDisplayMode);
				
			iImageDecoder->Convert(&iStatus,*iFrameImg,0);
			SetActive();
			}
		else
			{	// indicate that we didn't find any images inside the file
			TRequestStatus* status=&iStatus;
			User::RequestComplete(status, KErrNotFound);
			SetActive();
			}
		}
	else // indicate that we had an error
		{
		TRequestStatus* status=&iStatus;
		User::RequestComplete(status, errVal);
		SetActive();
		}
	}

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/
TInt CImage_Reader::GetFileType(const TDesC& aFileName, TDes8& aFileType)
	{
	TInt ret(KErrNone);
	TEntry fileEntry;

	// Get entry, fails if the file can not be found or accessed.
	ret = iFsSession.Entry(aFileName,fileEntry);
	
	if(ret == KErrNone)
		{
		TBuf8<255> fileBuffer;
		
		if(!fileEntry.IsDir())
			{
			TInt fileSize = fileEntry.iSize;

			if(fileSize > 255)
				{// if file is bigger than 255, we only use first 255 bytes for recognizer
				fileSize = 255;
				}
			
			// Read data from the file for recognizing it.
			ret = iFsSession.ReadFileSection(aFileName,0,fileBuffer,fileSize);
			if(ret == KErrNone)
				{
				RApaLsSession rSession;
				ret = rSession.Connect();// open session 
				if(ret == KErrNone)
					{	
					TDataRecognitionResult fileDataType;
					// Use session to recognize the file's MIME type
					ret = rSession.RecognizeData(aFileName,fileBuffer,*&fileDataType);
					
					aFileType.Copy(fileDataType.iDataType.Des8());
					
					rSession.Close();// close session
					}
				}
			}	
		}
	
	return ret;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CImage_Reader::DoCancel()
	{
	if(iImageDecoder)
		{	// Called when somebody calls Cancel(), so we need to cancel any conversion
		iImageDecoder->Cancel();
		}
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
	
void CImage_Reader::RunL()
	{
	// conversion has finished, all we need to do is to infrm the owner..
	iCallBack.ImageReadDoneL(iStatus.Int());
	}

