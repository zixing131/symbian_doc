/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

// INCLUDES

#include "ControlsContainer.h"
#include "ImageContainer.h"
#include "AnimationContainer.h"
#include "BitmapContainer.h"
#include "AboutContainer.h"

#include "GraphicsMainView.h"
#include "GraphicsExternalInterface.h"
#include <GraphicsImages.rsg>
#include "Graphics.hrh"



// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CGraphicsMainView* CGraphicsMainView::NewLC(CGraphicsAppUi& aAppUi)
	{
	CGraphicsMainView* self = new (ELeave) CGraphicsMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CGraphicsMainView* CGraphicsMainView::NewL(CGraphicsAppUi& aAppUi)
	{
  	CGraphicsMainView* self = CGraphicsMainView::NewLC(aAppUi);
  	CleanupStack::Pop();
  	return self;
	}
// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CGraphicsMainView::CGraphicsMainView(CGraphicsAppUi& aAppUi)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CGraphicsMainView::~CGraphicsMainView()
	{
	delete iAppContainer;
	delete iMySplashContainer;
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CGraphicsMainView::ConstructL()
	{
	CreateWindowL();	
	
    TRect rect;
    AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
    SetRect(rect);
    
	ActivateL();
	
	iMySplashContainer = CMySplashContainer::NewL(*this);

	DrawNow();
	}


/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CGraphicsMainView::HandleResourceChange(TInt aType)
	{
    if ( aType==KEikDynamicLayoutVariantSwitch )
    	{    	
    	TRect rect;
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    
    	if(iAppContainer)
    		{
    		iAppContainer->SetRect(rect);
    		}
    	}

	CCoeControl::HandleResourceChange(aType);
	}


/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CGraphicsMainView::SplashTimeIsUpL(void)
{
	ChangeViewL(EImagesexampleBitmap);
	
	// delete splash container
	delete iMySplashContainer;
	iMySplashContainer = NULL;
}
// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CGraphicsMainView::ChangeViewL(TInt aView )
	{
	TRect clientR(CEikonEnv::Static()->EikAppUi()->ClientRect());

	CCoeControl* newContainer(NULL);
	TInt err(KErrNone);

	// New containers are made first
	// and any leave is catched with the TRAP
	
	switch ( aView )
		{
		case EImagesexampleImage:	
			{
			TFindFile imageFile(CCoeEnv::Static()->FsSession());
			if(KErrNone == imageFile.FindByDir(KTxImage1, KNullDesC))
				{	//requires image
				//thus if it is not found the container is not constructed
				newContainer = CImageContainer::NewL(clientR,imageFile.File());
				}
			}
			break;
		case EImagesexampleAnimation:
			{
			TFindFile aniFile(CCoeEnv::Static()->FsSession());
			if(KErrNone == aniFile.FindByDir(KTxAnimation1, KNullDesC))
				{	//requires animation gif file
				//thus if it is not found the container is not constructed
				newContainer = CAnimationContainer::NewL(clientR,aniFile.File());
				}
			}
			break;
		case EImagesexampleControls:
			newContainer = CControlsContainer::NewL(clientR);
			break;
		case EImagesexampleBitmap:
			newContainer = CBitmapContainer::NewL(clientR);
			break;
		case EImagesexampleAbout:
			newContainer = CAboutContainer::NewL(clientR);
			break;
		}

	// If TRAP catched a leave we abort the change
	if(err != KErrNone)
		{
		delete newContainer;
		newContainer = NULL;
		}

	if(newContainer)// if all was well we proceed
		{
		// delete old and set new one 
		delete iAppContainer;
		iAppContainer = newContainer;
		}		
		
	DrawNow();
	}


/*
-----------------------------------------------------------------------------
normal CCoeControl functions, see SDK documentation
-----------------------------------------------------------------------------
*/ 
void CGraphicsMainView::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}


/*
-----------------------------------------------------------------------------
normal key handling function for CCoeControl, gets all key events
when this container is on focus (and it has been added to the control stack)
-----------------------------------------------------------------------------
*/
TKeyResponse CGraphicsMainView::OfferKeyEventL(const TKeyEvent &aKeyEvent, TEventCode aType)
	{
	TKeyResponse  myRet = EKeyWasNotConsumed;
	
	if(iAppContainer)
    	{
    	iAppContainer->OfferKeyEventL(aKeyEvent,aType);
    	}

	return myRet;
	}
/*
-----------------------------------------------------------------------------
normal CCoeControl functions, see SDK documentation
-----------------------------------------------------------------------------
*/ 
TInt CGraphicsMainView::CountComponentControls() const
	{
	if(iAppContainer)
		{
		return 1;
		}
	else
		{
		return 0;
		}
	}
/*
-----------------------------------------------------------------------------
normal CCoeControl functions, see SDK documentation
-----------------------------------------------------------------------------
*/ 
CCoeControl* CGraphicsMainView::ComponentControl( TInt /*aIndex */) const
	{
	return iAppContainer;
	}
	
// End of File
