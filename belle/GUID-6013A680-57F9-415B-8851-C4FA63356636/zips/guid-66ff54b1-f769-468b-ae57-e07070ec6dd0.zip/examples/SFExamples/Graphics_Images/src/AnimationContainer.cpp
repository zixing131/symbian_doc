/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 
#include <eiklabel.h>
#include <eikenv.h>

#include "AnimationContainer.h"

#include <aknutils.h> 


const TInt KFrameReadInterval = 200000;

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAnimationContainer* CAnimationContainer::NewL( const TRect& aRect, const TDesC& aFileName)
	{
	CAnimationContainer* self = CAnimationContainer::NewLC( aRect,aFileName);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAnimationContainer* CAnimationContainer::NewLC( const TRect& aRect, const TDesC& aFileName)
	{
	CAnimationContainer* self = new ( ELeave ) CAnimationContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect,aFileName);
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAnimationContainer::~CAnimationContainer()
	{
    if (iFrameReadTimer)
    	{
        iFrameReadTimer->Cancel();
    	}
    	
    delete iFrameReadTimer;
    
	delete iAniFrame_Reader;
	delete iBitmap;	
	delete iBitmapDevice;
	delete iGraphicsContext;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CAnimationContainer::ConstructL( const TRect& aRect, const TDesC& aFileName)
	{
	CreateWindowL();
	
	SetRect( aRect );
	
	// construct the animation frame reader
	iAniFrame_Reader = CAniFrame_Reader::NewL(*this,aFileName);
	
	// get the actual size of the animation frame
	TSize imgSiz = iAniFrame_Reader->AniFrameSizeL();
	
	// if we got the size, then there are frames, and we can start
	if(imgSiz.iWidth > 0
	&& imgSiz.iHeight> 0)
		{
		// construct the bitmap for drawing the animation frames
		// use the actual size of the animation frames
		iBitmap = new(ELeave)CFbsBitmap();
		iBitmap->Create(imgSiz,EColor16M);
	
		// constrct the graphics device & context for drawing
		iBitmapDevice = CFbsBitmapDevice::NewL(iBitmap);
		User::LeaveIfError(iBitmapDevice->CreateContext(iGraphicsContext));
		
		// read the first animation frame
		iAniFrame_Reader->NextImageL();
		}
	
	ActivateL();
	}
/*
-------------------------------------------------------------------------------
iFrameReadTimer calls this function periodically to tell us to show the next frame
-------------------------------------------------------------------------------
*/	
TInt CAnimationContainer::DoReadNextFrameL(TAny* aPtr)
	{
	CAnimationContainer* self = static_cast<CAnimationContainer*>(aPtr);

	if(self->iAniFrame_Reader)// check that the reader has been constructed
		{	// and read the next frame
		self->iAniFrame_Reader->NextImageL();
		}
    
	return KErrNone;
	}
/*
-----------------------------------------------------------------------------
iAniFrame_Reader, uses this function to give use the frame we asked it to read
so we can draw it to teh bitmap for showing into the screen
-----------------------------------------------------------------------------
*/ 	
void CAnimationContainer::AppendFrameL(CFbsBitmap& aImage,CFbsBitmap& aMask,TRect aArea, TBool aReDraw)
	{
	if(iGraphicsContext)// make sure we have the context constructed
		{
		// check the size of the image for drawing
		TSize imgSiz(aImage.SizeInPixels());
		
		if(aReDraw)
			{// if its complete re-draw, we do not need to use the mask
			iGraphicsContext->DrawBitmap(TRect(0,0,imgSiz.iWidth,imgSiz.iHeight),&aImage);
			}
		else
			{	// othervise we need to check the position 
				// and use the mask to draw the frame on top of the old bitmap image
			iGraphicsContext->DrawBitmapMasked(aArea,&aImage,TRect(0,0,imgSiz.iWidth,imgSiz.iHeight),&aMask,EFalse);
			}
	}
	
	if(!iFrameReadTimer)
		{	// if it is first time we did this, we'll start the periodic timer
		iFrameReadTimer = CPeriodic::NewL(CActive::EPriorityHigh);
		iFrameReadTimer->Start(KFrameReadInterval, KFrameReadInterval, TCallBack(DoReadNextFrameL, this));
		}
	
	DrawNow();
	}
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CAnimationContainer::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
    
    if(iBitmap)// Check that we have the bitmap constructed
		{
		if(iBitmap->Handle())// and it has valid bitmap
			{
			// just draw it to fill the whole container screen
			// so not caring about the scaling issues in here.
			gc.DrawBitmap(Rect(),iBitmap);	
			}
		}

	}

/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CAnimationContainer::HandleResourceChange(TInt aType)
	{
    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{    // get new main panel rect and set it
        TRect rect;
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}


	
// End of File
