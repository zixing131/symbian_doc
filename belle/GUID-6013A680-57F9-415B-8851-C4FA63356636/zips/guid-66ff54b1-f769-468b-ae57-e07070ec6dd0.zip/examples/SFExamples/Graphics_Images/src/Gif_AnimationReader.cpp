/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include "Gif_AnimationReader.h"


_LIT8(KtxTypeImageGif_8			,"image/gif");

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAniFrame_Reader* CAniFrame_Reader::NewL(MAniReaderCallBack& aCallBack,const TDesC& aFileName)
	{
	CAniFrame_Reader* self = CAniFrame_Reader::NewLC(aCallBack,aFileName);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAniFrame_Reader* CAniFrame_Reader::NewLC(MAniReaderCallBack& aCallBack,const TDesC& aFileName)
	{
	CAniFrame_Reader* self = new ( ELeave ) CAniFrame_Reader(aCallBack);
	CleanupStack::PushL( self );
	self->ConstructL(aFileName);
	return self;
	}
	
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAniFrame_Reader::CAniFrame_Reader(MAniReaderCallBack& aCallBack)
:CActive(EPriorityNormal),iCallBack(aCallBack),iCurrImg(-1),iCurrCount(-1)
    {
    }
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CAniFrame_Reader::~CAniFrame_Reader()
	{
	Cancel();
	delete iImageDecoder;
	delete iFrameImg;
	delete iFrameMsk;
	}

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CAniFrame_Reader::ConstructL(const TDesC& aFileName)
	{
	CActiveScheduler::Add(this);// Active objects need to be added to the AO scheduler
	
	// construct the image decoder, that converts frames to bitmap & mask pairs
	iImageDecoder = CImageDecoder::FileNewL(CCoeEnv::Static()->FsSession(),aFileName,KtxTypeImageGif_8);
	// get total count of the frames
	iCurrCount = iImageDecoder->FrameCount();	
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
TSize CAniFrame_Reader::AniFrameSizeL(void)
	{
	TSize ret(0,0);
	
	if(iCurrCount > 0 && iImageDecoder)
		{	// first frame should be the real animation size...
		ret = iImageDecoder->FrameInfo(0).iOverallSizeInPixels;
		}
	
	return ret;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CAniFrame_Reader::NextImageL(void)
	{	
	if(iCurrCount > 0 && !IsActive())
		{
		iCurrImg++;// add 1 to the index, so we can read the next frame
		if(iCurrImg >= iCurrCount || iCurrImg < 0)
			{// incase the index is non-valid, we set it to zero
			 // should only happen after reading the last frame
			iCurrImg = 0;
			}
		
		// delete and costruct new frame bitmap to the right size for next frame
		delete iFrameImg;
		iFrameImg = NULL;
		iFrameImg = new(ELeave)CFbsBitmap();
		iFrameImg->Create(iImageDecoder->FrameInfo(iCurrImg).iOverallSizeInPixels,iImageDecoder->FrameInfo(iCurrImg).iFrameDisplayMode);
			
		// delete and costruct new mask bitmap to the right size for next frame mask
		delete iFrameMsk;
		iFrameMsk = NULL;
		iFrameMsk = new(ELeave)CFbsBitmap();
		iFrameMsk->Create(iImageDecoder->FrameInfo(iCurrImg).iOverallSizeInPixels,EGray2);

		// start reading the frame to the bitmaps
		iImageDecoder->Convert(&iStatus,*iFrameImg,*iFrameMsk,iCurrImg);
		SetActive();	
		}
	}


/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
void CAniFrame_Reader::DoCancel()
	{
	if(iImageDecoder)
		{   //only AC, thus we need to cancel it here..
		iImageDecoder->Cancel();
		}
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
	
void CAniFrame_Reader::RunL()
	{
	if(iFrameMsk && iFrameImg)// if both images were constructed
		{
		if(iFrameMsk->Handle() && iFrameImg->Handle())// and they have valid image in them
			{
			TBool reDraw(EFalse);
			// initialize the draw areas to be the whole image 
			TRect  drawArea(TPoint(0,0),iFrameImg->SizeInPixels());
			
			if(TFrameInfo::ERestoreToBackground & iImageDecoder->FrameInfo(iCurrImg).iFlags)
				{
				reDraw = ETrue;
				// Draw whole image again, thus we are not checking the coordinates
				// usually happens at least for the first frame
				}
			else
				{
				// frame does not draw the whole image area, but some other rectange area in it
				// thus we need to check it from the frame info.
				drawArea = iImageDecoder->FrameInfo(iCurrImg).iFrameCoordsInPixels;
				}
			
			// tell the owner to draw the frame into its own bitmap..
			iCallBack.AppendFrameL(*iFrameImg,*iFrameMsk,drawArea,reDraw);
			}
		}
	}

