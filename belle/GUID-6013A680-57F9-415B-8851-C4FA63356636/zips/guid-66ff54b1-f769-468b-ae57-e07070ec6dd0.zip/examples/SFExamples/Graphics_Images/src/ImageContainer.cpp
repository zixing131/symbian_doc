/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 
#include <eiklabel.h>
#include <eikenv.h>

#include "ImageContainer.h"
#include <aknutils.h> 

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImageContainer* CImageContainer::NewL( const TRect& aRect,const TDesC& aFileName)
	{
	CImageContainer* self = CImageContainer::NewLC( aRect,aFileName);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImageContainer* CImageContainer::NewLC( const TRect& aRect,const TDesC& aFileName)
	{
	CImageContainer* self = new ( ELeave ) CImageContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect,aFileName);
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CImageContainer::~CImageContainer()
	{
	delete iImage_Reader;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CImageContainer::ConstructL( const TRect& aRect,const TDesC& aFileName)
	{
	CreateWindowL();
	SetRect( aRect );
	ActivateL();
	DrawNow();
	
	// start image reader..
	iImage_Reader = CImage_Reader::NewL(*this,aFileName);
	}

/*
-----------------------------------------------------------------------------
MImageReaderCallBack callback function which CImage_Reader uses to tell
this container that the image is processed.
aError would tell if it succeeded or failed.
-----------------------------------------------------------------------------
*/ 	
void CImageContainer::ImageReadDoneL(TInt /*aError*/)
	{	// simply try drawing it
	DrawNow();
	}
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CImageContainer::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
    
    // clear the screen with default brush (solid white)
    gc.Clear(Rect());
    
    if(iImage_Reader)// check that we have image reader constructed
    	{
	    if(iImage_Reader->Bitmap())// check that it has constructed the bitmap
			{
			// and that the bitmap has valid data for drawing
			if(iImage_Reader->Bitmap()->Handle())
				{
				// just draw the image to the whole screen
				// without caring about the scaling issues
				gc.DrawBitmap(Rect(),iImage_Reader->Bitmap());	
				}
			}
    	}
	}


/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CImageContainer::HandleResourceChange(TInt aType)
	{
	TRect rect;

    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{    // get new main panel rect and set it
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}


	
// End of File
