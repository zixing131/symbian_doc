/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 
#include <eiklabel.h>
#include <eikenv.h>

#include "BitmapContainer.h"


#include <aknutils.h> 

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CBitmapContainer* CBitmapContainer::NewL( const TRect& aRect)
	{
	CBitmapContainer* self = CBitmapContainer::NewLC( aRect);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CBitmapContainer* CBitmapContainer::NewLC( const TRect& aRect)
	{
	CBitmapContainer* self = new ( ELeave ) CBitmapContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect);
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CBitmapContainer::~CBitmapContainer()
	{
	delete iBitmap;
	delete iBall;
	delete iMask;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CBitmapContainer::ConstructL( const TRect& aRect)
	{
	CreateWindowL();
	
	// find the image file to show
	TFindFile bitmapFile(CCoeEnv::Static()->FsSession());
	if(KErrNone == bitmapFile.FindByDir(KTxBitmapFile, KNullDesC))
		{	
		// construct the bitmap
		// which after we have valid bitmap instance
		// i.e. the pointer is valid
		iBitmap = new(ELeave)CFbsBitmap();
		
		// then load the actual image data to the bitmap
		TInt err = iBitmap->Load(bitmapFile.File(),0);
		// if Err == KErrNone, then it is ok
		// othervise it is most likely invalidand Handle will show it
		// we could also use User::LeaveIfError()
		// then instead of getting blank screen without image
		// we would have a leave during costruction
		// which would cause application to crash
		
		iBall = new(ELeave)CFbsBitmap();
		iBall->Load(bitmapFile.File(),1);
		
		iMask = new(ELeave)CFbsBitmap();
		iMask->Load(bitmapFile.File(),2);
		}
	
	SetRect( aRect );
	ActivateL();
	DrawNow();
	}

/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CBitmapContainer::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
    
    TBool hasImage(EFalse);
    
    if(iBitmap)// check that we have  constructed the bitmap
		{
		// and that the bitmap has valid data for drawing
		if(iBitmap->Handle())
			{
			// just draw the image to the whole screen
			// without caring about the scaling issues
			gc.DrawBitmap(Rect(),iBitmap);
			hasImage = ETrue;	
			}
		}
	
	// if we didn't get the image drawn, then we clear the screen
	if(!hasImage)
		{
		// clear the screen with default brush (solid white)
    	gc.Clear(Rect());
		}
	
	if(iBall && iMask)// check that we have  constructed the bitmap
		{
		// and that the bitmap has valid data for drawing
		if(iBall->Handle() && iMask->Handle())
			{
			TSize imageSize(iBall->SizeInPixels());
			
			TInt xGap = ((Rect().Width() - imageSize.iWidth) / 2);
			TInt yGap = ((Rect().Height()- imageSize.iHeight)/ 2);
			
			TRect destRect(xGap,yGap,(xGap + imageSize.iWidth),(yGap + imageSize.iHeight));
			
			gc.DrawBitmapMasked(destRect,iBall,TRect(0,0,imageSize.iWidth,imageSize.iHeight),iMask,ETrue);	
			}
		}
	}

/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CBitmapContainer::HandleResourceChange(TInt aType)
	{
	TRect rect;

    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{    // get new main panel rect and set it
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}


	
// End of File
