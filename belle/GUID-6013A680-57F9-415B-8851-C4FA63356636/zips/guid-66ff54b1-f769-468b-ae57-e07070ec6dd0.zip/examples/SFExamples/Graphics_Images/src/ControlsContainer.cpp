/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/
#include <eiklabel.h>
#include <eikenv.h>

#include <aknutils.h> 


#include "ControlsContainer.h"

#include "Image_Control.h"
#include "Animation_Control.h"

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CControlsContainer* CControlsContainer::NewL( const TRect& aRect )
	{
	CControlsContainer* self = CControlsContainer::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CControlsContainer* CControlsContainer::NewLC( const TRect& aRect )
	{
	CControlsContainer* self = new ( ELeave ) CControlsContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CControlsContainer::~CControlsContainer()
	{
	delete iImageControl;
	delete iAnimationControl;
	delete iBitmap;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CControlsContainer::ConstructL( const TRect& aRect )
	{
	CreateWindowL(); // create window for this container
	SetRect( aRect );// will set the size and system will call SizeChanged()-function
	
	ActivateL(); // activete this container

	// set the rects used for drawing the border frames as a base
	// they are calculated in the SizeChanged()-function
    TRect tmpAnimationRect(iAnimationRect);
    TRect tmpImageRect(iImageRect);

	// then shrink them a bit to get better visibility for the border frames
	tmpAnimationRect.Shrink(2,2);
	tmpImageRect.Shrink(2,2);	
		
	TFindFile imageFile3(CCoeEnv::Static()->FsSession());
	if(KErrNone == imageFile3.FindByDir(KTxImage3, KNullDesC))
		{	// and construct second image control
		iImageControl = CImageControl::NewL(*this,tmpImageRect,imageFile3.File());
		}
	
	TFindFile bitFile(CCoeEnv::Static()->FsSession());
	if(KErrNone == bitFile.FindByDir(KTxBitmap2, KNullDesC))
		{	
		// construct the bitmap
		// which after we have valid bitmap instance
		// i.e. the pointer is valid
		iBitmap = new(ELeave)CFbsBitmap();
		
		// then load the actual image data to the bitmap
		TInt err = iBitmap->Load(bitFile.File(),0);
		// if Err == KErrNone, then it is ok
		// othervise it is most likely invalidand Handle will show it
		// we could also use User::LeaveIfError()
		// then instead of getting blank screen without image
		// we would have a leave during costruction
		// which would cause application to crash
		}

	TFindFile aniFile3(CCoeEnv::Static()->FsSession());
	if(KErrNone == aniFile3.FindByDir(KTxAnimation3, KNullDesC))
		{	// and construct first animation control
		iAnimationControl = CAnimationControl::NewL(*this,tmpAnimationRect,aniFile3.File());
		}
	
	DrawNow();
	}

/*
-----------------------------------------------------------------------------
normal CCoeControl function used to tell system how many 
controls this container has 
-----------------------------------------------------------------------------
*/ 
TInt CControlsContainer::CountComponentControls() const
	{
	if(iImageControl
	&&  iAnimationControl )
		{ // if we have both controls we tell that to the system
		return 2;
		}
	else
		{
		return 0;
		}
	}

/*
-----------------------------------------------------------------------------
normal CCoeControl function used to give pointers 
to the controls inside this container 
-----------------------------------------------------------------------------
*/ 
CCoeControl* CControlsContainer::ComponentControl( TInt aIndex ) const
	{
	switch (aIndex)
		{
		case 0:
			return iImageControl;			
		
		case 1:
			return iAnimationControl;			
		
		default:
			return NULL;
		}
	}
/*
-----------------------------------------------------------------------------
normal key handling function for CCoeControl, gets all key events
when this container is on focus (and it has been added to the control stack)
-----------------------------------------------------------------------------
*/

TKeyResponse CControlsContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
	{
	TKeyResponse  myRet = EKeyWasNotConsumed;

	switch (aKeyEvent.iCode)
	    {
	    case EKeyDevice3: 
			{// ok button pressed, we could do something with the selected item
	/*			switch(iSelected)
					{
					case 0: // First image
						break;
					case 1: // first animation
						break;
					case 2: // second animation
						break;
					case 3: // second image
						break;
					};*/
			}
			break;
		// arrows are used for changing the selection
		// DrawNow(); is called so all changes are also drawn into the screen
		// calling DrawNow(); will make system to call Draw() function later.
	
		case EKeyLeftArrow:

			if(iSelected == 1)
				{
				iSelected = 0;
				}
			else if(iSelected == 3)
				{
				iSelected = 2; 
				}
			DrawNow();
			break;
	
		case EKeyRightArrow:
	
			if(iSelected == 0)
				{
				iSelected = 1;
				}
			else if(iSelected == 2)
				{
				iSelected = 3; 
				}
			DrawNow();
			break;
	
		case EKeyUpArrow:
	
			if(iSelected == 2)
				{
				iSelected = 0;
				}
			else if(iSelected == 3)
				{
				iSelected = 1; 
				}
			DrawNow();
			break;

	
		case EKeyDownArrow:
	
			if(iSelected == 0)
				{
				iSelected = 2;
				}
			else if(iSelected == 1)
				{
				iSelected = 3; 
				}
			DrawNow();
			break;
		default:
			break;
		}        

	return myRet;
}	
	
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CControlsContainer::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
	// clear the area with default brush (solid white)
	gc.Clear();

	// draw first image control border as lines with default pen (black & solid)
	gc.DrawLine(iBitmapRect2.iTl,TPoint(iBitmapRect2.iTl.iX,iBitmapRect2.iBr.iY));
	gc.DrawLine(iBitmapRect2.iTl,TPoint(iBitmapRect2.iBr.iX,iBitmapRect2.iTl.iY));
	gc.DrawLine(TPoint(iBitmapRect2.iTl.iX,iBitmapRect2.iBr.iY),iBitmapRect2.iBr);
	gc.DrawLine(TPoint(iBitmapRect2.iBr.iX,iBitmapRect2.iTl.iY),iBitmapRect2.iBr);

	// draw second image  control border as lines with default pen (black & solid)
	gc.DrawLine(iAnimationRect.iTl,TPoint(iAnimationRect.iTl.iX,iAnimationRect.iBr.iY));
	gc.DrawLine(iAnimationRect.iTl,TPoint(iAnimationRect.iBr.iX,iAnimationRect.iTl.iY));
	gc.DrawLine(TPoint(iAnimationRect.iTl.iX,iAnimationRect.iBr.iY),iAnimationRect.iBr);
	gc.DrawLine(TPoint(iAnimationRect.iBr.iX,iAnimationRect.iTl.iY),iAnimationRect.iBr);

	// draw first animation  control border as lines with default pen (black & solid)
	gc.DrawLine(iImageRect.iTl,TPoint(iImageRect.iTl.iX,iImageRect.iBr.iY));
	gc.DrawLine(iImageRect.iTl,TPoint(iImageRect.iBr.iX,iImageRect.iTl.iY));
	gc.DrawLine(TPoint(iImageRect.iTl.iX,iImageRect.iBr.iY),iImageRect.iBr);
	gc.DrawLine(TPoint(iImageRect.iBr.iX,iImageRect.iTl.iY),iImageRect.iBr);

	// draw second animation control border as lines with default pen (black & solid)
	gc.DrawLine(iBitmapRect.iTl,TPoint(iBitmapRect.iTl.iX,iBitmapRect.iBr.iY));
	gc.DrawLine(iBitmapRect.iTl,TPoint(iBitmapRect.iBr.iX,iBitmapRect.iTl.iY));
	gc.DrawLine(TPoint(iBitmapRect.iTl.iX,iBitmapRect.iBr.iY),iBitmapRect.iBr);
	gc.DrawLine(TPoint(iBitmapRect.iBr.iX,iBitmapRect.iTl.iY),iBitmapRect.iBr);
	
	// get the rect for the selected control for border drawing.
	TRect selRect(iBitmapRect2);
	switch(iSelected)
		{
		case 0: // First image
			selRect = iBitmapRect2;
			break;
		case 1: // first animation
			selRect = iAnimationRect;
			break;
		case 2: // second animation
			selRect = iBitmapRect;
			break;
		case 3: // second image	
			selRect = iImageRect;
			break;
		}	
	
	// set pen color for the drawing the border for selected control
	gc.SetPenColor(KRgbGreen);

	// draw first line of the border 
	gc.DrawLine(selRect.iTl,TPoint(selRect.iTl.iX,selRect.iBr.iY));
	gc.DrawLine(selRect.iTl,TPoint(selRect.iBr.iX,selRect.iTl.iY));
	gc.DrawLine(TPoint(selRect.iTl.iX,selRect.iBr.iY),selRect.iBr);
	gc.DrawLine(TPoint(selRect.iBr.iX,selRect.iTl.iY),selRect.iBr);
	
	// grow the rect for selected items border 
	selRect.Grow(1,1);
	// and draw the second line of the border 
	gc.DrawLine(selRect.iTl,TPoint(selRect.iTl.iX,selRect.iBr.iY));
	gc.DrawLine(selRect.iTl,TPoint(selRect.iBr.iX,selRect.iTl.iY));
	gc.DrawLine(TPoint(selRect.iTl.iX,selRect.iBr.iY),selRect.iBr);
	gc.DrawLine(TPoint(selRect.iBr.iX,selRect.iTl.iY),selRect.iBr);	

	TRect tmpBitmapRect(iBitmapRect);
	tmpBitmapRect.Shrink(2,2);
	
	TRect tmpBitmapRect2(iBitmapRect2);
	tmpBitmapRect2.Shrink(2,2);
	
    if(iBitmap)// check that we have  constructed the bitmap
		{
		// and that the bitmap has valid data for drawing
		if(iBitmap->Handle())
			{
			// just draw the image to the whole screen
			// without caring about the scaling issues
			gc.DrawBitmap(tmpBitmapRect,iBitmap);	
			gc.DrawBitmap(tmpBitmapRect2,iBitmap);	
			}
		}
	}



/*
-----------------------------------------------------------------------------
used for informinging about resource changes, 
in S60 one usage is to know when the layout of the screen has been changed
-----------------------------------------------------------------------------
*/
void CControlsContainer::HandleResourceChange(TInt aType)
	{
    if ( aType==KEikDynamicLayoutVariantSwitch )// layout change event
    	{   // get new main panel rect and set it
        TRect rect;
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
    	}

	// forward events for CCoeControl's base class handler
	CCoeControl::HandleResourceChange(aType);
	}

/*
-----------------------------------------------------------------------------
system calls this function when the size for the container has been chnaged
-----------------------------------------------------------------------------
*/ 
void CControlsContainer::SizeChanged()
	{
    TRect rect(Rect());
    
    rect.Shrink(2,2);
    
    iImageRect = iBitmapRect = iBitmapRect2 = iAnimationRect = rect;
    
    // calculate the half points for width & height
    TInt helfHeight= (rect.Height()/ 2);
    TInt helfWidth = (rect.Width() / 2);
    
    // set the bottom Y values for first row controls
    iBitmapRect2.iBr.iY = iAnimationRect.iBr.iY = (iAnimationRect.iTl.iY + helfHeight);
    
    // set the bottom Y values for second row controls
    iImageRect.iTl.iY = iBitmapRect.iTl.iY = iBitmapRect2.iBr.iY;
    
    // set the bottom X values for first row controls
    iBitmapRect2.iBr.iX = (iBitmapRect2.iTl.iX + helfWidth);
    iAnimationRect.iTl.iX = iBitmapRect2.iBr.iX;
    
    // set the bottom X values for second row controls
    iBitmapRect.iBr.iX = (iBitmapRect.iTl.iX + helfWidth);
    iImageRect.iTl.iX = iBitmapRect.iBr.iX;
    
    // set the rects used for drawinf the border frames as a base
    TRect tmpAnimationRect(iAnimationRect);
    TRect tmpImageRect(iImageRect);
   
	// then shrink them a bit to get better visibility for the border frames
	tmpAnimationRect.Shrink(2,2);
	tmpImageRect.Shrink(2,2);
	  
    if(iAnimationControl)
    	{	
    	iAnimationControl->SetRect(tmpAnimationRect);
    	}
    
    if(iImageControl)
    	{
    	iImageControl->SetRect(tmpImageRect);
    	}
 	}
 

	
// End of File
