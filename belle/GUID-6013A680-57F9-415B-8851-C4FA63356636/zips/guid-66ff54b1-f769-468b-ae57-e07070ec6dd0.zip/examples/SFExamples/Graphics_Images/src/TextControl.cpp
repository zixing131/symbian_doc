/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/
#include <eiklabel.h>
#include <eikenv.h>

#include "TextControl.h"

#include <aknutils.h> 


// example text used for showing in this control

// time value used for scrolling with the peridic timer 
const TInt KScrollInterval = 200000;

/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CTextControl* CTextControl::NewL(const TDesC& aText)
	{
	CTextControl* self = CTextControl::NewLC(aText);
	CleanupStack::Pop( self );
	return self;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CTextControl* CTextControl::NewLC(const TDesC& aText)
	{
	CTextControl* self = new ( ELeave ) CTextControl(aText);
	CleanupStack::PushL( self );
	self->ConstructL();
	return self;
	}
	
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CTextControl::CTextControl(const TDesC& aText):iText(aText)
	{
	// nothing to do..
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 
CTextControl::~CTextControl()
	{
    if (iScrollTimer)
    	{
        iScrollTimer->Cancel();
    	}
    	
    delete iScrollTimer;
	}
/*
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
*/ 	
void CTextControl::ConstructL(void)
	{
	iUseFont = AknLayoutUtils::FontFromId(EAknLogicalFontSecondaryFont);

	iCutOff = 0;
	iScrollTimer = CPeriodic::NewL(CActive::EPriorityStandard);
	iScrollTimer->Start(KScrollInterval, KScrollInterval, TCallBack(ScrollText, this));
	}
/*
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
*/	
TInt CTextControl::ScrollText(TAny* aPtr)
	{
	CTextControl* self = static_cast<CTextControl*>(aPtr);
	
	if(self->iUseFont)
		{
		self->iCutOff++;
		
		if(self->iText.Length() <= self->iCutOff)
			{
			self->iCutOff = 0;
			}
		
		TInt TextWidth = self->iUseFont->TextWidthInPixels(self->iText.Right(self->iText.Length() - self->iCutOff));
		
		if(TextWidth < (self->Rect().Width() / 2))
			{
			self->iCutOff = 0;	
			}
		
		self->DrawNow();
		}
    
	return KErrNone;
	}
/*
-----------------------------------------------------------------------------
normal Draw funtion for CCoeControl, which is used to draw to the screen
-----------------------------------------------------------------------------
*/ 
void CTextControl::Draw( const TRect& /*aRect*/ ) const
	{
	CWindowGc& gc = SystemGc();
	gc.SetBrushStyle(CGraphicsContext::ENullBrush);
	gc.Clear(Rect());

	if(iUseFont)
		{
		gc.SetPenColor(KRgbBlack);
		gc.UseFont(iUseFont);

		if(iCutOff <= 0)
			{
			gc.DrawText(iText,Rect(),iUseFont->AscentInPixels(), CGraphicsContext::ELeft, 0);
			}
		else if(iCutOff < iText.Length())
			{
			gc.DrawText(iText.Right(iText.Length() - iCutOff),Rect(),iUseFont->AscentInPixels(), CGraphicsContext::ELeft, 0);
			}
		
		gc.DiscardFont();
		}
	}
	
// End of File
