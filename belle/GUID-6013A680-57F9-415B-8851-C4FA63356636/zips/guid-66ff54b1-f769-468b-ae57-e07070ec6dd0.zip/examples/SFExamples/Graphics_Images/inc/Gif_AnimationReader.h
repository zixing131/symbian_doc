/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#ifndef __GIF_READER_H__
#define __GIF_READER_H__

#include <COEMAIN.H>
#include <ImageConversion.h>


class MAniReaderCallBack
	{
	public:// used to inform the owner when animation frame is read from the file
		virtual void AppendFrameL(CFbsBitmap& aImage,CFbsBitmap& aMask,TRect aArea, TBool aReDraw) = 0;
	};
	
	class CAniFrame_Reader : public CActive
	{
	public: // public constructors & destructor
		static CAniFrame_Reader* NewL(MAniReaderCallBack& aCallBack,const TDesC& aFileName);
		static CAniFrame_Reader* NewLC(MAniReaderCallBack& aCallBack,const TDesC& aFileName);
	    ~CAniFrame_Reader();
	    // public functions
	    void NextImageL(void);
	    TSize AniFrameSizeL(void);
	protected: // from active object
		void DoCancel();
		void RunL();
		// private constructors
		CAniFrame_Reader(MAniReaderCallBack& aCallBack);
	    void ConstructL(const TDesC& aFileName);
	private:
		MAniReaderCallBack&	iCallBack;
		TInt 				iCurrImg,iCurrCount;
		CImageDecoder*		iImageDecoder;
		CFbsBitmap*			iFrameMsk;  // frame image 
		CFbsBitmap*			iFrameImg;	// mask for frame image
	};


#endif // __GIF_READER_H__

