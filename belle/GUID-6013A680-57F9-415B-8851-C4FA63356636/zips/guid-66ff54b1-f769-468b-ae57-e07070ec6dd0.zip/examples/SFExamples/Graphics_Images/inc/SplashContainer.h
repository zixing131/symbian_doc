/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/

#ifndef __GRAPHICSEXAMPLE_SPLASCONTAINER_H__
#define __GRAPHICSEXAMPLE_SPLASCONTAINER_H__

#include <coecntrl.h>       // CCoeControl

#include <AknsBasicBackgroundControlContext.h> 
#include <aknsdrawutils.h>
#include <aknscontrolcontext.h>
#include <AknsSkinInstance.h>
#include <aknsutils.h>


class CFbsBitmap;
class CApaMaskedBitmap;

class MSplachScreenCallBack
	{
	public:// callback to tell that we have finished the process
		virtual void SplashTimeIsUpL(void) = 0;
	};
	
//-------------------------------------------------------------------
//
//-------------------------------------------------------------------
class CMySplashContainer : public CCoeControl
	    {
	public:
		static CMySplashContainer* NewL(MSplachScreenCallBack&	aCallBack);
		~CMySplashContainer();

	protected:
		// needed for skins thus used only with S60
		TTypeUid::Ptr MopSupplyObject(TTypeUid aId); 

	private:// From CoeControl
		virtual void SizeChanged();

		virtual void HandleResourceChange(TInt aType);

		void Draw(const TRect& aRect) const;
		// private constructors
		CMySplashContainer(MSplachScreenCallBack& aCallBack);
		void ConstructL(void);
		// callback function for the periodic timer
		static TInt DoProgressL(TAny* aPtr);
	private:
		MSplachScreenCallBack&	iCallBack;// callback to tell when we are finished

		// used for drawing the skins with S60
		CAknsBasicBackgroundControlContext*	iBgContext; 

		CPeriodic* 		iProgressTimer;// periodic timer for progress
		TInt			iProgressCount;// progress value
	};

  
#endif // __GRAPHICSEXAMPLE_SPLASCONTAINER_H__
