/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */


// INCLUDE FILES
#include "TaskManagerConnForm.h"
#include "TaskManagerConnInfo.h"

#include <SocketTaskManager.rsg>
#include <avkon.hrh>		// EAknSoftkeyOk
#include <eikedwin.h>		// CEikEdwin
#include <aknnumedwin.h>	// CAknIntegerEdwin
#include <eikseced.h>		// CEikSecretEditor


// ================= MEMBER FUNCTIONS =======================

// constructor
CTaskManagerConnForm::CTaskManagerConnForm( TTaskManagerConnInfo& aConnInfo ): iConnInfo( aConnInfo )
	{
	}

// ----------------------------------------------------------
// CTaskManagerConnForm::RunDlgLD()
// Runs this form.
// ----------------------------------------------------------
//
TBool CTaskManagerConnForm::RunDlgLD( TTaskManagerConnInfo& aConnInfo )
	{
	CTaskManagerConnForm* self = new (ELeave) CTaskManagerConnForm( aConnInfo );
	return self->ExecuteLD( R_TASKMANAGER_CONNFORM_DIALOG );
	}

// ----------------------------------------------------------
// CTaskManagerConnForm::PreLayoutDynInitL()
// This function is called by the dialog framework before 
// the dialog is sized and laid out.
// ----------------------------------------------------------
//
void CTaskManagerConnForm::PreLayoutDynInitL()
	{
	CEikEdwin* editor;
	
	// set server name
	editor = static_cast< CEikEdwin* >( ControlOrNull( ETaskManagerIdServer ) );
	if( editor )
		{
		TPtrC ptr(iConnInfo.ServerAddress());
		editor->SetTextL(&ptr);
		}
	
	// set port number
	CAknIntegerEdwin* portEditor =
			   static_cast< CAknIntegerEdwin* >( ControlOrNull( ETaskManagerIdPort ) );
	if( portEditor )
		{
		portEditor->SetValueL(iConnInfo.Port());
		}
	
	// set username
	editor = static_cast< CEikEdwin* >( ControlOrNull( ETaskManagerIdUsername ) );
	if( editor )
		{
		TPtrC ptr(iConnInfo.Username());
		editor->SetTextL(&ptr);
		}
		
	// set password
	CEikSecretEditor* secretEditor =
		static_cast< CEikSecretEditor* >( ControlOrNull( ETaskManagerIdPassword ) );
	if (secretEditor)
		{
		TPtrC ptr(iConnInfo.Password());
		secretEditor->SetText(ptr);
		}
	}
	
// ----------------------------------------------------------
// CTaskManagerConnForm::OkToExitL()
// This function is invoked when the user presses a button in 
// the button panel. It is not called if the Cancel button is 
// activated.
// ----------------------------------------------------------
//	
TBool CTaskManagerConnForm::OkToExitL( TInt aButtonId )
	{
	if ( aButtonId == EAknSoftkeyOk )
		{
		CEikEdwin* editor;
		
		// save server name
		editor = static_cast< CEikEdwin* >( ControlOrNull( ETaskManagerIdServer ) );
		if( editor )
			{
			TBuf< KMaxServerNameLength > server;
			editor->GetText( server );
			iConnInfo.SetServerAddress( server );
			}
		
		// save port number
		CAknIntegerEdwin* portEditor =
				   static_cast< CAknIntegerEdwin* >( ControlOrNull( ETaskManagerIdPort ) );
		if( portEditor )
			{
			TInt port;
			portEditor->GetTextAsInteger( port );
			iConnInfo.SetPort( port );
			}
		
		// save username
		editor = static_cast< CEikEdwin* >( ControlOrNull( ETaskManagerIdUsername ) );
		if( editor )
			{
			TBuf< KMaxUsernameLength > username;
			editor->GetText( username );
			iConnInfo.SetUsername( username );
			}

		// save password
		CEikSecretEditor* secretEditor =
					 static_cast< CEikSecretEditor* >( ControlOrNull( ETaskManagerIdPassword ) );
		if( secretEditor )
			{
			TBuf< KMaxPasswordLength > password;
			secretEditor->GetText( password );
			iConnInfo.SetPassword( password );
			}
		}

	return ETrue;
	}
	
// End of file
