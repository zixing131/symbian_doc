/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */


#ifndef __TIMEOUTTIMER_H__
#define __TIMEOUTTIMER_H__

// INCLUDE FILES
#include <e32base.h>

// CLASS DECLARATIONS

/**
* A class for notifying of a timeout event.
*/
class MTimeoutNotifier
    {
public:

    /*
    * Called when the timer raises an event.
    */
    virtual void TimerExpired() = 0;
    };

/**
* A class that raises timeout events.
*/
class CTimeOutTimer : public CTimer
    {
public:
    
    /**
    * Standard Symbian two-phase construction
    * @param aPriority Priority of the active object.
    * @param aNotify Timer observer.
    */
    static CTimeOutTimer* NewL( const TInt aPriority,
                                MTimeoutNotifier& aNotify );
    /**
    * Standard Symbian two-phase construction
    * @param aPriority Priority of the active object.
    * @param aNotify A handle to the class to be notified of a timeout event.
    */
    static CTimeOutTimer* NewLC( const TInt aPriority,
                                 MTimeoutNotifier& aNotify );
    /**
    * Destructor
    */
    virtual ~CTimeOutTimer();

protected: // from CTimer

    /**
    * Active object post-request handling.
    */
    void RunL();
    
    /**
    * Handles a leave occurring in the request completion event handler RunL()
    */
    TInt RunError( TInt aError );

private:

    /**
    * Constructor.
    * @param aPriority Priority of the active object.
    * @param aNotify A handle to the class to be notified of a timeout event.
    */
    CTimeOutTimer( const TInt aPriority,
                   MTimeoutNotifier& aNotify);

    /**
    * Standard Symbian second-phase construction.
    */
    void ConstructL();

private:

    // Handle to the class to be notified of a timeout event.
    MTimeoutNotifier&               iNotify;
    };

#endif

// End of file




