// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// License: "Symbian Foundation License v1.0" to Symbian Foundation
// members and "Symbian Foundation End User License Agreement v1.0"
// to non-members�at the URL
// "http://www.symbianfoundation.org/legal/licencesv10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// Contains the CMessAsyncWaiter class.
//



/**
 @file
*/

#ifndef __MESS_ASYNCWAITER_H_
#define __MESS_ASYNCWAITER_H_

#include <e32base.h>

/**
CMessAsyncWaiter is a class that publicily inherits the class CActive.
CActive is core class of the active object abstraction.
It encapsulates both issuing a request to an asynchronous service provider 
and handling the completed requests.
*/
class CMessAsyncWaiter : public CActive
	{
public:
	static CMessAsyncWaiter* NewL();
	~CMessAsyncWaiter();

	void StartAndWait();
	TInt Result() const;
private:
	CMessAsyncWaiter();
	// CActive implementation.
	virtual void RunL();
	virtual void DoCancel();
private:
	TInt iError;
	};
#endif // __MESS_ASYNCWAITER_H_
