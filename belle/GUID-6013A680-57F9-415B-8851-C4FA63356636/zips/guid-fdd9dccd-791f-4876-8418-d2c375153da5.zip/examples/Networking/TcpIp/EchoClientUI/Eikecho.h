/*
Copyright (c) 1997-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Header file for EIKON interface to ECHOENG� 
*/


#include <basched.h>
#include <eikenv.h>
#include <coecntrl.h>
#include <eikappui.h>
#include <e32keys.h>
#include <eikconso.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikon.rsg>
#include <eikinfo.h>
//#include <eikcmds.hrh>
#include <eikon.hrh>//newly added
#include <eikecho.rsg>
#include "ECHOENG.H"

#ifndef _EIKECHO_H_
#define _EIKECHO_H_



const TUid KUidEikEchoApp = {0xE800006A};

// Connection values: substitute alternative values for KInetAddr
// and KInetHostName if you want to use different servers
const TUint32 KInetAddr = INET_ADDR(10,159,34,198);//(193,63,255,1); //
_LIT(KInetHostName,"phoenix.doc.ic.ac.uk");

// Integer formatting descriptor
_LIT(KIntFormat,"%d");


//
// CConsoleControl: console-type control
//

class CConsoleControl : public CCoeControl, public MUINotify
	{
public:
	static CConsoleControl* NewL(CEchoEngine* aEchoEngine);
	~CConsoleControl();
	void ConstructL(CEchoEngine* aEchoEngine);

	// Override CCoeControl
    TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
    void ActivateL();

	//Implement MUINotify up calls
	void PrintNotify(const TDesC& aDes);
	void PrintNotify(TInt aInt);
	void ErrorNotifyL(const TDesC& aErrMessage, TInt aErrCode);
protected:
	CConsoleControl() {}
private:
	CEikConsoleScreen* iConsole;	// Standard EIKON console control
	CEchoEngine* iEchoEngine;		// The echo engine
	};

//
// CEchoAppUi: user interface command handling
//

class CEchoAppUi : public CEikAppUi
    {
public:
	CEchoAppUi(CEchoEngine* aEchoEngine);
    void ConstructL();
	void CreateConsoleL();
	~CEchoAppUi();
private:
	// Override CEikAppUi
    void HandleCommandL(TInt aCommand);
private:
	CConsoleControl* iConsoleControl;
	CEchoEngine* iEchoEngine;
	};

//
// CEchoDocument: document class, which owns the engine
//

class CEchoDocument : public CEikDocument
	{
public:
	CEchoDocument(CEikApplication& aApp);
	static CEchoDocument* NewL(CEikApplication& aApp);
	~CEchoDocument();
	void ConstructL();
private:
	// Override CApaDocument
	CEikAppUi* CreateAppUiL();
private:
	CEchoEngine* iEchoEngine; // Document owns the echo engine
	};

//
// CEchoApplication
//

class CEchoApplication : public CEikApplication
	{
private: // from CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};
#endif



