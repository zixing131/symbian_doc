/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/

#include <e32cons.h>
#include <e32uid.h>
#include <string.h>
#include "wsddll.h"
#include "pls.h"

#ifdef __WINSCW__
const TUid KWsdDllUid3 = {0xA000131D};

// WSD object type for this DLL
struct TWsdData
{
	int count;     // Global variable
	char name[20]; // Global variable
};

#else
	int count = 0;             // Global variable
	char name[20] = "Default"; // Global variable
#endif

#ifdef __WINSCW__
// Initialisation function for WSD objects - supplied to Pls()
LOCAL_C int InitializeWsd(TWsdData* aArg)
{
	aArg->count = 0; // Initialise global count with 0
	strcpy(aArg->name,"Default");
	return 0;
}

// Function to fetch the WSD object for this process
LOCAL_C TWsdData* GetGlobals()
{

	// Access the PLS of this process
	TWsdData* p = Pls<TWsdData>(KWsdDllUid3, &InitializeWsd);
	return p;
}

#define name (p->name)
#define count (p->count)

#endif

EXPORT_C int GetDllInt()
{
#ifdef __WINSCW__
	TWsdData* p = GetGlobals();
#endif
	return count;

}

EXPORT_C void GetDllString(char *str)
{
#ifdef __WINSCW__
	TWsdData* p = GetGlobals();
#endif
	strcpy(str,name);

}

EXPORT_C void SetDllInt(const int i)
{
#ifdef __WINSCW__
	TWsdData* p = GetGlobals();
#endif
	count = i;

}

EXPORT_C void SetDllString(char * str)
{
#ifdef __WINSCW__
	TWsdData* p = GetGlobals();
#endif
	strcpy(name,str);

}


// end of file
