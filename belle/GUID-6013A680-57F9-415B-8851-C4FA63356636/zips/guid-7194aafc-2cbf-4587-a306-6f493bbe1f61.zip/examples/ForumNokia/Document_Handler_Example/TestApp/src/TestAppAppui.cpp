/*
 * Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */
#include <avkon.hrh>
#include <aknnotewrappers.h>

#include "TestApp.pan"
#include "TestAppAppUi.h"
#include "TestAppAppView.h"
#include "TestApp.hrh"

#include <apmstd.h> //TDAtatype, link against: apmime.lib 
#include <DocumentHandler.h>
#include <apgcli.h> //RApaLsSession 

#ifdef __SERIES60_3X__
    _LIT(KTestFile,"c:\\data\\Images\\Pictures\\test.new");
#else
    _LIT(KTestFile,"c:\\nokia\\Images\\Pictures\\test.new");
#endif

#ifdef __SERIES60_3X__
    _LIT(KTestFile2,"c:\\data\\Images\\Pictures\\test2.new");
#else
    _LIT(KTestFile2,"c:\\nokia\\Images\\Pictures\\test2.new");
#endif

void CTestAppAppUi::ConstructL()
    {
    BaseConstructL();

    iAppView = CTestAppAppView::NewL(ClientRect());
    iDocHandler = CDocumentHandler::NewL( CEikonEnv::Static()->Process() );                  

    AddToStackL(iAppView);
    }

CTestAppAppUi::CTestAppAppUi()
    {
    // no implementation required
    }

CTestAppAppUi::~CTestAppAppUi()
    {
    if (iAppView)
        {
        RemoveFromStack(iAppView);
        delete iAppView;
        iAppView = NULL;
        }
    delete iDocHandler;
    }

// handle any menu commands
void CTestAppAppUi::HandleCommandL(TInt aCommand)
    {
    switch(aCommand)
        {
        case EEikCmdExit:
        case EAknSoftkeyExit:
            Exit();
            break;

        case ETestAppCommand1:
            {
            LaunchFileL(EFalse); //standalone
            break;
            }

        case ETestAppCommand2:
            {
            LaunchFileL(ETrue); //embedded
            break;
            }

        default:
            Panic(ETestAppBasicUi);
            break;
        }
    }

void CTestAppAppUi::LaunchFileL(TBool aEmbedded)
    {
    TFileName path;
    if (iCount++ % 2 == 0)
        {        
        path = KTestFile;
        }
    else
        {
        path = KTestFile2;
        }

    TDataType empty = TDataType();
  
    if( aEmbedded )
        {
        //Set the exit observer so NotifyExit or in 3rd edition
        //HandleServerAppExit will be called
        iDocHandler->SetExitObserver(this);   
        iDocHandler->OpenFileEmbeddedL(path,empty );             
        }        
    else
        {
        iDocHandler->OpenFileL(path,empty );
        
        //If the standalone handler is already running then update the
        //document file
        TUid handlerUid;
        TInt err = KErrNone;
        #ifdef __SERIES60_3X__
            err = iDocHandler->HandlerAppUid(handlerUid);
        #else
            RApaLsSession apaLs;
            User::LeaveIfError( apaLs.Connect() );
            err = apaLs.AppForDocument(path, handlerUid, empty);  
            apaLs.Close();          
        #endif
        
        if( !err )
            {
            RefreshDocumentFileL(handlerUid, path);
            }
        else if( err == KNotInitialized )
            {
            //Handler not initialized
            }
        else
            {
            //Some other error
            }
        
        }

    }

TBool CTestAppAppUi::RefreshDocumentFileL(const TUid& aUid, const TDesC& aFileName )    
    {
    TApaTaskList taskList(iCoeEnv->WsSession());
    TApaTask task = (taskList.FindApp(aUid));

    if (task.Exists())
        {
        //calls AppUi::OpenFileL, requires SwEvent capability      
        User::LeaveIfError(task.SwitchOpenFile(aFileName));
        //task.BringToForeground();
        return ETrue;
        }
    return EFalse;    
    }    
    
void CTestAppAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType); //call to upper class

    // ADDED FOR SCALABLE UI SUPPORT
    // *****************************
	//if ( aType == KEikDynamicLayoutVariantSwitch )
	//hard coded constant so it can be compiled with first edition
	
	if ( aType == 0x101F8121 )
	    {
	    iAppView->SetRect( ClientRect() );
	    }
	}


#ifdef __SERIES60_3X__
    void  CTestAppAppUi::HandleServerAppExit (TInt aReason)
	{
	//Handle the closing of the handler application
    MAknServerAppExitObserver::HandleServerAppExit( aReason );  	
	}
#else
    void CTestAppAppUi::NotifyExit(TExitMode aMode)    
	{
	//Handle the closing of the handler application
	//The mode can be set by the handler application by calling
	//iDoorObserver->NotifyExit(TExitMode);

	switch (aMode) 
	    {
	    
		/** Changes to the embedded document must be saved. */
	    case EKeepChanges:
	        {
	        //TODO
	        }
	        break;
	        
		/** Reverts back to the saved version of the embedded document, i.e. reloads the 
		whole document. */
	        case ERevertToSaved:
	        {
	        //TODO
	        }
	        break;
		/** No changes have been made to the embedded document. */
		case ENoChanges:
	        {
	        //TODO
	        }
	        break;
		/** The embedded document is empty. */
		case EEmpty:
	        {
	        //TODO
	        }
	        break;
	    default:
	        //TODO
	        break;
	    }
	}
#endif
