/*
 * Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef __HANDLER_DOCUMENT_H__
#define __HANDLER_DOCUMENT_H__


#include <akndoc.h>

// Forward references
class CHandlerAppUi;
class CEikApplication;


/*! 
  @class CHandlerDocument
  
  @discussion An instance of class CHandlerDocument is the Document part of the AVKON
  application framework for the handler example application
  */
class CHandlerDocument : public CAknDocument
    {
public:

/*!
  @function NewL
  
  @discussion Construct a CHandlerDocument for the AVKON application aApp 
  using two phase construction, and return a pointer to the created object
  @param aApp application creating this document
  @result a pointer to the created instance of CHandlerDocument
  */
    static CHandlerDocument* NewL(CEikApplication& aApp);

/*!
  @function NewLC
  
  @discussion Construct a CHandlerDocument for the AVKON application aApp 
  using two phase construction, and return a pointer to the created object
  @param aApp application creating this document
  @result a pointer to the created instance of CHandlerDocument
  */
    static CHandlerDocument* NewLC(CEikApplication& aApp);

/*!
  @function ~CHandlerDocument
  
  @discussion Destroy the object and release all memory objects
  */
    ~CHandlerDocument();

public: // from CAknDocument
/*!
  @function CreateAppUiL 
  
  @discussion Create a CHandlerAppUi object and return a pointer to it
  @result a pointer to the created instance of the AppUi created
  */
    CEikAppUi* CreateAppUiL();
    
public:	// from CEikDocument
	
	/**
    * From @c CEikDocument. Opens a file.
    * @param aDoOpen Open an existing file if @c ETrue, 
    * otherwise create a new file. Not used.
    * @param aFilename The file to open or create. Not used.
    * @param aFs File server session to use. Not used.
    * @return Pointer to file store object.
    */
    CFileStore* OpenFileL(TBool aDoOpen,const TDesC& aFilename,RFs& aFs);    

    void OpenFileL(CFileStore*& aFileStore, RFile& aFile);

private:

/*!
  @function ConstructL
  
  @discussion Perform the second phase construction of a CHandlerDocument object
  */
    void ConstructL();
    

/*!
  @function CHandlerDocument
  
  @discussion Perform the first phase of two phase construction 
  @param aApp application creating this document
  */
    CHandlerDocument(CEikApplication& aApp);
    
private:
    CEikAppUi* iAppUi;
    
    TFileName iFileName;
    };


#endif // __HANDLER_DOCUMENT_H__
