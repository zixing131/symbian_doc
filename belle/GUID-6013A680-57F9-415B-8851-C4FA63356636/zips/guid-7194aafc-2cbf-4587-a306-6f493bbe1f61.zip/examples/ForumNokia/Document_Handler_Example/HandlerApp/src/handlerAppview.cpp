/*
 * Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include <coemain.h>
#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>

#include "handlerAppView.h"
#include "handlerDocument.h"

const TInt KCharsToShowFromEnd = 10;

CHandlerAppView* CHandlerAppView::NewL(const TRect& aRect)
    {
    CHandlerAppView* self = CHandlerAppView::NewLC(aRect);
    CleanupStack::Pop(self);
    return self;
    }

CHandlerAppView* CHandlerAppView::NewLC(const TRect& aRect)
    {
    CHandlerAppView* self = new (ELeave) CHandlerAppView;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
    }

CHandlerAppView::CHandlerAppView()
    {
    // no implementation required
    }

CHandlerAppView::~CHandlerAppView()
    {
    // no implementation required
    }

void CHandlerAppView::ConstructL(const TRect& aRect)
    {
    // Create a window for this application view
    CreateWindowL();

    // Set the windows size
    SetRect(aRect);

    // Activate the window, which makes it ready to be drawn
    ActivateL();
    }

// Draw this application's view to the screen
void CHandlerAppView::Draw(const TRect& /*aRect*/) const
    {
    // Get the standard graphics context
    CWindowGc& gc = SystemGc();

    // Gets the control's extent
    TRect rect = Rect();

    // Clears the screen
    gc.Clear(rect);

    const CFont* normalFont = CEikonEnv::Static()->NormalFont();
    gc.UseFont( normalFont );

    //get some characters from file path end and show them.
    TBuf<KCharsToShowFromEnd> endText = KNullDesC();
    endText.Zero();
    if( iName.Length() > KCharsToShowFromEnd-2 )
        {
        endText = iName.Right(KCharsToShowFromEnd-1);
        }

    const TPoint KPoint1 = TPoint(1,41);
    const TPoint KPoint2 = TPoint(1,21);
    const TPoint KPoint3 = TPoint(1,61);

    gc.DrawText(iName, KPoint1 );
    gc.DrawText(endText, KPoint2 );
    gc.DrawText(iData, KPoint3 );
    }

void CHandlerAppView::SizeChanged()
    {
    DrawDeferred();
    }

void CHandlerAppView::SetFileData(TFileName& aFileName, TDes8& aData)
    {
    iName = aFileName;
    iData.Copy( aData );
    DrawDeferred();
    }
