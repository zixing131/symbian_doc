// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __ContactMoveVIEW_H_
#define __ContactMoveVIEW_H_

#include <QikViewBase.h>

class CEikLabel;

class CContactMoveMainView : public CQikViewBase
	{
public:

	static CContactMoveMainView* NewLC(CQikAppUi& aAppUi);
	~CContactMoveMainView();

public: // From CQikViewBase

	TVwsViewId ViewId()const;
	void HandleCommandL(CQikCommand& aCommand);

public:

	void SetTextL(const TDesC& aText);

protected: // From CQikViewBase

	void ViewConstructL();
	void SizeChanged();

private:

	CContactMoveMainView(CQikAppUi& aAppUi);
	void ConstructL();
	
private:

	CEikLabel* iEikLabel;

	};

#endif // __ContactMoveVIEW_H_

// End of File
