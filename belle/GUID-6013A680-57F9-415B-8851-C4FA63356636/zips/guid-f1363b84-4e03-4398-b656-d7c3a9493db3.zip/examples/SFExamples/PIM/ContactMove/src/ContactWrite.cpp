// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactWrite.h"

CContactWrite* CContactWrite::NewL()
	{
	CContactWrite* self = new (ELeave) CContactWrite();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactWrite::~CContactWrite()
	{
	delete iCntDb;
	}

CContactWrite::CContactWrite()
		: iCallback(&CContactWrite:: ParseWord)
	{
	}

void CContactWrite::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	}

CContactDatabase& CContactWrite::CntDatabase()
	{
	return *iCntDb;
	}

void CContactWrite::MoveContactL(TContactItemId aCntId, const TDesC& aNewGroup)
	{
	// open the contact item for exclusive use
	CContactItem* item = iCntDb->OpenContactLX(aCntId);
	CleanupStack::PushL(item);
	// Let�s find out what group the contact already belongs to
	TContactItemId groupId = KNullContactId;
	CContactItem* group = NULL;
	if (KUidContactCard == item->Type())
		{
		CContactCard* card = (CContactCard*)item;
		CContactIdArray* ids = card->GroupsJoinedLC();
		if (0 < ids->Count())
			{
			groupId = (*ids)[0];
			}
		CleanupStack::PopAndDestroy(ids);
		}
	if (KNullContactId != groupId)
		{
		// let�s remove the contact from the group
		group = iCntDb->OpenContactLX(groupId);
		CleanupStack::PushL(group);
		iCntDb->RemoveContactFromGroupL(*item, *group);

		CleanupStack::PopAndDestroy(group);
		CleanupStack::PopAndDestroy(); // exclusive lock on group
		group = NULL;
		}
	CleanupStack::PopAndDestroy(item);
	CleanupStack::PopAndDestroy(); // exclusive lock on item

	// let�s find the new group in the database, or create it if needs be

	groupId = KNullContactId;
	CContactIdArray* groupArrayId = iCntDb->GetGroupIdListL();
	if (NULL != groupArrayId)
		{
		CleanupStack::PushL(groupArrayId);
		for (TInt ii = 0 ; ii < groupArrayId->Count() ; ++ii)
			{
			group = iCntDb->ReadContactLC((*groupArrayId)[ii]);
			TPtrC label = ((CContactGroup*)group)->GetGroupLabelL();
			if (aNewGroup == label)
				{
				groupId = (*groupArrayId)[ii];
				ii = groupArrayId->Count(); // break
				}
			CleanupStack::PopAndDestroy(group);
			group = NULL;
			}
		CleanupStack::PopAndDestroy(groupArrayId);
		}
	if (KNullContactId == groupId)
		{
		group = iCntDb->CreateContactGroupLC(aNewGroup);
		groupId = group->Id();
		CleanupStack::PopAndDestroy(group);
		}
	// let�s add the contact to the group
	iCntDb->AddContactToGroupL(aCntId, groupId);
	}

CContactIdArray* CContactWrite::FindWithCallbackL(TFieldType aField, const TDesC& aMatch)
	{
	TContactTextDefItem field(aField);
	CContactTextDef* textDef = CContactTextDef::NewL();
	CleanupStack::PushL(textDef);
	textDef->AppendL(field);
	
	CDesCArray* match = new (ELeave) CDesCArrayFlat(1);
	CleanupStack::PushL(match);
	match->AppendL(aMatch);
	
	CContactIdArray* result = iCntDb->FindInTextDefLC(*match, textDef, iCallback);
	CleanupStack::Pop(result);
	CleanupStack::PopAndDestroy(match);
	CleanupStack::PopAndDestroy(textDef);
	return result;
	}

TInt CContactWrite::ParseWord(TAny* aParam)
	{
	SFindInTextDefWordParser* parserStruct = (SFindInTextDefWordParser*)aParam;
	TPtrC searchString(*(parserStruct->iSearchString));
	TInt index = KErrNotFound;
	TInt error = KErrNone;
	while(0 <= (index = searchString.Locate(' ')))
		{
		if (index > 0)
			{
			TRAP(error, parserStruct->iWordArray->AppendL(searchString.Left(index)));
			if (error != KErrNone)
				return error;
			if (searchString.Length() > index + 1)
				{
				searchString.Set(searchString.Mid(index  +1));
				}
			else
				{
				searchString.Set(KNullDesC());
				break;
				}
			}
		else
			{
			// remove first character as it is a space
			searchString.Set(searchString.Mid(1));
			}
		}
	if(searchString.Length() > 0) // the last word
		{
		TRAP(error, parserStruct->iWordArray->AppendL(searchString));
		if (error != KErrNone)
			return error;
		}
	return KErrNone;
	}

// End of File
