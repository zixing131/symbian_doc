// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactMove.rsg>

#include "ContactMoveAppUi.h"
#include "ContactMoveMainView.h"
#include "ContactWrite.h"
#include "ContactMove.hrh"

void CContactMoveAppUi::ConstructL()
	{

	BaseConstructL(EAknEnableSkin);
	iMainView = CContactMoveMainView::NewL(ClientRect());

	iContactWriter = CContactWrite::NewL();
	}
	
CContactMoveAppUi::~CContactMoveAppUi()
	{
	delete iContactWriter;
	delete iMainView;
	}

void CContactMoveAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		case EContactMove:
			{
			// moving the own card to a group may not be such a good idea
			// let's move the "Partner" card from \PIM\ContactFind
			_LIT(KStringMatch, "Partner");
			CContactIdArray* cards = NULL;
			TFieldType type = KUidContactFieldGivenName;
			TRAPD(error, cards = iContactWriter->FindWithCallbackL(type, KStringMatch()));
			// report result on the Label control
			if (KErrNone == error && NULL != cards)
				{
				CleanupStack::PushL(cards);
				if (cards->Count() > 0)
					{
					_LIT(KGroup, "NewGroup");
					TRAP(error, iContactWriter->MoveContactL((*cards)[0], KGroup()));
					if (error == KErrNone)
						{
						_LIT(KSuccess, "It Worked !");
						iMainView->SetTextL(KSuccess());
						}
					}
				else
					{
					_LIT(KNotFoundMsg, "Card Not Found");
					iMainView->SetTextL(KNotFoundMsg());
					}
				CleanupStack::PopAndDestroy(cards);
				}
			if (error != KErrNone)
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		default:
			break;
		}
	}

	

void CContactMoveAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

	
// End of File
