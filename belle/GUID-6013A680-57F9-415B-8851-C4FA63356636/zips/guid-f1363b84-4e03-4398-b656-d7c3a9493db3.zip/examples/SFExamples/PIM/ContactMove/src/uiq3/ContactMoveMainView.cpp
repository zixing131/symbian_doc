// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <ContactMove.rsg>

#include "ContactMoveExternalInterface.h"
#include "ContactMoveAppUi.h"
#include "ContactMoveMainView.h"
#include "ContactMove.hrh"

// MEMBER FUNCTIONS

CContactMoveMainView* CContactMoveMainView::NewLC(CQikAppUi& aAppUi)
	{
	CContactMoveMainView* self = new (ELeave) CContactMoveMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CContactMoveMainView::CContactMoveMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

CContactMoveMainView::~CContactMoveMainView()
	{
	}

void CContactMoveMainView::ConstructL()
	{
	BaseConstructL();
	SetExtentToWholeScreen();
	}
	
void CContactMoveMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_CONTACTMOVE_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EContactMoveLabelCtrl);
	}

TVwsViewId CContactMoveMainView::ViewId()const
	{
	return TVwsViewId(KUidContactMoveApp, KUidContactMoveMainView);
	}

void CContactMoveMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

void CContactMoveMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

void CContactMoveMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
