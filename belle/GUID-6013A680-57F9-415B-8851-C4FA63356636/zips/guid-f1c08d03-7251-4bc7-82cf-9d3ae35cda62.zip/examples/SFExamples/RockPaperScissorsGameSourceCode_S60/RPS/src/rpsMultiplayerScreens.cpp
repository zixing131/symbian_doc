/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

// INCLUDE FILES
#include <coemain.h>
#include "common.hrh" 
#include "rpsGameScreens.h" 
#include "rpsgameengine.h"
#include "bluetoothmanager.h"

/*
============================================================================
Control menu screen. User chooses to be either a Master (the player controls the game) or 
a Slave (the player waits for other player connection)	
============================================================================
*/	
CGameScreen* CControlScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CControlScreen* me = new (ELeave) CControlScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

CControlScreen::CControlScreen(CGameScreenManager& aScreenMgr)
: CMenuScreen(aScreenMgr)
{}

void CControlScreen::ConstructL()
	{	
	_LIT(KMaster, "Control Game");
	_LIT(KSlave, "Wait Connection");

	TGameScreenItem* item = new (ELeave) TGameScreenItem(RPS::EMaster, KMaster);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/3;
	item->iHighlighted = ETrue;
	iItems.AddFirst(*item);
	iIterator.SetToFirst();
	
	item = new (ELeave) TGameScreenItem(RPS::ESlave, KSlave);
	item->iX = KRPSScreensHAlignment;
	item->iY = 2*gScreenHeight/3;
	TGameScreenItem* current = iIterator;
	ASSERT(current);
	item->iDlink.Enque(&current->iDlink);	
	}

// Handles item selection according to menu
// Here, the next appropriate screen is displayed
void CControlScreen::DoProcessInput(RPS::TMenuOption aSelected)
	{
	switch (aSelected)
		{
		case(RPS::EMaster):
			iGameScreenMgr.BluetoothManager().StartBtMaster();
			break;
		case(RPS::ESlave):
			iGameScreenMgr.BluetoothManager().StartBtSlave();
			break;
		default:
			ASSERT(EFalse);
		}
	}

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------		
//CStartScreen
//-----------------------------------------------------------------------------		
	
CGameScreen* CStartScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CStartScreen* me = new (ELeave) CStartScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

CStartScreen::CStartScreen(CGameScreenManager& aScreenMgr)
: CMenuScreen(aScreenMgr)
{}

void CStartScreen::ConstructL()
	{	
	_LIT(KStartMsg, "Start Game");

	TGameScreenItem* item = new (ELeave) TGameScreenItem(RPS::EStart, KStartMsg);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/2;
	item->iHighlighted = ETrue;
	iItems.AddFirst(*item);
	iIterator.SetToFirst();
	}

// Handles item selection according to menu
// Here, the next appropriate screen is displayed
void CStartScreen::DoProcessInput(RPS::TMenuOption aSelected)
	{
	switch (aSelected)
		{
		case(RPS::EStart):
			iGameScreenMgr.BluetoothManager().StartGame();
			break;
		default:
			ASSERT(EFalse);
		}
	}

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------		
//CWaitStartScreen
//-----------------------------------------------------------------------------		

CWaitStartScreen* CWaitStartScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CWaitStartScreen* me = new (ELeave) CWaitStartScreen(aScreenMgr);
	return (me);
	}

void CWaitStartScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	_LIT(KWaitingText, "Waiting to start...");
		
   	gc.DrawText(KWaitingText, TPoint(KRPSScreensHAlignment, gScreenHeight/2)); 
	}


CWaitStartScreen::CWaitStartScreen(CGameScreenManager& aScreenMgr)
: 	CGameScreen(aScreenMgr)
	{}
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------		
//CWaitConnScreen
//-----------------------------------------------------------------------------		

CWaitConnScreen* CWaitConnScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CWaitConnScreen* me = new (ELeave) CWaitConnScreen(aScreenMgr);
	return (me);
	}

void CWaitConnScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	_LIT(KWaitingText, "Waiting to connect...");
		
   	gc.DrawText(KWaitingText, TPoint(KRPSScreensHAlignment, gScreenHeight/2)); 
	}

CWaitConnScreen::CWaitConnScreen(CGameScreenManager& aScreenMgr)
: 	CGameScreen(aScreenMgr)	
	{}


//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------		
//CErrorScreen
//-----------------------------------------------------------------------------		

CErrorScreen* CErrorScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CErrorScreen* me = new (ELeave) CErrorScreen(aScreenMgr);
	return (me);
	}

void CErrorScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
   	if(iGameScreenMgr.GameData().iRpsError == KErrDisconnected)
	   	{
	   	 _LIT(KDisconnectedText, "Lost Connection");
	   	 gc.DrawText(KDisconnectedText, TPoint(KRPSScreensHAlignment, gScreenHeight/3));
	   	}
   	else if(iGameScreenMgr.GameData().iRpsError == KErrTimedOut)
	   	{
	   	 _LIT(KTimedOutText, "Timed out");
	   	 gc.DrawText(KTimedOutText, TPoint(KRPSScreensHAlignment, gScreenHeight/3));
	   	}
	 else
		 {
	   	  _LIT(KGeneralErrText, "An error occurred");
		  gc.DrawText(KGeneralErrText, TPoint(KRPSScreensHAlignment, gScreenHeight/3));
		 }
	_LIT(KPressQuit, "Press 5 continue");
   	gc.DrawText(KPressQuit, TPoint(KRPSScreensHAlignment, 2*gScreenHeight/3));
	}

void CErrorScreen::ProcessInput(TUint& aKeyState)
	{
	if (aKeyState & KKey5)
		{// Quit and return to the main screen
		iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
		aKeyState &= ~KKey5; // Clear the input now it's been handled
		}
	}

void CErrorScreen::DeActivate()
	{
	if (iGameScreenMgr.PlayMode()==CGameScreenManager::ETwoPlayerShortlink)
		iGameScreenMgr.BluetoothManager().QuitMultiplayerGame();
	}

CErrorScreen::CErrorScreen(CGameScreenManager& aScreenMgr)
: 	CGameScreen(aScreenMgr)	
	{}

//-----------------------------------------------------------------------------		
//CConnectingScreen
//-----------------------------------------------------------------------------		

CConnectingScreen* CConnectingScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CConnectingScreen* me = new (ELeave) CConnectingScreen(aScreenMgr);
	return (me);
	}

void CConnectingScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	_LIT(KDisconnectedText, "Connecting...");
	gc.DrawText(KDisconnectedText, TPoint(KRPSScreensHAlignment, gScreenHeight/3));
	_LIT(KPressQuit, "Press 5 to cancel");
   	gc.DrawText(KPressQuit, TPoint(KRPSScreensHAlignment, 2*gScreenHeight/3));
	}

void CConnectingScreen::ProcessInput(TUint& aKeyState)
	{
	if (aKeyState & KKey5)
		{// Quit and return to main screen
		iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
		iGameScreenMgr.BluetoothManager().QuitMultiplayerGame();
		aKeyState &= ~KKey5; // Clear the input now it's been handled
		}
	}

CConnectingScreen::CConnectingScreen(CGameScreenManager& aScreenMgr)
: 	CGameScreen(aScreenMgr)	
	{}


//-----------------------------------------------------------------------------		
//CWaitOpponentScreen
//-----------------------------------------------------------------------------		

CWaitOpponentScreen* CWaitOpponentScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CWaitOpponentScreen* me = new (ELeave) CWaitOpponentScreen(aScreenMgr);
	return (me);
	}

void CWaitOpponentScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	_LIT(KWaitingText, "Waiting for opponent...");
		
   	gc.DrawText(KWaitingText, TPoint(KRPSScreensHAlignment, gScreenHeight/2)); 
	}



CWaitOpponentScreen::CWaitOpponentScreen(CGameScreenManager& aScreenMgr)
: 	CGameScreen(aScreenMgr)	
	{}
