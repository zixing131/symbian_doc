/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

// INCLUDE FILES
#include <eikenv.h>
#include <coemain.h>
#include <rps_0xA00054BC.mbg>
#include "common.hrh" 
#include "rps.hrh"
#include "rpsGameScreens.h" 
#include "rpsPlayTimer.h"
#include "rpsgameengine.h"
#include "bluetoothmanager.h"

_LIT(KRPSVersionString, "1.0");

_LIT(KRock, "Rock");
_LIT(KPaper, "Paper");
_LIT(KScissors, "Scissors");

//----------------------------------------------------
CGameScreenManager* CGameScreenManager::NewL(CRpsGameEngine& aEngine)
	{
	CGameScreenManager* me = new (ELeave) CGameScreenManager(aEngine);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (me);
	}
CGameScreen::CGameScreen(CGameScreenManager& aGameScreenMgr)
:	iGameScreenMgr(aGameScreenMgr)
	{}

CGameScreen::~CGameScreen()
{}

//----------------------------------------------------

CGameScreenManager::CGameScreenManager(CRpsGameEngine& aEngine)
: iGameState(ESplashScreen), iPlayMode(ESinglePlayer), iEngine(aEngine)
{}

void CGameScreenManager::ConstructL()
	{
	iGameScreens[ESplashScreen] = CSplashScreen::NewL(*this);	
	iGameScreens[EMainScreen] = CMainScreen::NewL(*this);	
	iGameScreens[EPausedScreen] = CPauseScreen::NewL(*this);
	iGameScreens[EPlayScreen] = CPlayScreen::NewL(*this);
	iGameScreens[EWaitOpponentScreen] = CWaitOpponentScreen::NewL(*this);
	iGameScreens[EResultScreen] = CResultScreen::NewL(*this);
	iGameScreens[EControlScreen] = CControlScreen::NewL(*this);
	iGameScreens[ENotifierScreen] = CNotifierScreen::NewL(*this);
	iGameScreens[EConnectingScreen] = CConnectingScreen::NewL(*this);
	iGameScreens[EStartScreen] = CStartScreen::NewL(*this);
	iGameScreens[EWaitStartScreen] = CWaitStartScreen::NewL(*this);
	iGameScreens[EWaitConnScreen] = CWaitConnScreen::NewL(*this);
	iGameScreens[EErrorScreen] = CErrorScreen::NewL(*this);	
	iGameScreens[EAboutScreen] = CAboutScreen::NewL(*this);
	
	// Bluetooth manager
	iBTManager = CBluetoothManager::NewL(*this);
	}

CGameScreenManager::~CGameScreenManager()
	{
	for (TInt index = 0; index < EGameScreensTotal;  index++)
		delete iGameScreens[index];
	
	delete iBTManager;
	}

void CGameScreenManager::SetGameState(TGameState aNewGameState)
	{
	CGameScreen* currentScreen = iGameScreens[iGameState];
	ASSERT(currentScreen);
	currentScreen->DeActivate(); // Processing required before screen is deactivated
	
	iGameState = aNewGameState;
	CGameScreen* newScreen = iGameScreens[iGameState];
	ASSERT(newScreen);
	newScreen->PreActivate(); // Processing required before screen is displayed
	}
// -------------------------------------------------------------------------------

TGameScreenItem::TGameScreenItem(RPS::TMenuOption aOption, const TDesC& aText)	
: iOption(aOption), iHighlighted(EFalse), iX(0), iY(0), iText(aText)
{}

// -------------------------------------------------------------------------------

CMenuScreen::CMenuScreen(CGameScreenManager& aGameScreenMgr)
: 	CGameScreen(aGameScreenMgr),
	iItems(_FOFF(TGameScreenItem, iDlink)),
	iIterator(iItems)
		{
		}	

CMenuScreen::~CMenuScreen()
	{
	TGameScreenItem* anyItem;
	iIterator.SetToFirst();
	while ((anyItem = iIterator++) != NULL)
	    {
	    anyItem->iDlink.Deque();
	    delete anyItem;
	    };
	}
	
void CMenuScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	TGameScreenItem* item=NULL;
	iIterator.SetToFirst();
	while((item = iIterator++) != NULL)
        {
        if (item->iHighlighted)
        	{
        	gc.SetPenColor(KRgbRed);
        	gc.DrawText(item->iText, TPoint(item->iX, item->iY));
        	gc.SetPenColor(KRgbGray);
        	}
        else	
        	gc.DrawText(item->iText, TPoint(item->iX, item->iY));        
        };     
	}


void CMenuScreen::ProcessInput(TUint& aKeyState)
	{
	iIterator.SetToFirst();
	TGameScreenItem* item=iIterator;
	
	while(item!= NULL)
        {
        if (!item->iHighlighted)
        	{
        	iIterator++; // No pre-increment operator is available
        	item = iIterator;
        	}
        else // Found the currently highlighted item
        	{ 
        	if (aKeyState & KControllerUp)
        		{// The up key was pressed
        		if (iItems.IsFirst(iIterator)) // At the first in the list 
        			iIterator.SetToLast(); // Roll around
        		else
        			iIterator--; // No pre-decrement operator is available
        		
        		TGameScreenItem* previous = iIterator;
        		ASSERT(previous);
        		if(previous != item)//only one item in the double list?
	        		{	        			
	        		previous->iHighlighted = ETrue;
	        		item->iHighlighted = EFalse;
	        		}
	        		
        		aKeyState &= ~KControllerUp; // Clear the input now it's been handled
        		}
        	else if (aKeyState & KControllerDown)
        		{// The down key was pressed
        		if (iItems.IsLast(iIterator)) // At the end of the list
        			iIterator.SetToFirst(); // Roll around to the first
        		else
        			iIterator++; // No preincrement operator is available
        		
        		TGameScreenItem* next = iIterator;
        		ASSERT(next);
        		if(next != item)//only one item in the double list?
	        		{
	        		next->iHighlighted = ETrue;
	        		item->iHighlighted = EFalse;
	        		}
	        			
        		aKeyState &= ~KControllerDown;  // Clear the input now it's been handled
        		} 
        	else if (aKeyState & KControllerCentre)
        		{
        		DoProcessInput(item->iOption);
        		aKeyState &= ~KControllerCentre;
        		}        	
        	break; // Input has been handled or is not relevant to this screen
        	}
        } 	
	}

// ---------------------------------

CGameScreen* CMainScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CMainScreen* me = new (ELeave) CMainScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

CMainScreen::CMainScreen(CGameScreenManager& aScreenMgr)
: CMenuScreen(aScreenMgr)
{}

void CMainScreen::ConstructL()
	{
	_LIT(KSingle, "Single Player");
	_LIT(KTwo, "Two Players");
	_LIT(KAbout, "About");
	
	TGameScreenItem* item = new (ELeave) TGameScreenItem(RPS::ESinglePlayer, KSingle);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/3;
	item->iHighlighted = ETrue;
	iItems.AddFirst(*item);
	iIterator.SetToFirst();
	
	item = new (ELeave) TGameScreenItem(RPS::ETwoPlayers, KTwo);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/2;
	TGameScreenItem* current = iIterator;
	ASSERT(current);
	item->iDlink.Enque(&current->iDlink);
	iIterator.Set(*item);

	item = new (ELeave) TGameScreenItem(RPS::EAbout, KAbout);
	item->iX = KRPSScreensHAlignment;
	item->iY = 2*gScreenHeight/3;
	current = iIterator;
	ASSERT(current);
	item->iDlink.Enque(&current->iDlink);
	}

// Handles item selection according to menu
// Here, the next appropriate screen is displayed
void CMainScreen::DoProcessInput(RPS::TMenuOption aSelected)
	{
	switch (aSelected)
		{
		case(RPS::ESinglePlayer):
			iGameScreenMgr.SetPlayMode(CGameScreenManager::ESinglePlayer);
			iGameScreenMgr.SetGameState(CGameScreenManager::EPlayScreen);
			break;
		case (RPS::ETwoPlayers):
			iGameScreenMgr.SetPlayMode(CGameScreenManager::ETwoPlayerShortlink); 
			iGameScreenMgr.SetGameState(CGameScreenManager::EControlScreen);
			break;
		case (RPS::EAbout):
			iGameScreenMgr.SetGameState(CGameScreenManager::EAboutScreen);
			break;
		default:
			ASSERT(EFalse);
		}
	}

// ------------------------------------------------
//Play menu

CGameScreen* CPlayScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CPlayScreen* me = new (ELeave) CPlayScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

CPlayScreen::CPlayScreen(CGameScreenManager& aScreenMgr)
: CMenuScreen(aScreenMgr)
{}

CPlayScreen::~CPlayScreen()
	{
	delete iPlayTimer;
	}

void CPlayScreen::ConstructL()
	{
	iPlayTimer = CPlayTimer::NewL(10000000, *this); // 10 second timeout
	
	TGameScreenItem* item = new (ELeave) TGameScreenItem(RPS::ERock, KRock);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/4;
	item->iHighlighted = ETrue;
	iItems.AddFirst(*item);
	iIterator.SetToFirst();
	
	item = new (ELeave) TGameScreenItem(RPS::EPaper, KPaper);
	item->iX = KRPSScreensHAlignment;
	item->iY = gScreenHeight/2;
	TGameScreenItem* current = iIterator;
	ASSERT(current);
	item->iDlink.Enque(&current->iDlink);
	iIterator.Set(*item);
	
	item = new (ELeave) TGameScreenItem(RPS::EScissors, KScissors);
	item->iX = KRPSScreensHAlignment;
	item->iY = 3*gScreenHeight/4;
	current = iIterator;
	ASSERT(current);
	item->iDlink.Enque(&current->iDlink);
	}

void CPlayScreen::PreActivate()
	{
	iGameScreenMgr.Roshambo().ResetPlayers();
	iPlayTimer->Start();
	}

void CPlayScreen::DeActivate()
	{
	// Cancel the play timer
	iPlayTimer->Cancel();
	
	// If the game is moving to pause because of inactivity, make sure to  
    // send a response to the opponent in a multiplayer game (no selection)
	if (iGameScreenMgr.GameData().iRpsError == KErrTimedOut)
		{
		if (iGameScreenMgr.PlayMode()==CGameScreenManager::ETwoPlayerShortlink)
			{
			iGameScreenMgr.BluetoothManager().SendData(TRoshambo::ENone);
			}
		iGameScreenMgr.GameData().iRpsError = KErrNone;
		}
	}

// The play timer went off - the user didn't take a move within the time limit
void CPlayScreen::PlayTimeout()
	{
	if(iGameScreenMgr.PlayMode()==CGameScreenManager::ESinglePlayer)
		{			
		iGameScreenMgr.Roshambo().SinglePlayerGame(TRoshambo::ENone);
		iGameScreenMgr.SetGameState(CGameScreenManager::EResultScreen);
		}
	else
		{
		ASSERT(iGameScreenMgr.PlayMode()==CGameScreenManager::ETwoPlayerShortlink);
		iGameScreenMgr.BluetoothManager().SendData(TRoshambo::ENone);	
		}
	}

// Handles item selection according to menu
// Here, the next appropriate screen is displayed
void CPlayScreen::DoProcessInput(RPS::TMenuOption aSelected)
	{
	if (iGameScreenMgr.PlayMode()==CGameScreenManager::ESinglePlayer)
		{
		switch (aSelected)
			{
			case(RPS::ERock):
				iGameScreenMgr.Roshambo().SinglePlayerGame(TRoshambo::ERock);
				break;
			case (RPS::EPaper):
				iGameScreenMgr.Roshambo().SinglePlayerGame(TRoshambo::EPaper);
				break;
			case (RPS::EScissors):
				iGameScreenMgr.Roshambo().SinglePlayerGame(TRoshambo::EScissors);
				break;
					
			default:
				ASSERT(EFalse);
			}
		iGameScreenMgr.SetGameState(CGameScreenManager::EResultScreen);
		}
	else
		{ // Multiplayer mode code here
		TRoshambo::TElement element(TRoshambo::ENone);
		switch (aSelected)
			{
			case(RPS::ERock):
				element = TRoshambo::ERock;
				break;
			case (RPS::EPaper):
				element = TRoshambo::EPaper;
				break;
			case (RPS::EScissors):
				element = TRoshambo::EScissors;
				break;
					
			default:
				ASSERT(EFalse);
			}
		iGameScreenMgr.BluetoothManager().SendData(element);
		}
	}

// -------------------------------------------------------------
// About Screen
// -------------------------------------------------------------
CGameScreen* CAboutScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CAboutScreen* me = new (ELeave) CAboutScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

CAboutScreen::CAboutScreen(CGameScreenManager& aScreenMgr)
: CMenuScreen(aScreenMgr)
{}

void CAboutScreen::ConstructL()
	{
	_LIT(KBack, "Back");
	
	TGameScreenItem* item = new (ELeave) TGameScreenItem(RPS::EReturnToMainScreen, KBack);
	item->iX = KRPSScreensHAlignment;
	item->iY = 8*gScreenHeight/9;
	item->iHighlighted = ETrue;
	iItems.AddFirst(*item);
	iIterator.SetToFirst();	
	}

// Handles item selection (in this case, returns to the main menu)
void CAboutScreen::DoProcessInput(RPS::TMenuOption aSelected)
	{
	switch (aSelected)
		{
		case(RPS::EReturnToMainScreen):
			iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
			break;
		default:
			ASSERT(EFalse);
		}
	}

void CAboutScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	_LIT(KVersion, "RPS version ");
	_LIT(KCreatedBy, "Created by");
	_LIT(KMS, "Maurizio Scotti");
	_LIT(KJCS, "Jo Stichbury");
	_LIT(KWithThanks, "With thanks to");
	_LIT(KSymsource, "Symsource Ltd");
	
	TBuf<KMaxRpsTextElement> versionText(KVersion);
	versionText.Append(KRPSVersionString());
	
	gc.DrawText(versionText, TPoint(KRPSScreensHAlignment, gScreenHeight/9)); 
   	gc.DrawText(KCreatedBy, TPoint(KRPSScreensHAlignment, 2*gScreenHeight/9));    
   	gc.DrawText(KMS, TPoint(KRPSScreensHAlignment, gScreenHeight/3));   	
   	gc.DrawText(KJCS, TPoint(KRPSScreensHAlignment, 4*gScreenHeight/9)); 
   	gc.DrawText(KWithThanks, TPoint(KRPSScreensHAlignment, 5*gScreenHeight/9)); 
   	gc.DrawText(KSymsource, TPoint(KRPSScreensHAlignment, 2*gScreenHeight/3)); 
	
   	CMenuScreen::DrawGameScreen();
	}

// -----------------------------------------------------------------------------		
// Pause Screen	
// -----------------------------------------------------------------------------		
	
CGameScreen* CPauseScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CPauseScreen* me = new (ELeave) CPauseScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

void CPauseScreen::DrawGameScreen()
	{
	ASSERT(iBmp);
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.BitBlt(iPos, iBmp);
	}

void CPauseScreen::ProcessInput(TUint& aKeyState)
	{
	if (aKeyState & KKey5)
		{// The '5' key has been pressed, return to the main screen
		iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
		aKeyState &= ~KKey5; // Clear the input now it's been handled
		}
	}

void CPauseScreen::DeActivate()
	{
	if (iGameScreenMgr.PlayMode()==CGameScreenManager::ETwoPlayerShortlink)
		iGameScreenMgr.BluetoothManager().QuitMultiplayerGame();
	
	iGameScreenMgr.GameEngine().UnpauseGame();
	}

CPauseScreen::CPauseScreen(CGameScreenManager& aScreenMgr)
: CGameScreen(aScreenMgr)
	{}

CPauseScreen::~CPauseScreen()
	{
	delete iBmp;
	}

void CPauseScreen::ConstructL()
	{
	_LIT(KRpsBmps, "\\resource\\apps\\rps_0xA00054BC.mbm");
	CEikonEnv* eikonEnv = CEikonEnv::Static();
	iBmp = eikonEnv->CreateBitmapL(KRpsBmps, EMbmRps_0xa00054bcPausemenu);
	
	TSize size = iBmp->SizeInPixels();
	TInt width = size.iWidth;
	TInt height = size.iHeight;
	iPos = TPoint(0,0);
	if (gScreenWidth > width)
		iPos.iX = (gScreenWidth - width)/2;
		
	if (gScreenHeight > height)
		iPos.iY = (gScreenHeight - height)/2;
	}

// -----------------------------------------------------------------------------		
// Splash Screen	
// -----------------------------------------------------------------------------		
	
CGameScreen* CSplashScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CSplashScreen* me = new (ELeave) CSplashScreen(aScreenMgr);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (static_cast<CGameScreen*>(me));
	}

void CSplashScreen::DrawGameScreen()
	{
	// Game ticks at between 20 and 30 fps
	// Display splash screen for 150 ticks (approx 6 seconds)
	const TInt KSplashTimeout = 150;
	
	if (++iSplashCounter<KSplashTimeout)
		{
		ASSERT(iBmp);
		CWindowGc& gc = CCoeEnv::Static()->SystemGc();
		gc.BitBlt(iPos, iBmp);
		}
	else
		{
		iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
		}
	}

CSplashScreen::CSplashScreen(CGameScreenManager& aScreenMgr)
: CGameScreen(aScreenMgr)
	{}

CSplashScreen::~CSplashScreen()
	{
	delete iBmp;
	}

void CSplashScreen::ConstructL()
	{
	_LIT(KRpsBmps, "\\resource\\apps\\rps_0xA00054BC.mbm");
	CEikonEnv* eikonEnv = CEikonEnv::Static();
	iBmp = eikonEnv->CreateBitmapL(KRpsBmps, EMbmRps_0xa00054bcSplashscreen);
	
	TSize size = iBmp->SizeInPixels();
	TInt width = size.iWidth;
	TInt height = size.iHeight;
	iPos = TPoint(0,0);
	if (gScreenWidth > width)
		iPos.iX = (gScreenWidth - width)/2;
	else
		iPos.iX =(width = gScreenWidth)/2;
		
	if (gScreenHeight > height)
		iPos.iY = (gScreenHeight - height)/2;
	else
		iPos.iY = (height - gScreenHeight)/2;
	}

CResultScreen* CResultScreen::NewL(CGameScreenManager& aScreenMgr)
	{
	CResultScreen* me = new (ELeave) CResultScreen(aScreenMgr);
	return (me);
	}

// -----------------------------------------------------------------------------		
// Results Screen	
// -----------------------------------------------------------------------------		
void CResultScreen::DrawGameScreen()
	{
	CWindowGc& gc = CCoeEnv::Static()->SystemGc();
	gc.SetPenStyle(CGraphicsContext::ENullPen);	
	gc.UseFont(CCoeEnv::Static()->NormalFont());
	gc.SetPenColor(KRgbGray);
	
	TRoshambo roshambo = iGameScreenMgr.Roshambo();
	_LIT(KChoiceText, "You: ");
	_LIT(KNoChoice, " Nothing");
	
	TBuf<KMaxRpsTextElement> choiceText(KChoiceText);
	
	if (roshambo.LocalPlayer()==TRoshambo::ERock)
		{
		choiceText.Append(KRock());
		}
	else if (roshambo.LocalPlayer()==TRoshambo::EPaper)
		{
		choiceText.Append(KPaper());
		}
	else if (roshambo.LocalPlayer()==TRoshambo::EScissors)
		{
		choiceText.Append(KScissors());
		}
	else 
		{
		ASSERT(roshambo.LocalPlayer()==TRoshambo::ENone);
		choiceText.Append(KNoChoice());
		}

   	gc.DrawText(choiceText, TPoint(KRPSScreensHAlignment, gScreenHeight/6));    
   	
   	_LIT(KGameOppChoice, "Opponent: ");
   	TBuf<KMaxRpsTextElement> oppChoiceText(KGameOppChoice);
	
	if (roshambo.Opponent()==TRoshambo::ERock)
		{
		oppChoiceText.Append(KRock());
		}
	else if (roshambo.Opponent()==TRoshambo::EPaper)
		{
		oppChoiceText.Append(KPaper());
		}
	else if (roshambo.Opponent()==TRoshambo::EScissors)
		{
		oppChoiceText.Append(KScissors());
		}
	else 
		{
		ASSERT(roshambo.Opponent()==TRoshambo::ENone);
		oppChoiceText.Append(KNoChoice());
		}
	
   	gc.DrawText(oppChoiceText, TPoint(KRPSScreensHAlignment, gScreenHeight/3));    
   	
   	TRoshambo::TResult result = roshambo.CalculateResult();
   	
   	_LIT(KGameResult, "You ");
   	TBuf<KMaxRpsTextElement> resultText(KGameResult);
   	
   	if (result==TRoshambo::EWin)
   		{
   		_LIT(KWin, "Win!");
   		resultText.Append(KWin);
   		}
   	else if (result==TRoshambo::ELose)
   		{
   		_LIT(KLose, "Lose!");
   		resultText.Append(KLose);
   		}
   	else if (result==TRoshambo::EDraw)
   		{
   		_LIT(KDraw, "Drew!");
   		resultText.Append(KDraw);
   		}
   	else
   		{
   		ASSERT(result==TRoshambo::ENoContest);
   		_LIT(KAbandoned, "Game was abandoned");
   		resultText = KAbandoned();
   		}
   	
	//Draw the rps result
	gc.DrawText(resultText, TPoint(KRPSScreensHAlignment, gScreenHeight/2)); 
   	
   	_LIT(KPressKey, "Again? Press center key");
   	gc.DrawText(KPressKey, TPoint(KRPSScreensHAlignment, 2*gScreenHeight/3));
   	
   	_LIT(KPressQuit, "Quit? Press 5");
   	gc.DrawText(KPressQuit, TPoint(KRPSScreensHAlignment, 5*gScreenHeight/6));	
	}

void CResultScreen::ProcessInput(TUint& aKeyState)
	{
	if (aKeyState & KControllerCentre)
		{// The center  key has been pressed, return to the play screen
		if(iGameScreenMgr.PlayMode()==CGameScreenManager::ESinglePlayer)
			{			
			iGameScreenMgr.SetGameState(CGameScreenManager::EPlayScreen);
			}
		else
			{			
			iGameScreenMgr.BluetoothManager().ReplayGame();
			}
		aKeyState &= ~KControllerCentre; // Clear the input now it's been handled
		}
	else if (aKeyState & KKey5)
		{// The '5' key has been pressed to quit, return to the main screen
		iGameScreenMgr.SetGameState(CGameScreenManager::EMainScreen);
		iGameScreenMgr.BluetoothManager().QuitMultiplayerGame();
		aKeyState &= ~KKey5; // Clear the input now it's been handled
		}
	}


CResultScreen::CResultScreen(CGameScreenManager& aScreenMgr)
: CGameScreen(aScreenMgr)	
{}

// -----------------------------------
// CNotifierScreen 
// -----------------------------------

CNotifierScreen* CNotifierScreen::NewL(CGameScreenManager& aGameScreenMgr)
	{
	CNotifierScreen* me = new (ELeave) CNotifierScreen(aGameScreenMgr);
	return (me);
	}

CNotifierScreen::CNotifierScreen(CGameScreenManager& aGameScreenMgr)
:CGameScreen(aGameScreenMgr){}

CNotifierScreen::~CNotifierScreen()
{}

// This is a dummy screen that doesn't re-draw - thus allowing a notifier to be visible
void CNotifierScreen::DrawGameScreen()
	{
	
	}
