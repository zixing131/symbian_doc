/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CBluetoothDeviceDiscoverer is responsible for displaying to the player (Master role) the available
                BT devices in range from which they can choose. CBluetoothDeviceDiscoverer is implemented using the
                Rnotifier dialog that is provided by the Notifier Framework. If the application needs to customize the 
                BT discovery [by displaying to the user the BT devices in range using a custumize UI] then the
                application needs to use the RHostResolver class instead of the RNotifier class. Steps to use
                the RHostResolver are:
 
                1) RHostResolver::Open(RSocketServ &aSocketServer, TUint anAddrFamily, TUint aProtocol);
                2) RHostResolver::GetByAddress(const TSockAddr &anAddr, TNameEntry &aResult, TRequestStatus &aStatus);
                3) In the RunL store the BT address and call RHostResolver::Next() to get the next availble BT device.
                4) When the BT discovery is finished then pass the array of BT device addresses to the engine (by a callbck)
                   to be displayed by the customized UI (like a multi choice control).
                5) The Master player selects the BT devices to which she wants to connect.
                6)The App engine will create one Connector per BT device selected by the Master player
 
*/


#ifndef __BLUETOOTHDEVICEDISCOVERER_H__
#define __BLUETOOTHDEVICEDISCOVERER_H__

#include <bt_sock.h>
#include <btmanclient.h>
#include <btsdp.h>
#include "commoninterfaces.h"

/**
* CBluetoothDeviceDiscoverer
* Displays to the player the BT device in range to choose from
*/
class CBluetoothDeviceDiscoverer : public CActive
    {
public:
	/**
	* Two stage constructor
	* @param aObs Device discovery observer
	*/
    static CBluetoothDeviceDiscoverer* NewL(MBluetoothDeviceDiscovererObserver& aObs);
    
	/**
	* Destructor
	*/
    ~CBluetoothDeviceDiscoverer();
    
	/**
	* Displays the BT device in range for the player to choose from
	* @param aSelectionFilter	pckgbuf to send paramaters to the device selection dialog via the notifier framework
	*/
    void DiscoverAndSelectDeviceL(const TBTDeviceSelectionParamsPckg& aSelectionFilter);
private:
	/**
	* Constructor
	* @param aObs	Device discovery observer
	*/
    CBluetoothDeviceDiscoverer(MBluetoothDeviceDiscovererObserver& aObs);
    
	/**
	* Second phase constructor 
	*/
    void ConstructL();
  
    //From CActive
	/**
	* Handles CBluetoothDeviceDiscoverer's completion events
	*/
    void RunL();
    
	/**
	* Cancels an oustanding Notifier request
	*/
    void DoCancel();
    
	/**
	* Handles a leave occurring in the request completion event handler RunL()
	* @param aError	 The leave code
	* @return TInt	 The default implementation returns aError.A derived class implementation should return KErrNone,
	*				 if it handles the leave; otherwise it should return any suitable value to cause the handling
	*				 of the error to be propagated back to the active scheduler.
	*/
	virtual TInt RunError(TInt aError);
private:
	/**
	* The reference to the device discoverer observer
	*/
	MBluetoothDeviceDiscovererObserver& iObserver;
	
	/**
	* A handle to the Notifier Server's session 
	*/
	RNotifier iBTDevicesNotifier;
	
	/**
	* Pckgbuf to retrieve the response from the device selection dialog via the Notifier framework
	*/
	TBTDeviceResponseParamsPckg iResponse;
    };

#endif // __BLUETOOTHDEVICEDISCOVERER_H__
