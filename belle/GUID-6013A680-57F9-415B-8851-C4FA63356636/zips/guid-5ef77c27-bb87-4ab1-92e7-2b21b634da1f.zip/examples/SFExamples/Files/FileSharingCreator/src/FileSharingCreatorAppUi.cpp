/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */ 

// INCLUDES
#include <f32file.h>
#include <eikapp.h>
#include <FileSharingCreator.rsg>

#include "FileSharingCreatorAppUi.h"
#include "FileSharingCreatorMainView.h"
#include "FileSharingCreator.hrh"

// CONSTANTS
_LIT(KDataFileName,   "filesharing.txt");
_LIT(KClientFileName, "FileSharingClient.exe");

const TInt KFileServerSlot = 1;
const TInt KFileHandleSlot = 2;

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CFileSharingCreatorAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	
	iMainView = CFileSharingCreatorMainView::NewL(ClientRect());
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileSharingCreatorAppUi::~CFileSharingCreatorAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CFileSharingCreatorAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EFileSharingCreatorTransferToProcess:
			{
			DoTransferFileL();
			
			iEikonEnv->InfoWinL(
				R_FILESHARINGCREATOR_CAPTION,
				R_FILESHARINGCREATOR_TRANSFERRED);
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}

	

// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CFileSharingCreatorAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}



void CFileSharingCreatorAppUi::DoTransferFileL()
	{
	// Connect to the file server session and share it.
	RFs fs;
	User::LeaveIfError(fs.Connect());
	CleanupClosePushL(fs);
	User::LeaveIfError(fs.ShareProtected());
	
	// Get the file name that is located in the private folder.
	RBuf privatePath;
	privatePath.Create(KMaxFileName);
	fs.PrivatePath(privatePath);
	TParsePtrC parseAppPath(Application()->AppFullName());
	TParse parse;
	parse.Set(parseAppPath.Drive(), &privatePath, &KDataFileName);
	
	// Open the file to be shared.
	RFile file;
	User::LeaveIfError(file.Open(fs, parse.FullName(), EFileRead));
	CleanupClosePushL(file);
	
	// Create the process that will use the file.
	RProcess process;
	User::LeaveIfError(process.Create(KClientFileName, KNullDesC));
	CleanupClosePushL(process);
	
	// Transfer to process storing the RFs handle into
	// environment slot KFileServerSlot and
	// the RFile handle into slot KFileHandleSlot.
	User::LeaveIfError(file.TransferToProcess(
			process, KFileServerSlot, KFileHandleSlot));
	
	// Resume the process, which means start it.
	process.Resume();
	
	// Cleanup the resources.
	CleanupStack::PopAndDestroy(3, &fs); // close p, file, and fs
	}

// End of File
