/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */
// INCLUDE FILES
#include <barsread.h> //TResourceReader
#include <CalendarAPIexample.rsg>
#include "CalendarAPIexampleSearchContainer.h"
#include "CalendarAPIexample.pan"
#include "CalendarAPIexampleAppUi.h"
#include "CalendarAPIexampleSearchView.h"


// ================= MEMBER FUNCTIONS =======================

// constructor
CCalendarAPIexampleSearchContainer::CCalendarAPIexampleSearchContainer(CCalendarAPIexampleSearchView& aView)
    :   iSearchView(aView)
        {
        }
        
// destructor
CCalendarAPIexampleSearchContainer::~CCalendarAPIexampleSearchContainer()
    {
    }
    
// Two-phased constructor.  
CCalendarAPIexampleSearchContainer* CCalendarAPIexampleSearchContainer::NewL(const TRect& aRect,
                                                                            CCalendarAPIexampleSearchView& aView)
    {
    CCalendarAPIexampleSearchContainer* self = new (ELeave) CCalendarAPIexampleSearchContainer(aView);
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    CleanupStack::Pop(self);
    return self;
    }

// Symbian OS default constructor can leave.    
void CCalendarAPIexampleSearchContainer::ConstructL(const TRect& aRect)
    {
    CreateWindowL();    

    // Initialize component array
    InitComponentArrayL();
    
    iSearchListBox = new (ELeave) CAknSingleStyleListBox;
    iSearchListBox->SetContainerWindowL(*this); 

    TResourceReader reader; 
    CEikonEnv::Static()->CreateResourceReaderLC(reader, R_CALENDARAPIEXAMPLE_SEARCH_LIST); 
    iSearchListBox->ConstructFromResourceL(reader); 
    CleanupStack::PopAndDestroy(); //reader

    iSearchListBox->SetListBoxObserver(this);
    iSearchListBox->CreateScrollBarFrameL(ETrue);
    iSearchListBox->ScrollBarFrame()->SetScrollBarVisibilityL(  CEikScrollBarFrame::EOff,
                                                                CEikScrollBarFrame::EAuto);
    
    Components().AppendLC(iSearchListBox,1);
    CleanupStack::Pop( iSearchListBox );
    
    SetRect(aRect);
    ActivateL();
    }

// ----------------------------------------------------
// CCalendarAPIexampleSearchContainer::SizeChanged()
// Responds to size changes to set the size and 
// position of the contents of this control. 
// ----------------------------------------------------
//      
void CCalendarAPIexampleSearchContainer::SizeChanged()
    {
    if (iSearchListBox)
        {
        iSearchListBox->SetRect(Rect());
        }
    }

void CCalendarAPIexampleSearchContainer::HandleResourceChange(TInt aType)
    {
    CCoeControl::HandleResourceChange(aType);
    if ( aType==KEikDynamicLayoutVariantSwitch )
        {
        TRect rect;
        AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane, rect);
        SetRect(rect);
        }
    }

    
// ----------------------------------------------------
// CCalendarAPIexampleSearchContainer::OfferKeyEventL()
// When a key event occurs, the control framework calls 
// this function for each control on the control stack, 
// until one of them can process the key event 
// (and returns EKeyWasConsumed).
// ----------------------------------------------------
//      
TKeyResponse CCalendarAPIexampleSearchContainer::OfferKeyEventL(
                                  const TKeyEvent& aKeyEvent,TEventCode aType)
    {
    if(aType != EEventKey)
        {
        return EKeyWasNotConsumed;
        }    
    else if(iSearchListBox)
        {
        return iSearchListBox->OfferKeyEventL( aKeyEvent, aType );
        }
    else
        {
        return EKeyWasNotConsumed;
        }
    }


// ----------------------------------------------------
// CCalendarAPIexampleSearchContainer::Draw()
// This function is used for window server-initiated 
// redrawing of controls, and for some 
// application-initiated drawing.
// ----------------------------------------------------
//              
void CCalendarAPIexampleSearchContainer::Draw(const TRect& aRect) const
    {
    
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle( CGraphicsContext::ENullPen );
    gc.SetBrushColor( KRgbWhite );
    gc.SetBrushStyle( CGraphicsContext::ESolidBrush );
    gc.DrawRect( aRect );
    
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleSearchContainer::SearchType()
// Returns the selected search range (week, month,...)
// ----------------------------------------------------
//          
TSearchType CCalendarAPIexampleSearchContainer::SearchType() const
    {
    switch (iSearchListBox->CurrentItemIndex())
        {
        case 0:
            return EWeek;
        case 1:
            return EMonth;
        case 2:
            return ESixMonths;
        case 3:
            return EYear;
        default:
            Panic(EUnSupportedSearchType);
            break;
        }
    return EWeek;
    }    

// ----------------------------------------------------
// CCalendarAPIexampleSearchContainer::HandleListBoxEventL()
// Handles listbox events.
// ----------------------------------------------------
//  

void CCalendarAPIexampleSearchContainer::HandleListBoxEventL(CEikListBox* /*aListBox*/, TListBoxEvent aEventType)
    {
    if (aEventType == EEventEnterKeyPressed || aEventType == EEventItemDoubleClicked)
        {
        iSearchView.HandleCommandL(ECalendarAPIexampleCmdSearch);
        }
    }


// end of file
