/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

// INCLUDE FILES
#include "CalendarAPIexampleEntryItemList.h"
#include "CalendarHelperEntry.h"
#include "CalendarAPIexampleEntryView.h"
#include <AknQueryDialog.h>

// ================= MEMBER FUNCTIONS =======================


// ----------------------------------------------------
// CCalendarAPIexampleEntryItemList::CreateSettingItemL()
// Framework method to create a setting item based upon 
// the user id aSettingId. The client code decides what
// type to construct. new (ELeave) must then be used and
// the resulting pointer returned. Ownership is 
// thereafter base class's responsibility.
// ----------------------------------------------------
//
CAknSettingItem* CCalendarAPIexampleEntryItemList::CreateSettingItemL( 
                                                            TInt aIdentifier )
    {   
    CAknSettingItem* settingItem = NULL;

    // create a setting item for each setting list resource
    switch (aIdentifier)
    {
    case ECalendarAPIexampleNameItem:
        {
        settingItem = new (ELeave) CAknTextSettingItem(aIdentifier, iName);
        break;
        }
    case ECalendarAPIexampleDateItem:
        settingItem = new (ELeave)  CAknTimeOrDateSettingItem(  
                                            aIdentifier, 
                                            CAknTimeOrDateSettingItem::EDate,
                                            iDate);
        break;
    case ECalendarAPIexampleAlarmItem:
        settingItem = new (ELeave) CAknBinaryPopupSettingItem(aIdentifier, 
                                                              iAlarm);
        break;
    case ECalendarAPIexampleAlarmTimeItem:
        settingItem = new (ELeave)  CAknTimeOrDateSettingItem(
                                            aIdentifier, 
                                            CAknTimeOrDateSettingItem::ETime,
                                            iAlarmTime);
        break;
    case ECalendarAPIexampleAlarmDateItem:
        settingItem = new (ELeave)  CAknTimeOrDateSettingItem(  
                                            aIdentifier, 
                                            CAknTimeOrDateSettingItem::EDate,
                                            iAlarmDate);
        break;
    case ECalendarAPIexampleSyncItem:
        settingItem = new (ELeave) CAknEnumeratedTextPopupSettingItem(  aIdentifier, 
                                                                        iSync);
        break;
    default:
        break;
        }
    return settingItem;
    
    }


    
// ----------------------------------------------------
// CCalendarAPIexampleEntryItemList::SetData()
// Reads values to each item in item list from the given
// entry.
// ----------------------------------------------------
//  
void CCalendarAPIexampleEntryItemList::SetData(const CCalHelperEntry& aData)
    {
    iName = aData.Name();
    iDate = aData.Date();
    iAlarm = (aData.Alarm() != 0);
    iAlarmTime = aData.AlarmTime();
    iAlarmDate = aData.AlarmTime();
    iSync = aData.SynchronizationMethod();
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleEntryItemList::SaveL()
// Sets value from itemlist to the given entry. Returns
// false if user input was invalid, otherwise true is
// returned.
// ----------------------------------------------------
//  
TBool CCalendarAPIexampleEntryItemList::SaveL()
    {
    StoreSettingsL();
    return ETrue;
    }

void CCalendarAPIexampleEntryItemList::GetValues(TDes& aName, TTime& aDate,
                   TBool& aAlarm, TTime& aAlarmTime,
                            TInt& aSync)
    {
    TDateTime alarmTime = iAlarmTime.DateTime();
    TDateTime alarmDate = iAlarmDate.DateTime();
    
    alarmTime.SetYear(alarmDate.Year());
    alarmTime.SetMonth(alarmDate.Month());
    alarmTime.SetDay(alarmDate.Day());    
    
    aName = iName;
    aDate = iDate;
    aAlarm = iAlarm;
    aAlarmTime = alarmTime;
    aSync = iSync;    
    
    }

void CCalendarAPIexampleEntryItemList::SetValues(
                            const TDesC& aName,
                            const TDateTime& aDate,
                            const TBool& aAlarm,
                            const TDateTime& aAlarmTime,
                            const TInt& aSync)                            
    {
    iName = aName;
    iDate = aDate;
    iAlarm = aAlarm;
    iAlarmTime = aAlarmTime;
    iAlarmDate = aAlarmTime;
    iSync = aSync;    
    }


// End of File
