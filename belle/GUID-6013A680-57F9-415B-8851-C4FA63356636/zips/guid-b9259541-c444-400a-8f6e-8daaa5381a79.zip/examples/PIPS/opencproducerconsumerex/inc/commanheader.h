/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/


#ifndef COMMANHEADER_H
#define COMMANHEADER_H

/* INCLUDE FILES */
#include <semaphore.h>

#define MAX_CLIENTS 	10
#define KPortNum 		2222
#define KMSGQKEY 		1000
#define KMAXSENDMSG  	100

#define	IN_SET_LOOPBACK_ADDR(a) \
	{ (a)->sin_addr.s_addr  = 0x0100007F; (a)->sin_family = AF_INET; }


/* Structure used for sending details to the Producer and Consumers */
typedef struct 
{
	int   noOfItems;
	int   noOfConsumers;
	sem_t itemLock;
} ThreadParam;

/* Structure defining Items to be Produced */
typedef struct 
{
	int    itemNum;
	char   itemName[50];
} ProducedItem;



/**
 * Declaration of Producer Thread Entry Point 
 * @param aParam - argument to thread Entry function
 *
 * @return thread return value
 */
void* ProducerThreadEntryPoint( void* aParam );

/**
 * Declaration of Consumer Thread Entry Point 
 * @param aParam - argument to thread Entry function
 *
 * @return thread return value
 */
void* ConsumerThreadEntryPoint( void* aParam );

#ifdef __cplusplus
extern "C" 
{
#endif
/**
 * Declaration of Function that creats Observing Thread
 * @param aNoOfMsg - Number of messages
 *
 * @return Nothing
 */
void CreateObserverThread( int aNoOfMsg );

/**
 * Declaration of Function that Push Item onto Stack
 * @param aItem - Item to be pushed
 *
 * @return Nothing
 */
void PushOntoStack( ProducedItem* aItem );

/**
 * Declaration of Function that Pop Item from Stack
 * @return aItem - Item Poped
 */
ProducedItem* PopFromStack();

/**
 * Declaration of Function that frees up Item
 * @param aItem - Item to be Deleted
 * @return Nothing
 */
void FreeItem(ProducedItem* aItem);

#ifdef __cplusplus
}
#endif


#endif /*COMMANHEADER_H*/

/*  End of File */
