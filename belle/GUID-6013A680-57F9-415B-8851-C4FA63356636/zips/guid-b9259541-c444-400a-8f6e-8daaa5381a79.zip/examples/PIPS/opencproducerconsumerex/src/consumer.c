/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/



/* INCLUDE FILES */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>

#include "CommanHeader.h"

/*****************************************************************************
*  ConsumerThreadEntryPoint
*  Function: Consumer Thread that consumes as amny as needed items when 
*  Producer has enough items produced
*  It also informs the Observer thread about item consumed
*******************************************************************************/

void* ConsumerThreadEntryPoint( void* aParam ) 
{
	ThreadParam* args = (ThreadParam*) aParam;
	int yetToConsume = args->noOfItems;
	int clientId = args->noOfConsumers;
	ProducedItem* consumeItem;
	int ret = 0;
	key_t msgQFd = -1;

	/* Construct the message to be send thru msg q */
	struct msgbuf* sendMsg = (struct msgbuf*)malloc(KMAXSENDMSG);
	sendMsg->mtype = 1;
	
	/* Get the Handler to Observer Msg Q */
	msgQFd = msgget(KMSGQKEY, IPC_CREAT);

	while (yetToConsume != 0) 
	{
		/* Acquire the Lock before checking for items available from Producer */
		sem_wait(&args->itemLock);
		/* Pop item from Producved Item-Stack */
		consumeItem = PopFromStack();
		if (consumeItem == NULL) 
		{
			/* No items in the Stack */
			sem_post(&args->itemLock);
			continue;
		}
		yetToConsume--;
		/* Inform the Observer about Item Consumption */
		sprintf(&sendMsg->mtext, " Consumer#%d Consuming Produced %s\0", clientId, consumeItem->itemName);
		ret = msgsnd(msgQFd, sendMsg, strlen(sendMsg->mtext)+4, 0);

		/* Release the Lock once after getting an item */
		sem_post(&args->itemLock);
		FreeItem(consumeItem);
	}

	free( sendMsg );
	return (int*)0;
}


/*  End of File */
