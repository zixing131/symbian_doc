// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CAudioTonePlayer declaration
// 
// 


#ifndef AUDIOTONEPLAYER_H
#define AUDIOTONEPLAYER_H

// INCLUDE FILES
#include <e32std.h>
#include <e32base.h>
#include <MdaAudioTonePlayer.h>

// CLASS DECLARATION

class CAudioTonePlayer : public CBase, public MMdaAudioToneObserver
	{
public: // Constructors and destructor
	static CAudioTonePlayer* NewL();
	static CAudioTonePlayer* NewLC();
	~CAudioTonePlayer();

public: // Public methods
	void PlayTone(TInt aFrequency, TTimeIntervalMicroSeconds aDuration);
	void PlayDualTone(TInt aFrequency1, TInt aFrequency2,
			TTimeIntervalMicroSeconds aDuration);
	void Stop();
	
private: // Constructors
	CAudioTonePlayer();
	void ConstructL();
	
private: // From MMdaAudioToneObserver
	void MatoPrepareComplete(TInt aError);
	void MatoPlayComplete(TInt aError);

private: // Private methods
	void DisplayErrorMessage(TInt aError);
	
private:
	CMdaAudioToneUtility* iTonePlayer;
	};

#endif // AUDIOTONEPLAYER_H

// End of File
