// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CAudioTonePlayer implementation
// 
// 


// INCLUDE FILES
#include <eikenv.h>
#include "AudioTonePlayer.h"

// CONSTANTS
const TInt KVolumeDenominator = 2;

// METHODS DEFINITION

CAudioTonePlayer::CAudioTonePlayer()
	{
	}

CAudioTonePlayer::~CAudioTonePlayer()
	{
	delete iTonePlayer;
	}

CAudioTonePlayer* CAudioTonePlayer::NewLC()
	{
	CAudioTonePlayer* self = new (ELeave)CAudioTonePlayer();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CAudioTonePlayer* CAudioTonePlayer::NewL()
	{
	CAudioTonePlayer* self=CAudioTonePlayer::NewLC();
	CleanupStack::Pop(self);
	return self;
	}

void CAudioTonePlayer::ConstructL()
	{
	iTonePlayer = CMdaAudioToneUtility::NewL(*this);
	}

void CAudioTonePlayer::PlayTone(TInt aFrequency,
		TTimeIntervalMicroSeconds aDuration)
	{
	Stop();
	iTonePlayer->PrepareToPlayTone(aFrequency, aDuration);
	}

void CAudioTonePlayer::PlayDualTone(TInt aFrequency1, TInt aFrequency2,
		TTimeIntervalMicroSeconds aDuration)
	{
	Stop();
	iTonePlayer->PrepareToPlayDualTone(aFrequency1, aFrequency2,
			aDuration);
	}

void CAudioTonePlayer::Stop()
	{
	iTonePlayer->CancelPlay();
	}

void CAudioTonePlayer::MatoPrepareComplete(TInt aError)
	{
	if (KErrNone == aError)
		{
		iTonePlayer->SetVolume(iTonePlayer->MaxVolume()
				/ KVolumeDenominator);
		iTonePlayer->Play();
		}
	else
		{
		// Do something when error happens.
		DisplayErrorMessage(aError);
		}
	}

void CAudioTonePlayer::MatoPlayComplete(TInt aError)
	{
	if (KErrNone == aError)
		{
		}
	else
		{
		// Do something when error happens.
		DisplayErrorMessage(aError);
		}
	}

void CAudioTonePlayer::DisplayErrorMessage(TInt aError)
	{
	const TInt KMaxBuffer = 15;
	_LIT(KErrorMessage, "Error: %d");
	TBuf<KMaxBuffer> buffer;
	buffer.AppendFormat(KErrorMessage, aError);
	TRAP_IGNORE(CEikonEnv::Static()->InfoWinL(KNullDesC, buffer));
	}

// End of File
