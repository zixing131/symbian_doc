// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __AUDIOTONE_MAINVIEW_H__
#define __AUDIOTONE_MAINVIEW_H__

// INCLUDES
#include <aknview.h>
#include <akndef.h>

// FORWARD DECLARATION
class CEikEdwin;

// CLASS DECLARATION

class CAudioToneMainView : public CCoeControl
	{
public: // Constructors and destructor
	static CAudioToneMainView* NewL(const TRect& aRect);
	static CAudioToneMainView* NewLC(const TRect& aRect);
	~CAudioToneMainView();
	
public: //  New methods
	void SetTextL(const TDesC& aText);
	
private: // Constructor
	void ConstructL(const TRect& aRect);

private: // From CoeControl
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;

	void Draw(const TRect& aRect) const;
	void SizeChanged();
	
private:
	CEikEdwin* iEikEdwin;
	};

#endif // __AUDIOTONE_MAINVIEW_H__

// End of File
