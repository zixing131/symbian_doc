// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <AudioTone.rsg>

#include "AudioToneAppUi.h"
#include "AudioToneMainView.h"
#include "AudioTonePlayer.h"
#include "AudioTone.hrh"

// CONSTANTS
const TInt KOneSecond = 1000 * 1000;

const TInt KOctaveA = 440;

const TInt KFrequencyOne1 = 1209;
const TInt KFrequencyOne2 = 697;

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CAudioToneAppUi::ConstructL()
	{


	BaseConstructL(EAknEnableSkin);
	
	iMainView = CAudioToneMainView::NewL(ClientRect());

	
	iTonePlayer = CAudioTonePlayer::NewL();
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CAudioToneAppUi::~CAudioToneAppUi()
    {
    delete iTonePlayer;
    

    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }

    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CAudioToneAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{

		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:

		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EAudioTonePlayTone:
			{
			iTonePlayer->PlayTone(KOctaveA,
					TTimeIntervalMicroSeconds(2 * KOneSecond));
			break;
			}
		
		case EAudioTonePlayDualTone:
			{
			iTonePlayer->PlayDualTone(KFrequencyOne1, KFrequencyOne2,
					TTimeIntervalMicroSeconds(KOneSecond));
			break;
			}
			
		case EAudioToneStopTone:
			{
			iTonePlayer->Stop();
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}

	


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CAudioToneAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


	
// End of File
