// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactReadField.rsg>

#include "ContactReadFieldAppUi.h"
#include "ContactReadFieldMainView.h"
#include "ContactRead.h"
#include "ContactReadField.hrh"

void CContactReadFieldAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactReadFieldMainView::NewL(ClientRect());

	iContactReader = CContactRead::NewL();
	}
	
CContactReadFieldAppUi::~CContactReadFieldAppUi()
    {
    delete iContactReader;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CContactReadFieldAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactReadField:
			{
			TFieldType type = KUidContactFieldGivenName;
			CContactDatabase& cntDb = iContactReader->CntDatabase();
			TContactItemId cntId = cntDb.OwnCardId();
			// this is just one easy way to get a TContactItemId.
			// the \PIM\PopulateContact sample code would have created
			// an own card.
			if (KNullContactId != cntId)
				{
				CDesCArray* result = NULL;
				TRAPD(error, result = iContactReader->ReadTextFieldL(cntId, type));
				// report error on the Label control
				if (KErrNone == error)
					{
					CleanupStack::PushL(result);
					if (result->Count() > 0)
						{
						iMainView->SetTextL(result->MdcaPoint(0));
						}
					else
						{
						_LIT(KFieldNotFound, "Field Not Found");
						iMainView->SetTextL(KFieldNotFound());
						}
					CleanupStack::PopAndDestroy(result);
					}
				else
					{
					_LIT(KErrorMsg, "Symbian Error Code = %D");
					TBuf<32> errorBuf;
					errorBuf.Format(KErrorMsg(), error);
					iMainView->SetTextL(errorBuf);
					}
				}
			else
				{
				_LIT(KCardNotFound, "No Own Card");
				iMainView->SetTextL(KCardNotFound());
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactReadFieldAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
