// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <ContactReadField.rsg>

#include "ContactReadFieldMainView.h"

CContactReadFieldMainView* CContactReadFieldMainView::NewL(const TRect& aRect)
	{
	CContactReadFieldMainView* self = CContactReadFieldMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

CContactReadFieldMainView* CContactReadFieldMainView::NewLC(const TRect& aRect)
	{
	CContactReadFieldMainView* self = new (ELeave) CContactReadFieldMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

CContactReadFieldMainView::~CContactReadFieldMainView()
	{
	delete iEikEdwin;
	}
	
void CContactReadFieldMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_CONTACTREADFIELD);	
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

void CContactReadFieldMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawNow();
		}
	}

TInt CContactReadFieldMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

CCoeControl* CContactReadFieldMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return NULL;
	}

void CContactReadFieldMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void CContactReadFieldMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
