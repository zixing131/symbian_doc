// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactRead.h"

CContactRead* CContactRead::NewL()
	{
	CContactRead* self = new (ELeave) CContactRead();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactRead::~CContactRead()
	{
	delete iCntDb;
	}

void CContactRead::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	}

CContactDatabase& CContactRead::CntDatabase()
	{
	return *iCntDb;
	}

CDesCArray* CContactRead::ReadTextFieldL(TContactItemId aCntId, TFieldType aType)
	{
	CDesCArray* result = new (ELeave) CDesCArrayFlat(2);
	CleanupStack::PushL(result);
	CContactItemViewDef* viewDef = CContactItemViewDef::NewLC(
										CContactItemViewDef::EIncludeFields,
										CContactItemViewDef::EMaskHiddenFields);
	viewDef->AddL(aType);
	CContactItem* item = iCntDb->ReadContactLC(aCntId, *viewDef);
	CContactItemFieldSet& fieldSet = item->CardFields();

	for(TInt ii = 0 ; ii < fieldSet.Count() ; ++ii)
		{
		CContactItemField& field = fieldSet[ii];
		if (KStorageTypeText == field.StorageType())
			{
			if (field.TextStorage()->IsFull())
				{
				const TPtrC value = field.TextStorage()->Text();
				result->AppendL(value);
				}
			}
		}

	CleanupStack::PopAndDestroy(item);
	CleanupStack::PopAndDestroy(viewDef);
	CleanupStack::Pop(result);
	return result;
	}

// End of File
