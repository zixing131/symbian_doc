/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *  
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * Neither the name of Nokia Corporation nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Description:  Header file of nfc AIW handler engine class.
 * 
 */

#ifndef __NFCAIWENGINE_H__
#define __NFCAIWENGINE_H__


// System Include Files
#include <AiwCommon.h>
#include <AiwCommon.hrh>
#include <AiwServiceHandler.h>
#include <AiwGenericParam.h>

// User Include Files.
#include "nfcshareconst.h"

// Forward declarations.
class NfcShareWrapper;

/*
 * This class implements AIW framework notify call back handler method,
 * easy sharing service setup and sharing of files(vCard, vCal). 
 */
class CNfcAiwEngine : public CBase, public MAiwNotifyCallback
    {
public:
    static CNfcAiwEngine* NewL( NfcShareWrapper* aNfcShareWrapper);
    static CNfcAiwEngine* NewLC( NfcShareWrapper* aNfcShareWrapper);
    virtual ~CNfcAiwEngine();
    
    TInt StartEasySetupServiceL();
    void StopServiceL();
    TInt StartSharingServiceL(NfcSharingType aSharingType);
    
    // From MAiwNotifyCallback.
    TInt HandleNotifyL(
        TInt aCmdId,
        TInt aEventId,
        CAiwGenericParamList& aEventParamList,
        const CAiwGenericParamList& aInParamList);
      
private:
    void ConstructL();
    CNfcAiwEngine(NfcShareWrapper* aNfcShareWrapper);
    TInt DoCommandL( const TDesC& aFileName, TInt error );
    
public:
    // Pointer to wrapper class to emit signals.
    NfcShareWrapper* iNfcShareWrapper; 
    
private:
    CAiwServiceHandler* iAiwServiceHandler; // Pointer to AIW service handler.
    RFs iFs;  // File system handle.
    RFile iFile; // File handle of shared file.
    NfcSharingType iSharingType; // Type of sharing.
    };

#endif  // __NFCAIWENGINE_H__

