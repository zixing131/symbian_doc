/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *  
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * Neither the name of Nokia Corporation nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Description:  source file of nfc share main window.
 * 
 */

// User Include Files.
#include "nfcsharewindow.h"
#include "nfcsharewrapper.h"

// System Include Files.
#include <QMessageBox>


/*
 * Constructor, create an instance of the wrapper class, initializes the UI by 
 * creating menubar and populates the menu items and 
 * connects signals to the slots.
 */
NfcShareWindow::NfcShareWindow(QWidget *parent) : QMainWindow(parent)
{
    mNfcShareWrapper = new NfcShareWrapper();   
    menubar = new QMenuBar(this);
    menubar->setObjectName(QString::fromUtf8("menubar"));
    menubar->setGeometry(QRect(0, 0, 800, 18));
    setMenuBar(menubar);

    createMenu();
}
/*
 * Creates the menu actions items, populate them to menubar and 
 * connect to respective handlers for the actions.
 */
void NfcShareWindow::createMenu()
{
    // Add start easy setup menu item.
    menu_startEasySetup= new QAction(tr("Start Easy setup"), this);
    menuBar()->addAction(menu_startEasySetup);
    connect(menu_startEasySetup, SIGNAL(triggered()), this, SLOT(startEasySetupService()));
       
	// Add start sharing vCard menu item.
    menu_startSharingvCard= new QAction(tr("Start Sharing vCard"), this);
    menuBar()->addAction(menu_startSharingvCard);
    connect(menu_startSharingvCard , SIGNAL(triggered()), this, SLOT(startSharingvCard()));

    // Add start sharing vCal menu item.
    menu_startSharingvCal= new QAction(tr("Start Sharing vCal"), this);
    menuBar()->addAction(menu_startSharingvCal);
    connect(menu_startSharingvCal , SIGNAL(triggered()), this, SLOT(startSharingvCal()));

    // Add stop easy setup menu item.
    menu_stopEasySetup = new QAction(tr("Stop Easy setup"), this);
    menuBar()->addAction(menu_stopEasySetup);
    connect(menu_stopEasySetup, SIGNAL(triggered()), this, SLOT(stopEasySetupService()));

    // Add help menu item.
    menu_helpAction = new QAction(tr("Help"), this);
    menuBar()->addAction(menu_helpAction);
    connect(menu_helpAction, SIGNAL(triggered()), this, SLOT(helpAction()));
    
    // Add About menu item.
    menu_aboutAction = new QAction(tr("About"), this);
    menuBar()->addAction(menu_aboutAction);
    connect(menu_aboutAction, SIGNAL(triggered()), this, SLOT(aboutAction()));
    
    // Add Exit menu item.
    menu_exitAction = new QAction(tr("Exit"), this);
    menuBar()->addAction(menu_exitAction);
    connect(menu_exitAction, SIGNAL(triggered()), this, SLOT(close()));
    
    // Connect the window updated signal of wrapper class to notify window slot.
    connect(mNfcShareWrapper, SIGNAL(windowUpdated(QString)), this, SLOT(notifyWindow(QString)));
}
/*
 * Displays the help message.
 */
void NfcShareWindow::helpAction()
{
    QMessageBox msgBox;
    // Display the help message.
    msgBox.setInformativeText("Select \"Start Easy Setup\" menu option, holding the NFC enabled devices close to commuinicate over NFC channel. "
            "After pairing over the bearer channel, select \"Start Sharing  vCard or vCal \" menu option to transfer vCard or vCal.");
    msgBox.exec();
}
/*
 * Displays the application details message.
 */
void NfcShareWindow::aboutAction()
{
    QMessageBox msgBox;
    // Display the application details.
    msgBox.setInformativeText("NFC Sharing application, Ver 1.0 Copyright (c) 2010 Nokia.  All rights reserved");
    msgBox.exec();
}

/*
 * Starts the vCard sharing operation.
 */
void NfcShareWindow::startSharingvCard()
{  
    mNfcShareWrapper->startSharingService(ENfcvCard);
}

/*
 * Starts the calendar event sharing operation.
 */
void NfcShareWindow::startSharingvCal()
{
    mNfcShareWrapper->startSharingService(ENfcvCal);
}
/*
 * Starts the easy setup service to pair the devices.
 */	
void NfcShareWindow::startEasySetupService()
{
    mNfcShareWrapper->startEasySetupService();
}

/*
 * Stops the setup service to disable current communication.
 */
void NfcShareWindow::stopEasySetupService()
{
    mNfcShareWrapper->stopService();
}

/*
 * Notification messages from the AIW handler displayed to user.
 * @param aStrMsg The message to be displayed to user.
 */
void NfcShareWindow::notifyWindow(QString aStrMsg)
{
    QMessageBox msgBox;
    msgBox.setInformativeText(aStrMsg);
    msgBox.exec();
}

/*
 * Destructor.
 */
NfcShareWindow::~NfcShareWindow()
{
    if(mNfcShareWrapper)
        {
        delete mNfcShareWrapper;
        mNfcShareWrapper = NULL;
        }
}
