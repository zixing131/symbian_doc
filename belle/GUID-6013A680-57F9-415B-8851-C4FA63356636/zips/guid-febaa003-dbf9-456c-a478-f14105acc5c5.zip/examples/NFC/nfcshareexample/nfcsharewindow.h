/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *  
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * Neither the name of Nokia Corporation nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Description:  Header file of nfc share main window.
 * 
 */


#ifndef NFCSHAREWINDOW_H
#define NFCSHAREWINDOW_H

// System Include Files.
#include <QtGui/QMainWindow>
#include <QtGui/QAction>
#include <QtGui/QMenuBar>
QT_BEGIN_NAMESPACE

// Forward declarations.
class NfcShareWrapper;

/*
 * NfcShareWindow: Main window of the NFC sharing example. 
 */
class NfcShareWindow : public QMainWindow
{
    Q_OBJECT

public:
	NfcShareWindow(QWidget *parent = 0);
    ~NfcShareWindow();
    void createMenu();
    
signals:
    void windowUpdated(QString text);
    
public slots: // Slots to receive action of menu trigger.
    void helpAction();
    void aboutAction();
    void notifyWindow(QString text);
	void startSharingvCard();
	void startSharingvCal();
    void startEasySetupService();
    void stopEasySetupService();

private:
    
    // Actions for menu items.
    QAction* menu_helpAction;  
    QAction* menu_aboutAction;
    QAction* menu_exitAction;
    QAction* menu_startEasySetup;
    QAction* menu_stopEasySetup;
    QAction* menu_startSharingvCal;
	QAction* menu_startSharingvCard;
	// Menubar.
    QMenuBar *menubar;  
    // Wrapper class pointer to call the signals.
    NfcShareWrapper* mNfcShareWrapper; 
   
};
QT_END_NAMESPACE
#endif // NFCSHAREWINDOW_H
