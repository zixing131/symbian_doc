/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *  
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * Neither the name of Nokia Corporation nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Description:  Source file for nfc AIW handler engine class.
 * 
 */

// User Include Files.
#include "nfcsharewrapper.h"
#include "nfcaiwengine.h"

/*
 * Constructor which will not leave. 
 */
CNfcAiwEngine::CNfcAiwEngine(NfcShareWrapper* aNfcShareWrapper) : iNfcShareWrapper(aNfcShareWrapper)
    {
    }

/*
 * Two phase Constructor.
 * @param aNfcShareWrapper The wrapper class pointer.
 */
CNfcAiwEngine* CNfcAiwEngine::NewL(NfcShareWrapper* aNfcShareWrapper)
    {
    CNfcAiwEngine* self = CNfcAiwEngine::NewLC(aNfcShareWrapper);
    CleanupStack::Pop();
    return self;
    }

/*
 * Two phase Constructor.
 * @param aNfcShareWrapper The wrapper class pointer.
 */
CNfcAiwEngine* CNfcAiwEngine::NewLC(NfcShareWrapper* aNfcShareWrapper)
    {
    CNfcAiwEngine* self = new (ELeave) CNfcAiwEngine(aNfcShareWrapper);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

/*
 * Standard EPOC 2nd phase constructor.
 */ 
void CNfcAiwEngine::ConstructL()
    {
    iAiwServiceHandler = CAiwServiceHandler::NewL();
    }

/*
 * Destructor.
 */
CNfcAiwEngine::~CNfcAiwEngine()
    {
    iFs.Close();
    if (iAiwServiceHandler)
        {
         delete iAiwServiceHandler;
         iAiwServiceHandler = NULL;
        }
    }

/*
 * Starts the easy setup service.
 */
TInt CNfcAiwEngine::StartEasySetupServiceL()
    {
    // Create AIW interest.
    RCriteriaArray interest;
    CleanupClosePushL(interest);
    TUid base;
    _LIT8(KContentType,"*");
    base.iUid = KAiwClassBase;
    CAiwCriteriaItem* criteria = CAiwCriteriaItem::NewLC( KAiwCmdNFCEasySetup, KAiwCmdNFCEasySetup, KContentType );
    criteria->SetServiceClass(base);
    User::LeaveIfError(interest.Append(criteria));

    // Attach to AIW interest.
    iAiwServiceHandler->Reset();
    iAiwServiceHandler->AttachL(interest);
    
    iAiwServiceHandler->ExecuteServiceCmdL( KAiwCmdNFCEasySetup,
            iAiwServiceHandler->InParamListL(),
            iAiwServiceHandler->OutParamListL(), KAiwOptASyncronous, this);
    CleanupStack::PopAndDestroy(2); // criteria, interest. 
    return KErrNone;
    }

/*
 * StartSharingServiceL(NfcSharingType aSharingType)
 * starts the sharing of files based on sharing type parameter.
 * @param aSharingType specifies the type of file shared.
 */
TInt CNfcAiwEngine::StartSharingServiceL(NfcSharingType aSharingType)
    {
    // Create AIW interest.
    RCriteriaArray interest;
    CleanupClosePushL(interest);
    iSharingType = aSharingType;
    TUid base;
    base.iUid = KAiwClassBase;
    _LIT8(KContentType,"*");
    CAiwCriteriaItem* criteria = CAiwCriteriaItem::NewLC( KAiwCmdNFCGiveUi, KAiwCmdNFCGiveUi, KContentType);
    criteria->SetServiceClass(base);
    User::LeaveIfError(interest.Append(criteria));

    // Attach to AIW interest.
    iAiwServiceHandler->Reset();
    iAiwServiceHandler->AttachL(interest);

    iAiwServiceHandler->ExecuteServiceCmdL(KAiwCmdNFCGiveUi,
            iAiwServiceHandler->InParamListL(),
            iAiwServiceHandler->OutParamListL(), KAiwOptASyncronous, this);
    CleanupStack::PopAndDestroy(2); // criteria, interest.
    return KErrNone;
    }

/*
* Handles notifications caused by an asynchronous Execute CommandL call
* or an event. 
* The result of command processing is sent as signal to UI. 
* @param aCmdId The service command associated to the event.
* @param aEventId Occured event, see AiwCommon.hrh.
* @param aEventParamList Event parameters, if any, as defined per
*        each event.
* @param aInParamList Input parameters, if any, given in the
*        related HandleCommmandL.
* @return Error code for the callback.
*/

TInt CNfcAiwEngine::HandleNotifyL(TInt aCmdId, TInt aEventId,
        CAiwGenericParamList& /* aEventParamList */,
        const CAiwGenericParamList& /* aInParamList */)
    {
    
    // Process based on command id and the event id.
    if (aCmdId == KAiwCmdNFCEasySetup && aEventId == KAiwEventStarted)
        {  
        QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated
                ("Easy setup will complete, if you tap it with a NFC device.")));

        }    
    else if (aCmdId == KAiwCmdNFCGiveUi && aEventId == KAiwEventStarted)
        {
        TInt err = KErrNone;
        if (ENfcvCard == iSharingType) 
            { 
            QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated
                    ("sharing vCard started.")));
            DoCommandL( KVCardFileName, err );
            }
        else if(ENfcvCal == iSharingType)
            { 
            QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated
                                ("sharing vCal started.")));
            DoCommandL( KCalenderFileName, err );
            }
        }
    else if ( aCmdId == KAiwCmdNFCGiveUi && aEventId == KAiwEventCompleted)
        {
        
        // Send nothification to UI that file sharing is complete.
        if (ENfcvCard == iSharingType) 
            { 
            QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated("vCard sharing is successfully completed")));
            }
        else if(ENfcvCal == iSharingType)
            { 
            QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated("vCal sharing is successfully completed")));
            }        
        iAiwServiceHandler->Reset();
        } 

    else if ( aCmdId == KAiwCmdNFCEasySetup && aEventId == KAiwEventCompleted )
        {
        
        // Send notification to the UI that easy set up is complete.
        QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated("Easy set up is complete.")));
        iAiwServiceHandler->Reset();
        }
    else if ( aCmdId == KAiwCmdNFCGiveUi && aEventId == KAiwEventError )
        {
        
        // Send notifcation to the UI that error occured during asynchronous tranfer request. 
        QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated("Error during asynchronous transfer request! Please try again")));
        iAiwServiceHandler->Reset();
        }
    else if ( aCmdId == KAiwCmdNFCEasySetup && aEventId == KAiwEventError )
        {
        
        // Send notifcation to the UI that error occured during asynchronous setup request.
        QT_TRYCATCH_LEAVING(emit(iNfcShareWrapper->windowUpdated("Error during asynchronous service setup request!")));
        iAiwServiceHandler->Reset();
        }
    
    else if ( aEventId == KAiwEventCanceled )
        {
        
        // Sharing cancelled.
        iAiwServiceHandler->Reset();
        }
    else if ( aEventId == KAiwEventError )
        {
        
        // AIW event failure. so reset the service handler.
        iAiwServiceHandler->Reset();
        }
    else
        {
        
        // Sharing failed, so reset the service handler.
        iAiwServiceHandler->Reset();
        }
    return KErrNone;
    }

/*
 * StopserviceL: stop the AIW service handlers from taking new request by deleting handler
 * and create a new handler for subsequent uses.
 */
void CNfcAiwEngine::StopServiceL()
    {
    iAiwServiceHandler->Reset();
    if(iAiwServiceHandler)
        {
        delete iAiwServiceHandler;
        }
    iAiwServiceHandler = CAiwServiceHandler::NewL();
    }

/*
 * DoCommandL
 * Executes the command to share the file via NFC channel(KAiwCmdNFCGive)
 * @param aFileName The file name to be shared.
 * @param error Failure value returned to the calling method.
 */
TInt CNfcAiwEngine::DoCommandL( const TDesC& aFileName, TInt error )
    {
    error = iFs.Connect();
    if (error == KErrNone)
        {
        error = iFs.ShareProtected();
        }

    if (error == KErrNone)
        {// Open file to be shared in read or sharereadonly mode.
        error = iFile.Open(iFs, aFileName, EFileRead | EFileShareReadersOnly);
        }
    if (error != KErrNone)
        {
        return error;
        }
     
     CAiwGenericParamList* inParamList = CAiwGenericParamList::NewLC();
     TAiwGenericParam obj(EGenericParamFile, TAiwVariant(iFile));
     
     // Attach the file to inParamList.
     inParamList->AppendL(obj);
     
     // Send the file via NFC (asynchronous).
     iAiwServiceHandler->ExecuteServiceCmdL( KAiwCmdNFCGiveUi, *inParamList,
                                             iAiwServiceHandler->OutParamListL(), KAiwOptASyncronous,
                                             this);
     CleanupStack::PopAndDestroy(); // inParamList.
     iFile.Close(); 
     iFs.Close();
     return error;
    }
