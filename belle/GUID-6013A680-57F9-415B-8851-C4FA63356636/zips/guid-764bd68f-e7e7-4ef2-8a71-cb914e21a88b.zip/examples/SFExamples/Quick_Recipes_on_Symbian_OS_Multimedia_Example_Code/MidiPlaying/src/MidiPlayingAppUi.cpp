// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <eikapp.h>
#include <f32file.h>
#include <MidiPlaying.rsg>

#include "MidiPlayingAppUi.h"
#include "MidiPlayingMainView.h"
#include "MidiPlaying.hrh"

// CONSTANTS
_LIT(KFileName, "\\data\\sample.mid");

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CMidiPlayingAppUi::ConstructL()
	{

	BaseConstructL(EAknEnableSkin);
	
	iMainView = CMidiPlayingMainView::NewL(ClientRect());
	
	iMidiPlayer = CMidiPlayer::NewL();
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CMidiPlayingAppUi::~CMidiPlayingAppUi()
    {
    delete iMidiPlayer;    

    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }

    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CMidiPlayingAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{

		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:

		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EMidiPlayingPlay:
			{
			// Construct file name.
			// It adds drive letter to KFileName, where drive letter
			// is the same as the application's executable.
			TParsePtrC parseAppPath(Application()->AppFullName());
			TParse parseFileName;
			parseFileName.Set(parseAppPath.Drive(), 0, &KFileName);
			
			iMidiPlayer->Play(parseFileName.FullName());
			break;
			}
			
		case EMidiPlayingStopPlaying:
			{
			iMidiPlayer->Stop();
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}	


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CMidiPlayingAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


// End of File
