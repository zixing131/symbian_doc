// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef MIDIPLAYER_H
#define MIDIPLAYER_H

// INCLUDE FILES
#include <e32std.h>
#include <e32base.h>
#include <midiclientutility.h>

// CLASS DECLARATION

class CMidiPlayer : public CBase, public MMidiClientUtilityObserver
	{
public: // Constructors and destructor
	static CMidiPlayer* NewL();
	static CMidiPlayer* NewLC();
	~CMidiPlayer();

public: // New methods
	void Play(const TDesC& aFileName);
	void Stop();
	
private:
	CMidiPlayer();
	void ConstructL();

private:// From MMidiClientUtilityObserver
	void MmcuoStateChanged(TMidiState aOldState, TMidiState aNewState,
			const TTimeIntervalMicroSeconds &aTime, TInt aError);
	void MmcuoTempoChanged(TInt aMicroBeatsPerMinute);
	void MmcuoVolumeChanged(TInt aChannel, TReal32 aVolumeInDecibels);
	void MmcuoMuteChanged(TInt aChannel, TBool aMuted);
	void MmcuoSyncUpdate(const TTimeIntervalMicroSeconds &aMicroSeconds,
			TInt64 aMicroBeats);
	void MmcuoMetaDataEntryFound(const TInt aMetaDataEntryId,
			const TTimeIntervalMicroSeconds &aPosition);
	void MmcuoMipMessageReceived(const RArray< TMipMessageEntry > &aMessage);
	void MmcuoPolyphonyChanged(TInt aNewPolyphony);
	void MmcuoInstrumentChanged(TInt aChannel, TInt aBankId,
			TInt aInstrumentId);

private: // Public methods
	void DisplayErrorMessage(TInt aError);
	
private: // Member variables
	CMidiClientUtility* iMidiUtility;
	};

#endif // MIDIPLAYER_H

// End of File
