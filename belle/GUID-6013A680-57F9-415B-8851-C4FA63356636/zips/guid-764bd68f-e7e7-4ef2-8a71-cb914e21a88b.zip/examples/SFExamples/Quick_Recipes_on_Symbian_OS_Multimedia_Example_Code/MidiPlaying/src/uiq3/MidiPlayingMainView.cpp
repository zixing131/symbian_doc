// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <MidiPlaying.rsg>

#include "MidiPlayingExternalInterface.h"
#include "MidiPlayingAppUi.h"
#include "MidiPlayingMainView.h"
#include "MidiPlaying.hrh"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CMidiPlayingMainView* CMidiPlayingMainView::NewL(CQikAppUi& aAppUi)
	{
	CMidiPlayingMainView* self = NewLC(aAppUi);
	CleanupStack::Pop(self);
	return self;
	}

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CMidiPlayingMainView* CMidiPlayingMainView::NewLC(CQikAppUi& aAppUi)
	{
	CMidiPlayingMainView* self = new (ELeave) CMidiPlayingMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CMidiPlayingMainView::CMidiPlayingMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CMidiPlayingMainView::~CMidiPlayingMainView()
	{
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CMidiPlayingMainView::ConstructL()
	{
	BaseConstructL();
	}
	
// --------------------------------------------------------------------------
// Called when this view is first time activated.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_MIDIPLAYING_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EMidiPlayingLabelCtrl);
	}

// --------------------------------------------------------------------------
// Returns the identifier of this view.
// --------------------------------------------------------------------------
TVwsViewId CMidiPlayingMainView::ViewId()const
	{
	return TVwsViewId(KUidMidiPlayingApp, KUidMidiPlayingMainView);
	}

// --------------------------------------------------------------------------
// Handles user command.
// In this example, all commands are sent to AppUi because
// we want to have the same code with S60.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the label has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
