// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <MidiPlaying.rsg>

#include "MidiPlayingMainView.h"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CMidiPlayingMainView* CMidiPlayingMainView::NewL(const TRect& aRect)
	{
	CMidiPlayingMainView* self = CMidiPlayingMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CMidiPlayingMainView* CMidiPlayingMainView::NewLC(const TRect& aRect)
	{
	CMidiPlayingMainView* self = new (ELeave) CMidiPlayingMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CMidiPlayingMainView::~CMidiPlayingMainView()
	{
	delete iEikEdwin;
	}
	
// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CMidiPlayingMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = CEikonEnv::Static()->AllocReadResourceLC(
		R_MIDIPLAYING_TEXT);	
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Returns the number of controls.
// In this example, it returns 1 because there is only one
// control, which is an edwin control.
// --------------------------------------------------------------------------
TInt CMidiPlayingMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

// --------------------------------------------------------------------------
// Returns the pointer of the controls.
// In this example, it returns the pointer of the edwin control.
// --------------------------------------------------------------------------
CCoeControl* CMidiPlayingMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return 0;
	}

// --------------------------------------------------------------------------
// Called when this control needs to be redrawn.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the edwin has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CMidiPlayingMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
