/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __BIOMESSAGE_H__
#define __BIOMESSAGE_H__


#include "BIOParser.h"

#include <sendas2.h>
#include <csendasaccounts.h>
#include <csendasmessagetypes.h>

// System Includes
#include <e32cons.h>

_LIT(KTestTitle, "BIO Parser Example" );

_LIT(KBodyText, "Every man passes his life in the search after friendship.");
_LIT(KAddress1, "9980501111");
_LIT(KAddress3, "9980502222");
_LIT(KAddress4, "9980503333");
_LIT(KAlias1, "alias1");
_LIT(KAlias2, "alias2");
_LIT(KSubject, "HELLO");

class CDummyObserver;
class CBioMessage : public CBase
{
public:
	static CBioMessage* NewL();
	~CBioMessage();
	void StartL();

	void Connect();
	void CreateL(RSendAsMessage& aMessage);
	void SendL(RSendAsMessage& aMessage);
	void ParseL();

private:
	CBioMessage();
	void ConstructL();
	void CleanMailFolderL(TMsvId aFolderId);

private:
	CConsoleBase* 			iConsole;

	RSendAs 				iSendAs;	
	CDummyObserver* 		iObserver;
	CMsvSession* 			iSession;
	CMsvEntry* 				iEntry;
	CMsvEntrySelection* 	iSelection;
};


class CDummyObserver : public CBase, public MMsvSessionObserver
{
public:
	void HandleSessionEventL(TMsvSessionEvent, TAny*, TAny*, TAny*) {};
};

#endif /*__BIOMESSAGE_H__*/
