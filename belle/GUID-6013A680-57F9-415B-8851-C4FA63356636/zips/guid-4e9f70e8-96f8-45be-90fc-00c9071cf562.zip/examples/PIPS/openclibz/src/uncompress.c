/*
Copyright (c) 2006-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/



/** @file uncompress.c
*    In this file I uncompress the file using libz api's
*    Here i make use of libz api which can read compressed files
*/
#include "OpenCLibzheader.h"

//
// In case of any error , display the error message .
//
void Error(const char * msg)
{
    printf( " %s\n",  msg);
    getchar();
    getchar();
    exit(1);
}



//Compresses the file using libz api's

void GzUnCompress(gzFile   in, FILE     * out)

{
    static char buf[BUFLEN];
    int len;
    int err;

    for (;;)
    {
        len = gzread(in, buf, sizeof(buf)); //libz api to read a compressed file
        if (len < 0) Error (gzerror(in, &err));
        if (len == 0) break;

        if ((int)fwrite(buf, 1, (unsigned)len, out) != len)
        {
            Error("failed fwrite");
        }
    }
   if (fclose(out)) Error("failed fclose");

   if (gzclose(in) != Z_OK) // libz api to close a compressed file

   Error("failed gzclose");



}




//UnCompresses the file using libz api's

void FileUnCompress( char  * file )

{
    static char buf[MAX_NAME_LEN];
    char *infile, *outfile;
    FILE  *out;
    gzFile in;
    char choice[3];
    uInt len = (uInt)strlen(file);
    strcpy(buf, file);

    if (len > SUFFIX_LEN && strcmp(file+len-SUFFIX_LEN, GZ_SUFFIX) == 0)
    {
        infile = file;
        outfile = buf;
        outfile[len-3] = '\0'; //create the output filename
    }
    else
    {
        outfile = file;
        infile = buf;
        strcat(infile, GZ_SUFFIX); //create the input filename
    }
    in = gzopen(infile, "rb"); // libz api to open a compressed file

    if (in == NULL)
    {

      Error("file not found ...try again \n");

    }
    out = fopen(outfile, "wb"); //open the output filename
    if (out == NULL)
    {
    gzclose(in);       // libz api to close a compressed file
    }

    GzUnCompress(in, out);

    printf("do you want to delete the original file (y /n) \n");

    scanf("%s",choice);

    if(choice[0] == 'y')
    unlink(file);
    printf(" Congrats .... uncompression done ...u can find uncompressed file in the same directory as of the source file\n");

}

/*  End of File */
