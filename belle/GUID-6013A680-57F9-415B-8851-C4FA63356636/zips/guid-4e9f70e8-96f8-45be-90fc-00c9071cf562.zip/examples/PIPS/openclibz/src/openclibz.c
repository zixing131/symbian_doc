/*
Copyright (c) 2006-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/


//#include <staticlibinit_gcce.h>

#include "OpenCLibzheader.h"




/** @file OpenCLibz.c
 The Libz example demonstrates how to use libz library to compress files and decompress it.
 Any kind of file ( txt , doc , xls , xml , mpeg , ppt , mp3 etc) can be compressed .
 This example can compress a file as well as string and it can decompress 
 a compressed file (.gz)
*/ 




// This aplication works with eshell as well ....so i have taken care of argumets 
/* ===========================================================================
 * Usage:  OpenCLibz [-d] [-f] [-h] [-r] [-1 to -9] [files...]
 *   -d : decompress
 *   -f : compress with Z_FILTERED
 *   -h : compress with Z_HUFFMAN_ONLY
 *   -r : compress with Z_RLE
 *   -1 to -9 : compression level
 *   files : absolute path
*/
//If user runs through the icon then he will be asked to enter the options.
//
int main (int argc, char *argv[])
	{
    char outmode[20];
    char  name[20+1]; // name of the file
    int uncompr = 0;//mode parameters to choose 
	
    strcpy(outmode, "wb6 ");
    
    argc--, argv++;

    while (argc > 0) 
    {
      if (strcmp(*argv, "-d") == 0)
        uncompr = 1;
      else if (strcmp(*argv, "-f") == 0)
        outmode[3] = 'f';
      else if (strcmp(*argv, "-h") == 0)
        outmode[3] = 'h';
      else if (strcmp(*argv, "-r") == 0)
        outmode[3] = 'R';
      else if ((*argv)[0] == '-' && (*argv)[1] >= '1' && (*argv)[1] <= '9' &&
               (*argv)[2] == 0)
        outmode[2] = (*argv)[1];
      else
        break;
      argc--, argv++;
    }
    if (outmode[3] == ' ')
        outmode[3] = 0;
    if (argc == 0) 
    {
      char choice;
      printf("enter the mode to process \n \n");
      printf("  h for Huffman only compression \n");      	
      printf("  f for filtered data compression\n");
      printf("  R for run-length encoding compression\n");
      printf("  d for decompress \n ");
      printf(" s to  compress a string\n\n " );      
      
      choice = getchar();
      
      if(choice == 'd')
      uncompr = 1;
      else 
      outmode[3] = choice;
      if(choice == 's')
      {
     		StringCompress();
      }
      else if (uncompr) 
      {
            printf("enter the filename to compress....for example if log.txt.gz is there in c drive then type  \n");    
        	
        	printf(" c:\\log.txt.gz  \n\n\n");
        	
        	scanf("%20s", name);        	   
        
        	FileUnCompress(name);
      }
      else
      {  
        	printf("enter the filename to compress....for example if log.txt is there in c drive then type  \n");
        	
        	printf(" c:\\log.txt  \n\n\n");
        	
        	scanf("%20s",name);        	
	  			
        	FileCompress(name, outmode);
      }
    } 
    else
    {
        do 
        {
            if (uncompr) 
            {
                FileUnCompress(*argv);
            } else {
                FileCompress(*argv, outmode);
            }
        } while (argv++, --argc);
    }

	 getchar();
	 getchar();
	 fclose(stdin);
	 fclose(stdout);
	 fclose(stderr);


    return 0;

	}


/*  End of File */
