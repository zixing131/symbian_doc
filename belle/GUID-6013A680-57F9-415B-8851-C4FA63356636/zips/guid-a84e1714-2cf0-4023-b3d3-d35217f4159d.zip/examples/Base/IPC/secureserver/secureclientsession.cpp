/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:
Contains the implementation of functions defined in the RSecureSession class.� 
*/


/**
 @file
*/

#include "secureclientandserver.h"
#include "secureclient.h"

/**
Constructor.
*/
RSecureSession::RSecureSession()
	{
	}

/**
Connects to the server using 4 message slots.
This creates a new session with the server.
In this example, the server is implemented as a separate thread. If the server is not running, the function starts the server before it tries to create a session with it.
The version information defines the lowest version of the server with which this client is compatible. Version compatibility is checked when the server side session is created. In this example, the version of the server and the version requested by the client are the same. This is because they are defined by constants common to the client source code and the server source code.
In a real application, versions would be defined independently.
@return KErrNone, if successful; otherwise, the value returned by StartThread() or CreateSession() if they were unsuccessful.
@see StartThread()
@see CSecureServer::NewSessionL()
@see RSecureSession::Version()
*/
TInt RSecureSession::Connect()
	{
	TInt r = StartThread(iServerThread);
	if (r == KErrNone)
		{
		r = CreateSession(KSecureServerName,Version(),KDefaultMessageSlots);
		}
	return(r);
	}

/**
Gets the lowest version of the server with which this client is compatible.
This is a client-side definition. If the server version is lower than this value, connection fails. In a real application, this is how a client can make sure that the server can provide the services that the client expects. The design of the client-server framework assumes that newer versions of a server are backward compatible with older versions of the server.
@return The version of the server that this client requires.
*/
TVersion RSecureSession::Version(void) const
	{
	return(TVersion(KSecureServMajorVersionNumber,KSecureServMinorVersionNumber,KSecureServBuildVersionNumber));
	}

/**
Deletes all handles associated with session.
*/
void RSecureSession::Close()
	{
	SendReceive(ESecureServerCloseSession);
	RHandleBase::Close();
	iServerThread.Close();
	}

/**
Gets the resource count from the server.
The resource count is the number of subsessions attached to the session.
@return The resource count.
*/
TInt RSecureSession::ResourceCountL()
	{
	TInt count = 0;
	TPckgBuf<TInt> pckgcount;
	TIpcArgs args(&pckgcount);
	User::LeaveIfError(SendReceive(ESecureServerResourceCount, args));
	count = pckgcount();
	return count;
	}
