// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <ContactWriteNewField.rsg>

#include "ContactWriteNewFieldExternalInterface.h"
#include "ContactWriteNewFieldAppUi.h"
#include "ContactWriteNewFieldMainView.h"
#include "ContactWriteNewField.hrh"

// MEMBER FUNCTIONS

CContactWriteNewFieldMainView* CContactWriteNewFieldMainView::NewLC(CQikAppUi& aAppUi)
	{
	CContactWriteNewFieldMainView* self = new (ELeave) CContactWriteNewFieldMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CContactWriteNewFieldMainView::CContactWriteNewFieldMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

CContactWriteNewFieldMainView::~CContactWriteNewFieldMainView()
	{
	}

void CContactWriteNewFieldMainView::ConstructL()
	{
	BaseConstructL();
	SetExtentToWholeScreen();
	}
	
void CContactWriteNewFieldMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_CONTACTWRITENEWFIELD_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EContactWriteNewFieldLabelCtrl);
	}

TVwsViewId CContactWriteNewFieldMainView::ViewId()const
	{
	return TVwsViewId(KUidContactWriteNewFieldApp, KUidContactWriteNewFieldMainView);
	}

void CContactWriteNewFieldMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

void CContactWriteNewFieldMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

void CContactWriteNewFieldMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
