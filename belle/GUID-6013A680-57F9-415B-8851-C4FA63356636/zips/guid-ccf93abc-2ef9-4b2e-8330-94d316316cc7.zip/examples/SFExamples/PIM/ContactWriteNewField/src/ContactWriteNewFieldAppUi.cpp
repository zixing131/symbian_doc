// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactWriteNewField.rsg>

#include "ContactWriteNewFieldAppUi.h"
#include "ContactWriteNewFieldMainView.h"
#include "ContactWrite.h"
#include "ContactWriteNewField.hrh"

void CContactWriteNewFieldAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactWriteNewFieldMainView::NewL(ClientRect());
	iContactWriter = CContactWrite::NewL();
	}
	
CContactWriteNewFieldAppUi::~CContactWriteNewFieldAppUi()
    {
    delete iContactWriter;
	delete iMainView;
    }

void CContactWriteNewFieldAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		case EContactWriteNewFieldAddEmployer:
			{
			_LIT(KNewEmployer, "Symbian Press Ltd");
			CContactDatabase& cntDb = iContactWriter->CntDatabase();
			TContactItemId cntId = cntDb.OwnCardId();
			// this is just one easy way to get a TContactItemId.
			// the \PIM\PopulateContact sample code would have created
			// an own card without an employer.
			if (KNullContactId != cntId)
				{
				TRAPD(error, iContactWriter->AddEmployerL(cntId, KNewEmployer()));
				// report error on the Label control
				if (KErrNone == error)
					{
					_LIT(KSuccess, "It Worked!");
					iMainView->SetTextL(KSuccess());
					}
				else
					{
					_LIT(KErrorMsg, "Symbian Error Code = %D");
					TBuf<32> errorBuf;
					errorBuf.Format(KErrorMsg(), error);
					iMainView->SetTextL(errorBuf);
					}
				}
			else
				{
				_LIT(KNotFound, "No Own Card");
				iMainView->SetTextL(KNotFound());
				}
			break;
			}
		default:
			break;
		}
	}

	

void CContactWriteNewFieldAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

	
// End of File
