/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:
Contains the E32Main() function, which executes the example.
The example demonstrates the use of local condition variable IPC mechanism. The threads created in the process use this condition variable to co-operate with each other.
The example performs the following tasks:
- create an object of the CQueue class, which in turn crates a queue of integer tokens
- create an object of the CProducer class, which in turn creates the producer thread
- create an object of the CConsumer class, which in turn creates the consumer thread
- create an object of the CUserInterface class ,which accepts asynchronous key press events from the console.
The CUserInterface class provides an interface for the user to interact with the threads created in the example.
The CQueue::iCondVar is the local condition varaibale that is used by the two threads to co-operate with each other.� 
*/



/**
 @file
 @see CQueue.
 @see CProducer.
 @see CConsumer.
 @see CUserInterface.
*/

#include "globals.h"
#include "queue.h"
#include "producer.h"
#include "consumer.h"
#include "userinterface.h"

LOCAL_D CConsoleBase* console;
LOCAL_C void DoExampleL();
LOCAL_C void callExampleL();

LOCAL_C void DoExampleL()
	{
	CActiveScheduler* scheduler = new (ELeave) CActiveScheduler();
	CleanupStack::PushL(scheduler);
	CActiveScheduler::Install(scheduler);

	// Create an object of the CQueue class.
	CQueue* tokens = CQueue::NewL();
	CleanupStack::PushL(tokens);

	// Print the KTextInvokeProducer string and wait for a key press.
	_LIT(KTextInvokeProducer,"Creating and starting the Producer Thread...[This produces a token every two seconds]\n");
	console->Printf(KTextInvokeProducer);
	_LIT(KTxtPressAnyKeyToContinue,"[press any key to continue]\n");
	console->Printf(KTxtPressAnyKeyToContinue);
	console->Getch();
	// Create an object of the CProducer class.
	CProducer* prod = CProducer::NewL(console,tokens);
	CleanupStack::PushL(prod);

	// Print the KTextInvokeConsumer string and wait for a key press.
	_LIT(KTextInvokeConsumer,"Creating and starting the Consumer Thread...[This consumes a token every second]\n");
	console->Printf(KTextInvokeConsumer);
	console->Printf(KTxtPressAnyKeyToContinue);
	console->Getch();

	// Create an object of the CConsumer class.
	CConsumer* cons = CConsumer::NewL(console,tokens);
	CleanupStack::PushL(cons);

	// Create an object of the CUserInterface class.
	// This handles key press requests from the console.
	CUserInterface* ui = CUserInterface::NewL(console,prod);
	CleanupStack::PushL(ui);
	
	_LIT(KTextStartAS,"Starting the active scheduler...\n");
	console->Printf(KTextStartAS);
	// Issue an asynchronous read request.
	ui->ReadFunc();
	// Start the active scheduler.
	CActiveScheduler::Start();

	CleanupStack::PopAndDestroy(5,scheduler);
	}

GLDEF_C TInt E32Main()
    {
	__UHEAP_MARK;
	CTrapCleanup* cleanup=CTrapCleanup::New();
	TRAPD(error,callExampleL());
	delete cleanup;
	__ASSERT_ALWAYS(!error,User::Panic(KTxtEPOC32EX,error));
	__UHEAP_MARKEND;
	return 0;
    }

LOCAL_C void callExampleL()
    {
	console=Console::NewL(KTxtExampleCode,TSize(KConsFullScreen,KConsFullScreen));
	CleanupStack::PushL(console);
	TRAPD(error,DoExampleL());
	if (error)
		console->Printf(KFormatFailed, error);
	else
		console->Printf(KTxtOK);
	console->Printf(KTxtPressAnyKey);
	console->Getch();
	CleanupStack::PopAndDestroy();
    }
