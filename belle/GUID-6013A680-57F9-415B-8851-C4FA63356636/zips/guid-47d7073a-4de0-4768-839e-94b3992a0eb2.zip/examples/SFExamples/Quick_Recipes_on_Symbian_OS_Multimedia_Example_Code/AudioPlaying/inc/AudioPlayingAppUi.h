// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef AUDIOPLAYINGAPPUI_H
#define AUDIOPLAYINGAPPUI_H


#include <aknappui.h>

class CAudioPlayingMainView;
class CSimpleAudioPlayer;


class CAudioPlayingAppUi : public CAknAppUi

    {
public:
	void ConstructL();
	~CAudioPlayingAppUi();

	void HandleCommandL(TInt aCommand);	

	void HandleResourceChangeL(TInt aType);


private:
	CAudioPlayingMainView* iMainView;
	CSimpleAudioPlayer* iAudioPlayer;

	};

#endif // AUDIOPLAYINGAPPUI_H

// End of File
