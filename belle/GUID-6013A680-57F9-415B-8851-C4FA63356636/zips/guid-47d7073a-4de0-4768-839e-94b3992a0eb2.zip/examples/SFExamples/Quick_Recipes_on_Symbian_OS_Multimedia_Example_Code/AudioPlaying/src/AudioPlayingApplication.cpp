// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikstart.h>

#include "AudioPlayingExternalInterface.h"
#include "AudioPlayingApplication.h"
#include "AudioPlayingDocument.h"

TUid CAudioPlayingApplication::AppDllUid() const
	{
	return KUidAudioPlayingApp;
	}

CApaDocument* CAudioPlayingApplication::CreateDocumentL()
	{
	return CAudioPlayingDocument::NewL(*this);
	}

CApaApplication* NewApplication()
	{
	return new CAudioPlayingApplication();
	}
	
GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication(NewApplication);
	}
	
	
// End of File
