// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDE FILES
#include <eikenv.h>
#include "SimpleAudioPlayer.h"

// CONSTANTS
const TInt KOneSecond = 1000 * 1000; // 1 second in microseconds
const TInt KVolumeDenominator = 2;

// METHODS DEFINITION

CSimpleAudioPlayer::CSimpleAudioPlayer()
	{
	}

CSimpleAudioPlayer::~CSimpleAudioPlayer()
	{
	delete iPlayerUtility;
	}

CSimpleAudioPlayer* CSimpleAudioPlayer::NewLC()
	{
	CSimpleAudioPlayer* self = new (ELeave) CSimpleAudioPlayer();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CSimpleAudioPlayer* CSimpleAudioPlayer::NewL()
	{
	CSimpleAudioPlayer* self = CSimpleAudioPlayer::NewLC();
	CleanupStack::Pop(self);
	return self;
	}

void CSimpleAudioPlayer::ConstructL()
	{
	iPlayerUtility = CMdaAudioPlayerUtility::NewL(*this);
	}

void CSimpleAudioPlayer::PlayL(const TDesC& aFileName)
	{
	iPlayerUtility->Close();
	iPlayerUtility->OpenFileL(aFileName);
	}

void CSimpleAudioPlayer::Pause()
	{
	iPlayerUtility->Pause();
	}

void CSimpleAudioPlayer::Resume()
	{
	iPlayerUtility->Play();
	}

void CSimpleAudioPlayer::Stop()
	{
	iPlayerUtility->Stop();
	}

void CSimpleAudioPlayer::Rewind(TInt aIntervalInSeconds)
	{
	iPlayerUtility->Pause();
	
	// Get the current position of the playback.
	TTimeIntervalMicroSeconds position;
	iPlayerUtility->GetPosition(position);
	
	// Add the interval to the current position.
	position = position.Int64() - aIntervalInSeconds * KOneSecond;
	
	// Set the new position.
	iPlayerUtility->SetPosition(position);
	iPlayerUtility->Play();
	}

void CSimpleAudioPlayer::FastForward(TInt aIntervalInSeconds)
	{
	iPlayerUtility->Pause();
	
	// Get the current position of the playback.
	TTimeIntervalMicroSeconds position;
	iPlayerUtility->GetPosition(position);
	
	// Subtract the interval from the current position.
	position = position.Int64() + aIntervalInSeconds * KOneSecond;
	
	// Set the new position.
	iPlayerUtility->SetPosition(position);
	iPlayerUtility->Play();
	}

void CSimpleAudioPlayer::MapcInitComplete(TInt aError,
		const TTimeIntervalMicroSeconds& /*aDuration*/)
	{
	if (KErrNone == aError)
		{
		iPlayerUtility->SetVolume(
				iPlayerUtility->MaxVolume() / KVolumeDenominator);
		iPlayerUtility->Play();
		}
	else
		{
		iPlayerUtility->Close();
		
		// Do something when an error happens.
		DisplayErrorMessage(aError);
		}
	}

void CSimpleAudioPlayer::MapcPlayComplete(TInt aError)
	{
	if (KErrNone == aError)
		{
		// Do something when the playback can be completed successfully.
		}
	else
		{
		// Do something when an error happens.
		DisplayErrorMessage(aError);
		}
	}

void CSimpleAudioPlayer::DisplayErrorMessage(TInt aError)
	{
	const TInt KMaxBuffer = 15;
	_LIT(KErrorMessage, "Error: %d");
	TBuf<KMaxBuffer> buffer;
	buffer.AppendFormat(KErrorMessage, aError);
	TRAP_IGNORE(CEikonEnv::Static()->InfoWinL(KNullDesC, buffer));
	}

// End of File
