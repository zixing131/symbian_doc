// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __AUDIOPLAYING_MAINVIEW_H__
#define __AUDIOPLAYING_MAINVIEW_H__

// INCLUDE FILES
#include <aknview.h>
#include <akndef.h>

class CEikEdwin;

// CLASS DECLARATION

class CAudioPlayingMainView : public CCoeControl
	{
public: // Constructors and destructor
	static CAudioPlayingMainView* NewL( const TRect& aRect );
	static CAudioPlayingMainView* NewLC( const TRect& aRect );
	~CAudioPlayingMainView();
	
public: //  New methods
	void SetTextL(const TDesC& aText);
	
private: // Constructor
	void ConstructL( const TRect& aRect );

private: // From CoeControl
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;

	void Draw(const TRect& aRect) const;
	void SizeChanged();
	
private:
	CEikEdwin* iEikEdwin;
	};

#endif // __AUDIOPLAYING_MAINVIEW_H__

// End of File
