/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CSendDTMF.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CSendDTMF class
*/
CSendDTMF* CSendDTMF::NewL(MExecAsync* aController)
	{
	CSendDTMF* self = new(ELeave) CSendDTMF(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.  Cancels outstanding requests.
*/
CSendDTMF::~CSendDTMF()
	{
	Cancel();
	}

/**
Sends DTMF tones as specified in aNumber.

@param aNumber Descriptor containing the DTMF tones to send
*/
void CSendDTMF::DoStartRequestL(const TDesC& aNumber)
	{
	if (aNumber.Length() == 1)
		{
		iSingleTone = ETrue;
		}
	else
		{
		iSingleTone = EFalse;
		}
	
	// Transmits DTMF tones across all the currently active voice calls.
	iTelephony->SendDTMFTones(iStatus, aNumber);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CSendDTMF::CSendDTMF(MExecAsync* aController)
	: CISVAPIAsync(aController, KSendDTMF)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CSendDTMF::ConstructL()
	{
	iSingleTone = EFalse;
	}

/**
Checks iStatus and prints details to console.
*/
void CSendDTMF::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		if (iSingleTone)
			{
			iConsole->Printf(_L("Beep\n"));
			ExampleNotify();
			}
		else
			{
			iConsole->Printf(_L("Beeps\n"));
			ExampleComplete();
			}
		}
	}

/**
Cancels asynchronous request to CTelephony::SendDTMFTones().
*/
void CSendDTMF::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::ESendDTMFTonesCancel);
	}
