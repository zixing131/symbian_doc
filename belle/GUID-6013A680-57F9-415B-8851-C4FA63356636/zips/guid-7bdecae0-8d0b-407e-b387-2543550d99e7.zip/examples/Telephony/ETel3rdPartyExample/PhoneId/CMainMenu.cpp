/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CMainMenu.h"

/**
Factory constructor.

@param  aConsole Console to which output is printed
@return          Instance of CMainMenu class
*/
CMainMenu* CMainMenu::NewLC(CConsoleBase& aConsole)
	{
	CMainMenu* self = new(ELeave) CMainMenu(aConsole);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

/**
Constructor. Called by factory constructor CMainMenu::NewLC()

@param Console to which output is printed
*/
CMainMenu::CMainMenu(CConsoleBase& aConsole)
	: CBaseMenuSync(aConsole)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CMainMenu::ConstructL()
	{
	CBaseMenuSync::ConstructL();
	iPhoneId = CPhoneId::NewL(this);
	iSubscriberId = CSubscriberId::NewL(this);
	}

/**
Destructor.
Deletes owned objects.
*/
CMainMenu::~CMainMenu()
	{
	delete iPhoneId;
	delete iSubscriberId;
	}

/**
Starts the request to get the phone ID and handles errors if they are returned.
*/
void CMainMenu::RunL()
	{
	switch(iState)
		{
	case EStart:
		iState = EGetPhoneId;
		SetActive();
		CompleteOwnRequest(KErrNone);
		break;
	case EEnd:
		CActiveScheduler::Stop();
		break;
	case EGetPhoneId:
		iState = EGetSubscriberId;
		TRAPD(errPhone, iPhoneId->StartRequestL());
		if (errPhone != KErrNone)
			{
			iConsole->Printf(_L("Request left with error code "));
			iConsole->Printf(_L("%d\n"), errPhone);
			return;
			}
		break;
	case EGetSubscriberId:
		iState = EEnd;
		TRAPD(errSub, iSubscriberId->StartRequestL());
		if (errSub != KErrNone)
			{
			iConsole->Printf(_L("%d\n"), errSub);
			return;
			}
		break;
	case EDummyAnswer:
	case EGetCallInfo:
	case EGetBatteryInfo:
	case EGetIndicator:
	case EGetLockInfo:
	case EGetSignalInfo:
	case EGetNetworkInfo:
	case EGetNetworkName:
	case EGetOperatorName:
	case EGetFlightModeInfo:
	case EGetNetworkRegStatus:
	case EGetLineStatus:
	case EGetCallStatus:
	case EAnswerIncomingCall:
	case EDialCall:
	case EGetDynamicCaps:
	case EHold:
	case EResume:
	case ESwap:
	case ESendDTMF:
	case EHangup:
	case ECallForwarding:
	case ECallWaiting:
	case ECallBarring:
	case EIdentityService:
	case EWaitingForKeyPress:
	case ESetNotifier:
	default:
		break;	
		}
	}

/**
Cancels the outstanding asynchronous request.
*/
void CMainMenu::DoCancel()
	{
	if(iState == EStart)
		{
		CompleteOwnRequest(KErrCancel);
		}
	else
		{
		iConsole->ReadCancel();
		}
	}
