/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CResume.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CResume class
*/
CResume* CResume::NewL(MExecAsync* aController)
	{
	CResume* self = new(ELeave) CResume(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CResume::~CResume()
	{
	Cancel();
	}

/**
Resumes the specified call if the dynamic call capabilities allow it.

@param aCallId Identifier of the call to resume
*/
void CResume::DoStartRequestL(CTelephony::TCallId aCallId)
	{
	_LIT(KDummyAnswerPanic, "CResume Get Method");
	__ASSERT_ALWAYS(!IsActive(), User::Panic(KDummyAnswerPanic, 1));
   iRequestNotify = EFalse;
	CTelephony::TCallCapsV1 callCapsV1;
   CTelephony::TCallCapsV1Pckg callCapsV1Pckg(callCapsV1);
   
   // Retrieves the dynamic call capabilities for calls you dialled or answered with CTelephony.
   iTelephony->GetCallDynamicCaps(aCallId, callCapsV1Pckg);

   if( callCapsV1.iControlCaps & CTelephony::KCapsResume )
      {
      // The call represented by aCallId can be resumed.
      iTelephony->Resume(iStatus, aCallId);
      SetActive();
      }
   else
      {
      // The call cannot be resumed.
      }
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CResume::CResume(MExecAsync* aController)
	: CISVAPIAsync(aController, KResume)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CResume::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and calls ExampleComplete() to notify
the menu object that the example has finished.
*/
void CResume::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the output to console if there is no error
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		ExampleComplete();
		}
	}

/**
Cancels asynchronous request to CTelephony::Resume()
*/
void CResume::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EResumeCancel);
	}

