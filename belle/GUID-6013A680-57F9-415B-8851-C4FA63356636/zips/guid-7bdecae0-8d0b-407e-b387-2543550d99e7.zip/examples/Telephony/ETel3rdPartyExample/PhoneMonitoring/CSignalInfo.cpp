/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CSignalInfo.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CSignalInfo class
*/
CSignalInfo* CSignalInfo::NewL(MExecAsync* aController)
	{
	CSignalInfo* self = new(ELeave) CSignalInfo(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CSignalInfo::~CSignalInfo()
	{
	Cancel();
	}

/**
Gets the signal strength and stores it in the iSignalStrengthV1Pckg package.
*/
void CSignalInfo::DoStartRequestL()
	{
	_LIT(KDummyAnswerPanic, "CSignalInfo Get Method");
	__ASSERT_ALWAYS(!IsActive(), User::Panic(KDummyAnswerPanic, 1));
	iRequestNotify = EFalse;
	
	// Retrieves the phone's current signal strength via the aDes argument.
	iTelephony->GetSignalStrength(iStatus, iSignalStrengthV1Pckg);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CSignalInfo::CSignalInfo(MExecAsync* aController)
	: CISVAPIAsync(aController, KSignalInfo),
	  iSignalStrengthV1Pckg(iSignalStrengthV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CSignalInfo::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the signal strength (in bars)
to the console if there is no error.
*/
void CSignalInfo::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		TInt32 strength = iSignalStrengthV1.iSignalStrength;
		TInt8 bars = iSignalStrengthV1.iBar;
		if (iRequestNotify)
			{
			iConsole->ClearScreen();
			iConsole->Printf(_L("~*THIS IS A NOTIFICATION*~\n"));
			}
		iConsole->Printf(KSignalStrengthMsg);
		iConsole->Printf(_L("There are %d bars!\n"), bars);
		iConsole->Printf(_L("Signal Strength is %d!\n"), strength);
		if (iRequestNotify)
			{
			DoRequestNotificationL();
			}
		else
			{
			ExampleComplete();
			}
		}
	}

/**
Requests to receive notifications of change in the signal strength.
*/
void CSignalInfo::DoRequestNotificationL()
   {
	// Panic if this object is already performing an asynchronous operation. 
	// Application will panic if you call SetActive() on an already active object.
	_LIT( KNotifyPanic, "CSignalInfo Notify Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = ETrue;
	
	// Registers interest in receiving change notifications for events.
	iTelephony->NotifyChange( 	iStatus,
								CTelephony::ESignalStrengthChange,
								iSignalStrengthV1Pckg );
	SetActive();
	}

/**
Cancels asynchronous request to CTelephony::GetSignalStrength().
*/
void CSignalInfo::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::ESignalStrengthChangeCancel);
	}
