/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CCallForwardingStatus.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CCallForwardingStatus class.
*/
CCallForwardingStatus* CCallForwardingStatus::NewL(MExecAsync* aController)
	{
	CCallForwardingStatus* self = new(ELeave) CCallForwardingStatus(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Cancels outstanding requests.
*/
CCallForwardingStatus::~CCallForwardingStatus()
	{
	Cancel();
	}

/**
Second phase constructor.
*/
void CCallForwardingStatus::ConstructL()
	{
	iSecondCondition = EFalse;
	}

/**
Retrieves the current forwarding status.
*/
void CCallForwardingStatus::DoStartRequestL()
	{
	_LIT( KNotifyPanic, "CCallForwardingStatus Get Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = EFalse;
	if (iSecondCondition)
		{
		iSecondCondition = EFalse;
		CTelephony::TCallForwardingCondition condition2 = CTelephony::ECallForwardingUnconditional;
		
		// Interrogates the current status of the call forwarding services.
		iTelephony->GetCallForwardingStatus(iStatus,
		                                    condition2,
		                                    iCallForwardingStatus2V1Pckg);
		}
	else
		{
		iSecondCondition = ETrue;
		CTelephony::TCallForwardingCondition condition1 = CTelephony::ECallForwardingNoReply;
		
		// Interrogates the current status of the call forwarding services.
		iTelephony->GetCallForwardingStatus(iStatus,
		                                    condition1,
		                                    iCallForwardingStatus1V1Pckg);
		}
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CCallForwardingStatus::CCallForwardingStatus(MExecAsync* aController)
	: CISVAPIAsync(aController, KCallForwardingStatus),
	  iCallForwardingStatus1V1Pckg(iCallForwardingStatus1V1),
	  iCallForwardingStatus2V1Pckg(iCallForwardingStatus2V1)
	{
	// Empty method
	}

/**
Checks the status of the active object and displays the current call forwarding
status if there is no error.
*/
void CCallForwardingStatus::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		if (!iSecondCondition)
			{
			iConsole->Printf(KCallForwardingStatusMsg);
			switch(iCallForwardingStatus1V1.iCallForwarding)
				{
			case CTelephony::EStatusActive:
				// Call Forwarding is active when there is no answer!
				// Could end application here by calling Terminate().
				// Wait for 5 seconds then continue by calling ExampleComplete().
				iConsole->Printf(_L("Call Forwarding impinges on incoming calls!\n"));
				iConsole->Printf(_L("Recify this to remove this delay\n"));
				User::After(5000000);
			case CTelephony::ENotActive:
			case CTelephony::ENotProvisioned:
			case CTelephony::ENotAvailable:
			case CTelephony::EUnknown:
				break;
				}
			switch(iCallForwardingStatus2V1.iCallForwarding)
				{
			case CTelephony::EStatusActive:
				// Call Forwarding is active on all incoming calls!
				// Could end application here by calling Terminate().
				// Wait for 5 seconds then continue by calling ExampleComplete().
				iConsole->Printf(_L("Call Forwarding impinges on incoming calls!\n"));
				iConsole->Printf(_L("Recify this to remove this delay\n"));
				User::After(5000000);
			case CTelephony::ENotActive:
			case CTelephony::ENotProvisioned:
			case CTelephony::ENotAvailable:
			case CTelephony::EUnknown:
				ExampleComplete();
				break;
				}
			}
		else
			{
			ExampleNotify();
			}
		}
	}

/**
Cancels asynchronous call to CTelephony::GetCallForwardingStatus().
*/
void CCallForwardingStatus::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EGetCallForwardingStatusCancel);
	}
