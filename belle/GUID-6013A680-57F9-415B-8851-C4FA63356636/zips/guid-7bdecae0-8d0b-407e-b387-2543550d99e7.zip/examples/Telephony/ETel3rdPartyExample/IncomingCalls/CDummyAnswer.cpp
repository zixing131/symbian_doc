/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CDummyAnswer.h"
#include "CMainMenu.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object that owns this object
@return             Instance of CDummyAnswer class
*/
CDummyAnswer* CDummyAnswer::NewL(MExecAsync* aController)
	{
	CDummyAnswer* self = new(ELeave) CDummyAnswer(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object that owns this object.
*/
CDummyAnswer::CDummyAnswer(MExecAsync* aController)
	: CActive(EPriorityStandard),
	  iController(aController)
	{
	iConsole = iController->GConsole();
	CActiveScheduler::Add(this);
	}

/**
Notifies the menu object that it has completed its request.
*/
void CDummyAnswer::ExampleComplete()
	{
	iController->ExecComplete(KNotType);
	}

/**
Second phase constructor.
*/
void CDummyAnswer::ConstructL()
	{
	// Creates a thread-relative timer
	User::LeaveIfError(iTimer.CreateLocal());
	iFirstTime = ETrue;
	}

/**
Sets iFirstTime to ETrue.
*/
void CDummyAnswer::ResetFirstTime()
	{
	iFirstTime = ETrue;
	}

/**
Destructor.
Cancels outstanding requests and closes the iTimer object.
*/
CDummyAnswer::~CDummyAnswer()
	{
	Cancel();
	iTimer.Close();
	}

/**
Starts the timer for the duration specified in aDelay.
*/
void CDummyAnswer::StartCount(TTimeIntervalMicroSeconds32 aDelay)
	{
	_LIT(KDummyAnswerPanic, "CDummyAnswer");
	__ASSERT_ALWAYS(!IsActive(), User::Panic(KDummyAnswerPanic, 1));
	iTimer.After(iStatus, aDelay);
	SetActive();
	}

/**
Checks the status of the active object and displays the current call duration
if there is no error.
*/
void CDummyAnswer::RunL()
	{
	if (iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Print console output message if there is no error
		iConsole->ClearScreen();
		iConsole->Printf(KMenuMsg);
		iConsole->Printf(KHangupMsg);
		iConsole->Printf(_L("Call Duration %d seconds\n"), iCount);
		iCount++;
		StartCount(1000000);
		}
	if (iFirstTime)
		{
		iFirstTime = EFalse;
		ExampleComplete();
		}
	}

/**
Stops counting and resets the call duration.
*/
void CDummyAnswer::DoCancel()
	{
	ResetFirstTime();
	iCount = 0;
	iTimer.Cancel();
	}
