/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CCallWaitingStatus.h"

/**
Factory constructor.
@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CFlightModeInfo class
*/
CCallWaitingStatus* CCallWaitingStatus::NewL(MExecAsync* aController)
	{
	CCallWaitingStatus* self = new(ELeave) CCallWaitingStatus(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CCallWaitingStatus::~CCallWaitingStatus()
	{
	Cancel();
	}

/**
Gets the call waiting status and stores it in the iCallWaitingStatusV1Pckg 
package.
*/
void CCallWaitingStatus::DoStartRequestL()
	{
	_LIT( KNotifyPanic, "CCallWaitingStatus Get Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = EFalse;
	
	// Interrogate the current status of the call waiting services.
	iTelephony->GetCallWaitingStatus(iStatus, iCallWaitingStatusV1Pckg);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of
                   CISVAPIBase
*/
CCallWaitingStatus::CCallWaitingStatus(MExecAsync* aController)
	: CISVAPIAsync(aController, KCallWaitingStatus),
	  iCallWaitingStatusV1Pckg(iCallWaitingStatusV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CCallWaitingStatus::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the call waiting status to
the console if there is no error.
*/
void CCallWaitingStatus::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Print the consol output message
		iConsole->Printf(KCallWaitingStatusMsg);
		switch(iCallWaitingStatusV1.iCallWaiting)
			{
		case CTelephony::EStatusActive:
			iConsole->Printf(_L("Call Waiting Provisioned\n"));
			ExampleNotify();
			break;
		case CTelephony::ENotActive:
		case CTelephony::ENotProvisioned:
		case CTelephony::ENotAvailable:
		case CTelephony::EUnknown:
			iConsole->Printf(_L("Call Waiting Not Provisioned\n"));
			ExampleComplete();
			break;
			}
		}
	}

/**
Cancels asynchronous request to CTelephony::GetCallWaitingStatus().
*/
void CCallWaitingStatus::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EGetCallWaitingStatusCancel);
	}
