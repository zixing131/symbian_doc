/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#ifndef __CBASEMENUASYNC_H__
#define __CBASEMENUASYNC_H__

#include <e32base.h>
#include <etel3rdparty.h>
#include <e32cons.h>
#include "CISVAPIAsync.h"

_LIT(KNewLine, "\n");
_LIT(KError, "iStatus != KErrNone, Something's Wrong!\n");

/**
Base Class providing functionality for and control of Etel 3rd Party Instances.
Also controls user input and handles displaying information to the user.
*/
class CBaseMenuAsync : public CActive, public MExecAsync
	{

// Methods
public:
	void Start();
	void CompleteOwnRequest(TInt aErr);
	void PostOwnRequest();
	virtual void Terminate();

protected:
	CBaseMenuAsync(CConsoleBase& aConsole);

	void GetInput();
	inline CTelephony* GetTelObj() const;
	inline CConsoleBase* GConsole() const;
	virtual void DoCancel() = 0;
	void ConstructL();
// Data
protected:
	/**
	The current operating state of the active object.
	*/
	TState iState;
	/**
	CTelephony Instance used by all member active objects
	to make calls to ETel ISV.
	*/
	CTelephony* iTelephony;
	/**
	Active object to perform next operations on.
	*/
	CISVAPIBase* iLastOperation;
	/**
	Console instance.
	*/
    CConsoleBase* iConsole;
	};

/**
Returns a pointer to object pointed to by iTelephony.

@return Pointer to CTelephony object used to make ETel ISV calls
*/
inline CTelephony* CBaseMenuAsync::GetTelObj() const
	{
	return iTelephony;
	}

/**
Returns a pointer to object pointed to by iConsole.

@return Pointer to CConsoleBase object used to display output
*/
inline CConsoleBase* CBaseMenuAsync::GConsole() const
	{
	return iConsole;
	}

#endif // __CBASEMENUASYNC_H__

