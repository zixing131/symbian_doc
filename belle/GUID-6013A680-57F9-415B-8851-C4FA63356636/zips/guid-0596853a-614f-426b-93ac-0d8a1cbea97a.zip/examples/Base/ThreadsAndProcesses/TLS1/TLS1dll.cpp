/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:�
DLL example program (1) to demonstrate Thread Local Storage (TLS).
This DLL implements the two classes CSetter and CGeneral
CSetter is used to set up the static text string, delete it, change it and display
its content.
CGeneral can show the content.
The point being made here is that the text string is, effectively, static writeable data.
It is accessible by all classes implemented in the DLL.
CSetter is the only class which sets the static data in this example but, in general,
any class implemented in the DLL can change/delete/fetch the data
through the pointer in thread local storage - it is a matter of application design. 
*/


#include "TLS1dll.h"

#include <e32uid.h>

_LIT(KTxt1,"<>\n");
_LIT(KFormat1,"<%S>\n");

///////////////////////////////////////////////////////////////////////
//
// Class CSetter implementation
//
///////////////////////////////////////////////////////////////////////	

	// C++ constructor sets reference to the console in the
	// initializer list.
    // Body of constructor is empty.
    // Constructor is exported because it is non-trivial
EXPORT_C CSetter::CSetter(CConsoleBase& aConsole)
	: iConsole(aConsole)
	{
	}


	// Destructor, deletes the static string
CSetter::~CSetter()
	{
	delete (HBufC*)Dll::Tls();
	Dll::SetTls(NULL);
	}


	// Delete any existing static string; allocates a new HBufC
	// and sets thread local storage to point to the HBufC.
EXPORT_C void CSetter::SetStaticTextL(const TDesC& aString)
	{
	delete (HBufC*)Dll::Tls();
	HBufC* pD = aString.AllocL();
	Dll::SetTls(pD);
	}


	// Show static text
EXPORT_C void  CSetter::ShowStaticText() const
	{
	TDesC* text = ((TDesC*)Dll::Tls());
	
	if (text)
		iConsole.Printf(KFormat1, text);
	else
		iConsole.Printf(KTxt1);
	}



///////////////////////////////////////////////////////////////////////
//
// Class CGeneral implementation
//
///////////////////////////////////////////////////////////////////////	

	// C++ constructor sets refrence to the console in the
	// initializer list.
    // Body of constructor is empty.
    // Constructor is exported because it is non-trivial
EXPORT_C CGeneral::CGeneral(CConsoleBase& aConsole)
	: iConsole(aConsole)
	{
	}


	// Show static text
EXPORT_C void  CGeneral::ShowStaticText() const
	{
	TDesC* text = ((TDesC*)Dll::Tls());
	
	if (text)
		iConsole.Printf(KFormat1, text);
	else
		iConsole.Printf(KTxt1);
	}


