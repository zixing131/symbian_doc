// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "FindMeActive.h"
#include "FindMeAppView.h"


// Name of requestor
_LIT(KRequestor,"FindMe App");
//Update interval
const TInt KUpdateInterval = 1000000;
// Timeout interval
const TInt KUpdateTimeOut = 15000000;
// Chache age
const TInt KCacheAge = 500000;


CFindMeActive* CFindMeActive::NewL(CFindMeAppView* aView)
	{
	CFindMeActive* self = new (ELeave) CFindMeActive();
	CleanupStack::PushL(self);
	self->ConstructL(aView);
	CleanupStack::Pop();
	return self;
	}


CFindMeActive::CFindMeActive() : CActive(EPriorityStandard)
	{
	CActiveScheduler::Add( this );
	}
		
	
void CFindMeActive::ConstructL(CFindMeAppView* aView)
	{
	// Set the pointer to our application view
	iView = aView;
    
	// Connect to the position server
	User::LeaveIfError(iPosServer.Connect());
  
	// Open the subsession to the server
	User::LeaveIfError(iPositioner.Open(iPosServer));
  
    // Set requestor
	User::LeaveIfError(iPositioner.SetRequestor(CRequestor::ERequestorService ,
												CRequestor::EFormatApplication , 
												KRequestor) );
 
    // Set update interval to receive one position information every 1 second.
    TPositionUpdateOptions udOpt;
    udOpt.SetUpdateInterval(TTimeIntervalMicroSeconds(KUpdateInterval));

    // The position server will terminate the request by the requestor 
    // in case it could not retreive position info in 1 minute.
    udOpt.SetUpdateTimeOut(TTimeIntervalMicroSeconds(KUpdateTimeOut));

    // Maximum age for cached information by which to be used.
    udOpt.SetMaxUpdateAge(TTimeIntervalMicroSeconds(KCacheAge));

    // Do not allow location server to send partial position data.
    udOpt.SetAcceptPartialUpdates(EFalse);
       
    // Set the update options.
    User::LeaveIfError(iPositioner.SetUpdateOptions(udOpt) );
  
    // Set the active object to start getting position information.
    iPositioner.NotifyPositionUpdate(iPositionInfo,iStatus);
	SetActive();
	}
		

CFindMeActive::~CFindMeActive()
	{
	Cancel(); 				// Cancel any outstanding active object requests
	iPositioner.Close(); 	// Close RPositioner
	iPosServer.Close();		// Cloase RPositionerServer
	}


void CFindMeActive::DoCancel()
	{
	iPositioner.CancelRequest(EPositionerNotifyPositionUpdate );
	}


void CFindMeActive::RunL()
	{
	// If successfully received position info
	if( iStatus.Int() == KErrNone || 
		iStatus.Int() == KPositionPartialUpdate )
		{
		// Update the view
		iView->PrintPos();
		}
	
	// Request the next position
    iPositioner.NotifyPositionUpdate( iPositionInfo, iStatus );
   	SetActive();
	}
		
