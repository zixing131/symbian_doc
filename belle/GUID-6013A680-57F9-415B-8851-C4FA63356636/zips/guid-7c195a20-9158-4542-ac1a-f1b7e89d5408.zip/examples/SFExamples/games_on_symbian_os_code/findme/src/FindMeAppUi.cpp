// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CFindMeAppUi implementation
// 
// 


// INCLUDE FILES
#include <avkon.hrh>
#include <aknmessagequerydialog.h>

#include <FindMe_0xE5F14158.rsg>

#include "FindMe.hrh"
#include "FindMe.pan"
#include "FindMeApplication.h"
#include "FindMeAppUi.h"
#include "FindMeAppView.h"


// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// CFindMeAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CFindMeAppUi::ConstructL()
	{
	// Initialise app UI with standard value.
	BaseConstructL(CAknAppUi::EAknEnableSkin);

	// Create view object
	iAppView = CFindMeAppView::NewL( ClientRect() );
	}

// -----------------------------------------------------------------------------
// CFindMeAppUi::CFindMeAppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CFindMeAppUi::CFindMeAppUi()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CFindMeAppUi::~CFindMeAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CFindMeAppUi::~CFindMeAppUi()
	{
	if ( iAppView )
		{
		delete iAppView;
		iAppView = NULL;
		}

	}

// -----------------------------------------------------------------------------
// CFindMeAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CFindMeAppUi::HandleCommandL( TInt aCommand )
	{
	}
// -----------------------------------------------------------------------------
//  Called by the framework when the application status pane
//  size is changed.  Passes the new client rectangle to the
//  AppView
// -----------------------------------------------------------------------------
//
void CFindMeAppUi::HandleStatusPaneSizeChange()
	{
	iAppView->SetRect( ClientRect() );
	} 

// End of File
