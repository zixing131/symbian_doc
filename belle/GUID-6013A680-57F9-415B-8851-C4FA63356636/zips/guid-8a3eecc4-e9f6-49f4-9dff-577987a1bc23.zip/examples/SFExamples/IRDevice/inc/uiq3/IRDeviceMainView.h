// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef IRDEVICEVIEW_H
#define IRDEVICEVIEW_H

// INCLUDES
#include <QikViewBase.h>

// FORWARD DECLARATION
class CEikLabel;

// CLASS DECLARATION

class CIRDeviceMainView : public CQikViewBase
	{
public: // Constructor and destructor
	static CIRDeviceMainView* NewL(CQikAppUi& aAppUi);
	static CIRDeviceMainView* NewLC(CQikAppUi& aAppUi);
	~CIRDeviceMainView();

public: // From CQikViewBase
	TVwsViewId ViewId()const;
	void HandleCommandL(CQikCommand& aCommand);

public: // Public methods
	void SetTextL(const TDesC& aText);

protected: // From CQikViewBase
	void ViewConstructL();
	void SizeChanged();

private: // Private constructors
	CIRDeviceMainView(CQikAppUi& aAppUi);	
	void ConstructL();
	
private: // Member variables
	CEikLabel* iEikLabel;
	};

#endif // IRDEVICEVIEW_H

// End of File
