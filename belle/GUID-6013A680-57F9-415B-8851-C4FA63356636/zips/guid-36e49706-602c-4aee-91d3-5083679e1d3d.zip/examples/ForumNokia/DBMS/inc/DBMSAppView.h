/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef __DBMSAPPVIEW_H__
#define __DBMSAPPVIEW_H__

#include <coecntrl.h>

/**
 * Class:       CDBMSAppView
 *
 * Description: An instance of this class is the Application View object for
 *              the DBMS example application.
 *
 *              The view simply shows empty screen. The Avkon GUI is just a
 *              simple tester of the database engine CDBMSDb in
 *              DBEngine.h. There is no functionality for the view, since
 *              all GUI actions relate to menu commands (see AppUi).
 */
class CDBMSAppView : public CCoeControl
    {
public:

    /**
     * Function:    NewL
     *
     * Description: Create a CDBMSAppView object, which will draw
     *              itself to aRect.
     *
     * Param:       aRect the rectangle this view will be drawn to
     *
     * Returns:     A pointer to the created instance of CDBMSAppView
     */
    static CDBMSAppView* NewL(const TRect& aRect);

    /**
     * Function:    ~CDBMSAppView
     *
     * Description: Destroy the view object
     */
     ~CDBMSAppView();

public:  // from CCoeControl

    /**
     * Function:     Draw
     *
     * Description:  Paints this view (an empty rect). This is called by the
     *               framework, when view needs to redraw itself.
     *
     * Param:        aRect Frame rectangle for container.
     */
    void Draw(const TRect& aRect) const;

private:

    /**
     * Function:    ConstructL
     *
     * Description: Perform the second phase construction of a
     *              CDBMSAppView object.
     *
     * Param:       aRect the rectangle this view will be drawn to
     */
    void ConstructL(const TRect& aRect);

    /**
     * Function:   CDBMSAppView
     *
     * Description: Perform the first phase of two phase construction.
     */
    CDBMSAppView();

private: // private attributes

    };

#endif // __DBMSAPPVIEW_H__
