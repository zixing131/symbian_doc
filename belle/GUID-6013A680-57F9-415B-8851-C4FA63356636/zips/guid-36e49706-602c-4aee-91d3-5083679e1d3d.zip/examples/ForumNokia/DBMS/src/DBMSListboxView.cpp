/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include <eikenv.h>
#include <avkon.hrh>
#include <gdi.h>
#include <eiktxlbx.h>  // CEikTextListBox
#include <eiklabel.h>  // CEikLabel
#include <eiktxlbm.h>  // CTextListBoxModel
#include <aknconsts.h>
#include <AknUtils.h>
#include "DBMSListboxView.h"


// ---------------------------------------------------------------------------
// CDBMSListboxView::NewL()
//
// Create instance of this view.
// ---------------------------------------------------------------------------
//
CDBMSListboxView* CDBMSListboxView::NewL(const TRect& aRect)
    {
    CDBMSListboxView* self = new (ELeave) CDBMSListboxView;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    CleanupStack::Pop(self);
    return self;
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::ConstructL()
//
// Perform the second phase construction. Construct the contained controls.
// ---------------------------------------------------------------------------
//
void CDBMSListboxView::ConstructL(const TRect& aRect)
    {
    // Create a window for this application view
    CreateWindowL();
	_LIT(KListboxView, "Listbox view");

    iLabel = new (ELeave) CEikLabel();
    iLabel->SetTextL(KListboxView);
    iLabel->SetContainerWindowL( *this );

    iListBox = new(ELeave)CEikTextListBox();
    iListBox->ConstructL( this);
    iListBox->SetContainerWindowL( *this );

    // Set the windows size
    SetRect(aRect);
    ActivateL();
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::SetCaptionL()
//
// Set caption for this view. Updates the label.
// ---------------------------------------------------------------------------
//
void CDBMSListboxView::SetCaptionL(const TDesC& aNewCaption)
    {
    iLabel->SetTextL(aNewCaption);
    SizeChanged();
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::SetListItemsL()
//
// Sets the listbox array and updates the view to reflect new array items.
// The listbox takes ownership of the given aNewItems array.
// ---------------------------------------------------------------------------
//
void CDBMSListboxView::SetListItemsL(CDesCArrayFlat* aNewItems)
    {
    CTextListBoxModel* model = iListBox->Model();
    model->SetItemTextArray(aNewItems);
    // Set ListBox model responsible for deleting the listItems array
    model->SetOwnershipType( ELbmOwnsItemArray );
    iListBox->HandleItemAdditionL();
    if(aNewItems->Count()>0)
        {
        // Select the first item, if there is one.
        iListBox->SetCurrentItemIndexAndDraw(0);
        }
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::CDBMSListboxView()
//
// Constructor
// ---------------------------------------------------------------------------
//
CDBMSListboxView::CDBMSListboxView()
    {
    // No implementation required
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::~CDBMSListboxView()
//
// Desctructor. Delete contained controls
// ---------------------------------------------------------------------------
//
CDBMSListboxView::~CDBMSListboxView()
    {
    delete iLabel;
    delete iListBox;
    }


// ---------------------------------------------------------------------------
// CDBMSAppUi::Draw()
//
// Draw the view background. This is called by the framework, when necessary.
//
// Note: The framework will draw the contained controls (label and the listbox)
// by using CountComponentControls() and ComponentControl() methods.
// ---------------------------------------------------------------------------
//
void CDBMSListboxView::Draw(const TRect& /*aRect*/) const
    {
    //Clear the screen
    CWindowGc& gc = SystemGc();
    gc.Clear(Rect());
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::SizeChanged()
//
// Specify locations and sizes of the label and listbox. Called by
// the framework when the view size is changed
// ---------------------------------------------------------------------------
//
void CDBMSListboxView::SizeChanged()
    {

        TRect containerRect = Rect(); // Rect of the container

        TSize labelSize = iLabel->MinimumSize();

        // Show the label in the upper part of the screen and in whole
        // screen width
        iLabel->SetExtent( TPoint(5,2),
                           TSize(containerRect.Width(), labelSize.iHeight) );

        // Fill the rest (bottom) of the screen with listbox
        iListBox->SetExtent( TPoint(5,labelSize.iHeight + 5 ),
            TSize( containerRect.Width(),
                   containerRect.Height()-labelSize.iHeight ) );
                   
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::CountComponentControls()
//
// Return number of contained controls.
// ---------------------------------------------------------------------------
//
TInt CDBMSListboxView::CountComponentControls() const
    {
        return 2; // Label and listbox
    }


// ---------------------------------------------------------
// CDBMSListboxView::ComponentControl()
//
// Return owned controls to framework so it will draw them.
// ---------------------------------------------------------
//
CCoeControl* CDBMSListboxView::ComponentControl(TInt aIndex) const
    {
    switch ( aIndex )
        {
        case 0:
            return iLabel;
        case 1:
            return iListBox;
        default:
            return NULL;
        }
    }

// ---------------------------------------------------------------------------
// CDBMSListboxView::OfferKeyEventL()
//
// Handle key events. Let the listbox handle the key events.
//
// AppUi must add this control to control stack to ensure key events are
// received and this method is called.
// ---------------------------------------------------------------------------
//
TKeyResponse CDBMSListboxView::OfferKeyEventL(const TKeyEvent& aKeyEvent,
    TEventCode aType)
    {
        return iListBox->OfferKeyEventL( aKeyEvent, aType );
    }


// ---------------------------------------------------------------------------
// CDBMSListboxView::GetSelectedItem()
//
// Get name of the selected item in the listbox.
// ---------------------------------------------------------------------------
//
TInt CDBMSListboxView::GetSelectedItem(TDes& aResult) const
    {
    CTextListBoxModel* model = iListBox->Model();
    if(model->NumberOfItems()==0)
        {
        return KErrNotFound;
        }

    aResult.Copy(model->ItemText(iListBox->CurrentItemIndex()));
    return KErrNone;
    }

//EOF
