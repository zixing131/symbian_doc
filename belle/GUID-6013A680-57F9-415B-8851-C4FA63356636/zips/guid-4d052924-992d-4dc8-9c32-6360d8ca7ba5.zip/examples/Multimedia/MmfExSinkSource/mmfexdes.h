/*
Copyright (c) 2001-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __MMFDES_H_
#define __MMFDES_H_


#include <mmf/server/mmfclip.h>
#include <mmf/common/mmfutilities.h>

//Panic codes for MMFDescriptor
enum TMMFExDescriptorPanicCode
	{
	EMMFDescriptorPanicBufferEmptiedLNotSupported = 1,
	EMMFDescriptorPanicBufferFilledLNotSupported
	};
	
class TMMFExDescriptorParams
	{
public:
	TAny* iDes ; // Address of TPtr8 describing source Descriptor
	TThreadId iDesThreadId ;
	} ;

typedef TPckgBuf<TMMFExDescriptorParams>  TMMFDescriptorConfig ;

// Defines a MMF sink and source plug-in that can write and read media data
// to a descriptor
// Implements CMMFClip, which itself derives from MDataSource and MDataSink
class CMMFExDescriptor : public CMMFClip
	{
public:
	// Data source factory
	static MDataSource* NewSourceL() ; 
	// Data sink factory
	static MDataSink* NewSinkL() ; 
	~CMMFExDescriptor() ;
	
private:
	// From MDataSource
	TFourCC SourceDataTypeCode( TMediaId /*aMediaId*/) ;
	void FillBufferL(CMMFBuffer* aBuffer, MDataSink* aConsumer,TMediaId /*aMediaId*/) ;//called by a MDataSink to request buffer fill
	void BufferEmptiedL( CMMFBuffer* aBuffer ) ;
	TBool CanCreateSourceBuffer() ;
	CMMFBuffer* CreateSourceBufferL(TMediaId /*aMediaId*/, TBool &aReference) ;
	void ConstructSourceL(  const TDesC8& aInitData ) ;

	// From MDataSink
	TFourCC SinkDataTypeCode(TMediaId /*aMediaId*/) ; //used by data path MDataSource/Sink for codec matching
	void EmptyBufferL( CMMFBuffer* aBuffer, MDataSource* aSupplier, TMediaId /*aMediaId*/ ) ; 
	void BufferFilledL( CMMFBuffer* aBuffer ) ;
	TBool CanCreateSinkBuffer() ;
	CMMFBuffer* CreateSinkBufferL( TMediaId /*aMediaId*/ , TBool &aReference) ;
	void ConstructSinkL( const TDesC8& aInitData ) ;

	// From CMMFClip
	void ReadBufferL( TInt aLength, CMMFBuffer* aBuffer, TInt aPosition, MDataSink* aConsumer);
	void WriteBufferL( TInt aLength, CMMFBuffer* aBuffer, TInt aPosition, MDataSource* aSupplier);
	void ReadBufferL( CMMFBuffer* aBuffer, TInt aPosition, MDataSink* aConsumer) ;
	void WriteBufferL( CMMFBuffer* aBuffer, TInt aPosition, MDataSource* aSupplier) ;
	void ReadBufferL( CMMFBuffer* aBuffer, TInt aPosition) ;
	void WriteBufferL( CMMFBuffer* aBuffer, TInt aPosition) ;
	TInt64 BytesFree() ;  // amount of space available for the clip
	TInt Size() ;  // length of clip

	// Construction
	void ConstructL( const TDesC8& aInitData ) ;
	CMMFExDescriptor();
	// Helpers
	void Reset() { iOffset = 0 ; };

private:
	// Need to know about the thread that the descriptor is in
	RThread iDesThread;
	TDes8* iDes ;
	TInt iOffset;
	TFourCC iSinkFourCC;
	TFourCC iSourceFourCC;
	TBool iUseTransferBuffer;
	} ;


#endif
