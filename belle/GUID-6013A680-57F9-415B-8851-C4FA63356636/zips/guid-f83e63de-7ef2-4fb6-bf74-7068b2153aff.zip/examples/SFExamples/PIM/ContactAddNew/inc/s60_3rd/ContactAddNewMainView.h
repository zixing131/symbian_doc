// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __ContactAddNew_MAINVIEW_H__
#define __ContactAddNew_MAINVIEW_H__

// INCLUDE FILES
#include <aknview.h>
#include <akndef.h>

class CEikEdwin;

// CLASS DECLARATION

class CContactAddNewMainView : public CCoeControl
	{
public:

	static CContactAddNewMainView* NewL( const TRect& aRect );
	static CContactAddNewMainView* NewLC( const TRect& aRect );
	~CContactAddNewMainView();
	
public:

	void SetTextL(const TDesC& aText);
	
private:

	void ConstructL( const TRect& aRect );

private: // From CoeControl

	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;

	void Draw(const TRect& aRect) const;
	void SizeChanged();
	
private:

	CEikEdwin* iEikEdwin;

	};

#endif // __ContactAddNew_MAINVIEW_H__

// End of File
