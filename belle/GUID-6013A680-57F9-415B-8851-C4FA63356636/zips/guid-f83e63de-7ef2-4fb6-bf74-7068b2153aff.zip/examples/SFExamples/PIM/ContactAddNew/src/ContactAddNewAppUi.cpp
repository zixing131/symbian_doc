// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactAddNew.rsg>

#include "ContactAddNewAppUi.h"
#include "ContactAddNewMainView.h"
#include "ContactWrite.h"
#include "ContactAddNew.hrh"

void CContactAddNewAppUi::ConstructL()
	{

	BaseConstructL(EAknEnableSkin);
	iMainView = CContactAddNewMainView::NewL(ClientRect());

	iContactWriter = CContactWrite::NewL();
	}
	
CContactAddNewAppUi::~CContactAddNewAppUi()
    {
    delete iContactWriter;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CContactAddNewAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactAddNew:
			{
			_LIT(KTelNumber, "012456789");
			_LIT(KFirstName, "Mememe");
			_LIT(KLastName, "Himhimhim");
			TRAPD(error, iContactWriter->AddCardL(KFirstName(), KLastName(), KTelNumber()));
			// report error on the Label control
			if (KErrNone == error)
				{
				_LIT(KSuccess, "It Worked!");
				iMainView->SetTextL(KSuccess());
				}
			else
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactAddNewAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
