// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikstart.h>

#include "ContactAddNewExternalInterface.h"
#include "ContactAddNewApplication.h"
#include "ContactAddNewDocument.h"

TUid CContactAddNewApplication::AppDllUid() const
	{
	return KUidContactAddNewApp;
	}

CApaDocument* CContactAddNewApplication::CreateDocumentL()
	{
	return new (ELeave) CContactAddNewDocument(*this);
	}

CApaApplication* NewApplication()
	{
	return new CContactAddNewApplication();
	}
	
GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication(NewApplication);
	}

// End of File
