/*
 * Copyright (c) 2009-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef __CAMERAWRAPPEREXAMPLEAPPVIEW_h__
#define __CAMERAWRAPPEREXAMPLEAPPVIEW_h__

// INCLUDES
#include <coecntrl.h>
#include <fbs.h>

#include <cameraengine.h>
#include <cameraengineobserver.h>




class CCameraWrapperExampleAppUi;

// CLASS DECLARATION
class CCameraWrapperExampleAppView : 
public CCoeControl, public MCameraEngineObserver
    {
    public: 
        // Constructors
        static CCameraWrapperExampleAppView* NewL (const TRect& aRect );
        static CCameraWrapperExampleAppView* NewLC (const TRect& aRect );
        virtual ~CCameraWrapperExampleAppView ();
    
    private: 
        // Functions from base classes
        void Draw (const TRect& aRect ) const;
        void DrawTexts(CWindowGc& gc) const;
        void SizeChanged ();
        void HandlePointerEventL (const TPointerEvent& aPointerEvent );
        void SetTitle(const TDesC& aTitle);
        void SetError( const TDesC& aMsg, TInt aVal );
        void SetError( const TDesC& aMsg, TInt aVal1, TInt aVal2 );
        void StartFocusing();
        void StorePicture( TDesC8* aData );

    public:
        TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
        CCameraEngine* CameraEngine(){return iCameraWrapper;};
        void CancelCapturedPicture(TBool aCleanTexts=ETrue);
        void Capture();        
        
    private: // From MCameraEngineObserver
        void MceoCameraReady();
        void MceoFocusComplete();
        void MceoCapturedDataReady( TDesC8* aData );
        void MceoCapturedBitmapReady( CFbsBitmap* aBitmap );
        void MceoViewFinderFrameReady( CFbsBitmap& aFrame );
        void MceoHandleError( TCameraEngineError aErrorType, TInt aError );
        void MceoHandleOtherEvent( const TECAMEvent& /*aEvent*/ );
    
    private: 
        // Constructors
        void ConstructL (const TRect& aRect );
        CCameraWrapperExampleAppView ();

    public:

    
    private:
        void CreateBackBufferL();
        void ReleaseBackBuffer();

    
    private: 
        // Data
        
        CCameraWrapperExampleAppUi*         iAppUi;

        // CameraWrapper class
        CCameraEngine*                      iCameraWrapper;

        TSize                               iViewFinderSize;
        TSize                               iCaptureSize;
    
        CFbsBitmap*                         iBackBuffer;
        CFbsBitmapDevice*                   iBackBufferDevice;
        CFbsBitGc*                          iBackBufferContext;
        
        const CFont*                        iTitleFont;
        TBuf<50>                            iTitle;
        TRect                               iFocusRect;
        
        // Is new picture focused whit camera shutter key
        TBool                               iCameraShutterFocusing;
        
        HBufC8*                             iData;
    
    };

#endif // __CAMERAWRAPPEREXAMPLEAPPVIEW_h__

// End of File
