/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include <utf.h>
#include <nfctype1connection.h>
#include <nfctype2connection.h>
#include <nfctype3connection.h>
#include <mifareclassicconnection.h>
#include <iso14443connection.h>
#include <nfctype1address.h>
#include <nfctype2address.h>
#include <nfctype3address.h>

#include <QString>

#include "activewait.h"
#include "nfctagsdiscovery_symbian.h"
#include "nfctagsdiscovery.h"

_LIT8(KSendText,"Sending data to tag");

// Create private class instance with NewL() metod.
NfcTagsDiscoveryPrivate* NfcTagsDiscoveryPrivate::NewL(NfcTagsDiscovery *aPublicAPI)
    {
    NfcTagsDiscoveryPrivate* self = NewLC(aPublicAPI);
    CleanupStack::Pop( self );  
    return self;
    }

// Create private class instance with NewLC() method.
NfcTagsDiscoveryPrivate* NfcTagsDiscoveryPrivate::NewLC(NfcTagsDiscovery *aPublicAPI)
    {
    NfcTagsDiscoveryPrivate* self = new (ELeave) NfcTagsDiscoveryPrivate(aPublicAPI);
    CleanupStack::PushL( self );
    self->ConstructL(aPublicAPI);
    return self;
    }

// Destructor.
NfcTagsDiscoveryPrivate::~NfcTagsDiscoveryPrivate()
    {
    iWait->AsyncStop();
    delete iPublicAPI;
    delete iWait;
    iNfcTagDiscovery->RemoveTagConnectionListener();
    iNfcTagDiscovery->RemoveTagSubscription();
    delete iNfcTagDiscovery ;
    delete iSubscription;
    delete iNfcType1Connection;
    delete iNfcType2Connection;
    delete iNfcType3Connection;
    delete iMifareClassicConnection;
    delete iIso14443Connection;
    delete iMifareClassicDataSector;
    iWriteBuffer.Close();
    iReadBuffer.Close();
    iServer.Close();
    delete iReadWait;
    delete iWriteWait;
    iNdefDiscovery->RemoveNdefMessageListener();
    iNdefDiscovery->RemoveAllNdefSubscription();
    delete iNdefDiscovery;
    }

/**
 * This method is called, to start Tag discovery 
 * - Add the tag connection listner to tag 
 * discovery instance.
 * - Subscribe for Type1, Type2, Type3, Iso14443 and 
 * Mifare tag connection modes.
 * - Wait for the request completion.
 * Note: If the connection mode of the tag is not added
 * to the subscription, that type of tag is not detected.
 */
void NfcTagsDiscoveryPrivate::StartTagDiscovery()
    { 
    // Clear the text in the main window.
    emit iPublicAPI->clearText();
    
    // Change the menu.
    emit iPublicAPI->changeMenu(NfcTagsDiscoveryPrivate::ETagDiscovery);

    // Add tag connection listener.
    TInt err = iNfcTagDiscovery->AddTagConnectionListener( *this );
    if(err == KErrNone)
        {
        emit iPublicAPI->showMessage("Added tag connection listener\n");
        }
    
    // Add all types of connection modes.
    iSubscription = CNfcTagSubscription::NewL();
    iSubscription->AddConnectionModeL(TNfcConnectionInfo::ENfcType1);
    iSubscription->AddConnectionModeL(TNfcConnectionInfo::ENfcType2);
    iSubscription->AddConnectionModeL(TNfcConnectionInfo::ENfcType3);
    iSubscription->AddConnectionModeL(TNfcConnectionInfo::ENfcMifareStd);
    iSubscription->AddConnectionModeL(TNfcConnectionInfo::ENfc14443P4);
    TRAP(err,iNfcTagDiscovery->AddTagSubscriptionL( *iSubscription ));
    
    if(err == KErrNone)
            {
            emit iPublicAPI->showMessage("Added all tag connections to subscription.\n");
            iWait->Start();
            }         
    }


/*
 * This method is called to start the NDEF discovery.
 * - Create the CNdefDiscovery class instance.
 * - Add a NDEF message listener to this instance.
 * - Subscribe the NDEF discovery to necessary Message
 * types and TNF info.
 */
void NfcTagsDiscoveryPrivate::StartNdefDiscovery()
    {
    // Clear the text in the application window.
    emit iPublicAPI->clearText();
    
    emit iPublicAPI->changeMenu(NfcTagsDiscoveryPrivate::ENdefDiscovery);
    TInt err = iNdefDiscovery->AddNdefMessageListener( *this );
    
    // Subscribe for the following NDEF message types.
    _LIT8( KSmartPoster, "Sp" );
    _LIT8( KTextRTD, "T" );
    _LIT8( KUriRTD, "U" );
    
    // Add 'NfcWellKnown', as the TNF user is interested in this kind of data. 
    err = iNdefDiscovery->AddNdefSubscription( CNdefRecord::ENfcWellKnown, KUriRTD);
    err = iNdefDiscovery->AddNdefSubscription( CNdefRecord::ENfcWellKnown, KSmartPoster);  
    err = iNdefDiscovery->AddNdefSubscription( CNdefRecord::ENfcWellKnown, KTextRTD);
    if(err == KErrNone)
        {
        emit iPublicAPI->showMessage("Added NDEF subscriptions successfully.\n");
        iWait->Start();
        }
    }

// This method is called to stop the tag discovery.
void NfcTagsDiscoveryPrivate::StopTagDiscovery()
    {
    iWait->AsyncStop();
    iNfcTagDiscovery->RemoveTagConnectionListener();
    iNfcTagDiscovery->RemoveTagSubscription();
    }

// This method is called to stop the NDEF discovery.
void NfcTagsDiscoveryPrivate::StopNdefDiscovery()
    {
    iWait->AsyncStop();
    iNdefDiscovery->RemoveNdefMessageListener();
    iNdefDiscovery->RemoveAllNdefSubscription();
    }

/**
 * Display the message after the completion of Read\Write operation on Tag.
 * This function is called, when the active request to read\write from the tag completes.
 */
void NfcTagsDiscoveryPrivate::TagOperationCompleted()
    {
    if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EExchangeDataWithIso14443Tag){
        emit iPublicAPI->showMessage("Exchange data with Iso14443 "
                "tag is successfull.\n");
        ShowTagInformation();
        } 
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EReadFromClass1Tag){
        emit iPublicAPI->showMessage("Read from Type1 tag "
                "completed.\n");
        ShowTagInformation();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EWriteToClass1Tag){
        emit iPublicAPI->showMessage("Write to Type1 tag "
                "completed.\n");
        ReadFromClass1Tag();    
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EReadFromClass2Tag){
        emit iPublicAPI->showMessage("Read from Type2 tag "
                "completed.\n");
        ShowTagInformation();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EWriteToClass2Tag){
        emit iPublicAPI->showMessage("Write to Type2 tag "
                "completed.\n");
        ReadFromClass2Tag();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EUpdateClass3Tag){
        emit iPublicAPI->showMessage("Update Type3 tag "
                "completed.\n");
        CheckClass3Tag();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::ECheckClass3Tag){
        emit iPublicAPI->showMessage("Check Type3 tag "
                "completed.\n");
        ShowTagInformation();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EWriteToMifareTag){
        emit iPublicAPI->showMessage("Write to mifare "
                "tag completed.\n");
        ReadFromMifareTag();
        }
    else if(iTagOperation == 
            NfcTagsDiscoveryPrivate::EReadFromMifareTag){
        emit iPublicAPI->showMessage("Read from mifare tag "
                "completed.\n");
        ShowTagInformation();
        }    
    }

// Constructor.
NfcTagsDiscoveryPrivate::NfcTagsDiscoveryPrivate(
        NfcTagsDiscovery* aPublicAPI): iPublicAPI(aPublicAPI)                                  
    {  
    
    }

// Two phase constructor.
void NfcTagsDiscoveryPrivate::ConstructL(NfcTagsDiscovery 
        *aPublicAPI)
    {  
    iWriteWait = CActiveWait::NewL(this);
    iReadWait = CActiveWait::NewL(this);
    iWait = new (ELeave) CActiveSchedulerWait();
    
    // Open Nfc server.
    iServer.Open();
    
    // Create Nfc tag discovery instance.    
    TRAPD(err,iNfcTagDiscovery = CNfcTagDiscovery::NewL( iServer ));
    
    // Create NDEF discovery instance.
    TRAP(err,iNdefDiscovery = CNdefDiscovery::NewL(iServer ));
    
    // Create all instance of supported tag types     
    TRAP(err,iNfcType1Connection = 
            CNfcType1Connection::NewL( iServer ));
    TRAP(err,iNfcType2Connection = 
            CNfcType2Connection::NewL( iServer ));
    TRAP(err,iNfcType3Connection = 
            CNfcType3Connection::NewL( iServer ));
    TRAP(err,iMifareClassicConnection = 
            CMifareClassicConnection::NewL( iServer ));
    TRAP(err,iIso14443Connection = 
            CIso14443Connection::NewL( iServer ));   
    
    // Add data to the read and write buffers.
    iWriteBuffer.ReAlloc(KSendText().Size());
    iWriteBuffer = KSendText;
    iReadBuffer.ReAlloc(KSendText().Size());
    }

/*
 * This method is called, when a tag is detected.
 * - Finds the type of tag.
 * - Open a connection with the tag.
 * - Writes data to the tag. After completion of write,
 * Reads the data from the tag and displays it.
 */
void NfcTagsDiscoveryPrivate::TagDetected(MNfcTag* aTag)
    {
    emit iPublicAPI->showMessage("\nA new tag is detected\n\n");
    
    // Check the type of the tag.
    if ( aTag->HasConnectionMode( 
            TNfcConnectionInfo::ENfc14443P4 ) )
        {
        // Open the connection to tag.
        emit iPublicAPI->showMessage("Iso14443 tag.\n");
        TInt error = aTag->OpenConnection( *iIso14443Connection ); 
        if(error == KErrNone)
            {
            emit iPublicAPI->showMessage("Connection mode is "
                    "successfully opened.\n");
            ExchangeDataWithIso14443Tag();
            }
        }
    else if ( aTag->HasConnectionMode( 
            TNfcConnectionInfo::ENfcType1 ) )
            {
            // Open the connection to tag.
            emit iPublicAPI->showMessage("Type1 tag.\n");
            TInt error = aTag->
                    OpenConnection( *iNfcType1Connection ); 
            if(error == KErrNone)
                {
                emit iPublicAPI->showMessage("Connection mode"
                        " is successfully opened.\n");
                WriteToClass1Tag();
                }
            }
    else if ( aTag->HasConnectionMode( 
            TNfcConnectionInfo::ENfcType2 ) )
                {
                // Open the connection to tag.
                emit iPublicAPI->showMessage("Type2 tag.\n");
                TInt error = aTag->
                        OpenConnection( *iNfcType2Connection );                
                if(error == KErrNone)
                    {
                    emit iPublicAPI->showMessage("Connection mode "
                            "is successfully opened.\n");
                    WriteToClass2Tag();
                    }
                }
    else if ( aTag->HasConnectionMode( TNfcConnectionInfo::ENfcType3 ) )
                {
                // Open the connection to tag.
                emit iPublicAPI->showMessage("Type3 tag.\n");
                TInt error = aTag->
                        OpenConnection( *iNfcType3Connection );                
                if(error == KErrNone)
                    {
                    emit iPublicAPI->showMessage("Connection mode "
                            "is successfully opened.\n");
                    UpdateClass3Tag();
                    }
                }
    else if ( aTag->
            HasConnectionMode( TNfcConnectionInfo::ENfcMifareStd ) )
                {
                // Open the connection to tag.
                emit iPublicAPI->showMessage("Mifare classic tag.\n");
                TInt error = aTag->
                        OpenConnection( *iMifareClassicConnection );                
                if(error == KErrNone)
                    {
                    emit iPublicAPI->showMessage("Connection mode "
                            "is successfully opened.\n");
                    WriteToMifareTag();
                    }
                }
    delete aTag;
    }

// This method is called, when a detected tag is lost.
void NfcTagsDiscoveryPrivate::TagLost()
    {
    if(iIso14443Connection->IsActivated())
        {
        iIso14443Connection->Deactivate();
        }
    emit iPublicAPI->clearText();
    emit iPublicAPI->showMessage("Tag is lost.\n");
    emit iPublicAPI->showMessage("Detected nfc tags information is \n"
            "displayed here.");
    }

// This method is called, when NDEF message is detected.
void NfcTagsDiscoveryPrivate::MessageDetected( CNdefMessage* aMessage )
    {
    if ( aMessage )
        {
        emit iPublicAPI->showMessage("NDEF Message received is :\n");
        TBuf8<200> buf(0);
        aMessage->ExportRawDataL(buf, 0);
        HBufC16* recData = HBufC16::NewL(80);
        recData = CnvUtfConverter::ConvertToUnicodeFromUtf8L(buf);
        emit iPublicAPI->showMessage(QString::fromUtf16(recData->Ptr(),recData->Length()));
        delete recData;
        delete aMessage;  
        }
    }

// Exchange data with Iso14443 tag.
void NfcTagsDiscoveryPrivate::ExchangeDataWithIso14443Tag()
    { 
    iTagOperation = 
            NfcTagsDiscoveryPrivate::EExchangeDataWithIso14443Tag;
    iIso14443Connection->
    ExchangeData(iWriteWait->iStatus, iWriteBuffer, iReadBuffer); 
    if(!iWriteWait->IsActive()){
        emit iPublicAPI->showMessage("Exchange data started\n");
        iWriteWait->SetActive();
        }
    }

// Read/Write OTP data to Class1 Tag
void NfcTagsDiscoveryPrivate::WriteToClass1Tag()
    { 
    iTagOperation = NfcTagsDiscoveryPrivate::EWriteToClass1Tag;
    
    // block address 
    TInt block = 1;
    
    // byte address.
    TInt byte = 6;    
    TNfcType1Address address(byte, block);  
    
    // Write information on the the tag.
    iNfcType1Connection->
    Write( iWriteWait->iStatus, iWriteBuffer, address );    
    if(!iWriteWait->IsActive()){
        emit iPublicAPI->showMessage("Write to class1 tag "
                "started.\n");
        iWriteWait->SetActive();
        }
    }

// Read/Write data to Class1 Tag.
void NfcTagsDiscoveryPrivate::ReadFromClass1Tag()
    { 
    iTagOperation = NfcTagsDiscoveryPrivate::EReadFromClass1Tag;
    
    // block address.
    TInt block = 1;
    
    // byte address.
    TInt byte = 6;    
    TNfcType1Address address( byte, block );
    
    // Read the information from the tag.
    iNfcType1Connection->Read( iReadWait->iStatus, iReadBuffer,KSendText().Size(), address );    
    if(!iReadWait->IsActive()){
        emit iPublicAPI->showMessage("Read from class1 tag started\n");
        iReadWait->SetActive();
        }
    }

// Write to the Class2 tag.
void NfcTagsDiscoveryPrivate::WriteToClass2Tag()
    { 
    iTagOperation = NfcTagsDiscoveryPrivate::EWriteToClass2Tag;
    TInt block = 4;      
    iNfcType2Connection->Write( iWriteWait->iStatus, iWriteBuffer, block );    
    if(!iWriteWait->IsActive()){
        emit iPublicAPI->showMessage("Write to class2 tag started.\n");
        iWriteWait->SetActive();
        }
    }

// Read/Write to Class2 Tag.
void NfcTagsDiscoveryPrivate::ReadFromClass2Tag()
    {
    iTagOperation = NfcTagsDiscoveryPrivate::EReadFromClass2Tag;
    TInt block = 4;
    TInt byte = 0;    
    TNfcType2Address address( byte, block );    
    iNfcType2Connection->
    Read( iReadWait->iStatus, 
            iReadBuffer, KSendText().Length(), address);    
    if(!iReadWait->IsActive()){
        emit iPublicAPI->showMessage("Read from class2 "
                "tag started\n");
        iReadWait->SetActive();
        }
    }

// Update/Check information in Class3 Tag.
void NfcTagsDiscoveryPrivate::UpdateClass3Tag()
    {
    iTagOperation = NfcTagsDiscoveryPrivate::EUpdateClass3Tag;
    TInt byte = 1;
    TInt block = 1; 
    TInt service = 11;
    TNfcType3Address address( byte, block, service );      
    iNfcType3Connection->
    Update( iWriteWait->iStatus, iWriteBuffer, address );
    if(!iWriteWait->IsActive()){
        emit iPublicAPI->showMessage("Update class3 tag "
                "started.\n");
        iWriteWait->SetActive();
        }
    }

// Check the information in class3 Tag.
void NfcTagsDiscoveryPrivate::CheckClass3Tag()
    {
    iTagOperation = NfcTagsDiscoveryPrivate::ECheckClass3Tag;
    TInt byte = 1;
    TInt block = 1; 
    TInt service = 11;
    TNfcType3Address address( byte, block, service );     
    iNfcType3Connection->
    Check( iReadWait->iStatus, iReadBuffer,
            KSendText().Size(), address );
    if(!iReadWait->IsActive()){
        emit iPublicAPI->showMessage("Check class3 tag "
                "started.\n");
        iReadWait->SetActive();
        }
    }

// Write data into a sector of Mifare tag.
void NfcTagsDiscoveryPrivate::WriteToMifareTag()
    {
    iTagOperation = NfcTagsDiscoveryPrivate::EWriteToMifareTag;
    
    RBuf8 keyA;
    CleanupClosePushL( keyA );
    keyA.CreateL(100);
    RBuf8 keyB;
    keyB.CreateL(100);
    CleanupClosePushL( keyB );
    
    TInt sect = 1;
    if(iMifareClassicDataSector)
        {
        delete iMifareClassicDataSector;
        iMifareClassicDataSector = NULL;
        }
    iMifareClassicDataSector = CMifareClassicSector::NewL(
            CMifareClassicSector::E1KSector);
   
    iMifareClassicConnection->WriteSector( 
            iWriteWait->iStatus, 
            *iMifareClassicDataSector, 
            sect);
    
    iWriteWait->SetActive();
    
    CleanupStack::PopAndDestroy(); // keyA
    CleanupStack::PopAndDestroy(); // keyB
    }

// Read the data from a sector of Mifare tag.
void NfcTagsDiscoveryPrivate::ReadFromMifareTag()
    { 
    iTagOperation = NfcTagsDiscoveryPrivate::EReadFromMifareTag;
    
    RBuf8 keyA;
    CleanupClosePushL( keyA );
    keyA.CreateL(100);
    RBuf8 keyB;
    keyB.CreateL(100);
    CleanupClosePushL( keyB );
     
     TInt sect = 1;
     if(iMifareClassicDataSector)
         {
         delete iMifareClassicDataSector;
         iMifareClassicDataSector = NULL;
         }
     iMifareClassicDataSector = CMifareClassicSector::NewL(
             CMifareClassicSector::E1KSector);

     iMifareClassicConnection->ReadSector( 
         iReadWait->iStatus, 
         *iMifareClassicDataSector, 
         sect,
         keyA,
         keyB);
     
     iReadWait->SetActive();
     
     CleanupStack::PopAndDestroy(); // keyA
     CleanupStack::PopAndDestroy(); // keyB

    }

// Display the information read from the tag.
void NfcTagsDiscoveryPrivate::ShowTagInformation()                                      
    {
    // Information read from the tag is displayed here.
    if(iTagOperation == NfcTagsDiscoveryPrivate::EReadFromMifareTag)
        {
        HBufC8* recData8 = iMifareClassicDataSector->ExportDataLC();
        emit iPublicAPI->showMessage("Information read from "
                "the tag:\n");
        emit iPublicAPI->showMessage(QString::fromUtf16( 
                CnvUtfConverter::ConvertToUnicodeFromUtf8L(
                        *recData8)->Ptr(), 
                        CnvUtfConverter::ConvertToUnicodeFromUtf8L(
                                *recData8)->Length())); 
        CleanupStack::PopAndDestroy(); 
        }
    else{
        emit iPublicAPI->showMessage("Information read from "
            "the tag:\n");
        emit iPublicAPI->showMessage(
                QString::fromUtf16(
                        CnvUtfConverter::ConvertToUnicodeFromUtf8L(
                        iReadBuffer)->Ptr(),
                        CnvUtfConverter::ConvertToUnicodeFromUtf8L(
                                iReadBuffer)->Length()));
        }
    }
