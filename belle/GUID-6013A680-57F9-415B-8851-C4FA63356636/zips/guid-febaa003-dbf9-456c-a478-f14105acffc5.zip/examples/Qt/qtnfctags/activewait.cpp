/*
* Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of "Eclipse Public License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.eclipse.org/legal/epl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:  ActiveWait
*
*/


#include <utf.h>
#include <e32debug.h>

#include "activewait.h"


CActiveWait* CActiveWait::NewL(NfcTagsDiscoveryPrivate* privateAPI)
    {
    CActiveWait* self = NewLC(privateAPI);
    CleanupStack::Pop( self );
    return self;
    }

CActiveWait* CActiveWait::NewLC(NfcTagsDiscoveryPrivate* privateAPI)
    {
    CActiveWait* self = new (ELeave) CActiveWait(privateAPI);
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

CActiveWait::~CActiveWait()
    {
    Cancel();
    }

void CActiveWait::SetActive()
    {
    CActive::SetActive();
    }

void CActiveWait::RunL()
    {
    iPrivateAPI->TagOperationCompleted();
    }

void CActiveWait::DoCancel()
    {
    Cancel();
    }


CActiveWait::CActiveWait(NfcTagsDiscoveryPrivate* privateAPI) : 
        CActive( EPriorityStandard ),
        iPrivateAPI(privateAPI)
    {
    
    }

void CActiveWait::ConstructL()
    {    
    CActiveScheduler::Add( this );
    }
