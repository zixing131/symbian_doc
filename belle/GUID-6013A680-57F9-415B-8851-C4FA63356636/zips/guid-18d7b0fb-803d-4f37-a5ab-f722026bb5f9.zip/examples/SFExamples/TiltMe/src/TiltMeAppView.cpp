/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� Application view implementation
*/ 


// INCLUDE FILES
#include <coemain.h>
#include "TiltMeAppView.h"
#include <aknnotewrappers.h>


// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CTiltMeAppView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CTiltMeAppView* CTiltMeAppView::NewL( const TRect& aRect )
	{
	CTiltMeAppView* self = CTiltMeAppView::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CTiltMeAppView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CTiltMeAppView* CTiltMeAppView::NewLC( const TRect& aRect )
	{
	CTiltMeAppView* self = new ( ELeave ) CTiltMeAppView;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}

// -----------------------------------------------------------------------------
// CTiltMeAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();

	// Set the windows size
	SetRect( aRect );

	// Activate the window, which makes it ready to be drawn
	ActivateL();
	
	// Construtig the time objects
	iFirst = TTime();
    iSecond = TTime();
    // Setting the initial time
    iFirst.HomeTime();
	}

// -----------------------------------------------------------------------------
// CTiltMeAppView::CTiltMeAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CTiltMeAppView::CTiltMeAppView() : iSensorFound(EFalse)
	{
	// No implementation required
	}


// -----------------------------------------------------------------------------
// CTiltMeAppView::~CTiltMeAppView()
// Destructor.
// -----------------------------------------------------------------------------
//
CTiltMeAppView::~CTiltMeAppView()
	{
	StopSensor();
	delete iAccSensor;
	}


// -----------------------------------------------------------------------------
// CTiltMeAppView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	// Gets the control's extent
	TRect drawRect( Rect());
	// Clears the screen
	gc.Clear( drawRect );
	
	if( iSensorFound )
		{
		const CFont* fontUsed = CEikonEnv::Static()->LegendFont();
		gc.UseFont(fontUsed);
		gc.SetPenColor(KRgbBlack);
		
		// Draw the acceleration values in all directions
		TBuf<35> values;
		values.Format(_L("X:  %d  Y:  %d  Z:  %d"), iXAccl, iYAccl, iZAccl);		
		gc.DrawText(values, TPoint(15,15));

		//
		// Draw the direction arrow
		//
		// Find the screen center point
		TPoint screenCenter = Rect().iBr;
		screenCenter.iX >>= 1;
		screenCenter.iY >>= 1;

		// Draw the poiting arrow
		gc.SetPenSize(TSize(8,8));
		gc.SetPenStyle(CGraphicsContext::ESolidPen);
		gc.SetPenColor(KRgbRed);
		gc.DrawLine( screenCenter, (screenCenter-TPoint( (TInt)(iYAccl*0.1), (TInt)(iXAccl*0.1) )) );

		// Draw the center pivot point
		gc.SetPenStyle(CGraphicsContext::ENullPen);
		gc.SetBrushColor(KRgbDarkGreen);
		gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
		gc.DrawEllipse( TRect( (screenCenter-TPoint(8,8)), (screenCenter+TPoint(10,10)) ) );
		
		gc.DiscardFont();
		}
	}


// -----------------------------------------------------------------------------
// CTiltMeAppView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::SizeChanged()
	{  
	DrawNow();
	}


// -----------------------------------------------------------------------------
// CTiltMeAppView::HandleDataEventL( TRRSensorInfo aSensor, 
//												 TRRSensorEvent aEvent )
//
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::HandleDataEventL( TRRSensorInfo /*aSensor*/, 
									   TRRSensorEvent aEvent )
	{
    iSecond.HomeTime();
    // Find the interval from the second time to the first
	TTimeIntervalMicroSeconds interv = iSecond.MicroSecondsFrom(iFirst);
    TInt64 i = interv.Int64();
    if(i >= 100000)
        {
        iXAccl = aEvent.iSensorData1;
        iYAccl = aEvent.iSensorData2;
        iZAccl = aEvent.iSensorData3;
        // Reset the first time to the current one.	
        iFirst.HomeTime();
        // Update the screen
        DrawNow();
        }
	}



// -----------------------------------------------------------------------------
// CTiltMeAppView::StartSensor()
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::StartSensor()
	{
	// If the sensor is initially not found
	if( !iSensorFound )
		{
		// Get list of available sensors (if any)
		RArray <TRRSensorInfo> sensorsList;
		CRRSensorApi::FindSensorsL( sensorsList );
	
		//Number of sensors available
		TInt count = sensorsList.Count();
	
		for( TInt i = 0 ; i != count ; ++i )
		    {
		    // If the ID matches Nokia 5500
		    if( sensorsList[i].iSensorId == 0x10273024 )	// 0x303E sensor ID for N95 
		    	{
		    	// Use the sensor found
		     	iAccSensor = CRRSensorApi::NewL( sensorsList[i] );
		     	// Register the sensor for our app
		     	iAccSensor->AddDataListener( this );
				iSensorFound = ETrue;
				return;
		    	}
			}
		
		// If we reach here that means we could not find a sensor.
		CAknInformationNote* note3 = new (ELeave) CAknInformationNote();
		CleanupStack::PushL(note3);
		note3->ExecuteLD(_L("No 3D sensor could be found!"));
		CleanupStack::Pop();
		}
	}


// -----------------------------------------------------------------------------
// CTiltMeAppView::StopSensor()
// -----------------------------------------------------------------------------
//
void CTiltMeAppView::StopSensor()
	{
	// If the sensor has been registered
	if( iSensorFound )
		{
		iAccSensor->RemoveDataListener();
		iSensorFound = EFalse;
		// Clean up
		delete iAccSensor;
		iAccSensor = NULL;
		}
	}


// End of File
