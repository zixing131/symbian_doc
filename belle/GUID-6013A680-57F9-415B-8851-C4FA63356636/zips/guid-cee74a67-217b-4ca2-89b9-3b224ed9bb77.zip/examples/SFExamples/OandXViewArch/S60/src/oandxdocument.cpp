/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include "OandXApplication.h"
#include "OandXAppUi.h"
#include "OandXDocument.h"

COandXDocument* COandXDocument::NewL(CEikApplication& aApp)
/**
	Factory function allocates new initialized document object.
	
	@param	aApp			The application object, which is used
							to initialize the newly-created document object.
	@return					New initialized document object.  The
							object is owned by the caller.
 */
	{
	COandXDocument* self = new(ELeave) COandXDocument(aApp);
	return self;
	}

COandXDocument::COandXDocument(CEikApplication& aApp)
/**
	This constructor is only defined to initialize the
	platform-specific superclass with the supplied application object.
	
	@param	aApp			Application object which is used to
							initialize the platform-specific
							superclass.
 */
:	CAknDocument(aApp)
	{
	// empty.
	}

COandXDocument::~COandXDocument()
/**
	This d'tor is empty but defining it here ensures
	that only one instance is generated.
 */
	{
	// empty.
	}

CEikAppUi* COandXDocument::CreateAppUiL()
/**
	Implement CEikDocument by creating a new app UI object.
	
	@return					New app UI object.  This is CBase-initialized
							and its constructor has been called, but no
							secondary initialization has been performed.
 */
	{
	iAppUi = new (ELeave) COandXAppUi;
	return iAppUi;
	}

void COandXDocument::StoreL(CStreamStore& aStore,CStreamDictionary& aStreamDic) const
/**
	Override CEikDocument by storing the current game state.
	
	@param	aStore			Stream store whose streams will describe the game.
	@param	aStreamDic		On exit associates stream UIDs with the corresponding
							stream IDs.
	@see RestoreL
 */
	{
	TStreamId id = iAppUi->StoreL(aStore);
	aStreamDic.AssignL(KUidOandXApp, id);
	}
	
void COandXDocument::RestoreL(const CStreamStore& aStore,const CStreamDictionary& aStreamDic)
/**
	Override CEikDocument by restoring a game from the supplied stream store.
	
	@param	aStore			Stream store which contains the externalized game.
	@param	aStreamDic		Associates stream UIDs with the corresponding stream IDs.
	@see StoreL
 */
	{
	TStreamId id = aStreamDic.At(KUidOandXApp);
	iAppUi->RestoreL(aStore, id);
	}
 
CFileStore* COandXDocument::OpenFileL(TBool aDoOpen,const TDesC& aFilename,RFs& aFs)
/**
	Overrides CAknDocument by directly calling CEikDocument::OpenFileL.
	This function must be defined for S60 because the CAknDocument implementation
	of OpenFileL does not support document-based applications.
	
	@param	aDoOpen			Whether should open an existing file instead of
							creating a new file.
	@param	aFilename		The path and name of the file to open or create.
	@param	aFs				File server session to use.
 */
	{
	return CEikDocument::OpenFileL(aDoOpen,aFilename,aFs);
	}
