/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#ifndef OANDX_APPUI_H
#define OANDX_APPUI_H

#include <aknviewappui.h>
#include <eikmenup.h>
#include <eikmenub.h>

class COandXAppViewContainer;
class COandXController;
class COandXEngine;
class COandXGameView;
class COandXHistoryView;

class COandXAppUi : public CAknViewAppUi
/**
	Standard application UI class handles menu commands and
	reports information to the user.
 */
	{
public:
	COandXAppUi();
	virtual ~COandXAppUi();

	// New functions
	void ReportWhoseTurn();
	void ReportWinnerL(TInt aWinner);

	// From CEikAppUi, for persistent data
	TStreamId StoreL(CStreamStore& aStore) const;
	void RestoreL(const CStreamStore& aStore, TStreamId aStreamId);
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);

private:
	// From CEikAppUi
	void HandleCommandL(TInt aCommand);
	void ConstructL();

public:
	// AppUi owns the controller, engine and application view.
	COandXController* iController;
	COandXEngine* iEngine;
private:
	COandXGameView* iAppView;     // Non-owning pointers to
	COandXHistoryView* iHistView; // the two views
	};


// Global accessor functions

GLREF_C COandXAppUi* OandXAppUi();
GLREF_C COandXController& Controller();
GLREF_C COandXEngine& Engine();

#endif // OANDX_APPUI_H

