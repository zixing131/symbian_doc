/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/

#include <coemain.h>
#include <gulutil.h>
#include <e32keys.h>
#include <aknviewappui.h>


#include "OandXAppView.h"
#include "OandXAppUi.h"
#include "OandXController.h"
#include "OandXEngine.h"
#include <OandX.rsg>
#include "OandX.pan"
#include "OandX.hrh"
#include "oandxdefs.h"

COandXGameView* COandXGameView::NewLC()
    {
    COandXGameView* self = new ( ELeave ) COandXGameView();
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

COandXGameView::COandXGameView( )
    {
    }

void COandXGameView::ConstructL()
    {
    BaseConstructL( R_OANDX_GAME_VIEW );
    iContainer = COandXAppViewContainer::NewL(ClientRect());
    iContainer->SetMopParent( this );
    }

COandXGameView::~COandXGameView()
    {
    if (iGameViewStacked)
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
    delete iContainer;
    }

TUid COandXGameView::Id() const
    {
    return KUidOandXView;
    }
    
void COandXGameView::HandleCommandL( TInt aCommand )
    {   
    switch ( aCommand )
        {

        case EAknSoftkeyBack:
            {
            AppUi()->HandleCommandL( EEikCmdExit );
            break;
            }

        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
    }

void COandXGameView::HandleViewRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect(ClientRect());
        }
    }
    
void COandXGameView::DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane)
    {
	if (aResourceId != R_OANDX_GAME_MENU)
		{
		return;
		}
	if (Controller().IsNewGame())
		{
		aMenuPane->DeleteMenuItem(EOandXNewGame);
		if (!Controller().IsCrossTurn())
			{
			aMenuPane->SetItemTextL(EOandXFirstPlayer,R_OANDX_X_MOVES_FIRST);
			}
		}
	else
		{
		aMenuPane->DeleteMenuItem(EOandXFirstPlayer);
		}
	}

void COandXGameView::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                                 TUid /*aCustomMessageId*/,
                                 const TDesC8& /*aCustomMessage*/ )
    {
	__ASSERT_ALWAYS(!iGameViewStacked, Panic(EOandXControlAlreadyStacked));
    AppUi()->AddToStackL( *this, iContainer );
    iGameViewStacked = ETrue;

    iContainer->MakeVisible(ETrue);
    iContainer->DrawNow();
    }

void COandXGameView::DoDeactivate()
    {
	__ASSERT_ALWAYS(iGameViewStacked, Panic(EOandXControlNotStacked));
    AppUi()->RemoveFromViewStack( *this, iContainer );
    iGameViewStacked = EFalse;
    
    iContainer->MakeVisible(EFalse);
    }
    
COandXAppViewContainer* COandXGameView::Container()
    {
    return iContainer;
    }


// O and X symbol-drawing control member functions

void COandXSymbolControl::DrawSymbol(CWindowGc& aGc, const TRect& aRect, TBool aDrawCross) const
	{
	TRect drawRect(aRect);
	
	// Shrink by about 15%
	drawRect.Shrink(aRect.Width()/6,aRect.Height()/6); 
	
    // Pen size set to just over 10% of the overall shape's size
	TSize penSize(aRect.Width()/9,aRect.Height()/9);
	aGc.SetPenSize(penSize);
	aGc.SetPenStyle(CGraphicsContext::ESolidPen);
	
	if (aDrawCross)
		{
		aGc.SetPenColor(KRgbGreen);
		
		// Cosmetic reduction of cross size by half the line width
		drawRect.Shrink(penSize.iWidth/2,penSize.iHeight/2);
		
		aGc.DrawLine(drawRect.iTl, drawRect.iBr);
		TInt temp;
		temp = drawRect.iTl.iX;
		drawRect.iTl.iX = drawRect.iBr.iX;
		drawRect.iBr.iX = temp;
		aGc.DrawLine(drawRect.iTl, drawRect.iBr);
		}
	else // draw a circle
		{
		aGc.SetPenColor(KRgbRed);
		aGc.SetBrushStyle(CGraphicsContext::ESolidBrush);
		aGc.DrawEllipse(drawRect);
		}
	};

// Tile member functions

COandXTile::COandXTile()
	{
	}
	
COandXTile::~COandXTile()
	{
	}

void COandXTile::ConstructL(RWindow& aWindow)
	{
	SetContainerWindowL(aWindow);
	// No call to ActivateL() as the window is activated by its container
	}

void COandXTile::Draw(const TRect& /*aRect*/) const
	{
	TTileState tileType;
	tileType = iCmdHandler->TileStatus(this);

	CWindowGc& gc = SystemGc();
	TRect rect = Rect();
	
	if (IsFocused())
		{
		gc.SetBrushColor(KRgbYellow);
		}
	gc.Clear(rect);
	if (tileType!=ETileBlank)
		{
		DrawSymbol(gc, rect, tileType==ETileCross);
		}
	}

void  COandXTile::SetOwnerAndObserver(COandXAppViewContainer* aControl)
	{
	iCmdHandler = aControl;
	SetObserver(aControl);
	}

void COandXTile::TryHitL()
	{
	if (iCmdHandler->TryHitSquareL(this))
		{
		DrawDeferred();
		}
	}

TKeyResponse COandXTile::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	TKeyResponse keyResponse = EKeyWasNotConsumed;
	if (aType!=EEventKey)
		{
		return keyResponse;
		}
	switch (aKeyEvent.iCode)
		{
	case EKeyOK:
		TryHitL();
		keyResponse = EKeyWasConsumed;
		break;
	default:
		keyResponse = EKeyWasNotConsumed;
		break;		
		}
	return keyResponse;
	}

TCoeInputCapabilities COandXTile::InputCapabilities() const
	{
	return TCoeInputCapabilities::ENavigation;
	}

void COandXTile::HandlePointerEventL(const TPointerEvent& aPointerEvent)
	{
	if (aPointerEvent.iType == TPointerEvent::EButton1Down)
		{
		TryHitL();
		}
	}

void COandXTile::FocusChanged(TDrawNow aDrawNow)
	{
	if (aDrawNow == EDrawNow)
		{
		DrawNow();
		}
	}


// Status window member functions

COandXStatusWin* COandXStatusWin::NewL(RWindow& aWindow)
	{
	COandXStatusWin* self=new(ELeave) COandXStatusWin;
	CleanupStack::PushL(self);
	self->ConstructL(aWindow);
	CleanupStack::Pop();
	self->SetFocusing(EFalse);
	return self;
	}

COandXStatusWin::COandXStatusWin()
	{
	}
	
COandXStatusWin::~COandXStatusWin()
	{
	}
	
void COandXStatusWin::ConstructL(RWindow& aWindow)
	{
	SetContainerWindowL(aWindow);
	// No call to ActivateL() as the window is activated by its container
	}

void COandXStatusWin::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	TRect boxRect = Rect();
	gc.Clear(boxRect);
	TInt boxHeight = boxRect.iBr.iY - boxRect.iTl.iY;
	boxRect.iTl.iX = boxRect.iBr.iX - boxHeight;
	DrawSymbol(gc, boxRect, Controller().IsCrossTurn());
	}


// App View member functions

#define KBorderWidth 10
#define KLineWidth ((KTilesPerRow > KTilesPerCol ? KTilesPerRow : KTilesPerCol) > 4 ? 2 : 4)


COandXAppViewContainer* COandXAppViewContainer::NewL(const TRect& aRect)
	{
	COandXAppViewContainer* self = new(ELeave) COandXAppViewContainer;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	CleanupStack::Pop(self);
	return self;
	}

COandXAppViewContainer::COandXAppViewContainer()
/**
	
 */
	{
	// empty.
	}

COandXAppViewContainer::~COandXAppViewContainer()
	{
	for (TInt i=0; i<KNumberOfTiles; i++)
		{
		delete iTiles[i];
		}
	iTiles.Close();
	delete iStatusWin;
	}

void COandXAppViewContainer::ConstructL(const TRect& aRect)
	{
	// Create a window for this application view
	CreateWindowL();

	for (TInt i = 0; i < KNumberOfTiles; i++)
		{
		User::LeaveIfError(iTiles.Append(CreateTileL()));
		}
	ComponentControl(0)->SetFocus(ETrue);
	iStatusWin = COandXStatusWin::NewL(Window());

	// Set the window's size
	SetRect(aRect); // needs to be after component creation - see SizeChanged()
	// Activate the window, which makes it ready to be drawn
	ActivateL();
	}

COandXTile* COandXAppViewContainer::CreateTileL()
	{
	COandXTile* tile = new(ELeave) COandXTile;
	CleanupStack::PushL(tile);
	tile->ConstructL(Window());
	CleanupStack::Pop(); // tile
	tile->SetOwnerAndObserver(this);
	return tile;
	}
	
void COandXAppViewContainer::SizeChanged()
	{
	__ASSERT_DEBUG(iTiles[KNumberOfTiles-1], Panic(EOandXNoTiles)); // all component tiles must already exist

	TRect rect = Rect();
	rect.iTl.iY = rect.iBr.iY - KStatusWinHeight;
	iStatusWin->SetRect(rect);
	rect = Rect();
	rect.iBr.iY -= KStatusWinHeight;
	TSize controlSize = rect.Size();
	TSize tileSize;
	tileSize.iWidth=2*((controlSize.iWidth-2*KBorderWidth-(KTilesPerRow-1)*KLineWidth)/(2*KTilesPerRow));
	tileSize.iHeight=2*((controlSize.iHeight-2*KBorderWidth-(KTilesPerCol-1)*KLineWidth)/(2*KTilesPerCol));
	iTileSide = tileSize.iWidth < tileSize.iHeight ? tileSize.iWidth :tileSize.iHeight;
	TSize boardSize;
	boardSize.iWidth = KTilesPerRow*iTileSide + (KTilesPerRow-1)*KLineWidth;
	boardSize.iHeight = KTilesPerCol*iTileSide + (KTilesPerCol-1)*KLineWidth;
	iBoardRect.iTl.iX = (controlSize.iWidth - boardSize.iWidth)/2;
	iBoardRect.iTl.iY = (controlSize.iHeight - boardSize.iHeight)/2;
	iBoardRect.iBr.iX = iBoardRect.iTl.iX + boardSize.iWidth;
	iBoardRect.iBr.iY = iBoardRect.iTl.iY + boardSize.iHeight;
	iBorderRect = iBoardRect;
	iBorderRect.Grow(KBorderWidth,KBorderWidth);
	
	for (TInt i=0; i<KNumberOfTiles; i++)
		{
		TInt row = i / KTilesPerRow;
		TInt col = i % KTilesPerRow;
		TRect tileRect;
		tileRect.iTl.iX = iBoardRect.iTl.iX + col * (iTileSide + KLineWidth);
		tileRect.iTl.iY = iBoardRect.iTl.iY + row * (iTileSide + KLineWidth);
		tileRect.iBr.iX = tileRect.iTl.iX + iTileSide;
		tileRect.iBr.iY = tileRect.iTl.iY + iTileSide;
		ComponentControl(i)->SetRect(tileRect);
		}
	}
	
void COandXAppViewContainer::ResetView()
	{
	MoveFocusTo(0);
	DrawNow();
	}


void COandXAppViewContainer::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	TRect rect = Rect();
	
	// Draw outside the border
	gc.SetPenStyle(CGraphicsContext::ENullPen);
	gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
	gc.SetBrushColor(KRgbWhite);
	DrawUtils::DrawBetweenRects(gc, rect, iBorderRect);
	
	// Draw a border around the board
	gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
	gc.SetBrushColor(KRgbGray);
	DrawUtils::DrawBetweenRects(gc, iBorderRect, iBoardRect);
	
	//Draw the first vertical line
	gc.SetBrushColor(KRgbBlack);
	TRect line;
	line.iTl.iX = iBoardRect.iTl.iX + iTileSide;
	line.iTl.iY = iBoardRect.iTl.iY;
	line.iBr.iX = line.iTl.iX + KLineWidth;
	line.iBr.iY = iBoardRect.iBr.iY;
	gc.DrawRect(line);
	// Draw the remaining (KTilesPerRow-2) vertical lines
	for (TInt i = 0; i < KTilesPerRow - 2; i++)
		{
		line .iTl.iX += iTileSide + KLineWidth;
		line .iBr.iX += iTileSide + KLineWidth;
		gc.DrawRect(line);
		}
	// Draw the first horizontal line
	line.iTl.iX = iBoardRect.iTl.iX;
	line.iTl.iY = iBoardRect.iTl.iY + iTileSide;
	line.iBr.iX = iBoardRect.iBr.iX;
	line.iBr.iY = line.iTl.iY + KLineWidth;
	gc.DrawRect(line);
	// Draw the remaining (KTilesPerCol -2) horizontal lines
	for (TInt i = 0; i < KTilesPerCol - 2; i++)
		{
		line .iTl.iY += iTileSide + KLineWidth;
		line .iBr.iY += iTileSide + KLineWidth;
		gc.DrawRect(line);
		}
	}


TInt COandXAppViewContainer::CountComponentControls() const
	{
	return KNumberOfTiles +1;
	}

CCoeControl* COandXAppViewContainer::ComponentControl(TInt aIndex) const
	{
	if (aIndex==KNumberOfTiles)
		{
		return iStatusWin;
		}
	else
		{
		return const_cast<COandXTile*>(iTiles[aIndex]);
		}
	}

TKeyResponse COandXAppViewContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	TKeyResponse keyResponse = EKeyWasNotConsumed;
	if (aType!=EEventKey)
		{
		return keyResponse;
		}
	TInt index = IdOfFocusControl();
	switch (aKeyEvent.iCode)
		{
	case EKeyLeftArrow: // check not in first column
		if (index % KTilesPerRow)
			{
			MoveFocusTo(index-1);
			keyResponse = EKeyWasConsumed;
			}
		break;
	case EKeyRightArrow: // check not in last column
		if ((index % KTilesPerRow) < KTilesPerRow - 1)
			{
			MoveFocusTo(index+1);
			keyResponse = EKeyWasConsumed;
			}
		break;
	case EKeyUpArrow: // check not on top row
		if (index >= KTilesPerRow)
			{
			MoveFocusTo(index-KTilesPerRow);
			keyResponse = EKeyWasConsumed;
			}
		break;
	case EKeyDownArrow: // check not in bottom row
		if (index < KNumberOfTiles - KTilesPerRow)
			{
			MoveFocusTo(index+KTilesPerRow);
			keyResponse = EKeyWasConsumed;
			}
		break;
	default:
		keyResponse = ComponentControl(index)->OfferKeyEventL(aKeyEvent,aType);
		break;
		}
	return keyResponse;
	}

TInt COandXAppViewContainer::IdOfFocusControl()
	{
	TInt ret = -1;
	for (TInt i=0; i<KNumberOfTiles; i++)
		{
		if (ComponentControl(i)->IsFocused())
			{
			ret = i;
			break;
			}
		}
	__ASSERT_ALWAYS(ret>=0, Panic(EOandXNoTileWithFocus));
	return ret;
	}
	
void COandXAppViewContainer::SwitchFocus(TInt aFromIndex, CCoeControl* aToControl)
	{
	ComponentControl(aFromIndex)->SetFocus(EFalse, EDrawNow);
	aToControl->SetFocus(ETrue, EDrawNow);
	}
	
void COandXAppViewContainer::MoveFocusTo(const TInt index)
	{
	TInt oldIndex = IdOfFocusControl();
	if (index!= oldIndex)
		{
		SwitchFocus(oldIndex, ComponentControl(index));
		}
	}


void COandXAppViewContainer::HandleControlEventL(CCoeControl* aControl, TCoeEvent aEventType)
	{
	switch (aEventType)
		{
	case EEventRequestFocus:
		SwitchFocus(IdOfFocusControl(), aControl);
		break;
	default:
		break;
		}
	}

TBool COandXAppViewContainer::TryHitSquareL(const COandXTile* aControl)
	{
	return Controller().HitSquareL(Index(aControl));
	}

TTileState COandXAppViewContainer::TileStatus(const COandXTile* aControl) const
	{
	return Engine().TileStatus(Index(aControl));
	}

void COandXAppViewContainer::ShowTurn()
	{
	iStatusWin->DrawDeferred();
	}
