/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#ifndef OANDXAPPVIEW_H
#define OANDXAPPVIEW_H

#include <coecntrl.h>
#include <coedef.h>
#include <aknview.h>
#include "oandxdefs.h"

class COandXAppViewContainer;
class COandXTile;


class COandXGameView : public CAknView
    {
public: // Constructor and destructor
    static COandXGameView* NewLC();
    ~COandXGameView();

    // Functions from base classes
    TUid Id() const;
    void HandleCommandL(TInt aCommand);
    void HandleViewRectChange();
    void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane); 
    COandXAppViewContainer* Container();

private:
    COandXGameView();
    void ConstructL();

    void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
        const TDesC8& aCustomMessage);
    void DoDeactivate();

private: // Data
    COandXAppViewContainer* iContainer;
	// Set if the Game View's container is added to the control stack.
	TBool iGameViewStacked;
    };

class COandXSymbolControl : public CCoeControl
	{
protected:
	void DrawSymbol(CWindowGc& aGc, const TRect& aRect, TBool aDrawCross) const;
	};
	
class MViewCmdHandler
    {
public:
    virtual TBool TryHitSquareL(const COandXTile* aControl)=0;
    virtual TTileState TileStatus(const COandXTile* aControl) const =0;
    };
    
class COandXTile : public COandXSymbolControl
	{
public:
	COandXTile();
	~COandXTile();
	void ConstructL(RWindow& aWindow);

	// From CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	TCoeInputCapabilities InputCapabilities() const;

	// New function
	void SetOwnerAndObserver(COandXAppViewContainer* aControl);

protected:
	void HandlePointerEventL(const TPointerEvent& aPointerEvent);
	void FocusChanged(TDrawNow aDrawNow);

private:
	// from CCoeControl
	void Draw(const TRect& aRect) const;
	
	// New function
	void TryHitL();

private:
	MViewCmdHandler* iCmdHandler;
	};

class COandXStatusWin : public COandXSymbolControl
	{
public:
	static COandXStatusWin* NewL(RWindow& aWindow);
	~COandXStatusWin();

private:
	COandXStatusWin();
	void ConstructL(RWindow& aWindow);
	void Draw(const TRect& aRect) const;
	};



class COandXAppViewContainer : public CCoeControl, public MCoeControlObserver, public MViewCmdHandler
	{
public:
	static COandXAppViewContainer* NewL(const TRect& aRect);
	virtual ~COandXAppViewContainer();
	
	// From CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);

	// new functions	
	void MoveFocusTo(const TInt aIndex);
	TInt IdOfFocusControl();
	void ShowTurn();
	void ResetView();

private:
	COandXAppViewContainer();
	void ConstructL(const TRect& aRect);

	void SwitchFocus(TInt aFromIndex, CCoeControl* aToControl);
	void DrawComps(TRect& aRect) const;
	COandXTile * CreateTileL();

	// From CCoeControl
	void Draw(const TRect& aRect) const;
	void SizeChanged();
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;
	
	// From MCoeControlObserver
	void HandleControlEventL(CCoeControl* aControl, TCoeEvent aEventType);

	// From MViewCmdHandler
	TBool TryHitSquareL(const COandXTile* aControl);
	TTileState TileStatus(const COandXTile* aControl) const;

private:
	RPointerArray<COandXTile> iTiles; // View owns the tiles
	COandXStatusWin* iStatusWin;	  // and its own status window.
	TRect iBoardRect;  // Board area
	TRect iBorderRect; // Bounding rectangle for border
	TInt iTileSide;	   // Tile dimension, allowing for line widths and border
	};

#endif // OANDXAPPVIEW_H
