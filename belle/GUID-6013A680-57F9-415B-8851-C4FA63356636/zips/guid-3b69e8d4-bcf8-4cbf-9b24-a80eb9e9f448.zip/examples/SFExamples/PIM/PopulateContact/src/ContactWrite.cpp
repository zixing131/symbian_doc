// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactWrite.h"

CContactWrite* CContactWrite::NewL()
	{
	CContactWrite* self = new (ELeave) CContactWrite();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactWrite::~CContactWrite()
	{
	delete iCntDb;
	}

void CContactWrite::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	}

CContactDatabase& CContactWrite::CntDatabase()
	{
	return *iCntDb;
	}

void CContactWrite::PopulateContactL()
	{
	PopulateOwnCardL();
	_LIT(KFirstFirst, "first");
	_LIT(KSecondFirst, "second");
	_LIT(KThirdFirst, "Partner");
	_LIT(KLast, "last");
	TContactItemId first = AddCardL(KFirstFirst(), KLast());
	TContactItemId second = AddCardL(KSecondFirst(), KLast());
	AddCardL(KThirdFirst(), KLast());
	_LIT(KGroup1, "MyGroup1");
	_LIT(KGroup2, "MyGroup2");
	MoveContactL(first, KGroup1());
	MoveContactL(second, KGroup2());
	}


void CContactWrite::PopulateOwnCardL()
	{
	_LIT(KOwnFirstName, "ownfirstname");
	TContactItemId ownId = iCntDb->OwnCardId();
	if (KNullContactId == ownId)
		{
		CContactItem* ownCard = iCntDb->CreateOwnCardLC();
		CleanupStack::PopAndDestroy(ownCard);
		ownCard = NULL;
		ownId = iCntDb->OwnCardId();
		}
	CContactItemViewDef* viewDef = CContactItemViewDef::NewLC(
										CContactItemViewDef::EIncludeFields,
										CContactItemViewDef::EMaskHiddenFields);
	viewDef->AddL(KUidContactFieldGivenName);
	viewDef->AddL(KUidContactFieldCompanyName);
	CContactItem* ownItem = iCntDb->OpenContactLX(ownId, *viewDef );
	CleanupStack::PushL(ownItem);
	CContactItemFieldSet& ownFieldSet = ownItem->CardFields();
	TInt companyIndex = KErrNotFound;
	while (0 <= (companyIndex = ownFieldSet.Find(KUidContactFieldCompanyName)))
		{
		ownFieldSet.Remove(companyIndex);
		}
	TBool nameFound = EFalse;
	for(TInt ii = 0 ; ii < ownFieldSet.Count() && !nameFound; ++ii)
		{
		CContactItemField& field = ownFieldSet[ii];
		if (KStorageTypeText == field.StorageType())
			{
			CContactTextField* storage = field.TextStorage();
			TPtrC text = storage->Text();
			nameFound = (field.ContentType().ContainsFieldType(KUidContactFieldGivenName) &&
						storage->IsFull() && text.Length() > 0);
			}
		}
	if (!nameFound)
		{
		CContactItemField* firstName = CContactItemField::NewLC(KStorageTypeText);
		firstName->AddFieldTypeL(KUidContactFieldGivenName);
		firstName->TextStorage()->SetTextL(KOwnFirstName());
		ownItem->AddFieldL(*firstName);
		CleanupStack::Pop(firstName);
		iCntDb->CommitContactL(*ownItem);
		}
	CleanupStack::PopAndDestroy(ownItem);
	CleanupStack::PopAndDestroy(); // exclusive lock on ownItem
	CleanupStack::PopAndDestroy(viewDef);
	}

TContactItemId CContactWrite::AddCardL(const TDesC& aFirstName, const TDesC& aLastName)
	{
	CContactCard* contactCard = CContactCard::NewLC();
	
	CContactItemField* firstName = CContactItemField::NewLC(KStorageTypeText);
	firstName->AddFieldTypeL(KUidContactFieldGivenName);
	firstName->TextStorage()->SetTextL(aFirstName);
	contactCard->AddFieldL(*firstName);
	CleanupStack::Pop(firstName);
	
	CContactItemField* lastName = CContactItemField::NewLC(KStorageTypeText);
	lastName->AddFieldTypeL(KUidContactFieldFamilyName);
	lastName->TextStorage()->SetTextL(aLastName);
	contactCard->AddFieldL(*lastName);
	CleanupStack::Pop(lastName);
	
	TContactItemId result = iCntDb->AddNewContactL( *contactCard );
	
	CleanupStack::PopAndDestroy(contactCard);
	return result;
	}

void CContactWrite::MoveContactL(TContactItemId aCntId, const TDesC& aNewGroup)
	{
	// open the contact item for exclusive use
	CContactItem* item = iCntDb->OpenContactLX(aCntId);
	CleanupStack::PushL(item);
	// Let�s find out what group the contact already belongs to
	TContactItemId groupId = KNullContactId;
	CContactItem* group = NULL;
	if (KUidContactCard == item->Type())
		{
		CContactCard* card = (CContactCard*)item;
		CContactIdArray* ids = card->GroupsJoinedLC();
		if (0 < ids->Count())
			{
			groupId = (*ids)[0];
			}
		CleanupStack::PopAndDestroy(ids);
		}
	if (KNullContactId != groupId)
		{
		// let�s remove the contact from the group
		group = iCntDb->OpenContactLX(groupId);
		CleanupStack::PushL(group);
		iCntDb->RemoveContactFromGroupL(*item, *group);

		CleanupStack::PopAndDestroy(group);
		CleanupStack::PopAndDestroy(); // exclusive lock on group
		group = NULL;
		}
	CleanupStack::PopAndDestroy(item);
	CleanupStack::PopAndDestroy(); // exclusive lock on item

	// let�s find the new group in the database, or create it if needs be

	groupId = KNullContactId;
	CContactIdArray* groupArrayId = iCntDb->GetGroupIdListL();
	if (NULL != groupArrayId)
		{
		CleanupStack::PushL(groupArrayId);
		for (TInt ii = 0 ; ii < groupArrayId->Count() ; ++ii)
			{
			group = iCntDb->ReadContactLC((*groupArrayId)[ii]);
			TPtrC label = ((CContactGroup*)group)->GetGroupLabelL();
			if (aNewGroup == label)
				{
				groupId = (*groupArrayId)[ii];
				ii = groupArrayId->Count(); // break
				}
			CleanupStack::PopAndDestroy(group);
			group = NULL;
			}
		CleanupStack::PopAndDestroy(groupArrayId);
		}
	if (KNullContactId == groupId)
		{
		group = iCntDb->CreateContactGroupLC(aNewGroup);
		groupId = group->Id();
		CleanupStack::PopAndDestroy(group);
		}
	// let�s add the contact to the group
	iCntDb->AddContactToGroupL(aCntId, groupId);
	}


// End of File
