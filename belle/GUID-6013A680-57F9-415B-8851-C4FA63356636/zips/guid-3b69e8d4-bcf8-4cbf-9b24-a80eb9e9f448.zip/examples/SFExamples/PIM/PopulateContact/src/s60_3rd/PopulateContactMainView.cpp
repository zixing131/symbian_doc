// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <PopulateContact.rsg>

#include "PopulateContactMainView.h"

CPopulateContactMainView* CPopulateContactMainView::NewL(const TRect& aRect)
	{
	CPopulateContactMainView* self = CPopulateContactMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

CPopulateContactMainView* CPopulateContactMainView::NewLC(const TRect& aRect)
	{
	CPopulateContactMainView* self = new (ELeave) CPopulateContactMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

CPopulateContactMainView::~CPopulateContactMainView()
	{
	delete iEikEdwin;
	}
	
void CPopulateContactMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_POPULATECONTACT);
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

void CPopulateContactMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawNow();
		}
	}

TInt CPopulateContactMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

CCoeControl* CPopulateContactMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return NULL;
	}

void CPopulateContactMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void CPopulateContactMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
