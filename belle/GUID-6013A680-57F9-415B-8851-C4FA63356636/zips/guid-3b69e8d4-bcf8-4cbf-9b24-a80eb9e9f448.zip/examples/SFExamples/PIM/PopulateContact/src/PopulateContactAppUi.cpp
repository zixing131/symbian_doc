// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <PopulateContact.rsg>

#include "PopulateContactAppUi.h"
#include "PopulateContactMainView.h"
#include "ContactWrite.h"
#include "PopulateContact.hrh"

void CPopulateContactAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CPopulateContactMainView::NewL(ClientRect());

	iContactWriter = CContactWrite::NewL();
	}
	
CPopulateContactAppUi::~CPopulateContactAppUi()
    {
    delete iContactWriter;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CPopulateContactAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EPopulateContact:
			{
			TRAPD(error, iContactWriter->PopulateContactL());
			// report error on the Label control
			if (KErrNone == error)
				{
				_LIT(KSuccess, "It Worked!");
				iMainView->SetTextL(KSuccess());
				}
			else
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		case EDeleteDatabase:
			{
			TRAPD(error, iContactWriter->CntDatabase().DeleteDefaultFileL());
			// report error on the Label control
			if (KErrNone == error)
				{
				_LIT(KSuccess, "It Worked!");
				iMainView->SetTextL(KSuccess());
				}
			else
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CPopulateContactAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
