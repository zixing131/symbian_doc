/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: BitmapsGraphicsShell.h� 
*/


#ifndef __BitmapsGraphicsShell_H
#define __BitmapsGraphicsShell_H

#include <coecntrl.h>
#include <coeccntx.h>

#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>

#include "BitmapsGraphicsControl.h"

// UID of app

const TUid KUidExampleShellApp={ 0xE800004F };

//
// TExampleShellModel
//

class TExampleShellModel
	{
public:
	TExampleShellModel();
	TBool Differs(const TExampleShellModel* aCompare) const;
public:
	TFileName iLibrary; // active control
	};

//
// class CExampleShellContainer
//

class CExampleShellContainer : public CCoeControl,
		public MCoeControlBrushContext,
		public MGraphicsExampleObserver
    {
public:
    void ConstructL(const TRect& aRect, TExampleShellModel* aModel);
    ~CExampleShellContainer();
	// changing view
	void ResetExampleL(CGraphicExampleControl* aExample);
private: // from CCoeControl
	void Draw(const TRect& /*aRect*/) const;
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
    TInt CountComponentControls() const;
    CCoeControl* ComponentControl(TInt aIndex) const;
private: // from MGraphicsExampleObserver
	void NotifyGraphicExampleFinished();
public: // also from MGraphicsExampleObserver
	void NotifyStatus(const TDesC& aMessage);
private: // new function
	void CreateLabelL();
private: // data
	CGraphicExampleControl* iExampleControl; // example control
	CEikLabel* iLabel; // label for status messages
	// irrelevant
	TExampleShellModel* iModel;
    };

//
// CExampleShellDocument
//

class CExampleShellDocument : public CEikDocument
	{
public:
	CExampleShellDocument(CEikApplication& aApp): CEikDocument(aApp) { }
	TExampleShellModel* Model() { return(&iModel); }
private: // from CEikDocument
	CEikAppUi* CreateAppUiL();
private:
	TExampleShellModel iModel;
	};

//
// CExampleShellAppUi
//

class CExampleShellAppUi : public CEikAppUi
    {
public:
    void ConstructL();
	~CExampleShellAppUi();
private: // from CEikAppUi
	void HandleCommandL(TInt aCommand);
private: // internal use
//	void PrepareToolbarButtons();
private:
    CExampleShellContainer* iContainer;
	TExampleShellModel* iModel;
    };

//
// CExampleShellApplication
//

class CExampleShellApplication : public CEikApplication
	{
private: // from CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};

#endif
