/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef __ENCODERSELECTIONDIALOG_H__
#define __ENCODERSELECTIONDIALOG_H__

// INCLUDES
#include <aknview.h>
#include <eikdialg.h>
#include <akndialog.h>
#include <eiklbo.h>
#include <AknsDrawUtils.h>

// FORWARD DECLARATIONS
class CImageConverterEngine;
class CAknSingleStyleListBox;


// CLASS DECLARATION

/**
*  Dialog class
*  Test various controls.
*/
class CEncoderSelectionDialog : public CAknDialog, public MEikListBoxObserver
    {
    public: // Constructors and destructor
        /**
        * Constructor
        * @param aImageTypes Image types to choose from.
        * @param sSelectedIdx The selected index is stored here.
        */      
        CEncoderSelectionDialog( 
            RImageTypeDescriptionArray& aImageTypes, 
            TInt& aSelectedIdx );
        
        /**
        * Destructor
        */
        ~CEncoderSelectionDialog();

    public: // from base classes
        /**
        * From CAknDialog set parameters before and do cleanup after showing 
        * dialog.
        */
        void PreLayoutDynInitL();

        void PostLayoutDynInitL();

        /**
        * From CCoeControl. Pass key events to contained listbox.
        */
        TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,
            TEventCode aType);

        /**
        * From CAknDialog update member variables of CAknExEditorDialog.
        * @param aButtonId The ID of the button that was activated.
        * @return Should return ETrue if the dialog should exit,
        *    and EFalse if it should not
        */
        TBool OkToExitL(TInt aButtonId);

    private: // from base classes
        /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

        /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;
    
        void SizeChanged();
        void HandleListBoxEventL(CEikListBox* aListBox, TListBoxEvent aEventType);
        void HandleResourceChange(TInt aType);

        static TInt PeriodicTimerCallBack(TAny* aAny);

    private: // data

        /*! @var iImageTypes the image types to choose from. */
        RImageTypeDescriptionArray& iImageTypes;

        /*! @var iSelectedIdx the selected index from image types */
        TInt& iSelectedIdx;
    
        /*! @var iListBox the control used to display the results */
        CAknSingleStyleListBox* iListBox;

        /*! @var iMessageList the list of messages to display */
        CDesCArrayFlat* iMessageList;
        
        CPeriodic*      iPeriodic;
        
    };

#endif //__ENCODERSELECTIONDIALOG_H__
