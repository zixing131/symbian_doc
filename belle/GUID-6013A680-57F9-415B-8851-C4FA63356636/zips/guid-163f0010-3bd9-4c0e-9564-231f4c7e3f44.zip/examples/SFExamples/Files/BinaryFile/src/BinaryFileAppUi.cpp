/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */ 

// INCLUDES
#include <f32file.h>
#include <bautils.h>
#include <BinaryFile.rsg>

#include "BinaryFileAppUi.h"
#include "BinaryFileMainView.h"
#include "BinaryFile.hrh"

// CONSTANTS
const TInt KMaxBuffer = 512;
_LIT(KNewFileName,    "c:\\data\\newfile.dat");
_LIT(KSourceFileName, "c:\\data\\sourcefile.dat");
_LIT(KDestFileName,   "c:\\data\\destfile.dat");

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CBinaryFileAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);	
	iMainView = CBinaryFileMainView::NewL(ClientRect());
	BaflUtils::EnsurePathExistsL(iCoeEnv->FsSession(), KNewFileName);
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CBinaryFileAppUi::~CBinaryFileAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CBinaryFileAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:

		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EBinaryFileWriteToFile:
			{
			RFs& fileServer = iCoeEnv->FsSession();
			
			// Create a buffer to be written to the file.				
			RBuf8 buffer;
			User::LeaveIfError(buffer.CreateMax(KMaxBuffer));
			CleanupClosePushL(buffer);
				
			// Fill the buffer with your data.
			// �
			for (TInt i = 0; i < KMaxBuffer; i++)
				{
				buffer[i] = i;
				}

			// Write buffer to the file.
			WriteDescToFileL(fileServer, KNewFileName, buffer);

			// Delete the buffer.
			CleanupStack::PopAndDestroy(&buffer);
			
			iEikonEnv->InfoWinL(
					R_BINARYFILE_CAPTION, R_BINARYFILE_FILEWRITTEN);
			break;
			}
			
		case EBinaryFileReadFromFile:
			{
			RFs& fileServer = iCoeEnv->FsSession();
			
			// Create a new buffer
			RBuf8 buffer;
			User::LeaveIfError(buffer.CreateMax(KMaxBuffer));
			CleanupClosePushL(buffer);
			
			// Read from the file.
			// We have to make sure that the buffer has enough space,
			// otherwise it will panic.
			ReadDescFromFileL(fileServer, KSourceFileName, buffer);
			
			// Write the buffer to a file.
			WriteDescToFileL(fileServer, KDestFileName, buffer);
			
			// Delete the buffer.
			CleanupStack::PopAndDestroy(&buffer);
			
			iEikonEnv->InfoWinL(R_BINARYFILE_CAPTION, R_BINARYFILE_FILEREAD);
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}

	


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CBinaryFileAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}



// --------------------------------------------------------------------------
// Writes descriptor to a file.
// --------------------------------------------------------------------------
void CBinaryFileAppUi::WriteDescToFileL(RFs& aFs, const TDesC& aFileName,
		const TDesC8& aBuffer)
	{
	RFile file;
	User::LeaveIfError(file.Replace(aFs, aFileName, EFileWrite));
	CleanupClosePushL(file);
	
	User::LeaveIfError(file.Write(aBuffer, aBuffer.Length()));
	
	CleanupStack::PopAndDestroy(&file);
	}

// --------------------------------------------------------------------------
// Reads descriptor from a file.
// Note that the descriptor must have sufficient length; otherwise it
// will leave.
// --------------------------------------------------------------------------
void CBinaryFileAppUi::ReadDescFromFileL(RFs& aFs, const TDesC& aFileName,
		TDes8& aBuffer)
	{
	RFile file;
	User::LeaveIfError(file.Open(aFs, aFileName, EFileRead));
	CleanupClosePushL(file);
	
	// Get the file size.
	TInt fileSize;
	User::LeaveIfError(file.Size(fileSize));
	
	// If the maximum length of the buffer is less than the file size,
	// it means we don't have enough space.
	if (aBuffer.MaxLength() < fileSize)
		{
		User::Leave(KErrOverflow);
		}
	User::LeaveIfError(file.Read(aBuffer, fileSize));
	
	CleanupStack::PopAndDestroy(&file); // file
	}

// End of File
