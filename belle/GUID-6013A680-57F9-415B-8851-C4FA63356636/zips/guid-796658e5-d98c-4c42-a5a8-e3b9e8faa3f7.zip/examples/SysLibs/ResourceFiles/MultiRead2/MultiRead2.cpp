/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:
This example shows how to use multiple resource files with cross-referenced
resources.  It depends on the resource file created for the MultiRead1 project.
It introduces a second resource file, MultiRead2, which contains an LLINK
to a resource defined in the MultiRead1 project. The important point to note is
that the effect of introducing this second resource file is minimal: just
another #include file; and the logic in doExampleL() would be identical whether
the LLINK pointed to another resource in the same file or a different file.� 
*/





#include "CommonToResourceFilesEx.h"
#include <multiread2.rsg> // user resources
#include "MultiRead.h"    // definition of multi-resource-reader class

// Do the example
void doExampleL()
	{
	_LIT(KFormat,"%S\n");

	// allocate multi-reader
	CMultipleResourceFileReader* multiReader =
			CMultipleResourceFileReader::NewLC();

	// open resource file on the emulator(__WINS__  is defined for the Windows emulator)
    #if defined(__WINS__)
    // add MultiRead1 version 23
    _LIT(KZSystemDataBasigbRsc,"Z:\\Resource\\apps\\MultiRead1.rsc");
    multiReader->AddResourceFileL(KZSystemDataBasigbRsc,23);
    // add MultiRead2 version 17
    _LIT(KZSystemDataBasiguRsc,"Z:\\Resource\\apps\\MultiRead2.rsc");
    multiReader->AddResourceFileL(KZSystemDataBasiguRsc,17);
    #else  // open a resource file on the target phone
    // add MultiRead1 version 23
    _LIT(KCSystemDataBasigbRsc,"C:\\Resource\\apps\\MultiRead1.rsc");
    multiReader->AddResourceFileL(KCSystemDataBasigbRsc,23);
    // add MultiRead2 version 17
    _LIT(KCSystemDataBasiguRsc,"C:\\Resource\\apps\\MultiRead2.rsc");
    multiReader->AddResourceFileL(KCSystemDataBasiguRsc,17);
    #endif
	
	// read resource that returns a reference to another resource
	HBufC8* refBuffer=multiReader->AllocReadLC(R_USER_HELLOREF);
	TResourceReader theReader;
	theReader.SetBuffer(refBuffer);
	TInt referencedId=theReader.ReadInt32(); // treat resource as integer
	CleanupStack::PopAndDestroy(); // refBuffer
	// read the other resource
	HBufC8* dataBuffer=multiReader->AllocReadLC(referencedId);
	TResourceReader reader;
	reader.SetBuffer(dataBuffer);
	TPtrC textdata = reader.ReadTPtrC();

	// write string to test console
	console->Printf(KFormat, &textdata);
	// clean up data buffer
	CleanupStack::PopAndDestroy(); // finished with dataBuffer
	// cleanup multi-reader
	CleanupStack::PopAndDestroy(); // multi-reader
	}
