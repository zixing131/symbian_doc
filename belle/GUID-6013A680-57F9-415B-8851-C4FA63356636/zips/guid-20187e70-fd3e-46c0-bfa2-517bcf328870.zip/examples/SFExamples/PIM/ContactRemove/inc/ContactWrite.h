// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __ContactWrite_H_
#define __ContactWrite_H_

#include <e32std.h>
#include <e32base.h>
#include <CNTDB.H>
#include <CNTITEM.H>
#include <CNTFIELD.H>
#include <CNTDEF.H>

class CContactWrite : public CBase
{
public:

	static CContactWrite* NewL();
	~CContactWrite();

	void RemoveContactL(TContactItemId aCntId);
	CContactDatabase& CntDatabase();

private:

	void ConstructL();

private:

	CContactDatabase* iCntDb;

};

#endif // __ContactWrite_H_

// End of File
