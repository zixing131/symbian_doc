// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <ContactRemove.rsg>

#include "ContactRemoveMainView.h"

CContactRemoveMainView* CContactRemoveMainView::NewL(const TRect& aRect)
	{
	CContactRemoveMainView* self = CContactRemoveMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

CContactRemoveMainView* CContactRemoveMainView::NewLC(const TRect& aRect)
	{
	CContactRemoveMainView* self = new (ELeave) CContactRemoveMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

CContactRemoveMainView::~CContactRemoveMainView()
	{
	delete iEikEdwin;
	}
	
void CContactRemoveMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
	iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_CONTACTREMOVE);
	iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

void CContactRemoveMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawNow();
		}
	}

TInt CContactRemoveMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

CCoeControl* CContactRemoveMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return NULL;
	}

void CContactRemoveMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void CContactRemoveMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
