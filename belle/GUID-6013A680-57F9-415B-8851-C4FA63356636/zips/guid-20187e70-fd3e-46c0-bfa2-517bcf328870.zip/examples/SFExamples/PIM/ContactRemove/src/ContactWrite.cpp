// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactWrite.h"

CContactWrite* CContactWrite::NewL()
	{
	CContactWrite* self = new (ELeave) CContactWrite();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactWrite::~CContactWrite()
	{
	delete iCntDb;
	}

void CContactWrite::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	}

CContactDatabase& CContactWrite::CntDatabase()
	{
	return *iCntDb;
	}

void CContactWrite::RemoveContactL(TContactItemId aCntId)
	{
	// just delete it
	iCntDb->DeleteContactL(aCntId);
	}


// End of File
