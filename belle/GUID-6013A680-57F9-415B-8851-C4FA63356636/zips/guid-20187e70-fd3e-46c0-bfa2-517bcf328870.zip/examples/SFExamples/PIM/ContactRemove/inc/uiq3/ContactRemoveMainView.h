// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef __ContactRemoveVIEW_H_
#define __ContactRemoveVIEW_H_

#include <QikViewBase.h>

class CEikLabel;

class CContactRemoveMainView : public CQikViewBase
	{
public:

	static CContactRemoveMainView* NewLC(CQikAppUi& aAppUi);
	~CContactRemoveMainView();

public: // From CQikViewBase

	TVwsViewId ViewId()const;
	void HandleCommandL(CQikCommand& aCommand);

public:

	void SetTextL(const TDesC& aText);

protected: // From CQikViewBase

	void ViewConstructL();
	void SizeChanged();

private:

	CContactRemoveMainView(CQikAppUi& aAppUi);
	void ConstructL();
	
private:

	CEikLabel* iEikLabel;

	};

#endif // __ContactRemoveVIEW_H_

// End of File
