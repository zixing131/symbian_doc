// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactRemove.rsg>

#include "ContactRemoveAppUi.h"
#include "ContactRemoveMainView.h"
#include "ContactWrite.h"
#include "ContactRemove.hrh"

void CContactRemoveAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactRemoveMainView::NewL(ClientRect());

	iContactWriter = CContactWrite::NewL();
	}
	
CContactRemoveAppUi::~CContactRemoveAppUi()
	{
	delete iContactWriter;
	delete iMainView;
	}

void CContactRemoveAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		case EContactRemove:
			{
			CContactDatabase& cntDb = iContactWriter->CntDatabase();
			TContactItemId cntId = cntDb.OwnCardId();
			// this is just one easy way to get a TContactItemId.
			// the \PIM\PopulateContact sample code would have created
			// an own card
			if (KNullContactId != cntId)
				{
				TRAPD(error, iContactWriter->RemoveContactL(cntId));
				// report error on the Label control
				if (KErrNone == error)
					{
					_LIT(KSuccess, "It Worked!");
					iMainView->SetTextL(KSuccess());
					}
				else
					{
					_LIT(KErrorMsg, "Symbian Error Code = %D");
					TBuf<32> errorBuf;
					errorBuf.Format(KErrorMsg(), error);
					iMainView->SetTextL(errorBuf);
					}
				}
			else
				{
				_LIT(KNotFound, "No Own Card");
				iMainView->SetTextL(KNotFound());
				}
			break;
			}
		default:
			break;
		}
	}

	

void CContactRemoveAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

	
// End of File
