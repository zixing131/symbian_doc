// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <ContactRemove.rsg>

#include "ContactRemoveExternalInterface.h"
#include "ContactRemoveAppUi.h"
#include "ContactRemoveMainView.h"
#include "ContactRemove.hrh"

// MEMBER FUNCTIONS

CContactRemoveMainView* CContactRemoveMainView::NewLC(CQikAppUi& aAppUi)
	{
	CContactRemoveMainView* self = new (ELeave) CContactRemoveMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CContactRemoveMainView::CContactRemoveMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

CContactRemoveMainView::~CContactRemoveMainView()
	{
	}

void CContactRemoveMainView::ConstructL()
	{
	BaseConstructL();
	SetExtentToWholeScreen();
	}
	
void CContactRemoveMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_CONTACTREMOVE_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EContactRemoveLabelCtrl);
	}

TVwsViewId CContactRemoveMainView::ViewId()const
	{
	return TVwsViewId(KUidContactRemoveApp, KUidContactRemoveMainView);
	}

void CContactRemoveMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

void CContactRemoveMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

void CContactRemoveMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
