/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include <f32file.h>
#include "CommonFramework.h"
	
static RFs fsSession;

// example functions
void CreatePathsL(); // sets up the paths to parse
void ParseNamesL(const TDesC& aFullName); // does the parsing

void WaitForKey()
	{
	_LIT(KMessage,"Press any key to continue\n\n");
	console->Printf(KMessage);
	console->Getch();
	}

static void doExampleL()
    {
	// Connect to file server
	User::LeaveIfError(fsSession.Connect()); // Start session
	CreatePathsL();
	fsSession.Close(); // close session
	}

void CreatePathsL()
	{
	// Define descriptor constants using the _LIT macro 
	_LIT(KFuncName,"\nDoParsing()\n");
	_LIT(KParse1,"d:\\path\\fn.ext");
	_LIT(KParse2,"autoexec.bat");
	_LIT(KParse3,"\\readme");
	_LIT(KParse4,"\\include\\stdio.h");
	_LIT(KParse5,".profile");
	_LIT(KParse6,"autoexec.*");
	console->Printf(KFuncName);
	// Parse a full path, then paths with various components missing 
	// to show the results of using a default path and related path
	// to fill in missing path components.
	ParseNamesL(KParse1);
	WaitForKey();
	ParseNamesL(KParse2);
	WaitForKey();
	ParseNamesL(KParse3);
	WaitForKey();
	ParseNamesL(KParse4);
	WaitForKey();
	ParseNamesL(KParse5);
	WaitForKey();
	ParseNamesL(KParse6);
	WaitForKey();
	}

void ParseNamesL(const TDesC& aFullName)
	{
	_LIT(KFullName,"Full name=%S\n");
	_LIT(KPathComponents,"Drive=%S  path=%S  name=%S  ext=%S\n");
	_LIT(KFullNameText,"Full name against session path=%S\n");
	_LIT(KExtension,".txt");
	_LIT(KParsedPath,"Full name against session path and default extension=%S\n");

	// Set up parse using TParse::Set(). Print whole path, then each path
	// component in turn.
	// Parse path using the default session path, using RFs::Parse 
	// then additionally with a related path.
	TParse p;
	// do isolated parse
	User::LeaveIfError(p.Set(aFullName,NULL,NULL));
	console->Printf(KFullName, &p.FullName());
	TFileName drivename(p.Drive());
	TFileName pathname(p.Path());
	TFileName filename(p.Name());
	TFileName extension(p.Ext());
	console->Printf(KPathComponents,&drivename,&pathname,&filename,&extension);
	// do parse including session path
	User::LeaveIfError(fsSession.Parse(aFullName,p));
	console->Printf(KFullNameText,&(p.FullName()));
	// add default extension
	User::LeaveIfError(fsSession.Parse(aFullName,KExtension,p));
	console->Printf(KParsedPath,&(p.FullName()));
	}




