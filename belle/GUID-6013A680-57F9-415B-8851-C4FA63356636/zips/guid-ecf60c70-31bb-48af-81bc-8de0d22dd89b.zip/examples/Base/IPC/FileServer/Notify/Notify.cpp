/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "Notify.h"

_LIT(KStarted,"Copy started\n");
_LIT(KComplete,"Copy complete\n");
_LIT(KProgress,"%d bytes copied\n");

// 
// TFileCopyProgressMonitor
// 

TFileCopyProgressMonitor::TFileCopyProgressMonitor(CFileMan& aFileMan)
:iFileMan(aFileMan)
	{	
	}

// Called when copy operation started
MFileManObserver::TControl TFileCopyProgressMonitor::NotifyFileManStarted()
	{
	console->Printf(KStarted);
	return EContinue;
	}

// Called when copy operation is in progress
MFileManObserver::TControl TFileCopyProgressMonitor::NotifyFileManOperation()
	{
	console->Printf(KProgress,iFileMan.BytesTransferredByCopyStep());
	return EContinue;
	}

// Called when copy operation is complete
MFileManObserver::TControl TFileCopyProgressMonitor::NotifyFileManEnded()
	{
	console->Printf(KComplete);
	return EContinue;
	}
	

//
// Do the example
//

LOCAL_C void doExampleL()
    {
	_LIT(KSourcePath,"dataFile\\");
	_LIT(KDestinationPath,"dataFileCopy\\");
	
	TInt err;

	  // Connect session
	RFs fsSession;
	User::LeaveIfError(fsSession.Connect());
	
	  // create the private directory
	User::LeaveIfError(fsSession.CreatePrivatePath(RFs::GetSystemDrive()));
	
	  // Set the session path to the private directory
    User::LeaveIfError(fsSession.SetSessionToPrivate(RFs::GetSystemDrive()));
	
	  // Get the private directory name
	TFileName path;
	fsSession.PrivatePath(path);
  
      // Create a source and a target directory
	RBuf pathSource;
	RBuf pathDestination;
	
	pathSource.CreateL(sizeof(TFileName));
	pathSource.CleanupClosePushL();
	pathSource.Append(path);
	pathSource.Append(KSourcePath);
	
	pathDestination.CreateL(sizeof(TFileName));
	pathDestination.CleanupClosePushL();
	pathDestination.Append(path);
	pathDestination.Append(KDestinationPath);
	
	err=fsSession.MkDir(pathSource);
	if (err!=KErrAlreadyExists)
		User::LeaveIfError(err);
	
	err=fsSession.MkDir(pathDestination);
	if (err!=KErrAlreadyExists)
		User::LeaveIfError(err);
	
	  // Create 2 source files in the source directory
	  // so that we have something to copy.
    _LIT(KFile1,"dataFile1.txt");
    _LIT(KFile2,"dataFile2.txt");
    _LIT8(KFile1Data,"File data qwertyu");
    _LIT8(KFile2Data,"File data iop");
    
    fsSession.SetSessionPath(pathSource);
    RFile file;
    
    User::LeaveIfError(file.Replace(fsSession,KFile1,EFileWrite));
	User::LeaveIfError(file.Write(KFile1Data));
	User::LeaveIfError(file.Flush()); // Commit data
	file.Close(); // close file having finished with it
	
	User::LeaveIfError(file.Replace(fsSession,KFile2,EFileWrite));
	User::LeaveIfError(file.Write(KFile2Data));
	User::LeaveIfError(file.Flush()); // Commit data
	file.Close(); // close file having finished with it
    
    	// Create file management object
	CFileMan* fileMan = CFileMan::NewL(fsSession);
	CleanupStack::PushL(fileMan); 

	   // Create file management notification object and set to observe
	TFileCopyProgressMonitor fileCopyProgressMonitor(*fileMan);
	fileMan->SetObserver(&fileCopyProgressMonitor);
	
	  // Do copy (here synchronously)
	fileMan->Copy(pathSource,pathDestination);
	
	  // Clean up 3 items 
	CleanupStack::PopAndDestroy(3);
	
	  // Close file server session and note that we have not deleted
	  // any files or directories created here.
	fsSession.Close();
	}

