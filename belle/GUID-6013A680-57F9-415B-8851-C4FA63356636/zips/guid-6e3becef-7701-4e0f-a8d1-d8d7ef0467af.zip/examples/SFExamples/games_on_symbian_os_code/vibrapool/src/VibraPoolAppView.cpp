// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Application view implementation
// 
// 


// INCLUDE FILES
#include <coemain.h>
#include "VibraPoolAppView.h"
#include <e32math.h>

// Definitions related to the animation of the ball
#define BALL_DIAMETER 25
#define THRESHOLD  15
#define TABLE_BORDER 30
#define STEP 3


// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CVibraPoolAppView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CVibraPoolAppView* CVibraPoolAppView::NewL( const TRect& aRect )
	{
	CVibraPoolAppView* self = CVibraPoolAppView::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CVibraPoolAppView* CVibraPoolAppView::NewLC( const TRect& aRect )
	{
	CVibraPoolAppView* self = new ( ELeave ) CVibraPoolAppView;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self; 
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();
	// Set the windows size
	SetRect( aRect );
	// Activate the window, which makes it ready to be drawn
	ActivateL();

	//========================================
	// Constructing our vibration control
	//========================================
	//
    iVibra = CHWRMVibra::NewL(); // No callbacks
    // Initial ball location on screen (set randomly).
    // Tee idea here is to limit the range of random numbers generated to the
    // valid area of the pool table where the ball may bouce (taking into consideration
    // the width of the wooden borders of the table and the diameter of the ball).
    iBallLoc.iX = Math::Random()%(aRect.Width()-(TABLE_BORDER*2)-(BALL_DIAMETER)-(THRESHOLD*2))+(THRESHOLD+TABLE_BORDER);
    iBallLoc.iY = Math::Random()%(aRect.Height()-(TABLE_BORDER*2)-(BALL_DIAMETER)-(THRESHOLD*2))+(THRESHOLD+TABLE_BORDER);
    // Number of pixels to step each time the ball moves
    iMoveX = iMoveY = STEP;
    // The ball is drawn because it did not fall in a hole
	iDrawBall = ETrue;
	// Construct and start our asynchronous object responsible of moving the ball. 
	iMove = CMoveBall::NewL(*this);
    iMove->StartMovingBall();
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::CVibraPoolAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CVibraPoolAppView::CVibraPoolAppView()
	{
	// No implementation required
	}


// -----------------------------------------------------------------------------
// CVibraPoolAppView::~CVibraPoolAppView()
// Destructor.
// -----------------------------------------------------------------------------
//
CVibraPoolAppView::~CVibraPoolAppView()
	{
    delete iVibra;
    delete iMove;
    }


// -----------------------------------------------------------------------------
// CVibraPoolAppView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	// Gets the control's extent
	TRect drawRect( Rect());
	// Clears the screen
	gc.Clear( drawRect );

	// Drawing the table
	//
	gc.SetPenStyle(CGraphicsContext::ENullPen);
	gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
	gc.SetBrushColor(TRgb(128,80,50));	// Dark brown
	gc.DrawRect(drawRect);
	gc.SetBrushColor(KRgbDarkGreen);
	gc.DrawRect(TRect(10,10, drawRect.Width()-10,drawRect.Height()-10));
	gc.SetBrushColor(KRgbGreen);
	gc.DrawRect(TRect(TABLE_BORDER,TABLE_BORDER, drawRect.Width()-TABLE_BORDER,drawRect.Height()-TABLE_BORDER));

	// Drawing the holes (the positions are set empirically)
	//
	gc.SetBrushColor(KRgbBlack);
		// Upper left
	gc.DrawEllipse(TRect(15, 15, 50, 50));
		// Upper right
	gc.DrawEllipse(TRect(drawRect.Width()-50, 15, drawRect.Width()-15, 50));
		// Lower left
	gc.DrawEllipse(TRect(15, drawRect.Height()-50, 50, drawRect.Height()-15));
		// Upper left
	gc.DrawEllipse(TRect(drawRect.Width()-50, drawRect.Height()-50, drawRect.Width()-15, drawRect.Height()-15));
		
	// Drawing the ball
	//
	if(iDrawBall)
		{		
		gc.SetBrushColor(KRgbRed);
		// The ball is drawn in its new location everytime CMoveBall updates it
		gc.DrawEllipse(TRect(iBallLoc.iX, iBallLoc.iY, iBallLoc.iX+25, iBallLoc.iY+25));
		}
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::SizeChanged()
	{  
	DrawNow();
	}


//======================== VIBRAPOOL SPECIFIC FUNCTIONS ========================

// -----------------------------------------------------------------------------
// CVibraPoolAppView::HolesDetection()
// Called by application to detect if the ball fell in a hole or not
// -----------------------------------------------------------------------------
//
TBool CVibraPoolAppView::HolesDetection()
	{
	TRect r = Rect();
	// TABLE_BORDER represents the value of THRESHOLD+(TABLE_BORDER/2) which is the distance between
	// the position of the ball and the center of the hole. If it is less than 6 then the ball falls.
	// Otherwise, it continues rolling.
		// check if ball falls in upper left hole
	if( iBallLoc.iX - TABLE_BORDER <= 6 && iBallLoc.iY - TABLE_BORDER <= 6 || 
		// check if ball falls in upper right hole
		(Rect().Width()-TABLE_BORDER) - iBallLoc.iX <= (6+BALL_DIAMETER) && iBallLoc.iY - TABLE_BORDER <= 6 ||
		// check if ball falls in lower left hole
		iBallLoc.iX - TABLE_BORDER <= 6 && (Rect().Height()-TABLE_BORDER) - iBallLoc.iY <= (6+BALL_DIAMETER)  ||
		// check if ball falls in upper right hole
		(Rect().Width()-TABLE_BORDER) - iBallLoc.iX <= (6+BALL_DIAMETER) && (Rect().Height()-TABLE_BORDER) - iBallLoc.iY <= (6+BALL_DIAMETER) )		
		{
		iMove->StopMoveBall();
		// When the ball falls in the hole do not draw it
		iDrawBall = EFalse;	
		return ETrue;
		}
	return EFalse;
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::WallsDetection()
// Called by application to detect if the ball hits a wall
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::WallsDetection()
	{
	// Check if the ball will hit the right table border
	if(iBallLoc.iX+iMoveX >= (Rect().Width()-(TABLE_BORDER+BALL_DIAMETER-STEP)) )
		{
		// Change the direction of the movement to move to the left
		iMoveX = -STEP;	
		// If vibration is "on" in the device profile settings
		if(iVibra->VibraSettings()==CHWRMVibra::EVibraModeON)
			{			
			iVibra->StartVibraL(100, 20);
			}
		}
	// Check if the ball will hit the left table border
	else if(iBallLoc.iX-iMoveX <= TABLE_BORDER )
		{
		// Change the direction of the movement to move to the right
		iMoveX = STEP;
		if(iVibra->VibraSettings()==CHWRMVibra::EVibraModeON)
			{			
			iVibra->StartVibraL(100, 20);
			}
		}

	// Increment the horizontal stepping
	iBallLoc.iX += iMoveX;
	
	// Check if the ball will hit the lower table border
	if(iBallLoc.iY+iMoveY >= (Rect().Height()-(TABLE_BORDER+BALL_DIAMETER-STEP)) )
		{
		// Change the direction of the movement to move up
		iMoveY = -STEP;		
		if(iVibra->VibraSettings()==CHWRMVibra::EVibraModeON)
			{			
			iVibra->StartVibraL(100, 20);
			}
		}
	// Check if the ball will hit the upper table border
	else if(iBallLoc.iY-iMoveY <= TABLE_BORDER )
		{
		// Change the direction of the movement to move down
		iMoveY  = STEP;
		if(iVibra->VibraSettings()==CHWRMVibra::EVibraModeON)
			{			
			iVibra->StartVibraL(100, 20);
			}
		}

	// Increment the vertical stepping
	iBallLoc.iY += iMoveY;	
	
	// After ball location is updated check if the ball is to fall in a hole 
	if( HolesDetection() )
		{
		// If vibration is on in the profile settings
		if(iVibra->VibraSettings()==CHWRMVibra::EVibraModeON)
			{
			// Vibrate in negative direction	
			iVibra->StartVibraL(300, -100);
			// Update the screen now
			DrawNow();
			// First interval of half a second
			User::After(500000);		
			// Vibrate in positive direction	
			iVibra->StartVibraL(300, 100);
			// Second interval of another half second
			User::After(500000);		
			iVibra->StartVibraL(1000, -100);		
			}
		}
	}
	
// -----------------------------------------------------------------------------
// CVibraPoolAppView::UpdateScreen()
// This is the callback fundtion called from CMoveBall
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::UpdateScreen()
	{
	WallsDetection();
	DrawNow();
	}
		
// -----------------------------------------------------------------------------
// CVibraPoolAppView::ReStartGame()
// Clears the location of the ball and the timer, then relocates and restarts 
// the timer
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::ReStartGame()
	{
	// Redisplay the ball after it fell in the hole
	iDrawBall = ETrue;
	iMove->StopMoveBall();
	iBallLoc.iX = Math::Random()%(Rect().Width()-(TABLE_BORDER*2)-(BALL_DIAMETER)-(THRESHOLD*2))+(THRESHOLD+TABLE_BORDER);
    iBallLoc.iY = Math::Random()%(Rect().Height()-(TABLE_BORDER*2)-(BALL_DIAMETER)-(THRESHOLD*2))+(THRESHOLD+TABLE_BORDER);
    iMove->StartMovingBall();
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppView::StopGame()
// THe functions checks in its implementation if its object is already running
// before trying to stop it. This prevents the panic caused by trying to cancel
// an asynchronous call which is not outstanding on the schedular
// -----------------------------------------------------------------------------
//
void CVibraPoolAppView::StopGame()
	{
	iMove->StopMoveBall();
	}


// End of File
