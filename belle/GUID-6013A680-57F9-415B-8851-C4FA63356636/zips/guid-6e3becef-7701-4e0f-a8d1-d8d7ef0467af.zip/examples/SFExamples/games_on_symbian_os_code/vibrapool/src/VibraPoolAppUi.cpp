// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CVibraPoolAppUi implementation
// 
// 


// INCLUDE FILES
#include <avkon.hrh>
#include <aknmessagequerydialog.h>
#include <VibraPool_0xE460ABF6.rsg>

#include "VibraPool.hrh"
#include "VibraPool.pan"
#include "VibraPoolApplication.h"
#include "VibraPoolAppUi.h"
#include "VibraPoolAppView.h"


// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// CVibraPoolAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CVibraPoolAppUi::ConstructL()
	{
	// Initialise app UI with standard value.
	BaseConstructL(CAknAppUi::EAknEnableSkin);

	// Create view object
	iAppView = CVibraPoolAppView::NewL( ClientRect() );
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppUi::CVibraPoolAppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CVibraPoolAppUi::CVibraPoolAppUi()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppUi::~CVibraPoolAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CVibraPoolAppUi::~CVibraPoolAppUi()
	{
	if ( iAppView )
		{
		delete iAppView;
		iAppView = NULL;
		}
	}

// -----------------------------------------------------------------------------
// CVibraPoolAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CVibraPoolAppUi::HandleCommandL( TInt aCommand )
	{
	switch( aCommand )
		{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;
		case ERestart:
			{
			iAppView->ReStartGame();
			}
			break;
		case EStop:
			{
			iAppView->StopGame();
			}
			break;
		default:
			Panic( EVibraPoolUi );
			break;
		}
	}

// -----------------------------------------------------------------------------
//  Called by the framework when the application status pane
//  size is changed.  Passes the new client rectangle to the
//  AppView
// -----------------------------------------------------------------------------
//
void CVibraPoolAppUi::HandleStatusPaneSizeChange()
	{
	iAppView->SetRect( ClientRect() );
	} 

// End of File
