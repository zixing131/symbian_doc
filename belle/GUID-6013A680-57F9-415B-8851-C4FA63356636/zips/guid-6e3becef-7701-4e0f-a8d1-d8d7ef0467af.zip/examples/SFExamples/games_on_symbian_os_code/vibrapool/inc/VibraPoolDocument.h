// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declares document class for application.
// 
// 


#ifndef __VIBRAPOOLDOCUMENT_h__
#define __VIBRAPOOLDOCUMENT_h__

// INCLUDES
#include <akndoc.h>

// FORWARD DECLARATIONS
class CVibraPoolAppUi;
class CEikApplication;


// CLASS DECLARATION

/**
* CVibraPoolDocument application class.
* An instance of class CVibraPoolDocument is the Document part of the
* AVKON application framework for the VibraPool example application.
*/
class CVibraPoolDocument : public CAknDocument
	{
	public: // Constructors and destructor

		/**
		* NewL.
		* Two-phased constructor.
		* Construct a CVibraPoolDocument for the AVKON application aApp
		* using two phase construction, and return a pointer
		* to the created object.
		* @param aApp Application creating this document.
		* @return A pointer to the created instance of CVibraPoolDocument.
		*/
		static CVibraPoolDocument* NewL( CEikApplication& aApp );

		/**
		* NewLC.
		* Two-phased constructor.
		* Construct a CVibraPoolDocument for the AVKON application aApp
		* using two phase construction, and return a pointer
		* to the created object.
		* @param aApp Application creating this document.
		* @return A pointer to the created instance of CVibraPoolDocument.
		*/
		static CVibraPoolDocument* NewLC( CEikApplication& aApp );

		/**
		* ~CVibraPoolDocument
		* Virtual Destructor.
		*/
		virtual ~CVibraPoolDocument();

	public: // Functions from base classes

		/**
		* CreateAppUiL
		* From CEikDocument, CreateAppUiL.
		* Create a CVibraPoolAppUi object and return a pointer to it.
		* The object returned is owned by the Uikon framework.
		* @return Pointer to created instance of AppUi.
		*/
		CEikAppUi* CreateAppUiL();

	private: // Constructors

		/**
		* ConstructL
		* 2nd phase constructor.
		*/
		void ConstructL();

		/**
		* CVibraPoolDocument.
		* C++ default constructor.
		* @param aApp Application creating this document.
		*/
		CVibraPoolDocument( CEikApplication& aApp );

	};

#endif // __VIBRAPOOLDOCUMENT_h__

// End of File
