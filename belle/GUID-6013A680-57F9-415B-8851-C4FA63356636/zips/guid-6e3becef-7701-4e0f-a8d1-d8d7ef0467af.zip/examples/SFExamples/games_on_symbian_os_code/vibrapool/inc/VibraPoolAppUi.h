// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declares UI class for application.
// 
// 


#ifndef __VIBRAPOOLAPPUI_h__
#define __VIBRAPOOLAPPUI_h__

// INCLUDES
#include <aknappui.h>


// FORWARD DECLARATIONS
class CVibraPoolAppView;


// CLASS DECLARATION
/**
* CVibraPoolAppUi application UI class.
* Interacts with the user through the UI and request message processing
* from the handler class
*/
class CVibraPoolAppUi : public CAknAppUi
	{
	public: // Constructors and destructor

		/**
		* ConstructL.
		* 2nd phase constructor.
		*/
		void ConstructL();

		/**
		* CVibraPoolAppUi.
		* C++ default constructor. This needs to be public due to
		* the way the framework constructs the AppUi
		*/
		CVibraPoolAppUi();

		/**
		* ~CVibraPoolAppUi.
		* Virtual Destructor.
		*/
		virtual ~CVibraPoolAppUi();

	private:  // Functions from base classes

		/**
		* From CEikAppUi, HandleCommandL.
		* Takes care of command handling.
		* @param aCommand Command to be handled.
		*/
		void HandleCommandL( TInt aCommand );

		/**
		*  HandleStatusPaneSizeChange.
		*  Called by the framework when the application status pane
 		*  size is changed.
		*/
		void HandleStatusPaneSizeChange();

	private: // Data

		/**
		* The application view
		* Owned by CVibraPoolAppUi
		*/
		CVibraPoolAppView* iAppView;
		
		
	};

#endif // __VIBRAPOOLAPPUI_h__

// End of File
