// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SEARCH_CONTAINER_H__
#define __SEARCH_CONTAINER_H__



// INCLUDES
#include <aknview.h>
#include <akndef.h>
#include "WikiDb.h"

// FORWARD DECLARATION
class CAknSingleStyleListBox;
class CAknSearchField;
class CAknNavigationDecorator;
class CAknNavigationControlContainer;
class CSearchView;
class CRecCountContainer;
class CWikiDb;

// CLASS DECLARATION

/**
*  CSearchContainer container control class.
*  An instance of CSearchContainer contains the view drawn to the screen
*  for CSearchView
*/
class CSearchContainer : public CCoeControl, public MCoeControlObserver, public MWikiCountObserver
    {
    public: // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Create a CSearchContainer object, which will draw itself to aRect
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CSearchContainer.
        */
        static CSearchContainer* NewL( const TRect& aRect, CSearchView& aView, CRecCountContainer& aRecContainer );

        /**
        * NewLC.
        * Two-phased constructor.
        * Create a CSearchContainer object, which will draw itself to aRect
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CSearchContainer.
        */
        static CSearchContainer* NewLC( const TRect& aRect, CSearchView& aView, CRecCountContainer& aRecContainer );

        /**
        * ConstructL
        * 2nd phase constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL( const TRect& aRect );
                
        /**
        * ~CSearchContainer
        * Destructor.
        */        
        ~CSearchContainer();

    private: // Constructor
    
	    /**
	    * CSearchContainer
	    * Constructor.
	    */     
    	CSearchContainer( CSearchView& aView, CRecCountContainer& aRecContainer );    
    	
    public: // from CoeControl

        /**
        * CountComponentControls
        * @return number of controls inside this container.
        */
        TInt CountComponentControls() const;

        /**
        * ComponentControl
        * @param Index number of the control.
        * @return Pointer of controls inside this container.
        */
        CCoeControl* ComponentControl( TInt aIndex ) const;
        
        /**
        * Called by framework when the view size is changed.
        */
        void SizeChanged();
         
        /**
        * Reacts to screen size change
        */
        void HandleResourceChange( TInt aType );        

        /**
        * OfferKeyEventL handles key events.
        *
        * @param aKeyEvent the key event
        * @param aType the type of key event
        * @return EKeyWasConsumed if keyevent was handled, EKeyWasNotConsumed 
        * otherwise 
        */
        TKeyResponse OfferKeyEventL( const TKeyEvent& aKeyEvent, 
             TEventCode aType );
        
    public: // From MCoeControlObserver

	    /**
	    * HandleControlEventL handles an event from an observed control.
	    *
	    * @param aControl the control that reported the event
	    * @param aEventType contains info about the event
	    */
	    void HandleControlEventL( CCoeControl* aControl, TCoeEvent aEventType );
    	
    public: // from MWikiCountObserver

		void CountUpdatedL( TInt aError );	    
	    
    public: // New functions
    
		void RefreshL( TBool aResetNaviPane = EFalse );

		TBool ZeroItemsInList() { return iItemArray->MdcaCount() == 0; };

    	void HandleSelectCommandL();
		
    private: // New functions
    
    	void CreateListBoxL();
    	void CreateFindBoxL();	

        /**
        * SetNaviPaneTextL.
        * Sets text to Navigation Pane
        */
        void SetNaviPaneTextL( const TDesC& aText, TBool aShowLeft, TBool aShowRight );
    	void UpdateListBoxL();
    	void PopulateItemArrayL();

    	TBool CanScrollPrev();
    	TBool CanScrollNext();    	
    	void GotoPrevPageL();
    	void GotoNextPageL();

    	HBufC* GetSearchTextLC();    	
    	void AppendItemToListL( CDesCArray& aList, const TDesC& aItem );
    	HBufC* FormatListItemLC( const TDesC& aItem );
    	TPtrC DeFormatListItem( const TDesC& aFormattedItem );
    	TBool IsSearchTextPresent() { return ( iSearchText->Length() > 0 ); } ;
    	void SetRecCountAndDrawL( const TInt aRecCount );  	
    	
    private: // Member data

	    /**
	    * iView
	    */
    	CSearchView& iView;
    	
	    /**
	    * iRecContainer
	    */    	
    	CRecCountContainer& iRecContainer;
    	
        /**
        * iWikiEngine
        */    	
    	CWikiDb& iWikiEngine;
    	
        /**
        * iListBox
        */    	
    	CAknSingleStyleListBox* iListBox;
    	
        /**
        * iFindBox
        */    	
    	CAknSearchField* iFindBox;

        /**
        * iNaviDecorator
        */
        CAknNavigationDecorator* iNaviDecorator;

        /**
        * iNaviPane
        */
        CAknNavigationControlContainer* iNaviPane;
    	
        /**
        * iItemArray
        */    	
        CDesCArray* iItemArray;    	
    	
        /**
        * iSearchText
        */        
    	HBufC* iSearchText;
    };

#endif // __SEARCH_CONTAINER_H__


// End of File