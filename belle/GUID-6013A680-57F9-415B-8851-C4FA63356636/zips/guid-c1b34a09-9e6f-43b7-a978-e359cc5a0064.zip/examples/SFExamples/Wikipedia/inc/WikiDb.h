// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


#ifndef __WIKI_DB_H__
#define __WIKI_DB_H__

#include <e32std.h>
#include <SqlDb.h>
#include <UTF.h>

const TInt KMaxCharByCharSqlQueryLen = 1024;
const TInt KMaxCharByCharQueryLen = 128;
const TInt KMaxArticleTextLen = 32768;
const TInt KItemsPerPage = 6;

#ifdef __WINS__
_LIT(KSqlDbName, "C:\\Wikipedia\\wikipedia.db");
#else
_LIT(KSqlDbName, "e:\\Wikipedia\\wikipedia.db");
#endif

_LIT8(KSqlDbConfig, "");
_LIT8(KWikiSqlStmtGetArticle, "select content, links from pages where title='%S'");
_LIT8(KWikiSqlStmtJustTitle, "select title from pages where title like '%S%%' order by title");
_LIT8(KWikiSqlStmtTitleOffset, "select title from pages where title like '%S%%' order by title limit -1 offset %D");

_LIT8(KCountAll, "select sum(count) from countHelper1");
_LIT8(KCountWith1Char, "select count from countHelper1 where prefix='%S'");
_LIT8(KCountWith2Chars, "select sum(count) from countHelper3 where prefix like '%S%%'");
_LIT8(KCountWith3Chars, "select count from countHelper3 where prefix='%S'");
_LIT8(KCountWith4Chars, "select sum(count) from countHelper5 where prefix like '%S%%'");
_LIT8(KCountWith5Chars, "select count from countHelper5 where prefix='%S'");
_LIT8(KCountWithManyChars, "select count(*) from pages where title like '%S%%'");

_LIT8(KTitleFormat, "<h2>%S</h2>");
_LIT8(KHtmlParagpraph, "<p>");
_LIT8(KLinkFormat, "<a href=\"http://en.wikipedia.org/wiki/%S#%S\">%S</a><br>");
_LIT8(KFullArticleLinkFormat, "<p><a href=\"http://en.wikipedia.org/wiki/%S\">Full article</a><p>");

enum TRequestCode 
	{
	ECancel,
	ERecordCount,
	ERecordCountNext
	};

enum TPageState
	{
	EInitialise,
	EPageUp,
	ENextItem
	};

class MWikiCountObserver
    {
    public:

		virtual void CountUpdatedL( TInt aError ) = 0;
	};

class CWikiDb : public CActive 
	{
    public: // Constructor and destructor

		/**
	    * NewL
	    * 1st phase Constructor
	    */	
		static CWikiDb* NewL();
	
		/**
	    * ~CWikiDb
	    * Destructor
	    */	
		~CWikiDb();	


	private: // Constructors

		/**
	    * CWikiDb
	    * C++ Constructor
	    */		
		CWikiDb();
	
		/**
        * ConstructL.
        * 2nd phase constructor.
        */		
		void ConstructL();
	
	public:
	
	// prepares the statements...
	void SearchL(const TDesC& aPrefix, MWikiCountObserver* aObserver);
	
	void PageUpL( const TDesC& aPrefix );
	
	/**
	 * Offers traversal of results specified by previous call to Search.
	 * @return ETrue if there are more elements to traverse
	 */
	TBool Next();
	
	/**
	 * Get the title of the article currently under cursor.
	 */
	const TInt GetTitle(TPtrC& aTitle);
	
	/**
	 * Get the content of the article currently under cursor.
	 */
	const TDesC8& GetArticleContentL();

	
	/**
	 * Get the article content by title.
	 */
	const TDesC8& GetArticleContentL(const TDesC& aTitle);

	/**
	 * Get the article content by title.
	 */
	const TDesC8& GetArticleContentL(const TDesC8& aTitle);

	/**
	 * Set the current article content by title
	 */	
	void SetCurrentArticleL( const TDesC& aTitle );

	/**
	 * Get the current article content
	 */		
	const TDesC8& GetCurrentArticleContentL();
	
	TBool DoesNextItemExist();
	
	TInt CurrentPage() { return iCurPage; };
	TInt CurrentItem() { return iCurItem; };	
	TInt NumRecords() { return iNumRecords; };
	
	public: // from CActive
	void DoCancel();
	void RunL();
	
	private:
	void EnsureArticleFormattedL(const TDesC& aTitle);
	void EnsureArticleFormattedL(const TDesC8& aTitle);
	void ReplaceChar(const TDesC8& aSource, TDes8& aTarget, const TChar& aToReplace, const TChar& aReplacement);
	void RunQueryL();
	void RunRecCountQueryL();	
	void SetPageAndItemL( const TPageState aPageState );
	HBufC* EscapeL( const TDesC& aQuery) const;
	HBufC8* EscapeL( const TDesC8& aQuery) const;
	void StartRecordCountL();
	void TraverseRecCountL();

	protected:
	
	RSqlDatabase iDatabase;
	RSqlStatement iStatement;
	RSqlStatement iCountStatement;
	RBuf8 iQueryBuf;
	RBuf8 iCountBuf;
	RBuf8 iUtf8Chars;
	RBuf8 iArticleText;
	HBufC* iCurArticleTitle;
	MWikiCountObserver* iObserver;
	
	protected:
	TRequestCode 		iRequestCode;
	TRequestStatus* 	iRequestStatus;
	RBuf8 				iRequestTitle;
	TPtrC8* 			iRequestBuffer;
	
	TInt				iCurItem;
	TInt				iCurPage;
	TBool				iAtNextItem;
	TInt				iNumRecords;
	};
	
#endif //__WIKI_DB_H__
