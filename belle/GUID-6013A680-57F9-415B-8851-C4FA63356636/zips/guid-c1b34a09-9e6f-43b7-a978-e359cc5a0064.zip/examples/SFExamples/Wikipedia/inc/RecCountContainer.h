// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __RECCOUNT_CONTAINER_H__
#define __RECCOUNT_CONTAINER_H__



// INCLUDES
#include <aknview.h>
#include <akndef.h>
#include "WikiDb.h"

// FORWARD DECLARATION
class CSearchView;
class CWikiDb;
class CAknsBasicBackgroundControlContext;

// CLASS DECLARATION

/**
*  CRecCountContainer container control class.
*  An instance of CRecCountContainer contains the view drawn to the screen
*  for CSearchView
*/
class CRecCountContainer : public CCoeControl
    {
    public: // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Create a CRecCountContainer object, which will draw itself to aRect
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CRecCountContainer.
        */
        static CRecCountContainer* NewL( const TRect& aRect, CSearchView& aView );

        /**
        * NewLC.
        * Two-phased constructor.
        * Create a CRecCountContainer object, which will draw itself to aRect
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CRecCountContainer.
        */
        static CRecCountContainer* NewLC( const TRect& aRect, CSearchView& aView );

        /**
        * ConstructL
        * 2nd phase constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL( const TRect& aRect );
                
        /**
        * ~CRecCountContainer
        * Destructor.
        */        
        ~CRecCountContainer();

    private: // Constructor
    
	    /**
	    * CRecCountContainer
	    * Constructor.
	    */     
    	CRecCountContainer( CSearchView& aView );    
    	
    public: // from CoeControl

	    /**
	    * Draw
	    * Draws the control to the screen
	    */     
    	void Draw( const TRect& aRect ) const;    
    
        /**
        * CountComponentControls
        * @return number of controls inside this container.
        */
        TInt CountComponentControls() const;

        /**
        * ComponentControl
        * @param Index number of the control.
        * @return Pointer of controls inside this container.
        */
        CCoeControl* ComponentControl( TInt aIndex ) const;
        
        /**
        * Called by framework when the view size is changed.
        */
        void SizeChanged();
         
        /**
        * Reacts to screen size change
        */
        void HandleResourceChange( TInt aType );    
        
        /**
        * Pass skin information if needed.
        */
        TTypeUid::Ptr MopSupplyObject( TTypeUid aId );        
    	
    public: // New functions

		void SetTextL( TInt aNumRecords );
    	
    private: // New functions

    	HBufC* FormatStringL( const TDesC& aString, const TInt aNumRecords );
    
    public: // Member data
    
    	CAknsBasicBackgroundControlContext* iBackground;
    	
    private: // Member data

	    /**
	    * iView
	    */
    	CSearchView& iView;
    	
        /**
        * iWikiEngine
        */    	
    	CWikiDb& iWikiEngine;
    	
        /**
        * iText
        */
        HBufC* iText;
    };

#endif // __RECCOUNT_CONTAINER_H__


// End of File