// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __DETAIL_VIEW_H__
#define __DETAIL_VIEW_H__


// INCLUDES
#include "BrowserView.h"

// CLASS DECLARATION

/**
* CDetailView view class.
* An instance of the Application View object for the SqlSrvDemo
* example application
*/
class CDetailView: public CBrowserView
    {
    public:    // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Construct a CDetailView for the AVKON application aApp.
        * Using two phase construction,and return a pointer to the created object.
        * @return a pointer to the created instance of CDetailView
        */
        static CDetailView* NewL();

        /**
        * NewLC.
        * Two-phased constructor.
        * Construct a CDetailView for the AVKON application aApp.
        * Using two phase construction,and return a pointer to the created object.
        * @return a pointer to the created instance of CDetailView
        */
        static CDetailView* NewLC();

        /**
        * ~CDetailView.
        * Virtual Destructor.
        */
        virtual ~CDetailView();
      
    private:    // Constructors and destructor

        /**
        * CDetailView.
        * C++ default constructor.
        */
        CDetailView();

        /**
        * ConstructL.
        * 2nd phase constructor.
        */
        void ConstructL();

        /**
        * ConstructContainerL
        * Construct a CAboutContainer for this view
        */ 
        void ConstructContainerL();
       };


#endif // __DETAIL_VIEW_H__


// End of File