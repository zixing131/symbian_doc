// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __BROWSER_CONTAINER_H__
#define __BROWSER_CONTAINER_H__

// INCLUDES
#include <aknview.h>
#include <BrCtlInterface.h>

// FORWARD DECLARATION
class CBrowserView;

// CLASS DECLARATION

/**
* CBrowserContainer container control class.
* An instance of CBrowserContainer contains the view drawn to the screen
* for BrowserView
*/
class CBrowserContainer : public CCoeControl 
   {	
	public:
	    /**
	    * Reacts to screen size change
	    */
		void HandleResourceChange( TInt aType );
	    
		/**
	    * CountComponentControls
	    * @return number of controls inside this container.
	    */
	    TInt CountComponentControls() const;
				
		/**
		 * Called by framework when the view size is changed.
		 */
	    void SizeChanged();
    	
        /**
        * ComponentControl
        * @param Index number of the control.
        * @return Pointer of controls inside this container.
        */
        CCoeControl* ComponentControl( TInt aIndex ) const;
             
	    /**
		* CBrowserContainer
		* Destructor.
		*/     
	    ~CBrowserContainer();
	    
    protected: // Constructors
	    /**
	    * CBrowserContainer
	    * Constructor.
	    * @param Reference to CBrowserView
	    */        
    	CBrowserContainer (CBrowserView& aView);
	
	    /**
	    * ConstructL
	    * 2nd phase constructor.
	    * @param aRect Frame rectangle for container.
	    */
	    void ConstructL(const TRect& aRect);
    
	protected: // New function
	
		void ScrollBrowserToTopL();
		
    protected:
    
		CBrowserView& iView;
	
		CBrCtlInterface* iBrowser;
   };

#endif /*__BROWSER_CONTAINER_H__*/

// End of File