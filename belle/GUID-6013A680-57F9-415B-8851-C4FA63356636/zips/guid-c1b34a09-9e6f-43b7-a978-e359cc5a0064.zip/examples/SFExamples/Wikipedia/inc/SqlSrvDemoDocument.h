// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SQLSRVDEMO_DOCUMENT_H__
#define __SQLSRVDEMO_DOCUMENT_H__



// INCLUDES
#include <akndoc.h>


// FORWARD DECLARATIONS
class CSqlSrvDemoAppUi;
class CEikApplication;



// CLASS DECLARATION

/**
* CSqlSrvDemoDocument application class.
* An instance of class CSqlSrvDemoDocument is the Document part of the AVKON
* application framework for the CSqlSrvDemoApplication example application.
*/
class CSqlSrvDemoDocument : public CAknDocument
    {
    public:  // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Construct a CSqlSrvDemoDocument for the AVKON application aApp.
        * Using two phase construction, and return a pointer to the created object.
        * @param aApp Application creating this document.
        * @return A pointer to the created instance of CSqlSrvDemoDocument.
        */
        static CSqlSrvDemoDocument* NewL( CEikApplication& aApp );

        /**
        * NewLC.
        * Two-phased constructor.
        * Construct a CSqlSrvDemoDocument for the AVKON application aApp.
        * Using two phase construction, and return a pointer to the created object.
        * @param aApp Application creating this document.
        * @return A pointer to the created instance of CSqlSrvDemoDocument.
        */
        static CSqlSrvDemoDocument* NewLC( CEikApplication& aApp );

        /**
        * ~CSqlSrvDemoDocument
        * Virtual Destructor.
        */
        virtual ~CSqlSrvDemoDocument();

    public: // from CAknDocument

        /**
        * CreateAppUiL
        * From CEikDocument, CreateAppUiL.
        * Create a CSqlSrvDemoAppUi object and return a pointer to it.
        * The object returned is owned by the Uikon framework.
        * @return Pointer to created instance of AppUi.
        */
        CEikAppUi* CreateAppUiL();

    private:  // Constructors

        /**
        * ConstructL
        * 2nd phase constructor.
        */
        void ConstructL();

        /**
        * CSqlSrvDemoDocument.
        * C++ default constructor.
        * @param aApp Reference to Application class object
        */
        CSqlSrvDemoDocument( CEikApplication& aApp );

    };


#endif // __SQLSRVDEMO_DOCUMENT_H__


// End of File