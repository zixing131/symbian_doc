// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __BROWSER_VIEW_H__
#define __BROWSER_VIEW_H__

// INCLUDES
#include <aknview.h>

// FORWARD DECLARATION
class CBrowserContainer;

// CLASS DECLARATION

/**
* CBrowserView view class.
* An instance of the Application View object for the SqlSrvDemo
* example application
*/

class CBrowserView: public CAknView
    {
    public:
	    /**
	    * Id
	    * From CAknView, return Uid.
	    * @return Uid Uid value
	    */
	    TUid Id() const;
    
        /**
        * HandleCommandL
        * From CAknView, takes care of command handling.
        * @param aCommand Command to be handled
        */
        void HandleCommandL( TInt aCommand );
        
        /**
        * HandleSizeChange
        * Called by HandleResourceChangeL() from CSqlSrvDemoAppUi when layout 
        * is changed.
        * @param aType Type of resources that have changed
        */
        void HandleSizeChange( TInt aType );
        
        /**
        * DoActivateL
        * From CAknExView, activate an AknView.
        * @param aPrevViewId The id of the previous view
        * @param aCustomMessageId message identifier
        * @param aCustomMessage custom message provided when the view is changed
        */
        void DoActivateL( const TVwsViewId& aPrevViewId,
                          TUid aCustomMessageId,
                          const TDesC8& aCustomMessage );

        /**
        * DoDeactivate
        * From AknView, deactivate an AknView
        * Remove the container class instance from the App UI's stack and
        * deletes the instance
        */
        void DoDeactivate();
        
    protected:
    	
    	/**
    	* ConstructContainerL
    	* Function to be overridden by dervied class 
    	* to construct correct container for each derived view
    	*/
    	virtual void ConstructContainerL() = 0;
    
    private: // From MEikMenuObserver	
    	/**
    	 * DynInitMenuPaneL
    	 * Dynamically initialises a menu pane
    	 * @param aResourceId Resource to be handled.
    	 */    
		void DynInitMenuPaneL( TInt aResourceId, CEikMenuPane *aMenuPane );   
    
    protected:    // Data
	    /**
	    * iContainer,container for this view
	    * owned by CDetailView object.
	    */
	    CBrowserContainer* iContainer;
    
        /** View Identifier **/
        TUid       iIdentifier;
    };

#endif // __BROWSER_VIEW_H__

// End of File