// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __DETAIL_CONTAINER_H__
#define __DETAIL_CONTAINER_H__

// INCLUDES
#include "BrowserContainer.h"

// FORWARD DECLARATION
class CWikiDb;
class CDetailView;

// CLASS DECLARATION

/**
* CDetailContainer container control class.
* An instance of CDetailContainer contains the view drawn to the screen
* for DetailView
*/
class CDetailContainer : public CBrowserContainer, public MBrCtlLoadEventObserver
    {
    public:  // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Create a CDetailContainer object, which will draw itself to aRect.
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CDetailContainer.
        */
        static CDetailContainer* NewL( const TRect& aRect, CDetailView& aView );

        /**
        * NewLC.
        * Two-phased constructor.
        * Create a CDetailContainer object, which will draw itself to aRect.
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CDetailContainer.
        */
        static CDetailContainer* NewLC( const TRect& aRect, CDetailView& aView );

        /**
        * ConstructL
        * 2nd phase constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL( const TRect& aRect );
        
    private: // Constructor
    
	    /**
	    * CDetailContainer
	    * Constructor.
	    */     
    	CDetailContainer( CDetailView& aView );
    	
    public: // from CoeControl
        
    	/**
        * OfferKeyEventL handles key events.
        *
        * @param aKeyEvent the key event
        * @param aType the type of key event
        * @return EKeyWasConsumed if keyevent was handled, EKeyWasNotConsumed 
        * otherwise 
        */
        TKeyResponse OfferKeyEventL( const TKeyEvent& aKeyEvent, 
             TEventCode aType );

    public: // from MBrCtlLoadEventObserver
    
    	void HandleBrowserLoadEventL ( TBrCtlDefs::TBrCtlLoadEvent aLoadEvent,
    		TUint aSize, TUint16 aTransactionId ); 
    	
    private: // Member data
    	
    	CWikiDb& iWikiEngine;
        
        TBool iOnlineConfirmed;
    };

#endif // __DETAIL_CONTAINER_H__

// End of File