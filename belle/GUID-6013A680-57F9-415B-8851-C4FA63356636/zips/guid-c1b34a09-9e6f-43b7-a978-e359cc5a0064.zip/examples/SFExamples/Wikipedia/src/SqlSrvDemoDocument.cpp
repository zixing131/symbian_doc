// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include "SqlSrvDemoAppUi.h"
#include "SqlSrvDemoDocument.h"


// ========================= MEMBER FUNCTIONS ==================================


// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::CSqlSrvDemoDocument()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CSqlSrvDemoDocument::CSqlSrvDemoDocument( CEikApplication& aApp ) :
                                          CAknDocument( aApp )
    {
    // No implementation required
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSqlSrvDemoDocument* CSqlSrvDemoDocument::NewL( CEikApplication& aApp )
    {
    CSqlSrvDemoDocument* self = NewLC( aApp );
    CleanupStack::Pop( self );
    return self;
    }


// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSqlSrvDemoDocument* CSqlSrvDemoDocument::NewLC( CEikApplication& aApp )
    {
    CSqlSrvDemoDocument* self = new ( ELeave ) CSqlSrvDemoDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CSqlSrvDemoDocument::ConstructL()
    {
    // No implementation required
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::~CSqlSrvDemoDocument()
// Destructor.
// -----------------------------------------------------------------------------
//
CSqlSrvDemoDocument::~CSqlSrvDemoDocument()
    {
    // No implementation required
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoDocument::CreateAppUiL()
// Create the application user interface, and return a pointer to it
// -----------------------------------------------------------------------------
//
CEikAppUi* CSqlSrvDemoDocument::CreateAppUiL()
    {
    return( static_cast<CEikAppUi*>( new ( ELeave ) CSqlSrvDemoAppUi ) );
    }

// End of File
