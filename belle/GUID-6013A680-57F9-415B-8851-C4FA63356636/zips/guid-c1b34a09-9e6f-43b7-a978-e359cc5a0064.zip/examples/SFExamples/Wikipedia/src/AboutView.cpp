// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


// INCLUDE FILES
#include <aknviewappui.h>
#include <SqlSrvDemo.rsg>

#include "AboutView.h"
#include "AboutContainer.h"
#include "SqlSrvDemo.hrh"

// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CAboutView::CAboutView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CAboutView::CAboutView()
    {
    iIdentifier = TUid::Uid( EAboutViewId );
    }

// -----------------------------------------------------------------------------
// CAboutView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CAboutView* CAboutView::NewL()
    {
    CAboutView* self = CAboutView::NewLC();
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CAboutView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CAboutView* CAboutView::NewLC()
    {
    CAboutView* self = new ( ELeave ) CAboutView();
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

// -----------------------------------------------------------------------------
// CAboutView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CAboutView::ConstructL()
	{
    BaseConstructL( R_BROWSER_VIEW );
    }

// -----------------------------------------------------------------------------
// CAboutView::~CAboutView()
// Destructor.
// -----------------------------------------------------------------------------
//
CAboutView::~CAboutView()
    {
    // No implementation required
    }

void CAboutView::ConstructContainerL()
	{
	iContainer = CAboutContainer::NewL( ClientRect(), *this );
	}

// End of File
