// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include "SearchContainer.h"
#include "SearchView.h"
#include <aknlists.h>
#include <aknsfld.h>
#include <aknnavi.h>
#include <aknnavide.h>
#include <e32debug.h>
#include "SqlSrvDemoAppUi.h"
#include "WikiDb.h"
#include "RecCountContainer.h"

const TInt KMaxSearchLength = 255;
const TInt KArraySize = 4;
const TInt KFormatLen = 3;

_LIT( KSplashText, "Start typing to search 2.2m Wikipedia articles" );
_LIT( KZeroRecordsText, "" );
_LIT( KNaviTextNull, "" );
_LIT( KNaviTextMultiplePages, "Page %D ..." );
_LIT( KNaviTextLastOfMultiplePages, "Page %D" );
_LIT( KListItemFormat, "\t%S\t\t" );

// ========================= MEMBER FUNCTIONS ==================================


// -----------------------------------------------------------------------------
// CSearchContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSearchContainer* CSearchContainer::NewL( const TRect& aRect, CSearchView& aView, CRecCountContainer& aRecContainer )
    {
    CSearchContainer* self = CSearchContainer::NewLC( aRect, aView, aRecContainer );
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CSearchContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSearchContainer* CSearchContainer::NewLC( const TRect& aRect, CSearchView& aView, CRecCountContainer& aRecContainer )
    {
    CSearchContainer* self = new ( ELeave ) CSearchContainer( aView, aRecContainer );
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
    }

// -----------------------------------------------------------------------------
// CSearchContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CSearchContainer::ConstructL( const TRect& aRect )
    {
    iItemArray = new ( ELeave ) CDesCArrayFlat( KArraySize );  
    
    CreateWindowL();

    CreateListBoxL();
    CreateFindBoxL(); 
    RefreshL();
    
    SetRect( aRect );
    ActivateL();
    }

CSearchContainer::~CSearchContainer()
	{
	delete iListBox;
	delete iFindBox;
    delete iNaviDecorator;	
	delete iItemArray;
	delete iSearchText;
	}

CSearchContainer::CSearchContainer( CSearchView& aView, CRecCountContainer& aRecContainer ) :
	iView( aView ), iRecContainer( aRecContainer ), iWikiEngine( CSqlSrvDemoAppUi::WikiEngine() )
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CSearchContainer::CountComponentControls() const
// returns number of controls inside this container.
// -----------------------------------------------------------------------------
//
TInt CSearchContainer::CountComponentControls() const
    {
    TInt count = 0;
    if ( iListBox )
        {
        count++;
        }
    if ( iFindBox )
        {
        count++;
        }
    return count;
    }


// -----------------------------------------------------------------------------
// CSearchContainer::ComponentControl() const
// returns pointer of controls inside this container
// -----------------------------------------------------------------------------
//
CCoeControl* CSearchContainer::ComponentControl( TInt aIndex ) const
    {
    switch ( aIndex )
	    {
	    case 0:
	        return iListBox;
	    case 1:
	        return iFindBox;
	    default:
	        return NULL;
	    }
    }

// -----------------------------------------------------------------------------
// CSearchContainer::SizeChanged
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CSearchContainer::SizeChanged()
    {
	// Set list box size.
	iListBox->SizeChanged();

    // Set find box size.
    AknFind::HandleFixedFindSizeChanged( this, iListBox, iFindBox );
    }

// -----------------------------------------------------------------------------
// CSearchContainer::HandleResourceChange
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CSearchContainer::HandleResourceChange(TInt aType)
    {
    CCoeControl::HandleResourceChange( aType );
    if ( aType == KEikDynamicLayoutVariantSwitch )
        {
        SetRect( iView.SearchRect() );
        }
    }  

// -----------------------------------------------------------------------------
// CSearchContainer::OfferKeyEventL
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
TKeyResponse CSearchContainer::OfferKeyEventL(
    const TKeyEvent& aKeyEvent, TEventCode aType )
    {
	TKeyResponse response = EKeyWasNotConsumed;

    switch  (aKeyEvent.iCode )
        {
        case EKeyUpArrow:
        case EKeyDownArrow:
            // Scrolling the list box. Forward to iListBox.
            response = iListBox->OfferKeyEventL( aKeyEvent, aType );
            break;

        case EKeyLeftArrow:
        	GotoPrevPageL();
            response = EKeyWasConsumed;        	
        	break;
        	
        case EKeyRightArrow:
        	GotoNextPageL();
            response = EKeyWasConsumed;        	
        	break;
        	
        case EKeyDevice3:
        	// Select key - handle it
        	HandleSelectCommandL();
            response = EKeyWasConsumed;
            break;

        default:
            // Forward key events to find box.
            response = iFindBox->OfferKeyEventL( aKeyEvent, aType );
            break;
        }

    return response;
    }

// -----------------------------------------------------------------------------
// CSearchContainer::HandleControlEventL
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CSearchContainer::HandleControlEventL( CCoeControl* aControl, TCoeEvent aEventType )
    {
	if ( aEventType == EEventStateChanged && aControl == iFindBox )
		{
	    HBufC* searchBuf = GetSearchTextLC();
        if ( *searchBuf != *iSearchText )
            {
            delete iSearchText;
            iSearchText = NULL;
            iSearchText = searchBuf->Des().AllocL();            
            UpdateListBoxL();
            }
        CleanupStack::PopAndDestroy( searchBuf );
		}
    }

void CSearchContainer::CountUpdatedL( TInt aError )
	{
	User::LeaveIfError( aError );
	SetRecCountAndDrawL( iWikiEngine.NumRecords() );
	}

void CSearchContainer::RefreshL( TBool aResetNaviPane /* = EFalse */ )
	{
	if ( aResetNaviPane )
		{
    	SetNaviPaneTextL( KNaviTextNull, EFalse, EFalse );		
		}
	else
		{
	    if ( !IsSearchTextPresent() )
	    	{
	        iListBox->View()->SetListEmptyTextL( KSplashText );
	    	SetNaviPaneTextL( KNaviTextNull, EFalse, EFalse );
	    	SetRecCountAndDrawL( -1 );
	    	}
	    else
	    	{
	    	if ( iItemArray->MdcaCount() == 0 )
	    		{
	            iListBox->View()->SetListEmptyTextL( KZeroRecordsText );
	        	SetNaviPaneTextL( KNaviTextNull, EFalse, EFalse );      
	    		}
	    	else
	    		{
	    		HBufC* naviText = NULL;
	    		TInt realCurPage = iWikiEngine.CurrentPage() + 1;
	    		TInt realCurItem = iWikiEngine.CurrentItem() + 1;
	    		TBool nextItemExists = iWikiEngine.DoesNextItemExist();
	    		
	    		if ( nextItemExists )
	    			{
	    			// This is one of multiple pages
	    			naviText = HBufC::NewLC( KNaviTextMultiplePages().Length() + KFormatLen );
	    			naviText->Des().Format( KNaviTextMultiplePages, realCurPage );
	    			}
	    		else if ( realCurPage != 1 )
	    			{
	    			// This is the last of multiple pages
	    			naviText = HBufC::NewLC( KNaviTextLastOfMultiplePages().Length() + KFormatLen );
	    			naviText->Des().Format( KNaviTextLastOfMultiplePages, realCurPage );	    			
	    			}
	    		else
	    			{
	    			naviText = KNaviTextNull().AllocLC();	
	    			}
	    		
	    		SetNaviPaneTextL( *naviText, CanScrollPrev(), CanScrollNext() );
	    		CleanupStack::PopAndDestroy( naviText );
	    		}
	    	}	
		}
	}

void CSearchContainer::CreateListBoxL()
	{	
    iListBox = new ( ELeave ) CAknSingleStyleListBox();
    iListBox->SetContainerWindowL( *this );
    iListBox->ConstructL( this );    
    iListBox->SetObserver( this );
    iListBox->Model()->SetItemTextArray( iItemArray );
    iListBox->Model()->SetOwnershipType( ELbmDoesNotOwnItemArray );
	}

void CSearchContainer::CreateFindBoxL()
	{
    CAknSearchField::TSearchFieldStyle style( CAknSearchField::ESearch );
    CGulIcon* defaultIcon = NULL;
    iFindBox = CAknSearchField::NewL(
        *this, style, defaultIcon, KMaxSearchLength );

    iSearchText = HBufC::NewL( 0 );
    
    iFindBox->SetObserver( this );
	}

// -----------------------------------------------------------------------------
// CSearchContainer::SetNaviPaneTextL()
// Changes text to navi pane
// -----------------------------------------------------------------------------    
void CSearchContainer::SetNaviPaneTextL( const TDesC& aText, TBool aShowLeft, TBool aShowRight )
    {
	// Create navipane pointer
	if ( !iNaviPane )
		{
		CEikStatusPane *sp = ( ( CAknAppUi* )iEikonEnv->EikAppUi() )->StatusPane();
		
		// Fetch pointer to the default navi pane control
		iNaviPane = ( CAknNavigationControlContainer * )sp->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
		}
    
    if ( iNaviDecorator )
        {
        delete iNaviDecorator;
        iNaviDecorator = NULL;        
        }
        
    iNaviDecorator = iNaviPane->CreateNavigationLabelL( aText );
    iNaviDecorator->MakeScrollButtonVisible( ETrue );
    iNaviDecorator->SetScrollButtonDimmed( CAknNavigationDecorator::ELeftButton, !aShowLeft );
    iNaviDecorator->SetScrollButtonDimmed( CAknNavigationDecorator::ERightButton, !aShowRight );

    iNaviPane->PushL( *iNaviDecorator );
    }

// -----------------------------------------------------------------------------
// CSearchContainer::UpdateListBoxL
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CSearchContainer::UpdateListBoxL()
    {
	SetRecCountAndDrawL( -1 );
	iWikiEngine.SearchL( *iSearchText, this );
    PopulateItemArrayL();
    }

void CSearchContainer::PopulateItemArrayL()
	{
	CDesCArray* items = new ( ELeave ) CDesCArrayFlat( KArraySize );
	TInt count = 0;
	if ( IsSearchTextPresent() )
		{
		while ( count < KItemsPerPage && iWikiEngine.Next() )
			{	
			// Append the title of the next item
			TPtrC colText;
			User::LeaveIfError( iWikiEngine.GetTitle( colText ) );
			AppendItemToListL( *items, colText );
			
			// Increment counter
			count++;
			}
		}
	
	// Replace the item array
	delete iItemArray;
	iItemArray = items;	
	
    iListBox->Model()->SetItemTextArray( iItemArray );
    iListBox->Model()->SetOwnershipType( ELbmDoesNotOwnItemArray );
    iListBox->SetCurrentItemIndex( 0 );
    iListBox->HandleItemAdditionL();
    
    RefreshL();
	}

void CSearchContainer::HandleSelectCommandL()
	{
	// Get the index of the currently selected item
	TInt itemIndex = iListBox->CurrentItemIndex();
	
	if ( itemIndex != KErrNotFound ) // If there is no item selected then ignore
		{
		// Get the text of the current item
		TPtrC itemText = iItemArray->MdcaPoint( itemIndex );
		
		// De-format the list item text to get the title alone
		TPtrC itemTitle = DeFormatListItem( itemText );
		
		// Set the title of the current article
		iWikiEngine.SetCurrentArticleL( itemTitle );
		// Reset the navi pane
	    RefreshL( ETrue );
	    //  Activate the detail view
		iView.OpenDetailViewL();
		}
	}

TBool CSearchContainer::CanScrollPrev()
	{
	return iWikiEngine.CurrentPage() > 0;
	}

TBool CSearchContainer::CanScrollNext()
	{
	return ( IsSearchTextPresent() && iWikiEngine.DoesNextItemExist() );
	}

void CSearchContainer::GotoPrevPageL()
	{
	if ( CanScrollPrev() )
		{
		iWikiEngine.PageUpL( *iSearchText );
	    PopulateItemArrayL();
		}
	}

void CSearchContainer::GotoNextPageL()
	{
	if ( CanScrollNext() )
		{
	    PopulateItemArrayL();
		}
	}

HBufC* CSearchContainer::GetSearchTextLC()
	{
    TInt searchTextLength = iFindBox->TextLength();
    HBufC* searchBuf = HBufC::NewLC( searchTextLength );
    TPtr searchPtr = searchBuf->Des();
    iFindBox->GetSearchText( searchPtr );
    return searchBuf;
	}

void CSearchContainer::AppendItemToListL( CDesCArray& aList, const TDesC& aItem )
	{
	HBufC* itemText = FormatListItemLC( aItem );
	aList.AppendL( *itemText );
	CleanupStack::PopAndDestroy( itemText );	
	}

HBufC* CSearchContainer::FormatListItemLC( const TDesC& aItem )
	{
    HBufC* formattedItem = HBufC::NewLC( aItem.Length() + KFormatLen );
    formattedItem->Des().Format( KListItemFormat, &aItem );	
    return formattedItem;
	}

TPtrC CSearchContainer::DeFormatListItem( const TDesC& aFormattedItem )
	{
	TPtrC rightPortion = aFormattedItem.Right( aFormattedItem.Length() - 1 );
	return rightPortion.Left( rightPortion.Length() - 2 );	
	}

void CSearchContainer::SetRecCountAndDrawL( const TInt aRecCount )
	{
	iRecContainer.SetTextL( aRecCount );
	iRecContainer.DrawNow();
	}

// End of File
