// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


// INCLUDE FILES
#include "DetailContainer.h"
#include "DetailView.h"
#include "SqlSrvDemoAppUi.h"
#include "WikiDb.h"
#include <charconv.h>
#include <aknquerydialog.h>
#include <SqlSrvDemo.rsg>

_LIT(KConfirmText, "Leave database content to go to online Wikipedia page?");

// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CDetailContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CDetailContainer* CDetailContainer::NewL( const TRect& aRect, CDetailView& aView )
    {
    CDetailContainer* self = CDetailContainer::NewLC( aRect, aView );
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CDetailContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CDetailContainer* CDetailContainer::NewLC( const TRect& aRect, CDetailView& aView )
    {
    CDetailContainer* self = new ( ELeave ) CDetailContainer( aView );
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
    }

// -----------------------------------------------------------------------------
// CDetailContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CDetailContainer::ConstructL( const TRect& aRect )
    {
    CBrowserContainer::ConstructL(aRect);  
    iBrowser->AddLoadEventObserverL( this );
    
    _LIT( KUrl, "data:wikipedia" );
    _LIT8( KDataType, "text/html" );

    TDataType dataType( KDataType() );
    TUid uid;
    uid.iUid = KCharacterSetIdentifierIso88591;
    
	const TDesC8& articleText = iWikiEngine.GetCurrentArticleContentL();    	
	
	// This S60 code causes a memory leak
	iBrowser->LoadDataL( KUrl, articleText, dataType, uid );
	
	ScrollBrowserToTopL();
    }

CDetailContainer::CDetailContainer( CDetailView& aView ) :
	CBrowserContainer(aView),
	iWikiEngine( CSqlSrvDemoAppUi::WikiEngine() )
	{
	// No implementation
	}

//-----------------------------------------------------------------------------
// CDetailContainer::OfferKeyEventL
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
TKeyResponse CDetailContainer::OfferKeyEventL(
    const TKeyEvent& aKeyEvent, TEventCode aType )
    {
    TBool passToBrowser = ETrue;
    
    if (( aKeyEvent.iCode == EKeyDevice3 ) && ( !iOnlineConfirmed ) ) 
    	{
    	CAknQueryDialog* dialog = new ( ELeave ) CAknQueryDialog();
    	dialog->SetPromptL( KConfirmText );
    	passToBrowser = dialog->ExecuteLD( R_CONFIRM_QUERY );
    	iOnlineConfirmed = passToBrowser;
    	}

    if ( passToBrowser && iBrowser )
        {
        return iBrowser->OfferKeyEventL( aKeyEvent, aType );
        }
    return EKeyWasConsumed;
    }

void CDetailContainer::HandleBrowserLoadEventL( TBrCtlDefs::TBrCtlLoadEvent aLoadEvent,
		TUint /* aSize */, TUint16 /* aTransactionId */ )
	{
	if ( aLoadEvent == TBrCtlDefs::EEventNewContentDisplayed && iOnlineConfirmed )
		{
	    iBrowser->SetBrowserSettingL( TBrCtlDefs::ESettingsFontSize, TBrCtlDefs::EFontSizeLevelAllSmall );		
		}
	}

// End of File
