// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include "RecCountContainer.h"
#include "SearchView.h"
#include "SqlSrvDemoAppUi.h"
#include "WikiDb.h"
#include <aknutils.h>
#include <aknsutils.h> 
#include <aknsskininstance.h>
#include <aknsbasicbackgroundcontrolcontext.h>
#include <aknsdrawutils.h>

const TInt KFormatLen = 10;
const TInt KRecBaseFactor = 3;

_LIT( KNullString, "" );
_LIT( KMultipleRecords, "%D articles found" );
_LIT( KOneRecord, "%D article found" );

// ========================= MEMBER FUNCTIONS ==================================


// -----------------------------------------------------------------------------
// CRecCountContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CRecCountContainer* CRecCountContainer::NewL( const TRect& aRect, CSearchView& aView )
    {
    CRecCountContainer* self = CRecCountContainer::NewLC( aRect, aView );
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CRecCountContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CRecCountContainer* CRecCountContainer::NewLC( const TRect& aRect, CSearchView& aView )
    {
    CRecCountContainer* self = new ( ELeave ) CRecCountContainer( aView );
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
    }

// -----------------------------------------------------------------------------
// CRecCountContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CRecCountContainer::ConstructL( const TRect& aRect )
    {
    iText = KNullString().AllocL();
    iBackground = CAknsBasicBackgroundControlContext::NewL( KAknsIIDQsnBgAreaMain, Rect(), ETrue );    
    
    CreateWindowL();
    SetRect( aRect );
    ActivateL();
    DrawNow();
    }

CRecCountContainer::~CRecCountContainer()
	{
	delete iText;
	delete iBackground;
	}

CRecCountContainer::CRecCountContainer( CSearchView& aView ) :
	iView( aView ), iWikiEngine( CSqlSrvDemoAppUi::WikiEngine() )
	{
	// No implementation required
	}

void CRecCountContainer::Draw( const TRect& /* aRect */ ) const
	{
	CWindowGc& gc = SystemGc();	
    if ( iBackground )
        {
        MAknsSkinInstance* skin = AknsUtils::SkinInstance();      
        if ( !AknsDrawUtils::Background( skin, iBackground, gc, Rect() ) )
        	{
        	// No background drawn
        	}	
        }

    const CFont* font = AknLayoutUtils::FontFromId( EAknLogicalFontPrimaryFont );
    TRect textRect( Rect().iTl.iX, Rect().iBr.iY - KRecCountHeight, Rect().iBr.iX, ( Rect().iBr.iY ) );
    TInt textBaseline = KRecCountHeight - ( KRecCountHeight / KRecBaseFactor );
    gc.UseFont( font );
    gc.SetPenColor( KRgbWhite );
    gc.DrawText( *iText, textRect, textBaseline, CGraphicsContext::ECenter );
    gc.DiscardFont();
	}

// -----------------------------------------------------------------------------
// CRecCountContainer::CountComponentControls() const
// returns number of controls inside this container.
// -----------------------------------------------------------------------------
//
TInt CRecCountContainer::CountComponentControls() const
    {
    return 0;
    }


// -----------------------------------------------------------------------------
// CRecCountContainer::ComponentControl() const
// returns pointer of controls inside this container
// -----------------------------------------------------------------------------
//
CCoeControl* CRecCountContainer::ComponentControl( TInt aIndex ) const
    {
    switch ( aIndex )
	    {
	    default:
	        return NULL;
	    }
    }

// -----------------------------------------------------------------------------
// CRecCountContainer::SizeChanged
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CRecCountContainer::SizeChanged()
    {    
    if ( iBackground )
        {
        iBackground->SetRect( Rect() );
        }    
    }

// -----------------------------------------------------------------------------
// CRecCountContainer::HandleResourceChange
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
void CRecCountContainer::HandleResourceChange( TInt aType )
    {
//    // TODO - Handle new rect correctly
    CCoeControl::HandleResourceChange( aType );
    if ( aType == KEikDynamicLayoutVariantSwitch )
        {
        SetRect( iView.RecCountRect() );
        }
    }  

TTypeUid::Ptr CRecCountContainer::MopSupplyObject( TTypeUid aId )
    {
    if ( aId.iUid == MAknsControlContext::ETypeId && iBackground )
        {
        return MAknsControlContext::SupplyMopObject( aId, iBackground );
        }

    return CCoeControl::MopSupplyObject( aId );
    }

void CRecCountContainer::SetTextL( TInt aNumRecords )
	{
	delete iText;
	switch ( aNumRecords )
		{
		case -1:
	    	iText = KNullString().AllocL();
			break;
		
		case 1:
			iText = FormatStringL( KOneRecord, aNumRecords );			
			break;
			
		default:
			iText = FormatStringL( KMultipleRecords(), aNumRecords );			
			break;
		}
	}

HBufC* CRecCountContainer::FormatStringL( const TDesC& aString, const TInt aNumber )
	{
    HBufC* string = HBufC::NewL( aString.Length() + KFormatLen );
    string->Des().Format( aString, aNumber );	
    return string;
	}

// End of File
