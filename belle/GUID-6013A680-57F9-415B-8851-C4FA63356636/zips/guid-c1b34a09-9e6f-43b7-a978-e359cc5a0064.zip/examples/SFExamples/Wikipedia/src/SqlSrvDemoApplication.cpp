// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include "SqlSrvDemoDocument.h"
#include "SqlSrvDemoApplication.h"


// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CSqlSrvDemoApplication::CreateDocumentL()
// Create an SqlSrvDemo document, and return a pointer to it
// -----------------------------------------------------------------------------
//
CApaDocument* CSqlSrvDemoApplication::CreateDocumentL()
    {
    return( static_cast< CApaDocument* >( CSqlSrvDemoDocument::NewL( *this ) ) );
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoApplication::AppDllUid()
// Returns application UID
// -----------------------------------------------------------------------------
//
TUid CSqlSrvDemoApplication::AppDllUid() const
    {
    return KUidSqlSrvDemoApp;
    }

// End of File
