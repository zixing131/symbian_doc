// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


#include "WikiDb.h"

_LIT(KCopyleftNotice, "<hr><small>All text is available under the terms of the <a href=http://en.wikipedia.org/wiki/Wikipedia:Text_of_the_GNU_Free_Documentation_License>GNU Free Documentation License</a>.<br>(See <a href=http://en.wikipedia.org/wiki/Wikipedia:Copyrights>Copyrights</a> for details.)</small>");

CWikiDb::CWikiDb() : CActive( EPriorityIdle )
	{
	CActiveScheduler::Add( this );
	}

CWikiDb::~CWikiDb()
	{
	Cancel();
	iQueryBuf.Close();
	iCountBuf.Close();
	iUtf8Chars.Close();
	iArticleText.Close();
	iStatement.Close();
	iCountStatement.Close();
	iDatabase.Close();
	delete iCurArticleTitle;
	}

CWikiDb* CWikiDb::NewL()
	{
	CWikiDb* db = new (ELeave)CWikiDb();
	CleanupStack::PushL(db);
	db->ConstructL();
	CleanupStack::Pop(db);
	return db;
	}

void CWikiDb::ConstructL() 
	{
	User::LeaveIfError( iDatabase.Open( KSqlDbName ) );
	iQueryBuf.CreateL(KMaxCharByCharSqlQueryLen);
	iCountBuf.CreateL(KMaxCharByCharSqlQueryLen);
	iUtf8Chars.CreateL(KMaxCharByCharQueryLen);
	iArticleText.CreateL(KMaxArticleTextLen);
    iCurArticleTitle = HBufC::NewL( 0 );	
	}


// prepares the statements...
void CWikiDb::SearchL(const TDesC& aPrefix, MWikiCountObserver* aObserver)
	{
	iObserver = aObserver;
	SetPageAndItemL( EInitialise );
	HBufC* quoted = EscapeL(aPrefix);
	CleanupStack::PushL(quoted);
	User::LeaveIfError(CnvUtfConverter::ConvertFromUnicodeToUtf8(iUtf8Chars, *quoted));
	CleanupStack::PopAndDestroy(quoted);
	iQueryBuf.SetLength(0);
	iQueryBuf.Format(KWikiSqlStmtJustTitle, &iUtf8Chars);
	RunQueryL();
	StartRecordCountL();
	}

void CWikiDb::PageUpL( const TDesC& aPrefix )
	{
	TInt prevPage = iCurPage - 1;
	TInt offset = prevPage * KItemsPerPage;
	SetPageAndItemL( EPageUp );
	HBufC* quoted = EscapeL( aPrefix );
	CleanupStack::PushL( quoted );	
	User::LeaveIfError( CnvUtfConverter::ConvertFromUnicodeToUtf8( iUtf8Chars, *quoted ) );
	CleanupStack::PopAndDestroy( quoted );	
	iQueryBuf.SetLength(0);
	iQueryBuf.Format( KWikiSqlStmtTitleOffset, &iUtf8Chars, offset );
	RunQueryL();
	}

/**
 * Offers traversal of results specified by previous call to Search.
 * @return ETrue if there are more elements to traverse
 */
TBool CWikiDb::Next()
	{
	TBool found = ETrue;
	if ( iAtNextItem )
		{
		// We have previously called Next(), so we don't need to call it again
		iAtNextItem = EFalse;		
		}
	else
		{
		// Call Next() as normal
		TInt res = iStatement.Next();
		found = ( res == KSqlAtRow );
		}
	if ( found )
		{
		SetPageAndItemL( ENextItem );
		}
	return found;
	}


/**
 * Get the title of the article currently under cursor.
 */
const TInt CWikiDb::GetTitle(TPtrC& aTitle)
	{
	return iStatement.ColumnText(0, aTitle);
	}

/**
 * Get the content of the article currently under cursor.
 */
const TDesC8& CWikiDb::GetArticleContentL()
	{
	TPtrC ptr;
	GetTitle(ptr);
	EnsureArticleFormattedL(ptr);
	return iArticleText;
	}


/**
 * Get the article content by title.
 */
const TDesC8& CWikiDb::GetArticleContentL(const TDesC& aTitle)
	{
	EnsureArticleFormattedL(aTitle);
	return iArticleText;
	}

/**
 * Get the article content by title.
 */
const TDesC8& CWikiDb::GetArticleContentL(const TDesC8& aTitle)
	{
	EnsureArticleFormattedL(aTitle);
	return iArticleText;
	}


/**
 * Get the content and links from dbm, format into html and store into
 * iArticleText.
 */
void CWikiDb::EnsureArticleFormattedL(const TDesC& aTitle)
	{
	TBuf8<128> titleUtf8;
	User::LeaveIfError(CnvUtfConverter::ConvertFromUnicodeToUtf8(titleUtf8, aTitle));
	EnsureArticleFormattedL(titleUtf8);
	}

void CWikiDb::EnsureArticleFormattedL(const TDesC8& aTitleUtf8)
	{
	HBufC8* quoted = EscapeL(aTitleUtf8);
	CleanupStack::PushL(quoted);
	RSqlStatement stmt;
	CleanupClosePushL(stmt);
	TBuf8<256> getArticleQuery;
	getArticleQuery.Format(KWikiSqlStmtGetArticle, quoted);

	stmt.PrepareL(iDatabase, getArticleQuery);
	TInt res = stmt.Next();
	if ( res != KSqlAtRow ) 
		{
		User::Leave(KErrNotFound);
		}
	TPtrC8 content;
	TPtrC8 links;
	stmt.ColumnBinary(0, content);
	stmt.ColumnBinary(1, links);
	
	// format into html
	iArticleText.SetLength(0);
	_LIT(KHtmlEncodingMeta, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
	iArticleText.Append(KHtmlEncodingMeta);
	iArticleText.AppendFormat(KTitleFormat, &aTitleUtf8);
	iArticleText.Append(content);
	iArticleText.Append(KHtmlParagpraph);

	_LIT8(KChars, " _|");
	TBuf8<3> chars;
	chars.Copy(KChars); 
	
	TBuf8<256> articleNameWithUnderscores;
	ReplaceChar(aTitleUtf8, articleNameWithUnderscores, chars[0], chars[1]);

	// parse links field
	TInt linksLen = links.Length();
	TInt lastLinkEnd = 0;
	for ( TInt i = 0; i < linksLen; i++ ) {
		if ( links[i] == chars[2] )
			{
			// end of a link
			TPtrC8 link = links.Mid(lastLinkEnd, i - lastLinkEnd);
			lastLinkEnd = i+1;
			TBuf8<256> linkWithUnderscores;
			ReplaceChar(link, linkWithUnderscores, chars[0], chars[1]);
			// Append to the article
			iArticleText.AppendFormat(KLinkFormat, &articleNameWithUnderscores, &linkWithUnderscores, &link);
			}
	}

	iArticleText.AppendFormat(KFullArticleLinkFormat, &articleNameWithUnderscores);
	iArticleText.Append(KCopyleftNotice);
	// TODO append link to the full article
	CleanupStack::PopAndDestroy( &stmt );
	CleanupStack::PopAndDestroy(quoted);
	}

void CWikiDb::ReplaceChar(const TDesC8& aSource, TDes8& aTarget, const TChar& aToReplace, const TChar& aReplacement)
	{
	TInt len = aSource.Length();
	for ( TInt i = 0 ; i < len; i++ )
		{
		TChar ch = aSource[i];
		if ( ch == aToReplace ) 
			{
			aTarget.Append(aReplacement);
			}
		else 
			{
			aTarget.Append(ch);
			}
		}
	}

void CWikiDb::DoCancel()
	{
	iRequestCode = ECancel;
	}

void CWikiDb::RunL()
	{
	switch ( iRequestCode ) 
		{
		case ECancel:
			break;
			
		case ERecordCount:
			{
			RunRecCountQueryL();			
			TraverseRecCountL();
			}
			break;	
			
		case ERecordCountNext:
			{
			TInt found = iCountStatement.Next();
			if ( found == KSqlAtRow )
				{
				iNumRecords++;
				TraverseRecCountL();
				}
			else
				{
				iObserver->CountUpdatedL( iStatus.Int() );				
				}
			}
			break;
		}
	}

void CWikiDb::SetCurrentArticleL( const TDesC& aTitle )
	{
	delete iCurArticleTitle;
	iCurArticleTitle = aTitle.AllocL();
	}

const TDesC8& CWikiDb::GetCurrentArticleContentL()
	{
	return GetArticleContentL( *iCurArticleTitle );
	}

TBool CWikiDb::DoesNextItemExist()
	{
	if ( iAtNextItem )
		{
		return iAtNextItem;
		}
	TInt res = iStatement.Next();
	iAtNextItem = ( res == KSqlAtRow );
	return iAtNextItem;
	}

void CWikiDb::RunQueryL()
	{
	iStatement.Close();
	iStatement.PrepareL( iDatabase, iQueryBuf );
	}

void CWikiDb::RunRecCountQueryL()
	{
	iCountStatement.Close();
	iCountStatement.PrepareL( iDatabase, iCountBuf );
	}

void CWikiDb::SetPageAndItemL( const TPageState aPageState )
	{
	switch ( aPageState )
		{
		case EInitialise:
			{
			// Initialise the page and item at -1 values - which means
			// the cursor is currently not on a page or item
			iCurPage = -1;
			iCurItem = -1;
			iAtNextItem = EFalse;
			iNumRecords = 0;
			}
			break;
		
		case EPageUp:
			{
			// Get the number of the previous page
			TInt prevPage = iCurPage - 1;

			// Set the current item to be one before the first item in the previous page
			// The cursor will be placed at the first item in the previous page
			// when Next() is called
			iCurItem = ( prevPage * KItemsPerPage ) -1;

			// Set the current page to be one before the previous page
			// The page will be set when the cursor is placed at the first item
			// in the previous page (see above)
			iCurPage = prevPage - 1;
			iAtNextItem = EFalse;
			}
			break;
			
		case ENextItem:
			{
			// Set the cursor to the next item
			iCurItem++;
			
			// Increment the page count if we are on a new page
			if ( iCurItem % KItemsPerPage == 0 )
				{
				iCurPage++;
				}			
			}
			break;
			
		default:
			break;
		}
	}

const TUint16 KSingleQuote = 0x0027;
HBufC* CWikiDb::EscapeL( const TDesC& aQuery) const
	{
    TInt len = aQuery.Length();
    HBufC* buf = HBufC::NewLC( len * 2 + 4 );
    TPtr ptr = (buf->Des());
    for( TInt i=0;i<len;i++ )
        {
        if( aQuery[i] == KSingleQuote )
            {
            ptr.Append(aQuery[i]);
            ptr.Append(aQuery[i]);
            }
        else
            {
            ptr.Append(aQuery[ i ]);
            }
        }
    CleanupStack::Pop(buf);
    return buf;
	}

HBufC8* CWikiDb::EscapeL( const TDesC8& aQuery) const
	{
	TInt len = aQuery.Length();
	HBufC8* buf = HBufC8::NewLC( len * 2 + 4 );
	TPtr8 ptr = (buf->Des());
	for( TInt i=0;i<len;i++ )
	    {
	    if( aQuery[i] == KSingleQuote )
	        {
	        ptr.Append(aQuery[i]);
	        ptr.Append(aQuery[i]);
	        }
	    else
	        {
	        ptr.Append(aQuery[ i ]);
	        }
	    }
	CleanupStack::Pop(buf);
	return buf;
	}

void CWikiDb::StartRecordCountL()
	{
	if ( IsActive() )
		{
		Cancel();
		}
	
	TBool syncCount = ETrue;
	TSqlScalarFullSelectQuery fullSelectQuery(iDatabase);
	iCountBuf.Zero();
	switch (iUtf8Chars.Length())
		{
		case 0:
			{
			iCountBuf.Append(KCountAll);
			break;
			}
		case 1:
			{
			iCountBuf.AppendFormat(KCountWith1Char, &iUtf8Chars);
			break;
			}
		case 2:
			{
			iCountBuf.AppendFormat(KCountWith2Chars, &iUtf8Chars);
			break;
			}
		case 3:
			{
			iCountBuf.AppendFormat(KCountWith3Chars, &iUtf8Chars);
			break;
			}
		case 4:
			{
			iCountBuf.AppendFormat(KCountWith4Chars, &iUtf8Chars);
			break;
			}
		case 5:
			{
			iCountBuf.AppendFormat(KCountWith5Chars, &iUtf8Chars);
			break;
			}
		default:
			{
			iCountBuf.SetLength( 0 );
			iCountBuf.Copy( iQueryBuf );
			TRequestStatus* status = &iStatus;
			iStatus = KRequestPending;
			iRequestCode = ERecordCount;
			SetActive();
			User::RequestComplete( status, KErrNone );
			syncCount = EFalse;
			break;
			}
		}
	
	if ( syncCount )
		{
		TRAPD( err, iNumRecords = fullSelectQuery.SelectIntL( iCountBuf ) );
		switch ( err )
			{
			case KErrNotFound:
				iNumRecords = 0;
				break;
				
			case KErrNone:
				// Do nothing
				break;
				
			default:
				User::Leave( err );
				break;
			}
		iObserver->CountUpdatedL( KErrNone );
		}
	}

void CWikiDb::TraverseRecCountL()
	{
	if ( IsActive() )
		{
		Cancel();
		}	
	TRequestStatus* status = &iStatus;
	iStatus = KRequestPending;
	iRequestCode = ERecordCountNext;
	SetActive();
	User::RequestComplete( status, KErrNone );	
	}

// End of file
