// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <ContactAsynchSort.rsg>

#include "ContactAsynchSortMainView.h"

CContactAsynchSortMainView* CContactAsynchSortMainView::NewL(const TRect& aRect)
	{
	CContactAsynchSortMainView* self = CContactAsynchSortMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

CContactAsynchSortMainView* CContactAsynchSortMainView::NewLC(const TRect& aRect)
	{
	CContactAsynchSortMainView* self = new (ELeave) CContactAsynchSortMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

CContactAsynchSortMainView::~CContactAsynchSortMainView()
	{
	delete iEikEdwin;
	}
	
void CContactAsynchSortMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_CONTACTASYNCHSORT);	
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

void CContactAsynchSortMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawNow();
		}
	}

TInt CContactAsynchSortMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

CCoeControl* CContactAsynchSortMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return NULL;
	}

void CContactAsynchSortMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void CContactAsynchSortMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
