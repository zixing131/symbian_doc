// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactAsynchSort.rsg>

#include "ContactAsynchSortAppUi.h"
#include "ContactAsynchSortMainView.h"
#include "ContactRead.h"
#include "SortWrapper.h"
#include "ContactAsynchSort.hrh"

void CContactAsynchSortAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactAsynchSortMainView::NewL(ClientRect());

	iContactReader = CContactRead::NewL();
	iSortWrapper = new (ELeave) CSortWrapper(*iMainView, iContactReader->CntDatabase());
	}
	
CContactAsynchSortAppUi::~CContactAsynchSortAppUi()
    {
	delete iSortWrapper;
    delete iContactReader;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CContactAsynchSortAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactAsynchSort:
			{
			iSortWrapper->StartL(*iContactReader);
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactAsynchSortAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
