// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "SortWrapper.h"

CSortWrapper::CSortWrapper(CContactAsynchSortMainView& aView, CContactDatabase& aDb)
		: CActive(0), iView(aView), iDb(aDb)
	{
	CActiveScheduler::Add(this);
	}

void CSortWrapper::StartL(CContactRead& aReader)
	{
	iContactReader = &aReader;
	aReader.SortByNameL(iStatus);
	SetActive();
	}

void CSortWrapper::RunL()
	{
	// report result on the Label control
	if (KErrNone == iStatus.Int())
		{
		CContactIdArray* result = CContactIdArray::NewLC(iDb.SortedItemsL());
		TBuf<256> textBuf;
		_LIT(KPrefix, "success :");
		textBuf.Append(KPrefix());
		_LIT(KNoName, "NoName");
		// \PIM\PopulateContact should have created at least 3 cards
		// with both first names and last names.
		for (TInt ii = 0; ii < result->Count() && ii < 3; ++ii)
			{
			CDesCArray* last = iContactReader->ReadTextFieldL((*result)[ii], KUidContactFieldFamilyName);
			CleanupStack::PushL(last);
			CDesCArray* first = iContactReader->ReadTextFieldL((*result)[ii], KUidContactFieldGivenName);
			if (last->Count() > 0)
				textBuf.Append(last->MdcaPoint(0));
			else
				textBuf.Append(KNoName());
			if (first->Count() > 0)
				textBuf.Append(first->MdcaPoint(0));
			else
				textBuf.Append(KNoName());
			delete first;
			CleanupStack::PopAndDestroy(last);
			}
		CleanupStack::PopAndDestroy(result);
		iView.SetTextL(textBuf);
		}
	else
		{
		_LIT(KErrorMsg, "Symbian Error Code = %D");
		TBuf<32> errorBuf;
		errorBuf.Format(KErrorMsg(), iStatus.Int());
		iView.SetTextL(errorBuf);
		}
	}

TInt CSortWrapper::RunError(TInt aError)
	{
	_LIT(KErrorMsg2, "Symbian Error Code = %D");
	TBuf<32> errorBuf;
	errorBuf.Format(KErrorMsg2(), aError);
	TRAPD(error, iView.SetTextL(errorBuf));
	return error;
	}


void CSortWrapper::DoCancel()
	{
	iDb.CancelAsyncSort();
	}

