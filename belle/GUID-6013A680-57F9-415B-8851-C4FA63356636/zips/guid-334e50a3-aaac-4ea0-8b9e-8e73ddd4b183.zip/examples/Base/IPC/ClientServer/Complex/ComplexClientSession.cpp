/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Implementation of the RCountSession class� 
*/




#include "ComplexClientAndServer.h"
#include "ComplexClient.h"


// number of message slots.
const TUint kDefaultMessageSlots=4;

/**
Constructor
*/
RCountSession::RCountSession()
	{
	}


/**
Connects to the  server using 4 message slots.

In this example, the server is implemented as a separate thread.
The function starts that thread before attempting to create a session with the server.

The version information specifies the earliest version of the server that we can
talk to.
*/
TInt RCountSession::Connect()
	{
	TInt r=StartThread(iServerThread);
	if (r==KErrNone)
		r=CreateSession(KCountServerName,Version(),kDefaultMessageSlots);
	return(r); 
	}
	

/**
Returns the earliest version number of the server that we can talk to.
*/	
TVersion RCountSession::Version(void) const
	{
	return(TVersion(KCountServMajorVersionNumber,KCountServMinorVersionNumber,KCountServBuildVersionNumber));
	}


/**
A request to close the session.

It makes a call to the server, which deletes the object container and object index
for this session, before calling Close() on the base class.
*/
void RCountSession::Close()
	{
	SendReceive(ECountServCloseSession);
	RHandleBase::Close();
	iServerThread.Close();
	}


/**
A server request to get the number of subsessions
in this session.
*/
TInt RCountSession::ResourceCount()
	{
	TInt count=0;
	TPckgBuf<TInt> pckgcount;
	
	  // Note that TPckgBuf is of type TDes8
	TIpcArgs args(&pckgcount);
	SendReceive(ECountServResourceCount, args);
	
	  // Extract the value returned from the server. 
	count = pckgcount();
	return count;
	}



