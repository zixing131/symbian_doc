/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef AUDIOSTREAMVIEW_H
#define AUDIOSTREAMVIEW_H

// INCLUDES
#include <coecntrl.h>
#include "AudioStreamEngine.h"
#include <eikrted.h>

// FORWARD DECLARATIONS
class CAudioStreamEngine;

// CLASS DECLARATION

/**
*  CAudioStreamView  container control class.
*  
*/
class CAudioStreamView : public CCoeControl
{
public: 

/*!
 * NewL()
 * 
 * discussion Create new CAudioStreamView object, being able to draw 
 *    itself into aRect
 *
 * param aRect the rectangle this view will be drawn to
 * param aEngine the engine which core logic is used by this simple view
 * return a pointer to the created instance of CAudioStreamView
 */
    static CAudioStreamView* NewL(const TRect& aRect, 
        CAudioStreamEngine* aEngine);

/*!
 * NewLC()
 * 
 * discussion Create new CAudioStreamView object, being able to draw
 *    itself into aRect
 *
 * param aRect the rectangle this view will be drawn to
 * return a pointer to the created instance of CAudioStreamView 
 *    which has also been pushed to cleanup stack
 */
    static CAudioStreamView* NewLC(const TRect& aRect, 
        CAudioStreamEngine* aEngine);


/*!
 * ~CAudioStreamView()
 *
 * discussion Destroy the object and release all memory objects
 */
    ~CAudioStreamView();
        
public: // New functions

/*!
 * ShowMessageL()
 *
 * discussion Displays application messages for user
 *
 * param aMsg text to be displayed
 */
    void ShowMessageL(const TDesC& /* aMsg */);

public: // Functions from base classes

private: // Basic two-phase EPOC constructors

/*!
 * ConstructL()
 *
 * discussion Perform the second phase construction of a CAudioStreamView
 *    object
 *
 * param aRect Frame rectangle for container.
 */
    void ConstructL(const TRect& aRect, CAudioStreamEngine* aEngine);
 
/*!
 * CAudioStreamView()
 *
 * discussion Perform the first phase of two phase construction 
 */
    CAudioStreamView();

private: // Functions from base classes

   /**
    * From CoeControl,SizeChanged.
    */
    void SizeChanged();

   /**
    * From CoeControl,HandleResourceChange.
    */
    void HandleResourceChange(TInt aType);

   /**
    * From CoeControl,CountComponentControls.
    */
    TInt CountComponentControls() const;

   /**
    * From CCoeControl,ComponentControl.
    */
    CCoeControl* ComponentControl(TInt aIndex) const;

   /**
    * From CCoeControl,Draw.
    */
    void Draw(const TRect& aRect) const;
    
private: // New functions
    
        
private: // data members

    // Reference for engine object
    CAudioStreamEngine* iEngine;        

    // Displaying the application messages to user
    CEikRichTextEditor* iLogComponent;
    
};

#endif

// End of File


