/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

// INCLUDE FILES
#include <avkon.hrh>
#include <eikmenup.h>

#include "AudioStreamAppUi.h"
#include "AudioStreamView.h" 
#include <AudioStream.rsg>
#include "AudioStream.hrh"

#include "AudioStreamEngine.h"


// ----------------------------------------------------------------------------
// CAudioStreamAppUi::ConstructL()
//
// standard EPOC 2nd phase constructor
// ----------------------------------------------------------------------------
void CAudioStreamAppUi::ConstructL()
    {
    BaseConstructL(EAknEnableSkin);

    iEngine = CAudioStreamEngine::NewL( this ); 
    // pass the handle of CAudioStreamEngine to CAudioStreamView so the 
    // view can use the engine
    iView = CAudioStreamView::NewL(ClientRect(), iEngine);
    iView->SetMopParent( this );
    // add view to control stack
    AddToStackL( iView );   
    }

// ----------------------------------------------------------------------------
// CAudioStreamAppUi::~CAudioStreamAppUi()
//
// destructor
// ----------------------------------------------------------------------------
CAudioStreamAppUi::~CAudioStreamAppUi()
    {
    // remove view from control stack
    RemoveFromStack( iView );
    delete iView;
    
    delete iEngine;
    }

// ----------------------------------------------------------------------------
// CAudioStreamAppUi::DynInitMenuPaneL(TInt aResourceId,
//     CEikMenuPane* aMenuPane)
//
// this function is called by the EIKON framework just before it displays
// a menu pane. Its default implementation is empty, and by overriding it,
// the application can set the state of menu items dynamically according
// to the state of application data.
// ----------------------------------------------------------------------------
void CAudioStreamAppUi::DynInitMenuPaneL(
    TInt /*aResourceId*/, CEikMenuPane* /*aMenuPane*/)
    {
    }

// ----------------------------------------------------------------------------
// CAudioStreamAppUi::HandleKeyEventL(
//     const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
//
// takes care of key event handling
// ----------------------------------------------------------------------------
TKeyResponse CAudioStreamAppUi::HandleKeyEventL(
    const TKeyEvent& /*aKeyEvent*/,TEventCode /*aType*/)
    {
    return EKeyWasNotConsumed;
    }

// ----------------------------------------------------------------------------
// CAudioStreamAppUi::HandleCommandL(TInt aCommand)
//
// takes care of command handling
// ----------------------------------------------------------------------------
void CAudioStreamAppUi::HandleCommandL(TInt aCommand)
    {
    switch ( aCommand )
        {
        case EAknSoftkeyExit:
        case EEikCmdExit:
            {
            Exit();
            break;
            }
        case EAudioStreamCmdPlay:
            {
            iEngine->Play();
            break;
            }
        case EAudioStreamCmdRecord:
            {
            iEngine->Record();
            break;
            }
        case EAudioStreamCmdStop:
            {
            iEngine->Stop();
            break;
            }
        case EAudioStreamCmdLoad:
            {
            iEngine->LoadAudioFileL();
            break;
            }
        case EAudioStreamCmdSave:
            {
            iEngine->SaveAudioFileL();
            break;
            }
        case EAudioStreamCmdPcm:
            {
            iEngine->SetEncodingL(EFalse);
            break;
            }
        case EAudioStreamCmdAmr:
            {
            iEngine->SetEncodingL(ETrue);
            break;
            }
        default:
            break;      
        }
    }


// ----------------------------------------------------------------------------
// CAudioStreamView* CAudioStreamAppUi::GetView()
//
// returns a reference to application view
// ----------------------------------------------------------------------------
CAudioStreamView* CAudioStreamAppUi::GetView() const
    {
    return iView;
    }


// End of File  

