// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include "ContactRead.h"

CContactRead* CContactRead::NewL()
	{
	CContactRead* self = new (ELeave) CContactRead();
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

CContactRead::~CContactRead()
	{
	delete iMatch;
	delete iTextDef;
	delete iCntDb;
	}

CContactRead::CContactRead()
		: iCallback(&CContactRead:: ParseWord)
	{
	}

void CContactRead::ConstructL()
	{
	TRAPD(error, iCntDb = CContactDatabase::OpenL());
	if (KErrNotFound == error)
		{
		iCntDb = CContactDatabase::CreateL();
		}
	else
		{
		User::LeaveIfError(error);
		}
	iTextDef = CContactTextDef::NewL();
	iMatch = new (ELeave) CDesCArrayFlat(1);
	}

CContactDatabase& CContactRead::CntDatabase()
	{
	delete iMatch;
	delete iTextDef;
	return *iCntDb;
	}

CIdleFinder* CContactRead::FindWithCallbackL(TFieldType aField, const TDesC& aMatch, MIdleFindObserver* aObserver)
	{
	iTextDef->Reset();
	TContactTextDefItem field(aField);
	iTextDef->AppendL(field);
	iMatch->Reset();
	iMatch->AppendL(aMatch);
	return iCntDb->FindInTextDefAsyncL(*iMatch, iTextDef, aObserver, iCallback);
	}

TInt CContactRead::ParseWord(TAny* aParam)
	{
	SFindInTextDefWordParser* parserStruct = (SFindInTextDefWordParser*)aParam;
	TPtrC searchString(*(parserStruct->iSearchString));
	TInt index = KErrNotFound;
	TInt error = KErrNone;
	while(0 <= (index = searchString.Locate(' ')))
		{
		if (index > 0)
			{
			TRAP(error, parserStruct->iWordArray->AppendL(searchString.Left(index)));
			if (error != KErrNone)
				return error;
			if (searchString.Length() > index + 1)
				{
				searchString.Set(searchString.Mid(index  +1));
				}
			else
				{
				searchString.Set(KNullDesC());
				break;
				}
			}
		else
			{
			// remove first character as it is a space
			searchString.Set(searchString.Mid(1));
			}
		}
	if(searchString.Length() > 0) // the last word
		{
		TRAP(error, parserStruct->iWordArray->AppendL(searchString));
		if (error != KErrNone)
			return error;
		}
	return KErrNone;
	}

// End of File
