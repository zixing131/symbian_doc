// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactAsynchFind.rsg>

#include "ContactAsynchFindAppUi.h"
#include "ContactAsynchFindMainView.h"
#include "ContactRead.h"
#include "ContactAsynchFind.hrh"

void CContactAsynchFindAppUi::ConstructL()
	{

	BaseConstructL(EAknEnableSkin);
	iMainView = CContactAsynchFindMainView::NewL(ClientRect());


	iContactReader = CContactRead::NewL();
	}
	
CContactAsynchFindAppUi::~CContactAsynchFindAppUi()
    {
	delete iFindWrapper;
    delete iContactReader;
	delete iMainView;
    }

void CContactAsynchFindAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		case EContactAsynchFind:
			{
			// \PIM\PopulateContact should have created at a card with the
			// name set to "Partner"
			_LIT(KStringMatch, "Partner");
			TFieldType type = KUidContactFieldGivenName;
			iFindWrapper = iContactReader->FindWithCallbackL(type, KStringMatch, this);
			break;
			}
		default:
			break;
		}
	}


void CContactAsynchFindAppUi::IdleFindCallback()
	{
	if (iFindWrapper->IsComplete())
		{
		TInt error = iFindWrapper->Error();
		if (KErrNone ==  error)
			{
			CContactIdArray* result = iFindWrapper->TakeContactIds();
			TBuf<64> textBuf;
			_LIT(KPrefix, "success :");
			_LIT(KCardId, " %D");
			textBuf.Append(KPrefix());
			for (TInt ii = 0; ii < result->Count() && ii < 3; ++ii)
				{
				textBuf.AppendFormat(KCardId(), (*result)[ii]);
				}
			delete result;
			delete iFindWrapper;
			iFindWrapper = NULL; // prevents double deletion !!!!!!
			TRAP(error, iMainView->SetTextL(textBuf));
			}
		if (KErrNone !=  error)
			{
			_LIT(KErrorMsg, "Symbian Error Code = %D");
			TBuf<32> errorBuf;
			errorBuf.Format(KErrorMsg(), error);
			iMainView->SetTextL(errorBuf);
			}
		}
	// otherwise, keep going. maybe indicate progress on GUI.
	}


	

void CContactAsynchFindAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

	
// End of File
