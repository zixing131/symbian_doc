// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <ContactAsynchFind.rsg>

#include "ContactAsynchFindExternalInterface.h"
#include "ContactAsynchFindAppUi.h"
#include "ContactAsynchFindMainView.h"
#include "ContactAsynchFind.hrh"

// MEMBER FUNCTIONS

CContactAsynchFindMainView* CContactAsynchFindMainView::NewLC(CQikAppUi& aAppUi)
	{
	CContactAsynchFindMainView* self = new (ELeave) CContactAsynchFindMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CContactAsynchFindMainView::CContactAsynchFindMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

CContactAsynchFindMainView::~CContactAsynchFindMainView()
	{
	}

void CContactAsynchFindMainView::ConstructL()
	{
	BaseConstructL();
	SetExtentToWholeScreen();
	}
	
void CContactAsynchFindMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_CONTACTASYNCHFIND_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EContactAsynchFindLabelCtrl);
	}

TVwsViewId CContactAsynchFindMainView::ViewId()const
	{
	return TVwsViewId(KUidContactAsynchFindApp, KUidContactAsynchFindMainView);
	}

void CContactAsynchFindMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

void CContactAsynchFindMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

void CContactAsynchFindMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
