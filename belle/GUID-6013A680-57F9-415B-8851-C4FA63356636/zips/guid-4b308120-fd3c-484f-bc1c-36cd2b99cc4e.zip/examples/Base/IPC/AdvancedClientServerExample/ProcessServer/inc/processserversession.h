/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __PROCESSSERVERSESSION_H__
#define __PROCESSSERVERSESSION_H__

#include <e32base.h>
#include <e32std.h>
#include "processserver.h"


const TInt KMaxAsyncRequests = 4;
class CProcessServer;
/**
	Server-side client session class for process server
*/	
class CProcessServerSession : public CSession2
	{
public:
	static CProcessServerSession* NewL(CProcessServer& aServer);
	~CProcessServerSession();
	void CreateL();// Create a server-side client session
	void ServiceL(const RMessage2& aMessage);// Handles the client request
	
	
private:
	CProcessServerSession(CProcessServer& aServer);
	void ConstructL();
	
	// Active object class for asynchronous requests
	class CAsyncHandler : public CActive 
		{
	public:
		static CAsyncHandler* NewL(CProcessServer& aServer);
		~CAsyncHandler();
		
		 //Store async request in message array
		TInt ProcessRequest(const RMessage2& aMessage);
	private:

		CAsyncHandler(CProcessServer& aServer);
		void ConstructL();
		
		// CActive implementation
		void RunL();
		void DoCancel();
			
		TInt ExecuteFirstRequestInArray();// Execute messages in array
		
		/**
		Structure for holding a simple message
		*/
		class TMessage
			{
		public:
			const RMessage2& Message() const; 	// getter
			RMessage2& Message();				// setter
		private:
			RMessage2 iMessage;
			};
		
		void Complete(TInt aResult);
		
	private:
		RArray<TMessage>  		iMessageArray;
		CProcessServer& 		iServer;
		};
	
private:
	CProcessServer& iServer;
	CAsyncHandler* 	iAsyncRequestHandler;
	
	};

#endif
