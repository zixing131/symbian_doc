// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <FileStream.rsg>

#include "FileStreamExternalInterface.h"
#include "FileStreamAppUi.h"
#include "FileStreamMainView.h"
#include "FileStream.hrh"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileStreamMainView* CFileStreamMainView::NewLC(CQikAppUi& aAppUi)
	{
	CFileStreamMainView* self = new (ELeave) CFileStreamMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CFileStreamMainView::CFileStreamMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileStreamMainView::~CFileStreamMainView()
	{
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CFileStreamMainView::ConstructL()
	{
	BaseConstructL();
	}
	
// --------------------------------------------------------------------------
// Called when this view is first time activated.
// --------------------------------------------------------------------------
void CFileStreamMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_FILESTREAM_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EFileStreamLabelCtrl);
	}

// --------------------------------------------------------------------------
// Returns the identifier of this view.
// --------------------------------------------------------------------------
TVwsViewId CFileStreamMainView::ViewId()const
	{
	return TVwsViewId(KUidFileStreamApp, KUidFileStreamMainView);
	}

// --------------------------------------------------------------------------
// Handles user command.
// In this example, all commands are sent to AppUi because
// we want to have the same code with S60.
// --------------------------------------------------------------------------
void CFileStreamMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CFileStreamMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the label has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CFileStreamMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
