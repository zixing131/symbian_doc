/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */  

// INCLUDES
#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <FileStream.rsg>

#include "FileStreamMainView.h"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileStreamMainView* CFileStreamMainView::NewL(const TRect& aRect)
	{
	CFileStreamMainView* self = CFileStreamMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileStreamMainView* CFileStreamMainView::NewLC(const TRect& aRect)
	{
	CFileStreamMainView* self = new (ELeave) CFileStreamMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileStreamMainView::~CFileStreamMainView()
	{
	delete iEikEdwin;
	}
	
// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CFileStreamMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_FILESTREAM_TEXT);	
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CFileStreamMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Returns the number of controls.
// In this example, it returns 1 because there is only one
// control, which is an edwin control.
// --------------------------------------------------------------------------
TInt CFileStreamMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

// --------------------------------------------------------------------------
// Returns the pointer of the controls.
// In this example, it returns the pointer of the edwin control.
// --------------------------------------------------------------------------
CCoeControl* CFileStreamMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return 0;
	}

// --------------------------------------------------------------------------
// Called when this control needs to be redrawn.
// --------------------------------------------------------------------------
void CFileStreamMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the edwin has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CFileStreamMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
