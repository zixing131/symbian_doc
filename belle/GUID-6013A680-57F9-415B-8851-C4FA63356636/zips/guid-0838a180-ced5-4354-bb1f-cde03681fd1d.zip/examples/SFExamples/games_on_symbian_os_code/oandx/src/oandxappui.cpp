// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <avkon.hrh>
#include <aknnotewrappers.h>

#include "OandXAppUi.h"
#include "oandxcontroller.h"
#include "oandxengine.h"
#include "OandXAppView.h"
#include "oandxdefs.h"
#include "OandX.hrh"
#include <OandX.rsg>

#define MaxInfoNoteTextLen 40

COandXAppUi::COandXAppUi()
/**
	This empty constructor is defined to ensure that exactly
	one instance is generated.
 */
//:	iStacked(EFalse)
	{
	// empty.
	}

void COandXAppUi::ConstructL()
/**
	Sets default skin paramters, creates engine and app view.
	
	@see ~COandXAppUi
 */
	{
	// for v1.x SDKs, use no-arg BaseConstructL() overload
	BaseConstructL(EAknEnableSkin);
	iEngine = COandXEngine::NewL();
	iController = COandXController::NewL();
	iAppView = COandXAppView::NewL(ClientRect());
	AddToStackL(iAppView); // Enable keypresses to the view
	iStacked = ETrue;
   
	ReportWhoseTurn();
	}


COandXAppUi::~COandXAppUi()
/**
	This destructor undoes the secondary initialization in ConstructL.
	
	@see ConstructL
 */
	{
	if (iStacked)
		{
		RemoveFromStack(iAppView);
		}
	delete iAppView;
	delete iController;
	delete iEngine;
	}


void COandXAppUi::HandleCommandL(TInt aCommand)
/**
	This function handles commands from menus, softkeys,
	and from the system, e.g. EEikCmdExit.
	
	@param	aCommand		Command identifier.
 */
	{
	switch(aCommand)
		{
	case EEikCmdExit:
	case EAknSoftkeyExit:
		{
		SaveL();
		Exit();
		}
		break;
	case EOandXNewGame:
		{
		iController->Reset();
		iAppView->ResetView();
		}
		break;
	case EOandXSwitchTurn:
		{
		iController->SwitchTurn();
		}
		break;

	default:
		break;
		}
	}

void COandXAppUi::DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane)
	{
	if (aResourceId == R_OANDX_MENU)
		{
		if (iController->IsNewGame())
			{
			CEikMenuPaneItem::SData item;
			iCoeEnv->ReadResource(item.iText, iController->IsCrossTurn()?R_OANDX_O_MOVES_FIRST:R_OANDX_X_MOVES_FIRST );
			item.iCommandId = EOandXSwitchTurn;
			item.iFlags = 0;
			item.iCascadeId = 0;
			aMenuPane->AddMenuItemL(item);
			
			aMenuPane->DeleteMenuItem(EOandXNewGame);
			}
		}
	}

void COandXAppUi::ReportWhoseTurn()
/**
	Tell the user whose turn it is by displaying a nought or cross symbol.
 */
	{
	iAppView->ShowTurn();
	}

void COandXAppUi::ReportWinnerL(TInt aWinner)
/**
	Tell the user who won the game by displaying the information
	in a platform-specific dialog.
 */
	{
	TBuf<MaxInfoNoteTextLen> text;
	iEikonEnv->ReadResource(text, aWinner==ETileCross ? R_OANDX_X_WINS : R_OANDX_O_WINS);
	CAknInformationNote* infoNote = new (ELeave) CAknInformationNote;
	infoNote->ExecuteLD(text);
	}

TStreamId COandXAppUi::StoreL(CStreamStore& aStore) const
/**
	Store the current game state in the supplied stream store.
	
	@param	aStore			Stream store which will contain new
							stream which encodes the game state.
	@return					The new stream's ID.
	@see RestoreL
 */
	{
	RStoreWriteStream stream;
	TStreamId id = stream.CreateLC(aStore);
	stream << *this; // alternatively, use ExternalizeL(stream)
	stream.CommitL();
	CleanupStack::PopAndDestroy();
	return id;
	}

void COandXAppUi::RestoreL(const CStreamStore& aStore, TStreamId aStreamId)
/**
	Restore the current game state from the supplied stream.
	
	@param	aStore			Stream store which contains a stream
							which contains the externalized game state.
	@param	aStreamId		ID of stream in the store which contains
							the externalize game state.
	@see StoreL
 */
	{
	RStoreReadStream stream;
	stream.OpenLC(aStore,aStreamId);
	stream >> *this; // alternatively use InternalizeL(stream)
	CleanupStack::PopAndDestroy();
	}

void COandXAppUi::ExternalizeL(RWriteStream& aStream) const
/**
	Write the app ui's state, which includes all of the game state,
	to a writable stream.
	
	@param	aStream			Stream to which game state should be written.
 */
	{
	iEngine->ExternalizeL(aStream);
	iController->ExternalizeL(aStream);
	aStream.WriteInt8L(iAppView->IdOfFocusControl());
	}

void COandXAppUi::InternalizeL(RReadStream& aStream)
/**
	Restore the game state from the supplied readable stream.
	
	@param	aStream			Stream which contains externalized
							game state.
 */
	{
	iEngine->InternalizeL(aStream);
	iController->InternalizeL(aStream);
	ReportWhoseTurn();
	iAppView->MoveFocusTo(aStream.ReadInt8L());
	}


// Global accessor functions

GLDEF_C COandXAppUi* OandXAppUi()
/**
Accessor function provides access to singleton instance of app ui object.
@return  The application UI, cast to COandXAppUi.
 */
	{
	return static_cast<COandXAppUi*>(CEikonEnv::Static()->AppUi());
	}

GLDEF_C COandXController& Controller()
/**
Return mutable reference to singleton instance of COandXController object.
@return	Singleton COandXController object.
 */
	{
	return *OandXAppUi()->iController;
	}

GLDEF_C COandXEngine& Engine()
/**
Return mutable reference to singleton instance of COandXEngine object.
@return	Singleton COandXEngine object.
 */
	{
	return *OandXAppUi()->iEngine;
	}
