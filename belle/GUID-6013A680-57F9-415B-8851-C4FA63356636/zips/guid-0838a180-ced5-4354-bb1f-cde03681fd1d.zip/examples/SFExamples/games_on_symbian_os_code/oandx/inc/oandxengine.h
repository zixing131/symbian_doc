// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDXENGINE_H
#define OANDXENGINE_H

#include <s32std.h>

#include "oandxdefs.h"

class COandXEngine : public CBase
/**
	This engine class represents the board,
	a grid of tiles which can be modified by
	the controller.
 */
	{
public:
	static COandXEngine* NewL();
	virtual ~COandXEngine();
	
	// reset
	void Reset();
	
	// game logic
	TTileState TileStatus(TInt aIndex) const;
	TBool TryMakeMove(TInt aIndex, TBool aCrossTurn);
	TTileState GameWonBy() const;
	
	// persistence
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);
	
private:
	COandXEngine();
	
	TInt TileState(TInt aX, TInt aY) const;

private:
	/**
		Each tile's value is represented by an integer,
		ETileBlank, ETileNought, or ETileCross.
	 */
	TFixedArray<TTileState, KNumberOfTiles> iTileStates;
	};

#endif // OANDXENGINE_H
