// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDXDEFS_H
#define OANDXDEFS_H

// Generic board data
static const TInt KTilesPerRow = 3;
static const TInt KTilesPerCol = 3;
static const TInt KNumberOfTiles = (KTilesPerRow*KTilesPerCol);

// OandX-specific data
static const TInt KTilesPerSide = 3;

enum TTileState
	{
	ETileBlank  = 0,
	ETileNought = 1,
	ETileCross  = 4
	}; // Values chosen so that:
	   // KTilesPerRow*ETileNought < ETileCross
	   // KTilesPerCol*ETileNought < ETileCross

static const TInt KStatusWinHeight = 20; // in pixels

#endif // OANDXDEFS_H
