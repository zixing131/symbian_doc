// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDXAPPVIEW_H
#define OANDXAPPVIEW_H

#include <coecntrl.h>
#include <coedef.h>
#include "oandxdefs.h"

class COandXAppView;
class COandXTile;

class COandXSymbolControl : public CCoeControl
	{
protected:
	void DrawSymbol(CWindowGc& aGc, const TRect& aRect, TBool aDrawCross) const;
	};
	

class MViewCmdHandler
    {
public:
    virtual TBool TryHitSquareL(const COandXTile* aControl)=0;
    virtual TTileState TileStatus(const COandXTile* aControl) const =0;
    };
    
class COandXTile : public COandXSymbolControl
	{
public:
	COandXTile();
	~COandXTile();
	void ConstructL(RWindow& aWindow);

	// From CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	TCoeInputCapabilities InputCapabilities() const;

	// New function
	void SetOwnerAndObserver(COandXAppView* aControl);

protected:
	void HandlePointerEventL(const TPointerEvent& aPointerEvent);
	void FocusChanged(TDrawNow aDrawNow);

private:
	// from CCoeControl
	void Draw(const TRect& aRect) const;
	
	// New function
	void TryHitL();

private:
	MViewCmdHandler* iCmdHandler;
	};

class COandXStatusWin : public COandXSymbolControl
	{
public:
	static COandXStatusWin* NewL(RWindow& aWindow);
	~COandXStatusWin();

private:
	COandXStatusWin();
	void ConstructL(RWindow& aWindow);
	void Draw(const TRect& aRect) const;
	};



class COandXAppView : public CCoeControl, public MCoeControlObserver, public MViewCmdHandler
	{
public:
	static COandXAppView* NewL(const TRect& aRect);
	virtual ~COandXAppView();
	
	// From CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);

	// new functions	
	void MoveFocusTo(const TInt aIndex);
	TInt IdOfFocusControl();
	void ShowTurn();
	void ResetView();

private:
	COandXAppView();
	void ConstructL(const TRect& aRect);

	void SwitchFocus(TInt aFromIndex, CCoeControl* aToControl);
	void DrawComps(TRect& aRect) const;
	COandXTile * CreateTileL();

	// From CCoeControl
	void Draw(const TRect& aRect) const;
	void SizeChanged();
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;
	
	// From MCoeControlObserver
	void HandleControlEventL(CCoeControl* aControl, TCoeEvent aEventType);

	// From MViewCmdHandler
	TBool TryHitSquareL(const COandXTile* aControl);
	TTileState TileStatus(const COandXTile* aControl) const;

private:
	RPointerArray<COandXTile> iTiles; // View owns the tiles
	COandXStatusWin* iStatusWin;	  // and its own status window.
	TRect iBoardRect;  // Board area
	TRect iBorderRect; // Bounding rectangle for border
	TInt iTileSide;	   // Tile dimension, allowing for line widths and border
	};

#endif // OANDXAPPVIEW_H
