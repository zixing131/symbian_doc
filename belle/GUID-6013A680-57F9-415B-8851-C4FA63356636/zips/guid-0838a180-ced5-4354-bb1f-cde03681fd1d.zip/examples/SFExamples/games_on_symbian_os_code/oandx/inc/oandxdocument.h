// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDX_DOCUMENT_H
#define OANDX_DOCUMENT_H


#include <eikapp.h>
#include <akndoc.h>

class COandXAppUi;


class COandXDocument : public CAknDocument
/**
	Standard document class creates the application's UI,
	and stores and restores the game state.
 */
	{
public:
	static COandXDocument* NewL(CEikApplication& aApp);
 	virtual ~COandXDocument();

	// From CEikDocument
	virtual CEikAppUi* CreateAppUiL();
	virtual void StoreL(CStreamStore& aStore,CStreamDictionary& aStreamDic) const;
	virtual void RestoreL(const CStreamStore& aStore,const CStreamDictionary& aStreamDic);
	virtual CFileStore* OpenFileL(TBool aDoOpen,const TDesC& aFilename,RFs& aFs);

private:
	COandXDocument(CEikApplication& aApp);

private:
	COandXAppUi* iAppUi;
	};

#endif // OANDX_DOCUMENT_H
