// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDX_APPUI_H
#define OANDX_APPUI_H

#include <aknappui.h>
#include <eikmenup.h>
#include <eikmenub.h>

class COandXAppView;
class COandXController;
class COandXEngine;

class COandXAppUi : public CAknAppUi
/**
	Standard application UI class handles menu commands and
	reports information to the user.
 */
	{
public:
	COandXAppUi();
	virtual ~COandXAppUi();

	// New functions
	void ReportWhoseTurn();
	void ReportWinnerL(TInt aWinner);

	// From CEikAppUi, for persistent data
	TStreamId StoreL(CStreamStore& aStore) const;
	void RestoreL(const CStreamStore& aStore, TStreamId aStreamId);
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);

private:
	
	// From MEikMenuObserver
	void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);

	// From CEikAppUi
	void HandleCommandL(TInt aCommand);
	void ConstructL();

public:
	// AppUi owns the controller, engine and application view.
	COandXController* iController;
	COandXEngine* iEngine;
private:
	COandXAppView* iAppView;
	// Set if the app view was added to the control stack.
	TBool iStacked;
	};


// Global accessor functions

GLREF_C COandXAppUi* OandXAppUi();
GLREF_C COandXController& Controller();
GLREF_C COandXEngine& Engine();

#endif // OANDX_APPUI_H

