/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: 
*/

// system include
#include <stdio.h>
// GCCE specific header file
//#include <staticlibinit_gcce.h>


// Debug message
FILE* fpDebug = NULL;
char* logFileName = "c:\\logs\\trace.txt";
const char* anotherLogFile = "c:\\logs\\newlog.txt";

/**
* Use to redirect the printf statements
* @param aMessagePtr pointer to the message
* @param ... Variable parameters like printf
*
*/
int RedirectPrintf(char* aMessagePtr, ...)
{
    va_list marker;
    int printChar;
    if(fpDebug == NULL)
    {
        fpDebug = freopen(logFileName, "a+", stdout);
    }
    if(fpDebug != NULL)
    {
        va_start(marker, aMessagePtr);
        printChar = vprintf(aMessagePtr, marker);
        va_end(marker);
    }
    return printChar;
}

/**
* application entry point
*/

int main(void)
{
	int printInt = 10;
    // this will print in console
    printf("Redirecting printf to - %s\n", logFileName);
    // from this statement onwards, printf statement will be redirected to file
    printf("You wnt be able to see the message within the \nconsole.\n");
    // put this message first. Once RedirectPrintf statement is called, printf statement will be redirect to file.
    printf("Press enter to exit.");
    RedirectPrintf("Printing something using trace.\n");
    if(fpDebug != NULL)
    {
        printf("printing using printf method.\n");
        printf("Printing an integer - %d.\n", printInt);

        printf("Redirecting printf to another file - %s\n", anotherLogFile);
    	fpDebug = freopen(anotherLogFile, "a+", fpDebug);
        if(fpDebug != NULL)
        {
            printf("Start redirecting printf to - %s\n", anotherLogFile);
            printf("Closing the printf stream.\n");
            fclose(fpDebug);
        }
    }
    fflush(stdin);
    getchar(); // wait for user input before terminate
    return 0;
}


//End of file
