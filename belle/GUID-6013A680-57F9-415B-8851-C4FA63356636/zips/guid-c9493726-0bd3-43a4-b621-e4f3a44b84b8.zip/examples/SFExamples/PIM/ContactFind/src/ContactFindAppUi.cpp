// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikapp.h>
#include <ContactFind.rsg>

#include "ContactFindAppUi.h"
#include "ContactFindMainView.h"
#include "ContactRead.h"
#include "ContactFind.hrh"

void CContactFindAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	iMainView = CContactFindMainView::NewL(ClientRect());

	iContactReader = CContactRead::NewL();
	}
	
CContactFindAppUi::~CContactFindAppUi()
    {
    delete iContactReader;
#ifdef __SERIES60_3X__
	delete iMainView;
#endif
    }

void CContactFindAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
#ifdef __SERIES60_3X__
		case EAknSoftkeyExit:
#endif
		case EEikCmdExit:
			{
			User::Exit(0);
			break;
			}
		case EContactFind:
			{
			// \PIM\PopulateContact should have created at a card with the
			// name set to "Partner"
			_LIT(KStringMatch, "Partner");
			CContactIdArray* result = NULL;
			TFieldType type = KUidContactFieldGivenName;
			TRAPD(error, result = iContactReader->FindWithCallbackL(type, KStringMatch()));
			// report result on the Label control
			if (KErrNone == error && NULL != result)
				{
				// No CleanupStack::PushL this time. Nothing can leave.
				TBuf<64> textBuf;
				_LIT(KPrefix, "success :");
				_LIT(KCardId, " %D");
				textBuf.Append(KPrefix());
				for (TInt ii = 0; ii < result->Count() && ii < 3; ++ii)
					{
					textBuf.AppendFormat(KCardId(), (*result)[ii]);
					}
				delete result;
				iMainView->SetTextL(textBuf);
				}
			else
				{
				_LIT(KErrorMsg, "Symbian Error Code = %D");
				TBuf<32> errorBuf;
				errorBuf.Format(KErrorMsg(), error);
				iMainView->SetTextL(errorBuf);
				}
			break;
			}
		default:
			break;
		}
	}

	
#ifdef __SERIES60_3X__

void CContactFindAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}

#endif
	
// End of File
