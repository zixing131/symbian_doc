// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikedwin.h>
#include <eikenv.h>
#include <aknutils.h>
#include <ContactFind.rsg>

#include "ContactFindMainView.h"

CContactFindMainView* CContactFindMainView::NewL(const TRect& aRect)
	{
	CContactFindMainView* self = CContactFindMainView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

CContactFindMainView* CContactFindMainView::NewLC(const TRect& aRect)
	{
	CContactFindMainView* self = new (ELeave) CContactFindMainView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

CContactFindMainView::~CContactFindMainView()
	{
	delete iEikEdwin;
	}
	
void CContactFindMainView::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
	// Create an edwin on this control.
	iEikEdwin = new (ELeave) CEikEdwin();
	iEikEdwin->ConstructL(CEikEdwin::EReadOnly | CEikEdwin::ENoAutoSelection);
    iEikEdwin->SetContainerWindowL(*this);
	HBufC* message = ControlEnv()->AllocReadResourceLC(
		R_CONTACTFIND);	
    iEikEdwin->SetTextL(message);
	CleanupStack::PopAndDestroy(message);
	
	SetRect(aRect);
	ActivateL();
	}

void CContactFindMainView::SetTextL(const TDesC& aText)
	{
	if (iEikEdwin)
		{
		iEikEdwin->SetTextL(&aText);
		DrawNow();
		}
	}

TInt CContactFindMainView::CountComponentControls() const
	{
	if (iEikEdwin)
		{
		return 1;
		}
	return 0;
	}

CCoeControl* CContactFindMainView::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iEikEdwin;
		default:
			break;
		}
	return NULL;
	}

void CContactFindMainView::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void CContactFindMainView::SizeChanged()
    {
    if (iEikEdwin)
		{
		TRect rect(Rect());
		iEikEdwin->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
    }
	
// End of File
