/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:
 */ 

// INCLUDES
#include <bautils.h>
#include <FileStore.rsg>

#include "FileStoreAppUi.h"
#include "FileStoreMainView.h"
#include "FileStore.hrh"
#include "Employee.h"

// CONSTANTS
_LIT(KFileName1,    "c:\\data\\filestore1.dat");
_LIT(KFileName2,    "c:\\data\\filestore2.dat");

const TInt KIdentifier1 = 1;
_LIT(KName1,        "John Doe");
_LIT(KPhoneNumber1, "+1-222-333-4444");

const TInt KIdentifier2 = 2;
_LIT(KName2,        "Jane Roe");
_LIT(KPhoneNumber2, "+1-234-567-8900");

const TUid KHeaderUid    = TUid::Uid(0x01);
const TUid KEmployeesUid = TUid::Uid(0x02);

_LIT(KSignature, "QRECIPES");
const TUint32 KVersion = 1;

const TInt KMaxBuffer = 100;
const TChar KEndOfLine = '\f';


// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CFileStoreAppUi::ConstructL()
	{

	BaseConstructL(EAknEnableSkin);
	
	iMainView = CFileStoreMainView::NewL(ClientRect());

	BaflUtils::EnsurePathExistsL(iCoeEnv->FsSession(), KFileName1);
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileStoreAppUi::~CFileStoreAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    iArray.ResetAndDestroy();
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CFileStoreAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{

		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EFileStoreWriteEmployee:
			{
			// Create a new Employee.
			CEmployee* employee = new (ELeave) CEmployee();
			CleanupStack::PushL(employee);
			employee->SetIdentifier(KIdentifier1);
			employee->SetName(KName1);
			employee->SetPhoneNumber(KPhoneNumber1);
			
			// Add the Employee to the file store.
			WriteEmployeeToStoreL(iCoeEnv->FsSession(), KFileName1, *employee);
			
			CleanupStack::PopAndDestroy(employee);
			
			// Display a message on the main view.
			HBufC* message = iCoeEnv->AllocReadResourceLC(
					R_FILESTORE_EMPLOYEEWRITTEN);
			iMainView->SetTextL(*message);
			CleanupStack::PopAndDestroy(message);
			break;
			}
			
		case EFileStoreReadEmployee:
			{
			CEmployee* employee = new (ELeave) CEmployee();
			CleanupStack::PushL(employee);
			
			// Read the Employee from the file store.
			ReadEmployeeFromStoreL(iCoeEnv->FsSession(), KFileName1, *employee);
			
			// Display the Employee on the main view.
			RBuf buffer;
			buffer.CreateL(KMaxBuffer);
			CleanupClosePushL(buffer);
			buffer.AppendNum(employee->Identifier());
			buffer.Append(KEndOfLine);
			buffer.Append(employee->Name());
			buffer.Append(KEndOfLine);
			buffer.Append(employee->PhoneNumber());
			buffer.Append(KEndOfLine);
			iMainView->SetTextL(buffer);
			
			CleanupStack::PopAndDestroy(2, employee); // myEmployee and buffer
			break;
			}
		
		case EFileStoreWriteEmployeeMulti:
			{
			iArray.ResetAndDestroy();
			
			// Add two new Employees.
			CEmployee* employee = new (ELeave) CEmployee();
			employee->SetIdentifier(KIdentifier1);
			employee->SetName(KName1);
			employee->SetPhoneNumber(KPhoneNumber1);
			iArray.Append(employee); // ownership is transferred
			
			employee = new (ELeave) CEmployee();
			employee->SetIdentifier(KIdentifier2);
			employee->SetName(KName2);
			employee->SetPhoneNumber(KPhoneNumber2);
			iArray.Append(employee); // ownership is transferred
			
			// Add the Employees to the file store.
			WriteEmployeesWithMultiStreamsL(iCoeEnv->FsSession(), KFileName2,
					iArray);
			
			// Display a message on the main view.
			HBufC* message = iCoeEnv->AllocReadResourceLC(
					R_FILESTORE_EMPLOYEEWRITTENMULTI);
			iMainView->SetTextL(*message);
			CleanupStack::PopAndDestroy(message);
			break;
			}
			
		case EFileStoreReadEmployeeMulti:
			{
			iArray.ResetAndDestroy();
			
			ReadEmployeesWithMultiStreamsL(iCoeEnv->FsSession(), KFileName2,
					iArray);
			
			// Display all the Employees on the main view.
			RBuf buffer;
			buffer.CreateL(KMaxBuffer * iArray.Count());
			CleanupClosePushL(buffer);
			for (TInt i = 0; i < iArray.Count(); i++)
				{
				const CEmployee* employee = iArray[i];
				buffer.AppendNum(employee->Identifier());
				buffer.Append(KEndOfLine);
				buffer.Append(employee->Name());
				buffer.Append(KEndOfLine);
				buffer.Append(employee->PhoneNumber());
				buffer.Append(KEndOfLine);
				buffer.Append(KEndOfLine);
				}
			
			iMainView->SetTextL(buffer);
			
			CleanupStack::PopAndDestroy(&buffer);
			break;
			}
			
		default:
			// Do nothing
			break;
		}
	}


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CFileStoreAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}



void CFileStoreAppUi::WriteEmployeeToStoreL(RFs& aFs, const TDesC& aFileName,
		const CEmployee& aEmployee)
	{
	// Create a new file store.
	CFileStore* store = CDirectFileStore::ReplaceLC(aFs, aFileName, EFileWrite);
	store->SetTypeL(KDirectFileStoreLayoutUid);
	
	// Create a new stream on the store.
	RStoreWriteStream writeStream;
	TStreamId rootId = writeStream.CreateLC(*store);
	
	// Write Employee to the stream.
	writeStream << aEmployee;
	
	// Commit the changes to the stream and close the stream.
	writeStream.CommitL();
	CleanupStack::PopAndDestroy(&writeStream);
	
	// Set the root identifier of the store to this stream.
	store->SetRootL(rootId);
	
	// Commit the change to the store and close the store.
	store->Commit();
	CleanupStack::PopAndDestroy(store);
	}

void CFileStoreAppUi::ReadEmployeeFromStoreL(RFs& aFs, const TDesC& aFileName,
		CEmployee& aEmployee)
	{
	// Open the store.
	CFileStore* store = CDirectFileStore::OpenLC(aFs, aFileName, EFileRead);

	// Get the root stream. In this case, we have only one stream.
	RStoreReadStream readStream;
	readStream.OpenLC(*store, store->Root());
	
	// Read the Employee.
	readStream >> aEmployee;
	
	CleanupStack::PopAndDestroy(2, store); // readStream and store
	}

void CFileStoreAppUi::WriteEmployeesWithMultiStreamsL(RFs& aFs,
		const TDesC& aFileName,
		const RPointerArray<CEmployee>& aArray)
	{
	// Create a new file store.
	CFileStore* store = CDirectFileStore::ReplaceLC(aFs, aFileName,
			EFileWrite);
	store->SetTypeL(store->Layout());
	
	//
	// Write header information.
	//
	RStoreWriteStream headerStream;
	TStreamId headerId = headerStream.CreateLC(*store);
	
	headerStream << KSignature;
	headerStream << KVersion;
	headerStream << (TUint32) aArray.Count();
	
	headerStream.CommitL();
	CleanupStack::PopAndDestroy(&headerStream);
	
	//
	// Create a new employee to the store.
	//
	RStoreWriteStream employeeStream;
	TStreamId employeesId = employeeStream.CreateLC(*store);
	
	// Write Employees to the stream.
	for (TInt i = 0; i < aArray.Count(); i++)
		{
		employeeStream << *aArray[i];
		}
	
	employeeStream.CommitL();
	CleanupStack::PopAndDestroy(&employeeStream);
	
	//
	// Create a stream dictionary.
	//
	CStreamDictionary* dictionary = CStreamDictionary::NewLC();
	dictionary->AssignL(KHeaderUid, headerId);
	dictionary->AssignL(KEmployeesUid, employeesId);
	
	// Write stream dictionary in the root stream.
	RStoreWriteStream dictionaryStream;
	TStreamId rootId = dictionaryStream.CreateLC(*store);
	dictionaryStream << *dictionary;
	dictionaryStream.CommitL();
	
	CleanupStack::PopAndDestroy(2, dictionary); // dictionaryStream and dictionary
	
	// Set the root identifier of the store to this stream.
	store->SetRootL(rootId);
	
	// Commit the change to the store and close the store.
	store->Commit();
	CleanupStack::PopAndDestroy(store);
	}

void CFileStoreAppUi::ReadEmployeesWithMultiStreamsL(RFs& aFs,
		const TDesC& aFileName,
		RPointerArray<CEmployee>& aArray)
	{
	// Open the new file store.
	CFileStore* store = CDirectFileStore::OpenLC(aFs, aFileName,
			EFileWrite);
	
	//
	// Read stream dictionary
	//
	CStreamDictionary* dictionary = CStreamDictionary::NewLC();
	RStoreReadStream dictionaryStream;
	dictionaryStream.OpenLC(*store, store->Root());
	dictionaryStream >> *dictionary;
	CleanupStack::PopAndDestroy(&dictionaryStream);
	
	// Get the identifier of each stream in this store.
	TStreamId headerId = dictionary->At(KHeaderUid);
	TStreamId employeesId = dictionary->At(KEmployeesUid);
	CleanupStack::PopAndDestroy(dictionary);
	
	//
	// Read header information.
	//
	RStoreReadStream headerStream;
	headerStream.OpenLC(*store, headerId);
	
	HBufC* signature = HBufC::NewLC(headerStream, KMaxBuffer);
	// If needed, check the signature here.
	CleanupStack::PopAndDestroy(signature);
	TUint32 version;
	headerStream >> version;
	TUint32 numberOfEmployees;
	headerStream >> numberOfEmployees;
	
	CleanupStack::PopAndDestroy(&headerStream);
	
	//
	// Read the employees streams.
	//
	RStoreReadStream employeeStream;
	employeeStream.OpenLC(*store, employeesId);
	
	for (TUint32 i = 0; i < numberOfEmployees; i++)
		{
		CEmployee* employee = new (ELeave) CEmployee();
		CleanupStack::PushL(employee);
		employeeStream >> *employee;
		aArray.Append(employee); // ownership is transferred
		CleanupStack::Pop(employee);
		}
	
	CleanupStack::PopAndDestroy(&employeeStream);
	
	// Commit the change to the store and close the store.
	CleanupStack::PopAndDestroy(store);
	}

// End of File
