// dialogbox.h
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of CDialogBox and CLoader classes.
*/
#ifndef __DIALOGBOX_H__
#define __DIALOGBOX_H__

#include <e32std.h>
#include <e32base.h>
#include <w32std.h>
#include <gdi.h>
#include <e32math.h>

// Location of the bitmap images for
// incoming call animation.
#ifdef __WINS__
// Location of images for the emulator build.
	_LIT(KCallBitmaps1,"z:\\resource\\apps\\incoming1.mbm");
	_LIT(KCallBitmaps2,"z:\\resource\\apps\\incoming2.mbm");
	_LIT(KCallBitmaps3,"z:\\resource\\apps\\incoming3.mbm");
	_LIT(KCallBitmaps4,"z:\\resource\\apps\\incoming4.mbm");
	_LIT(KCallBitmaps5,"z:\\resource\\apps\\incoming5.mbm");
	_LIT(KCallBitmaps6,"z:\\resource\\apps\\incoming6.mbm");
#else
// Location of images for the hardware build.
	_LIT(KCallBitmaps1,"e:\\resource\\apps\\incoming1.mbm");
	_LIT(KCallBitmaps2,"e:\\resource\\apps\\incoming2.mbm");
	_LIT(KCallBitmaps3,"e:\\resource\\apps\\incoming3.mbm");
	_LIT(KCallBitmaps4,"e:\\resource\\apps\\incoming4.mbm");
	_LIT(KCallBitmaps5,"e:\\resource\\apps\\incoming5.mbm");
	_LIT(KCallBitmaps6,"e:\\resource\\apps\\incoming6.mbm");
#endif

class CLoader;
/**
This class handles the incoming call animation.
This class has methods to:
- Initialise the window server session, screen device,
  graphics content, window group and the window.
- Show incoming call animation.
*/
class CDialogBox : public CBase
	{
public:
	static CDialogBox* NewL(const TRect&);
	~CDialogBox();

	void Start();
	void Stop();

	void SetSemiTransparency();
	void RemoveSemiTransparency();
	TBool IsSemiTransparent() { return iSemiTransFlag;}

private:
	CDialogBox(const TRect&);
	void ConstructL();
	static TInt OnTick(TAny*);
	TBool Draw();

private:
	/**
	The window server session.
	*/
	RWsSession iWs;
	/**
	The handle to the server-side window group.
	*/
	RWindowGroup iGrp;
	/**
	Handle to the window.
	The incoming call animation is performed on this window.
	*/
	RWindow iWin;
	/**
	The software device screen.
	*/
	CWsScreenDevice* iScr;
	/**
	The window graphics context.
	*/
	CWindowGc* iGc;
	/**
	Represents the area of the screen available for drawing.
	*/
	TRect iRect;
	/**
	The counter to the number of images loaded to display the animation.
	*/
	TInt iImageCounter;
	/**
	Indicates if the call animation is semi-transparent.
	*/
	TBool iSemiTransFlag;
	/**
	The handle to bitmap images.
	*/
	CFbsBitmap* iCallFrame;
	/**
	The handle to bitmap images' mask.
	*/
	CFbsBitmap* iCallMaskFrame;
	/**
	The array to store bitmap images used for incoming call animation.
	*/
	RPointerArray<CFbsBitmap> iCallBuffer;
	/**
	The array of CLoader objects.
	@see CLoader.
	*/
	RPointerArray<CLoader> iLoaders;
	/**
	The CPeriodic object.
	It is used to periodically draw bitmap images
	to show the incoming call animation.
	*/
	CPeriodic* iTimer;
	};

/**
This class loads bitmap images from bitmap files.
*/
class CLoader: public CBase
	{
public:
	static CLoader* NewL(const TDesC& aFn);
	~CLoader();
	void Decode();

private:
	CLoader();
	void ConstructL(const TDesC& aFn);

#ifdef PORTRAIT_MODE
	void RotateL(CFbsBitmap& aBitmap);
#endif

public:
	/**
	The bitmap mask.
	*/
	CFbsBitmap* iMask;
	/**
	The bitmap loaded from the bitmap file.
	*/
	CFbsBitmap* iBitmap;
	};

#endif

