// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Symbian Foundation License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.symbianfoundation.org/legal/sfl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __EGLRENDERING_H__
#define __EGLRENDERING_H__


class MEngine;

#include "EGL/egl.h"
#include "VG/openvg.h"
#include "VG/vgu.h"


#include "engine.h"
#include "openvgengine.h"

const TInt KMaxConfigs = 100;
const TInt KTimerDelay = 10000;

/**
This class handles the rendering of the EGL display.
It defines methods to:
- initialise the display.
- update the display.
- handle key press events.
*/
class CEGLRendering : public CBase 
    {
public:
    static CEGLRendering* NewL(RWindow& aWindow);
    static CEGLRendering* NewLC(RWindow& aWindow);

    ~CEGLRendering();

    void Start();
    void Stop();

    static void EGLCheckError();
    static void EGLCheckReturnError(EGLBoolean aBool);
    static void VGCheckError();

    TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent);

    void UpdateDisplay();
    static TInt TimerCallBack(TAny* aDemo);
    


private:
    CEGLRendering(RWindow& aWindow);
    void ConstructL();

private:
    /**
    Handle to the active window.
    */
    RWindow& iWindow;
    /**
    The CPeriodic object used to update the contents of
    CEGLRendering::iDisplay and CEGLRendering::iSurface.
    */
    CPeriodic* iTimer;
    
    /**
    Handle to bitmap images of covers used in the example.
    */
    CFbsBitmap* iBitmap;
    /**
    The display on which the contents are drawn.
    */
    EGLDisplay iDisplay;
    /**
    The EGL drawing surface.
    */
    EGLSurface iSurface;
    /**
    Handle to the rendering context.
    */
    EGLContext iContextVG;
    /**
    Describes the format, type and size of the colour
    buffers for CEGLRendering::iSurface.
    */
    EGLConfig iConfig[KMaxConfigs];
    /**
    Stores the timestamp of the fast counter.
    */
    TUint32 iLastFrameTimeStamp;
    /**
    Stores the fast counter frequency of the
    Hardware Abstraction Layer.
    */
    TInt iFastCounterFrequency;
    /**
    Indicates if the mirror image of covers
    should be displayed.
    */
    TBool iShowMirrorToggled;
    TBool iBusySwapping;
    
    COpenVGEngine* iCurrentDemo;
    };
#endif
