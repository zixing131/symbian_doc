/*
* ==============================================================================
*  Name        : Coverflowapplication.h
*  Part of     : Coverflowapp
*  Interface   : 
*  Description : 
*  Version     : 
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation.
* ==============================================================================
*/

#ifndef __COVERFLOWAPPLICATION_H__
#define __COVERFLOWAPPLICATION_H__

// INCLUDES
#include <aknapp.h>

// CLASS DECLARATION

/**
* CCoverflowApplication application class.
* Provides factory to create concrete document object.
* An instance of CCoverflowApplication is the application part of the
* AVKON application framework for the Coverflowapp example application.
*/
class CCoverflowApplication : public CAknApplication
    {
    public: // Functions from base classes

        /**
        * From CApaApplication, AppDllUid.
        * @return Application's UID (KUidCoverflowApp).
        */
        TUid AppDllUid() const;

    protected: // Functions from base classes

        /**
        * From CApaApplication, CreateDocumentL.
        * Creates CCoverflowappDocument document object. The returned
        * pointer in not owned by the CCoverflowApplication object.
        * @return A pointer to the created document object.
        */
        CApaDocument* CreateDocumentL();

	virtual TFileName ResourceFileName() const { return KNullDesC(); }
    };

#endif // __COVERFLOWAPPLICATION_H__

// End of File

