// engine.h
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of the MEngine class.
*/
#ifndef __ENGINE_H__
#define __ENGINE_H__

/**
The abstract class that represents the engine of the example.
*/
class MEngine
	{
public:

	virtual void ActivateL() = 0;
	virtual void Deactivate() = 0;
	virtual void Step()= 0 ;
	virtual TBool IsPending() = 0;
	virtual TInt GetSpeed() = 0;

	virtual TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent) = 0;
	};

#endif
