// openvgengine.h
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of the COpenVGEngine class.
*/
#ifndef __OPENVGENGINE_H__
#define __OPENVGENGINE_H__

#include <VG/openvg.h>
#include <EGL/egl.h>
#include "engine.h"
// image Height/Width
const TInt KImageSize = 128;

// KMaxDisplayCoversExample3 refers to the number of album covers
// visible on the screen at any given point
const TInt KMaxDisplayCoversExample3 = 40;
const TInt KMaxDisplayLeftExample3 = -3;
const TInt KMaxDisplayRightExample3 = 3;


// the max number of covers you can store
const TInt KMaxCoversExample3 = 40;

/**
This class creates the EGL surface, EGL display and the VG image of bitmaps.
It also contains methods to display these on the EGL display.
*/
class  COpenVGEngine :  public CBase, public MEngine
	{
public:

	static COpenVGEngine* NewL(TSize aSize,EGLDisplay& aDisplay, EGLSurface& aSurface, EGLContext& aContext);
	virtual ~COpenVGEngine();
	TInt GetSpeed();
	//From MEngine
	void ActivateL();
	void Deactivate();
	void Step();
	TBool IsPending();
	TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent);


private:
	COpenVGEngine(TSize aSize,EGLDisplay& aDisplay, EGLSurface& aSurface, EGLContext& aContext);

	void DrawCover(TInt i);

	void NextCover();
	void PreviousCover();

	void ToggleCoverReflection();
	VGfloat GetMiddleCoverScalingFactor(VGfloat coverPosition);


private:
	/**
	The display on which the contents are drawn.
	*/
	EGLDisplay& iDisplay;
	/**
	The EGL drawing surface.
	*/
	EGLSurface& iSurface;
	/**
	Handle to the rendering context.
	*/
	EGLContext& iContext;
	/**
	Handle to access images.
	*/
	VGImage iImage;
	/**
	The location of each cover.
	*/
	VGfloat iCoverLocation[KMaxCoversExample3];
	/**
	The handle to the wanted cover.
	*/
	VGint iWantedCover;
    /**
	Indicates if a redraw event is pending on the window.
	*/
    TBool iHasPendingDraw;
	/**
	The speed offset for the cover image.
	*/
	VGfloat iSpeedOffset;
	/**
	Indicates if the mirror image of covers needs to be displayed.
	*/
	TBool iShowMirror;
	/**
	The size of the surface.
	*/
	TSize iSurfaceSize;
	/**
	Represents the speed with which the cover is toggled to another position.
	*/
	VGfloat iSpeed;
	/**
	The array of cover images.
	*/
	RArray<VGImage> iImages;
	/**
	The index of the current image.
	*/
	TInt iCurrentImageIndex;
	/**
	Handle to the paint object.
	*/
	VGPaint iShadowPaint;
	};


#endif
