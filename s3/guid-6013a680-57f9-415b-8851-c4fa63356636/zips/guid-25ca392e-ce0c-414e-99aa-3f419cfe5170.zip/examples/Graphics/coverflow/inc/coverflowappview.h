/*
* ==============================================================================
*  Name        : Coverflowappview.h
*  Part of     : Coverflow
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

#ifndef __COVERFLOWAPPVIEW_H__
#define __COVERFLOWAPPVIEW_H__

// INCLUDES
#include <coecntrl.h>
#include <Coverflowappui.h>

// CLASS DECLARATION
class CCoverflowAppView : public CCoeControl
    {
    public:
        CCoverflowAppView(CCoverflowAppUi& aAppUi);
        ~CCoverflowAppView();
        void ConstructL(const TRect& aRect);

    private:
        /**
        Pointer to the application UI class of the example.
        */
        CCoverflowAppUi& iAppUi;
        friend class CCoverflowAppUi;
    };

#endif // __COVERFLOWAPPVIEW_H__

// End of File

