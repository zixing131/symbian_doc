/*
* ==============================================================================
*  Name        : coverflowAppdocument.h
*  Part of     : COVERFLOW
*  Interface   : 
*  Description : 
*  Version     : 
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation.
* ==============================================================================
*/

#ifndef __COVERFLOWAPPDOCUMENT_H__
#define __COVERFLOWAPPDOCUMENT_H__

// INCLUDES
#include <akndoc.h>

// FORWARD DECLARATIONS
class CCoverflowAppUi;
class CEikApplication;


// CLASS DECLARATION

/**
* CCoverflowAppDocument application class.
* An instance of class CCoverflowAppDocument is the Document part of the
* AVKON application framework for the CoverflowApp example application.
*/
class CCoverflowAppDocument : public CAknDocument
    {
    public: // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Construct a CCoverflowAppDocument for the AVKON application aApp
        * using two phase construction, and return a pointer
        * to the created object.
        * @param aApp Application creating this document.
        * @return A pointer to the created instance of CCoverflowAppDocument.
        */
        static CCoverflowAppDocument* NewL( CEikApplication& aApp );

        /**
        * NewLC.
        * Two-phased constructor.
        * Construct a CCoverflowAppDocument for the AVKON application aApp
        * using two phase construction, and return a pointer
        * to the created object.
        * @param aApp Application creating this document.
        * @return A pointer to the created instance of CCoverflowappDocument.
        */
        static CCoverflowAppDocument* NewLC( CEikApplication& aApp );

        /**
        * ~CCoverflowAppDocument
        * Virtual Destructor.
        */
        virtual ~CCoverflowAppDocument();

    public: // Functions from base classes

        /**
        * CreateAppUiL
        * From CEikDocument, CreateAppUiL.
        * Create a CCoverflowAppUi object and return a pointer to it.
        * The object returned is owned by the Uikon framework.
        * @return Pointer to created instance of AppUi.
        */
        CEikAppUi* CreateAppUiL();

    private: // Constructors

        /**
        * ConstructL
        * 2nd phase constructor.
        */
        void ConstructL();

        /**
        * CCoverflowAppDocument.
        * C++ default constructor.
        * @param aApp Application creating this document.
        */
        CCoverflowAppDocument( CEikApplication& aApp );

    };

#endif // __COVERFLOWAPPDOCUMENT_H__

// End of File

