// ticker.h
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of the CTicker class.
*/
#ifndef __TICKER_H__
#define __TICKER_H__

#include <e32std.h>
#include <e32base.h>
#include <w32std.h>
#include <gdi.h>
#include <e32math.h>

_LIT(KNews, "Nokia launches US Edition of Nokia N95. The new Nokia N95, optimized for use with North American HSDPA/3G networks with additional features including: A-GPS, 124MB RAM and a higher capacity battery.");
const TInt KFontHeight = 20;

/**
This class is used to display moving text on the screen.
It creates a window and a timer object to display the
moving text on the screen.
*/
class CTicker: public CBase
	{
public:
	static CTicker* NewL(const TRect&, const TDesC&);
	~CTicker();

	void Start();
	void Stop();

private:
	CTicker(const TRect&, const TDesC&);
	void ConstructL();
	static TInt OnTick(TAny*);
	TBool Draw();

private:
	/**
	The window server session.
	*/
	RWsSession iWs;
	/**
	The handle to the server-side window group.
	*/
	RWindowGroup iGrp;
	/**
	Handle to the window.
	*/
	RWindow iWin;
	/**
	The software device screen.
	*/
	CWsScreenDevice* iScr;
	/**
	The window graphics context.
	*/
	CWindowGc* iGc;
	/**
	Represents the area of the screen available for drawing.
	*/
	TRect iRect;
	/**
	The text is displayed in this font.
	*/
	CFont* iFont;
	/**
	The text is drawn from this point.
	*/
	TPoint iPos;
	/**
	Contains the text to be drawn.
	*/
	TPtrC iString;
	/**
	The text length in pixels.
	*/
	TInt iLen;
	/**
	The CPeriodic object that periodically redraws the text.
	*/
	CPeriodic* iTimer;
	};

#endif
