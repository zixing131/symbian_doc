/*
* ==============================================================================
*  Name        : Coverflowappappui.h
*  Part of     : Coverflowapp
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

#ifndef __COVERFLOWAPPUI_H__
#define __COVERFLOWAPPUI_H__

// INCLUDES
#include <aknappui.h>
#include "ticker.h"
#include "dialogbox.h"

// FORWARD DECLARATIONS
class CCoverflowAppView;
class CEGLRendering; 


// CLASS DECLARATION
/**
* CCoverflowAppUi application UI class.
* Interacts with the user through the UI and request message processing
* from the handler class
*/
class CCoverflowAppUi : public CAknAppUi
    {
    public: // Constructors and destructor

        /**
        * ConstructL.
        * 2nd phase constructor.
        */
        void ConstructL();

        /**
        * CCoverflowAppUi.
        * C++ default constructor. This needs to be public due to
        * the way the framework constructs the AppUi
        */
        CCoverflowAppUi();

        /**
        * ~CCoverflowAppUi.
        * Virtual Destructor.
        */
        virtual ~CCoverflowAppUi();

    private:  // Functions from base classes

        /**
        * From CEikAppUi, HandleCommandL.
        * Takes care of command handling.
        * @param aCommand Command to be handled.
        */
        //void HandleCommandL( TInt aCommand );
        virtual TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
        /**
        * HandleResourceChangeL()
        * Called by framework when layout is changed.
        * @param aType the type of resources that have changed
        */
        //void HandleResourceChangeL( TInt aType );

    private: // Data

        /**
        * The application view
        * Owned by CCoverflowAppUi
        */
        CCoverflowAppView* iAppView;
        
        /**
        An object to handle rendering of the EGL display.
        */
        CEGLRendering* iDemo;
        /**
        An object used to display a text message on the EGL surface.
        */
        CTicker* iTicker;
        /**
        A boolean value to indicate whether the
        CTicker::iTimer active object is active or not.
        */
        TBool iPlayingTicker;
        /**
        An object that shows the incoming call animation.
        */
        CDialogBox* iDialogBox;
        /**
        A boolean value to indicate whether the call window is displayed or not.
        */
        TBool iCallWindow;

    };

#endif // __COVERFLOWAPPUI_H__

// End of File

