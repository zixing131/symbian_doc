// openvgengine.cpp
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of member functions of the COpenVGEngine class.
*/
#include <eikenv.h>
#include "openvgengine.h"
#include "eglrendering.h"
#include <e32math.h>

/**
Calls the vguComputeWarpQuadToQuad() function.
@return VGU_NO_ERROR
*/
GLDEF_D VGUErrorCode vguComputeWarpQuadToQuadProxy(VGfloat aDx0, VGfloat aDy0,
                                                   VGfloat aDx1, VGfloat aDy1,
                                                   VGfloat aDx2, VGfloat aDy2,
                                                   VGfloat aDx3, VGfloat aDy3,
                                                   VGfloat aSx0, VGfloat aSy0,
                                                   VGfloat aSx1, VGfloat aSy1,
                                                   VGfloat aSx2, VGfloat aSy2,
                                                   VGfloat aSx3, VGfloat aSy3,
                                                   VGfloat* aMatrix)
	{
	// sets the entries of aMatrix to the projective transformation
	// This maps:
	// (aSx0,aSy0) to (aDx0,aDy0)
	// (aSx1,aSy1) to (aDx1,aDy1)
	// (aSx2,aSy2) to (aDx2,aDy2)
	// (aSx3,aSy3) to (aDx3,aDy3)
	vguComputeWarpQuadToQuad(
                                                   aSx0, aSy0,
                                                   aSx1, aSy1,
                                                   aSx2, aSy2,
                                                   aSx3, aSy3,
                                                   aDx0, aDy0,
                                                   aDx1, aDy1,
                                                   aDx2, aDy2,
                                                   aDx3, aDy3,
                                                   aMatrix);
	return VGU_NO_ERROR;
	}

/**
The two phase constructor of the COpenVGEngine class.
@param aWindowSize The window size.
@param aDisplayThe display on which the contents are drawn.
@param aSurface The EGL drawing surface.
@param aContext The rendering context.
@return A COpenVGEngine object.
*/
COpenVGEngine* COpenVGEngine::NewL(TSize aWindowSize,EGLDisplay& aDisplay, EGLSurface& aSurface, EGLContext& aContext)
	{
	COpenVGEngine* self = new(ELeave) COpenVGEngine(aWindowSize,aDisplay,aSurface,aContext);
	return self;
	}

/**
Destructor.
*/
COpenVGEngine::~COpenVGEngine()
	{
	Deactivate();
	}

/**
Gets the toggle speed of the cover.
@return The toggle speed of the cover.
*/
TInt COpenVGEngine::GetSpeed()
	{
	return static_cast<TInt>(iSpeed*100000);
	}

/**
Checks if a redraw event is pending on the window.
@return ETrue if a redraw event is pending, else EFalse.
*/
TBool COpenVGEngine::IsPending()
	{
	return iHasPendingDraw;
	}

/**
Activates the drawing surface.
*/
void COpenVGEngine::ActivateL()
	{
	// Setup initial OpenVG context state.
	VGfloat clearColour[] = { 0.1f, 0.1f, 0.2f, 1.0f };
	// Set the value of  VG_CLEAR_COLOR to clearcolour.
	vgSetfv(VG_CLEAR_COLOR, 4, clearColour);
	// Set the image quality mode setting to VG_IMAGE_QUALITY_NONANTIALIASED.
	vgSeti(VG_IMAGE_QUALITY, VG_IMAGE_QUALITY_NONANTIALIASED);
	// Set the rendering quality mode setting to VG_RENDERING_QUALITY_NONANTIALIASED.
	vgSeti(VG_RENDERING_QUALITY, VG_RENDERING_QUALITY_NONANTIALIASED);
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_IMAGE_USER_TO_SURFACE);

	//Load and create the VGImage.
#ifdef __WINS__
	_LIT(KCoverBitmaps,"z:\\resource\\apps\\covers.mbm");
#else
	_LIT(KCoverBitmaps,"e:\\resource\\apps\\covers.mbm");
#endif
	// Create a bitmap image.
	// This is used to load all bitmap images to display them on the screen.
	CFbsBitmap* bitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(bitmap);
	TInt i = 0;
	// Load cover images.
	while(bitmap->Load(KCoverBitmaps,i++) == KErrNone)
		{
		TSize coverSize = bitmap->SizeInPixels();

		// Set the pixel format and colour to  VG_sRGB_565.s
		VGImageFormat dataFormat = VG_sRGB_565;
		VGint width = coverSize.iWidth;
		VGint height = coverSize.iHeight;
		// Get the amount of bytes per scanline.
		VGint dataStride = bitmap->ScanLineLength(coverSize.iWidth,bitmap->DisplayMode());

		// Create the VGImage.
		VGImage image = vgCreateImage(dataFormat, width, height,VG_IMAGE_QUALITY_NONANTIALIASED);
		CEGLRendering::VGCheckError();

		// Load Symbian bitmap into VGImage.
		vgImageSubData (image, bitmap->DataAddress(), dataStride, dataFormat, 0, 0, width, height );
		CEGLRendering::VGCheckError();

		// Add the image to the iImages array.
		iImages.AppendL(image);
		iHasPendingDraw = ETrue;
		}

	CleanupStack::Pop(bitmap);
	delete bitmap;

	// Check if no image is loaded.
	if(iImages.Count() == 0)
		{
		User::Leave(KErrNotFound);
		}

	iImage = iImages[0];

	// Create a new paint object.
	iShadowPaint = vgCreatePaint();
	if (iShadowPaint != VG_INVALID_HANDLE)
		{
		VGfloat paintColour[4] = { 0.4f, 0.4f, 0.6f, 1.0f };
		// Passing paintColour to the paint object.
		vgSetParameterfv(iShadowPaint, VG_PAINT_COLOR, 4, paintColour);
		CEGLRendering::VGCheckError();
		}
	}

/**
Deactivates the drawing surface.
*/
void COpenVGEngine::Deactivate()
	{
	TInt coverIndex=iImages.Count()-1;
	for (;coverIndex>=0;coverIndex--)
		{
		// De allocate the resources of all images in the iImages array.
		vgDestroyImage(iImages[coverIndex]);
		}

	// Destroy the paint object.
	vgDestroyPaint(iShadowPaint);
	eglWaitClient();

	// Reset the RArray.
	iImages.Reset();
	iHasPendingDraw = EFalse;
	}

/**
Updates the contents of the surface.
*/
void COpenVGEngine::Step()
	{
#ifdef PORTRAIT_MODE
	vgClear(0, 0, iSurfaceSize.iHeight, iSurfaceSize.iWidth);
#else
	vgClear(0, 0, iSurfaceSize.iWidth, iSurfaceSize.iHeight);
#endif
	// Calculate the speed of movement of the cover
	// depending on its current location.
	if (Abs(iCoverLocation[iWantedCover]) < 0.03)
		{
		iSpeed = 0.0f;
		iHasPendingDraw = EFalse;
		}
	else if (Abs(iCoverLocation[iWantedCover]) < 0.5)
		{
		iSpeed*=0.7;
		}
	else
		{
		iSpeed = 0.05*(2+ Abs(iCoverLocation[iWantedCover]) + (Abs(iCoverLocation[iWantedCover])+1) * (Abs(iCoverLocation[iWantedCover])+1) / 2);
		}
	// For each Cover, update its location in the correct direction.
	// Check if the wanted cover is already at the CenterStage point.
	VGfloat moveEachCover = iSpeed;
	if (iCoverLocation[iWantedCover] > 0.0)
		{
		moveEachCover *= -1;
		}

	TInt coverIndex;
	// Update the location of each cover.
	for (coverIndex = 0; coverIndex < KMaxCoversExample3; ++coverIndex)
		{
		iCoverLocation[coverIndex] += moveEachCover;
		}

	TInt coverClippingCount = 10;
	TInt middleCoverPos=0;
	VGfloat threshold = 0.50f;

	while(Abs(iCoverLocation[middleCoverPos])>threshold)
		{
		++middleCoverPos;
		}


	//left.
	TInt cutOff = middleCoverPos-coverClippingCount;
	if (cutOff<0)
		{
		cutOff=0;
		}
	for (TInt i=cutOff; i<middleCoverPos;i++)
		{
		DrawCover(i);
		}

	//right.
	cutOff = coverClippingCount + middleCoverPos;
	if (cutOff>=KMaxCoversExample3)
		{
		cutOff=KMaxCoversExample3-1;
		}

	for (TInt j = cutOff; j>=middleCoverPos ; --j)
		{
		DrawCover(j);
		}

#ifdef ENABLE_LOOP
	static TInt dir = 1;
	if (iWantedCover == (KMaxCoversExample3-1))
		{
		dir = -1;
		}
	else if (iWantedCover == 0)
		{
		dir = 1;
		}

	iWantedCover += dir;
	iHasPendingDraw = ETrue;
#endif
	}

/**
Draws a cover on the surface.
*/
void COpenVGEngine::DrawCover(TInt aCoverIndex)
	{
	VGImage image = iImages[aCoverIndex%iImages.Count()];
	// Starting at the outside, render each visible (+/-  KMaxDisplayCoversExample3/2) Cover.
	// Calculate its path.

	// Set the current matrix to the identity matrix.
	vgLoadIdentity();

#ifdef PORTRAIT_MODE
	vgTranslate(iSurfaceSize.iHeight, 0);
	vgRotate(90);
#endif

	VGfloat coverPosition = iCoverLocation[aCoverIndex];

	VGfloat tempMatrix[3][3];
	//flip coordinates.
	VGfloat flipmatrix[] =
		{
		1.0f, 0.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, 0.0f, 1.0f
		};
	vgMultMatrix(flipmatrix);

	VGint imageWidth = vgGetParameteri (image, VG_IMAGE_WIDTH);
	VGint imageHeight = vgGetParameteri (image, VG_IMAGE_HEIGHT);

	VGint yTrans = -200;

	// Factors which must be multiplied with side of image which will be projected towards back.
	// Valid if projecting right image side to back.
	// Opposite is (1 - factor) for projecting left image side.

	VGfloat bottomProjectXFactor= (0.75f);
	VGfloat bottomProjectYFactor = (0.20f);

	VGfloat topProjectXFactor = (0.75f);
	VGfloat topProjectYFactor = (0.90f);

	VGfloat imageSpacingFactor = 0.16;

	VGfloat translationOffset = 0.0;

	VGfloat middleTranslationOffset = KImageSize /2;
	VGfloat coverProjectionLimit = 10;

	if (coverPosition>=1)
		{
		// If considering an image on the right side, this is offset from middle to place image on screen.
		translationOffset = middleTranslationOffset- KImageSize/2 + KImageSize*imageSpacingFactor * (coverPosition -1);

		// Left side of image goes back.
		vguComputeWarpQuadToQuadProxy(  0.0f, 0.0f,
				   imageWidth, 0.0f,
				   0.0f, imageHeight,
				   imageWidth, imageHeight,

				   KImageSize * (1 - bottomProjectXFactor*(1-Abs(coverPosition)/coverProjectionLimit)),KImageSize * bottomProjectYFactor,// left vertex.
				   KImageSize, 0.0f,
				   KImageSize * (1 - topProjectXFactor*(1-Abs(coverPosition)/coverProjectionLimit)), KImageSize * topProjectYFactor,// left vertex.
				   KImageSize, KImageSize,

				   &tempMatrix[0][0]);
		}
	else if (coverPosition<-1)
		{
		// Must move an extra image width from centre , as coordinates from bottom left corner of image.
		translationOffset = - (middleTranslationOffset + (KImageSize * imageSpacingFactor) * ( -coverPosition - 1) + KImageSize/2) ;

		vguComputeWarpQuadToQuadProxy(  0.0f, 0.0f,
				   imageWidth, 0.0f,
				   0.0f, imageHeight,
				   imageWidth, imageHeight,

				   0.0f, 0.0f,
				   (bottomProjectXFactor*(1-Abs(coverPosition)/coverProjectionLimit))* KImageSize, bottomProjectYFactor * KImageSize, //Right Vertex.
				   0.0f, (KImageSize),
				   (topProjectXFactor*(1-Abs(coverPosition)/coverProjectionLimit)) * KImageSize, topProjectYFactor * KImageSize, //Right Vertex

				   &tempMatrix[0][0]);
		}
	else if((coverPosition > -1) && (coverPosition <= 0))// -0.07))
		{
		translationOffset = -middleTranslationOffset * Abs(coverPosition) - KImageSize/2 ;

		vguComputeWarpQuadToQuadProxy(  0.0f, 0.0f,
							   imageWidth, 0.0f,
							   0.0f, imageHeight,
							   imageWidth, imageHeight,

							   0.0f, 0.0f,
							   KImageSize * (1 - (1-bottomProjectXFactor) * Abs(coverPosition)), KImageSize * bottomProjectYFactor * Abs(coverPosition),
							   0.0f, KImageSize,
							   (KImageSize * (1 - ( 1 - topProjectXFactor) * Abs(coverPosition))) , KImageSize * (1 - (1 - topProjectYFactor) * Abs(coverPosition)),

							   &tempMatrix[0][0]);

		}

	else if ((coverPosition >=0) && (coverPosition <= 1))
		{

		translationOffset = middleTranslationOffset * Abs(coverPosition) - KImageSize/2 ;

		vguComputeWarpQuadToQuadProxy( 0.0f, 0.0f,
							   imageWidth, 0.0f,
							   0.0f, imageHeight,
							   imageWidth, imageHeight,

							   KImageSize * (1-bottomProjectXFactor)* (coverPosition), KImageSize * (bottomProjectYFactor) * (coverPosition),
							   KImageSize, 0,
							   KImageSize * ( 1 - topProjectXFactor) * (coverPosition) , KImageSize * (1 - (1 - topProjectYFactor) * Abs(coverPosition)),
							   KImageSize, KImageSize,

							   &tempMatrix[0][0]);
		}


	iSpeedOffset = 140*(iSpeed)*(iSpeed);

			if (iCoverLocation[iWantedCover]<0)
				{
				iSpeedOffset *=-1;
				}

	// Apply transformations to the current matrix.
	vgTranslate(iSurfaceSize.iWidth/2 + translationOffset + iSpeedOffset,yTrans);

	vgMultMatrix(&tempMatrix[0][0]);
	if (Abs(coverPosition)<=1)
		{
		VGfloat scale = GetMiddleCoverScalingFactor(coverPosition);
		vgScale(scale,scale);

		vgTranslate(-(scale-1)/2 * KImageSize,-(scale-1)/2 * KImageSize);
		}

	// Draw the image on the surface.
	vgDrawImage(image);
	CEGLRendering::VGCheckError();

	// Check if mirror images of covers have to be displayed.
	if(iShowMirror)
		{
		// Scale the current matrix to create inverted images.
		vgScale(1,-1);
		vgSeti(VG_IMAGE_MODE, VG_DRAW_IMAGE_MULTIPLY);
		vgTranslate(0,-4*KImageSize+226);

		// Draw the image on the surface.
		vgSetPaint(iShadowPaint, VG_FILL_PATH);
		vgDrawImage(image);
		CEGLRendering::VGCheckError();

		vgSeti(VG_IMAGE_MODE,VG_DRAW_IMAGE_NORMAL);
		}
	}

/**
Handles key events.
@param aKeyEvent The key event details.
*/
TKeyResponse COpenVGEngine::HandleKeyEventL(const TKeyEvent& aKeyEvent)
	{
	TKeyResponse response = EKeyWasConsumed;
	switch (aKeyEvent.iCode)
		{
	case EKeyRightArrow:
	// Move to the next cover if right arrow key is pressed.
		NextCover();
		break;

	case EKeyLeftArrow:
	// Move to the previous cover if left arrow key is pressed.
	PreviousCover();
		break;

	case EKeyBackspace:
	// Toggle the cover reflection flag.
		ToggleCoverReflection();
		break;
	default:
		response = EKeyWasNotConsumed;
		break;
		};
	return response;
	}

/**
Constructor
*/
COpenVGEngine::COpenVGEngine(TSize aWindowSize,EGLDisplay& aDisplay, EGLSurface& aSurface, EGLContext& aContext) :
	iDisplay(aDisplay),iSurface(aSurface),iContext(aContext),iWantedCover(20),iHasPendingDraw(EFalse),
	iShowMirror(ETrue)
	{
#ifdef PORTRAIT_MODE
	iSurfaceSize.iWidth = aWindowSize.iHeight;
	iSurfaceSize.iHeight = aWindowSize.iWidth;
#else
	iSurfaceSize = aWindowSize;
#endif
	// Initiate the location of each cover & make the wanted one the cover at the opposite end
	for(TInt i=0; i<KMaxCoversExample3; ++i)
		{
		iCoverLocation[i] = i;
		}
	}

/**
Gets the cover next to the middle cover.
*/
void COpenVGEngine::NextCover()
	{
	if (iWantedCover < (KMaxCoversExample3-1))
		{
		++iWantedCover;
		}
	iHasPendingDraw = ETrue;
	}

/**
Gets the cover previous to the middle cover.
*/
void COpenVGEngine::PreviousCover()
	{

	if (iWantedCover>0)
		{
		--iWantedCover;
		}
	iHasPendingDraw = ETrue;
	}

/**
Changes the iShowMirror flag.
This flag indicates if the reflection of the images is to be drawn on the surface.
*/
void COpenVGEngine::ToggleCoverReflection()
	{
	iShowMirror = !iShowMirror;
	}

/**
Gets the scaling factor for the middle cover.
@param aCoverPosition The location of the middle cover.
@return The scaling factor for the middle cover.
*/
VGfloat COpenVGEngine::GetMiddleCoverScalingFactor(VGfloat aCoverPosition)
	{
	if(Abs(aCoverPosition)>1)
		{
		return 0.0f;
		}

	return (-0.125 * Abs(aCoverPosition) + 1.125);
	}
