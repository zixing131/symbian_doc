/*
* ==============================================================================
*  Name        : Coverflowapplication.cpp
*  Part of     : CoverflowApp
*  Interface   : 
*  Description : 
*  Version     : 
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation.
* ==============================================================================
*/

// INCLUDE FILES
#include "CoverflowAppDocument.h"
#include "CoverflowApplication.h"

// ============================ MEMBER FUNCTIONS ===============================

// UID for the application;
// this should correspond to the uid defined in the mmp file
const TUid KUidCoverflowApp = { 0xA000017F };

// -----------------------------------------------------------------------------
// CCoverflowApplication::CreateDocumentL()
// Creates CApaDocument object
// -----------------------------------------------------------------------------
//
CApaDocument* CCoverflowApplication::CreateDocumentL()
    {
    // Create an CoverflowApp document, and return a pointer to it
    return (static_cast<CApaDocument*>
                    ( CCoverflowAppDocument::NewL( *this ) ) );
    }

// -----------------------------------------------------------------------------
// CCoverflowApplication::AppDllUid()
// Returns application UID
// -----------------------------------------------------------------------------
//
TUid CCoverflowApplication::AppDllUid() const
    {
    // Return the UID for the CoverflowApp application
    return KUidCoverflowApp;
    }

// End of File

