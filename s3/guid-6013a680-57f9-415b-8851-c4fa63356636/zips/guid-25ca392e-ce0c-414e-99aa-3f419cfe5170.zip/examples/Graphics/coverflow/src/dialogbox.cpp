// dialogbox.cpp
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file 
This example program shows the incoming call animation.
*/

#include "dialogbox.h"

/**
Constructor.
*/
CDialogBox::CDialogBox(const TRect& aRect):
	iRect(aRect)
	{
	}

/**
Performs the two-phase construction of an object of the CDialogBox class.
@param aRect The area of the screen available for drawing.
@return A CDialogBox object.
*/
CDialogBox* CDialogBox::NewL(const TRect& aRect)
	{
	CDialogBox* self = new(ELeave) CDialogBox(aRect);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Constructs the CDialogBox object.
*/
void CDialogBox::ConstructL()
	{
	// Connects the client session to the window server.
	User::LeaveIfError(iWs.Connect());
	
	// Constructs a new screen device attached to a particular window server session.
	iScr = new(ELeave) CWsScreenDevice(iWs);
	User::LeaveIfError(iScr->Construct());
	
	// Constructs a graphics context.
	iGc = new(ELeave) CWindowGc(iScr);
	User::LeaveIfError(iGc->Construct());
	
	// Creates a sessionless, uninitialised window group handle.
	iGrp = RWindowGroup(iWs);
	User::LeaveIfError(iGrp.Construct(0xdeadface, EFalse));
	iGrp.SetOrdinalPositionErr(0, 100);
	
	// Creates a sessionless, uninitialised window handle.
	iWin = RWindow(iWs);
	User::LeaveIfError(iWin.Construct(iGrp, (TInt)this));
	
	// Sets the window to be transparent using the alpha channel.
	iWin.SetTransparencyAlphaChannel();
	
	// Sets the background colour used for clearing in server-initiated redraws.
	iWin.SetBackgroundColor(TRgb(0,0,0,0));
	
	// Sets the size and position of a window.
	iWin.SetExtent(iRect.iTl, iRect.Size());
	
	// Displays the window and enables it to receive events.
	iWin.Activate();
	
	// Sets the ordinal position of a window.
	iWin.SetOrdinalPosition(-1);
	
	// Sets the window's visibility.
	iWin.SetVisible(EFalse);
	
	// Sends all pending commands in the buffer to the window server.
	iWs.Flush();
	
	// Allocates and constructs a CPeriodic object. Assign a priority to it.
	iTimer = CPeriodic::NewL(CActive::EPriorityStandard);
	
	// Appends CLoader objects in to the array.
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps1));
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps2));
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps3));
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps4));
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps5));
	iLoaders.AppendL(CLoader::NewL(KCallBitmaps6));

	for (TInt ii=0; ii < 6; ii++)
		{
		iLoaders[ii]->Decode();
		iCallBuffer.AppendL(iLoaders[ii]->iBitmap);
		iCallBuffer.AppendL(iLoaders[ii]->iMask);
		}

	iImageCounter = 0;
	iSemiTransFlag = EFalse;

	}
	
/**
Destructor.
*/
CDialogBox::~CDialogBox()
	{
	Stop();
	delete iTimer;
	
	iCallBuffer.ResetAndDestroy();
	iLoaders.ResetAndDestroy();

	delete iGc;
	delete iScr;
	
	// Close the nodes.
	iWin.Close();
	iGrp.Close();
	iWs.Close();
	}
	
/**
Starts showing the incoming call animation.
*/
void CDialogBox::Start()
	{
	// Sets the window's visibility.
	iWin.SetVisible(ETrue);
	if (!iTimer->IsActive())
		{
		// Starts generating periodic events. Pass the OnTick() function to call when the CPeriodic is scheduled after a timer event.
		iTimer->Start(0, 150*1000, TCallBack(CDialogBox::OnTick, this));
		}
	}
	
/**
Stops showing the incoming call animation.
*/
void CDialogBox::Stop()
	{
	// Sets the window's visibility.
	iWin.SetVisible(EFalse);
	
	// Sends all pending commands in the buffer to the window server.
	iWs.Flush();
	
	// Cancels the wait for completion of an outstanding request.
	iTimer->Cancel();
	}
	
/**
The callback function for the CDialogBox::iTimer object.
*/
TInt CDialogBox::OnTick(TAny* aArg)
	{
	CDialogBox* self = (CDialogBox*)aArg;
	
	// Invalidates the entire window.
	self->iWin.Invalidate();
	
	// Begins redrawing the window's invalid region
	self->iWin.BeginRedraw();
	
	// Activates the context for a given window 
	self->iGc->Activate(self->iWin);
	self->Draw();
	
	// Frees the graphics context to be used with another window.
	self->iGc->Deactivate();
	
	// Ends the current redraw.
	self->iWin.EndRedraw();
	
	// Sends all pending commands in the buffer to the window server.
	self->iWs.Flush();

	return 0;
	}
	
/**
Draws the control on the screen.
*/
TBool CDialogBox::Draw()
	{
	if(iImageCounter == 12)
		iImageCounter = 0;
	iCallFrame = iCallBuffer[iImageCounter++];
	iCallMaskFrame = iCallBuffer[iImageCounter++];
	
	// Performs a masked bitmap block transfer of a memory resident source bitmap.
	iGc->BitBltMasked(TPoint(10,10), iCallFrame, iCallFrame->SizeInPixels(), iCallMaskFrame, EFalse);

	return EFalse;
	}
/**
Sets the background colour.
*/
void CDialogBox::SetSemiTransparency()
	{
	iWin.SetBackgroundColor(TRgb(24,255,0,128));
	iSemiTransFlag = ETrue;
	}
	
/**
Removes the background colour.
*/
void CDialogBox::RemoveSemiTransparency()
	{
	iWin.SetBackgroundColor(TRgb(0,0,0,0));
	iSemiTransFlag = EFalse;
	}

/**
CLoader starts.
*/
CLoader* CLoader::NewL(const TDesC& aFn)
	{
	CLoader* self = new(ELeave) CLoader;
	CleanupStack::PushL(self);
	self->ConstructL(aFn);
	CleanupStack::Pop();
	return self;
	}
	
/**
Constructor.
*/
void CLoader::ConstructL(const TDesC& aFn)
	{
	iBitmap = new(ELeave) CFbsBitmap;
	User::LeaveIfError(iBitmap->Load(aFn, 0));

	iMask = new(ELeave) CFbsBitmap;
	User::LeaveIfError(iMask->Load(aFn, 1));

#ifdef PORTRAIT_MODE
	RotateL(*iBitmap);
	RotateL(*iMask);
#endif
	}

CLoader::CLoader()
	{
	}

/**
Destructor.
*/
CLoader::~CLoader()
	{
	// no need to destroy bitmaps because caller take ownership of them
	}

void CLoader::Decode()
	{
	}

#ifdef PORTRAIT_MODE

/**
Rotates the bitmap.
*/
void CLoader::RotateL(CFbsBitmap& aBitmap)
	{
	CFbsBitmap* tmp = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(tmp);
	
	// Gets the pixel-size of the bitmap. 
	const TSize bSz = aBitmap.SizeInPixels();
	
	// Gets the display mode of the bitmap. 
	const TDisplayMode bMode = aBitmap.DisplayMode();
	const TSize tSz(bSz.iHeight, bSz.iWidth);
	
	// Creates a bitmap with the specified size and display mode
	User::LeaveIfError(tmp->Create(tSz, bMode));
	
	// Gets the address of the first pixel in the bitmap
	TUint8* pTmp = (TUint8*)tmp->DataAddress();

	TInt y = tSz.iHeight - 1;
	TInt scanLineLength = tmp->ScanLineLength(tSz.iWidth,bMode);
	for (TInt x=0; x<bSz.iWidth; ++x)
		{
		TPtr8 buf(pTmp + (y * scanLineLength), scanLineLength);
		
		// Gets the bitmap's vertical scanline starting at the specified x co-ordinate.
		aBitmap.GetVerticalScanLine(buf, x, bMode);

		--y;
		}

	// Swaps the bitmap's width and height.
	User::LeaveIfError(aBitmap.SwapWidthAndHeight());
	Mem::Move(aBitmap.DataAddress(), tmp->DataAddress(), scanLineLength * tSz.iHeight);

	CleanupStack::PopAndDestroy(tmp);
	}

#endif
