/*
* ==============================================================================
*  Name        : Coverflowappview.cpp
*  Part of     : CoverflowApp
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

// INCLUDE FILES
#include <coemain.h>
#include <aknutils.h>
#include "CoverflowAppView.h"

// -----------------------------------------------------------------------------
// CCoverflowAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CCoverflowAppView::ConstructL( const TRect& aRect )
    {
    CreateWindowL();
    EnableDragEvents();
    SetExtentToWholeScreen();
    //Window().SetBackgroundColor();
    }

// -----------------------------------------------------------------------------
// CCoverflowAppView::CCoverflowAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CCoverflowAppView::CCoverflowAppView(CCoverflowAppUi& aAppUi):
CCoeControl(),
iAppUi(aAppUi)
    {
    // No implementation required
    }


// -----------------------------------------------------------------------------
// CCoverflowAppView::~CCoverflowAppView()
// Destructor.
// -----------------------------------------------------------------------------
//
CCoverflowAppView::~CCoverflowAppView()
    {
    // No implementation required
    }

// End of File

