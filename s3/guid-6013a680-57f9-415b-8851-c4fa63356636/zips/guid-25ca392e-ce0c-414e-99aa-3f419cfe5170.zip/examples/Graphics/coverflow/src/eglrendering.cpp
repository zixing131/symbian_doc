// eglrendering.cpp
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file
Contains the definition of member functions of the CEGLRendering class
*/
#include <eikenv.h>
//#include <techview/eiklbx.h>
#include <string.h>
#include "eglrendering.h"
#include "engine.h"
#include "openvgengine.h"
#include <hal.h>

/**
Attributes to be passed into eglChooseConfig .
*/
const EGLint	KColorRGB565AttribList[] =
		{
		EGL_RED_SIZE,			5,
		EGL_GREEN_SIZE,			6,
		EGL_BLUE_SIZE,			5,
		EGL_SURFACE_TYPE,		EGL_WINDOW_BIT,
		EGL_RENDERABLE_TYPE, 	EGL_OPENVG_BIT,
		EGL_NONE
		};

/**
Performs the two-phase construction of an object of the CEGLRendering class.
@param aWindow A handle to the active window.
@return A CEGLRendering object.
*/
CEGLRendering* CEGLRendering::NewL(RWindow& aWindow)
	{
	CEGLRendering* self = CEGLRendering::NewLC(aWindow);
	CleanupStack::Pop(self);
	return self;
	}

/**
Performs the two-phase construction of an object of the CEGLRendering class.
@param aWindow A handle to the active window.
@return A CEGLRendering object.
*/
CEGLRendering* CEGLRendering::NewLC(RWindow& aWindow)
	{
	CEGLRendering* self = new(ELeave) CEGLRendering(aWindow);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

/**
Destructor.
*/
CEGLRendering::~CEGLRendering()
	{
	// Stop the timer object.
	Stop();
	delete iTimer;

	if(iCurrentDemo)
		{
		// Deactivate the active drawing surface.
		iCurrentDemo->Deactivate();
		}
	delete iCurrentDemo;

	if (iContextVG!=EGL_NO_CONTEXT)
		{
		EGLCheckReturnError(eglDestroyContext(iDisplay,iContextVG));
		}

	if (iSurface!=EGL_NO_SURFACE)
		{
		EGLCheckReturnError(eglDestroySurface(iDisplay,iSurface));
		}

	EGLCheckReturnError(eglTerminate(iDisplay));
	EGLCheckReturnError(eglReleaseThread());

	delete iBitmap;
	}

/**
Starts the timer object.
*/
void CEGLRendering::Start()
	{
	// Start drawing the screen periodically
	iTimer->Start(0, KTimerDelay, TCallBack(TimerCallBack,this));
	}

/**
Stops the timer object.
*/
void CEGLRendering::Stop()
	{
	if(iTimer)
		{
		iTimer->Cancel();
		}
	}

/**
Checks for any egl errors.
*/
void CEGLRendering::EGLCheckError()
	{
	EGLint error = eglGetError();
	if(error != EGL_SUCCESS)
		{
		User::Panic(_L("EGL error"), error);
		}
	}

/**
Checks for any vg errors.
*/
void CEGLRendering::VGCheckError()
	{
	VGint error = vgGetError();
	if(error != VG_NO_ERROR)
		{
		User::Panic(_L("OpenVG error"), error);
		}
	}

/**
Checks for any egl errors.
@param aBool Indicates an error if true.
*/
void CEGLRendering::EGLCheckReturnError(EGLBoolean aBool)
	{
	if (!aBool)
		{
		User::Panic(_L("EGL return error"),eglGetError());
 		}
	}

/**
Constructor
@param aWindow Handle to the active window.
*/
CEGLRendering::CEGLRendering(RWindow& aWindow)
	: iWindow(aWindow)
	{
	}

/**
Handles key events.
@param aKeyEvent The key event details.
@return Indicates whether or not the key event was consumed.
*/
TKeyResponse CEGLRendering::HandleKeyEventL(const TKeyEvent& aKeyEvent)
	{
	TKeyResponse response = EKeyWasConsumed;
	switch (aKeyEvent.iCode)
		{
	case EKeySpace:
	// Handle the space bar key press event.
	// Stop the timer if it is active.
	// Start the timer if it is not active.
		iTimer->IsActive()? Stop() : Start();
		break;
	// Do nothing for tab, up arrow and down arrow key press events.
	case EKeyTab:
		break;
	case EKeyUpArrow:
		break;
	case EKeyDownArrow:
		break;
	case EKeyBackspace:
	// Stop displaying mirror images of the cover if backspace key is pressed.
		iShowMirrorToggled = ETrue;
	default:
		response = iCurrentDemo->HandleKeyEventL(aKeyEvent);
		break;
		};
	return response;
	}

/**
Constructs the CEGLRendering object.
*/
void CEGLRendering::ConstructL()
    {
	// Refresh the timer.
	iTimer = CPeriodic::NewL(CActive::EPriorityIdle);

	const TSize windowSize(iWindow.Size());

	// Create the display object.
	iDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	EGLCheckError();

	// Initialise the display object.
	EGLint iMajor, iMinor;
	// initialise the EGL display connection.
	EGLCheckReturnError(eglInitialize(iDisplay, &iMajor, &iMinor));
	RDebug::Printf("Vendor string %s", eglQueryString(iDisplay, EGL_VENDOR));
	RDebug::Printf("Version string %s", eglQueryString(iDisplay, EGL_VERSION));

	if ( NULL == strstr(eglQueryString(iDisplay, EGL_CLIENT_APIS), "OpenVG") )
		{
		RDebug::Printf("OpenVG not listed in supported client APIs %s", eglQueryString(iDisplay, EGL_CLIENT_APIS));
		}
	if ( NULL == strstr(eglQueryString(iDisplay, EGL_EXTENSIONS), "EGL_SYMBIAN_COMPOSITION") )
		{
		CEikonEnv::Static()->InfoMsg(_L("Graphics Composition is not supported in this SymbianOS version"));
		RDebug::Printf("EGL_SYMBIAN_COMPOSITION not listed in extension string %s", eglQueryString(iDisplay, EGL_EXTENSIONS));
		User::Leave(KErrNotSupported);
		}

	// Query the available number of configurations .
	EGLint numConfigs;
	// Get a list of all EGL frame buffer configurations for iDisplay.
	EGLCheckReturnError(eglGetConfigs(iDisplay, iConfig, KMaxConfigs, &numConfigs));

	// Choose the configuration to use
	EGLCheckReturnError(eglChooseConfig(iDisplay, KColorRGB565AttribList, iConfig, 1, &numConfigs));
	EGLCheckReturnError(eglBindAPI(EGL_OPENVG_API));

	// Create window surface to draw direct to.
	// Contents drawn on the iSurface will be directed to iWindow.
	iSurface = eglCreateWindowSurface(iDisplay, iConfig[0], &iWindow, NULL);
	EGLCheckError();

	TInt redSize, greenSize, blueSize, alphaSize;
	// Gets the information about the number of bits of alpha stored in the colour buffer.
	EGLCheckReturnError(eglGetConfigAttrib(iDisplay, iConfig[0], EGL_ALPHA_SIZE, &alphaSize));
	EGLCheckReturnError(eglGetConfigAttrib(iDisplay, iConfig[0], EGL_RED_SIZE, &redSize));
	EGLCheckReturnError(eglGetConfigAttrib(iDisplay, iConfig[0], EGL_GREEN_SIZE, &greenSize));
	EGLCheckReturnError(eglGetConfigAttrib(iDisplay, iConfig[0], EGL_BLUE_SIZE, &blueSize));
	RDebug::Print(_L("EGLConfig id:%d alpha:%d red:%d green:%d blue:%d"), iConfig[0],
			alphaSize, redSize, greenSize, blueSize);

	// Create context to store surface settings
	iContextVG = eglCreateContext(iDisplay, iConfig[0], NULL, NULL);
	EGLCheckError();

	CEGLRendering::EGLCheckReturnError(eglMakeCurrent(iDisplay, iSurface, iSurface, iContextVG));
	iCurrentDemo = COpenVGEngine::NewL(windowSize,iDisplay,iSurface,iContextVG);
	iCurrentDemo->ActivateL();

	User::LeaveIfError(HAL::Get(HAL::EFastCounterFrequency, iFastCounterFrequency));
	}


/**
Updates the display .
*/
void CEGLRendering::UpdateDisplay()
	{
	// Guard against unexpected re-entrant problem.
	if (iBusySwapping)
		{
		return;
		}

	if (iCurrentDemo->IsPending() || (!iCurrentDemo->IsPending() && iShowMirrorToggled))
		{
		iShowMirrorToggled = EFalse;

		// Updates the contents of the iDisplay.
		iCurrentDemo->Step();
		iBusySwapping = ETrue;

		// Flush colour buffer to the window surface.
		CEGLRendering::EGLCheckReturnError(eglSwapBuffers(iDisplay, iSurface));
		iBusySwapping = EFalse;

		TUint currentTimeStamp = User::FastCounter();
		TReal delta = currentTimeStamp - iLastFrameTimeStamp;

		TReal measuredFrameRate = static_cast<TReal>(iFastCounterFrequency/delta);

		iLastFrameTimeStamp = currentTimeStamp;
		RDebug::Printf("[Timestamp: %d FrameRate: %f]", iLastFrameTimeStamp, measuredFrameRate);
		}
	}

/**
Callback called by refresh timer.
@param aDemo The pointer to the argument of the callback function.
@return KErrNone.
*/
TInt CEGLRendering::TimerCallBack(TAny* aDemo)
	{
	static_cast<CEGLRendering*>(aDemo)->UpdateDisplay();
	return KErrNone;
	}
