// ticker.cpp
//
// Copyright (c) 2005-2008 Symbian Ltd.  All rights reserved.
//
/**
@file 
This example program constructs, starts and stops a ticker playback.
*/

#include "ticker.h"
#include <openfont.h>

/**
Constructor.
*/
CTicker::CTicker(const TRect& aRect, const TDesC& aString):
	iRect(aRect),
	iString(aString)
	{
#ifdef PORTRAIT_MODE
	iPos = TPoint(KFontHeight, 0);
#else
	iPos = TPoint(aRect.iBr.iX, KFontHeight);
#endif
	}

/**
Performs the two-phase construction of an object of the CTicker class.
@param aRect The area of the screen available for drawing.
@param aString The text to be drawn.
@return A CTicker object.
*/
CTicker* CTicker::NewL(const TRect& aRect, const TDesC& aString)
	{
	CTicker* self = new(ELeave) CTicker(aRect, aString);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Constructs the CTicker object.
*/
void CTicker::ConstructL()
	{
	// Connects the client session to the window server.
	User::LeaveIfError(iWs.Connect());
	
	// Constructs a new screen device attached to a particular window server session.
	iScr = new(ELeave) CWsScreenDevice(iWs);
	User::LeaveIfError(iScr->Construct());
	
	// Constructs a graphics context.
	iGc = new(ELeave) CWindowGc(iScr);
	User::LeaveIfError(iGc->Construct());

	// Creates a sessionless, uninitialised window group handle.
	iGrp = RWindowGroup(iWs);
	User::LeaveIfError(iGrp.Construct(0xdeadface, EFalse));
	iGrp.SetOrdinalPositionErr(0, 100);
	
	// Creates a sessionless, uninitialised window handle.
	iWin = RWindow(iWs);
	User::LeaveIfError(iWin.Construct(iGrp, (TInt)this));
	
	// Sets the window to be transparent using the alpha channel.
	iWin.SetTransparencyAlphaChannel();
	
	// Sets the background colour used for clearing in server-initiated redraws.
	iWin.SetBackgroundColor(TRgb(0,0,0,0));
	
	// Sets the size and position of a window.
	iWin.SetExtent(iRect.iTl, iRect.Size());
	
	// Displays the window and enables it to receive events.
	iWin.Activate();
	
	// Sets the ordinal position of a window.
	iWin.SetOrdinalPosition(-1);
	
	// Sets the window's visibility.
	iWin.SetVisible(EFalse);
	
	// Sends all pending commands in the buffer to the window server.
	iWs.Flush();
	
	// Specify the font specification that allows more attributes than TOpenFontSpec.
	TOpenFontSpec openSpec;
	
	// Sets whether the font should be drawn using anti-aliasing
    openSpec.SetBitmapType(EAntiAliasedGlyphBitmap);
    
    // Specify the font specification
	TFontSpec fs;
	
	// Gets the TFontSpec corresponding to this Open Font System font specification.
    openSpec.GetTFontSpec(fs);
    
    // Assign the font specification
    fs.iTypeface.iName = _L("SwissA");
    fs.iHeight = KFontHeight;

	// Gets the font which is the nearest to the given font specification.
	User::LeaveIfError(iScr->GetNearestFontInPixels(iFont, fs));
	iLen = iFont->TextWidthInPixels(iString);
	
	// Allocates and constructs a CPeriodic object. Assign a priority to it.
	iTimer = CPeriodic::NewL(CActive::EPriorityStandard);
	}

/**
Destructor
*/
CTicker::~CTicker()
	{
	Stop();
	delete iTimer;
	if(iScr)
		{
		// Releases a specified font.
		iScr->ReleaseFont(iFont);
		}
	delete iGc;
	delete iScr;
	
	// Close the nodes.
	iWin.Close();
	iGrp.Close();
	iWs.Close();
	}

/**
Starts the ticker playing.
*/
void CTicker::Start()
	{
	// Sets the window's visibility.
	iWin.SetVisible(ETrue);
	if (!iTimer->IsActive())
		{
		// Starts generating periodic events. Pass the OnTick() function to call when the CPeriodic is scheduled after a timer event.
		iTimer->Start(0, 20*1000, TCallBack(CTicker::OnTick, this));
		}
	}
	
/**
Stops the ticker.
*/
void CTicker::Stop()
	{
	// Sets the window's visibility.
	iWin.SetVisible(EFalse);
	
	// Sends all pending commands in the buffer to the window server.
	iWs.Flush();
	
	// Cancels the wait for completion of an outstanding request.
	iTimer->Cancel();
	}

/**
A callback function
*/
TInt CTicker::OnTick(TAny* aArg)
	{
	CTicker* self = (CTicker*)aArg;
	
	// Invalidates the entire window.
	self->iWin.Invalidate();
	
	// Begins redrawing the window's invalid region
	self->iWin.BeginRedraw();
	
	// Activates the context for a given window 
	self->iGc->Activate(self->iWin);
	self->Draw();
	
	// Frees the graphics context to be used with another window.
	self->iGc->Deactivate();
	
	// Ends the current redraw.
	self->iWin.EndRedraw();
	
	// Sends all pending commands in the buffer to the window server.
	self->iWs.Flush();

	return 0;
	}

/**
A Draw() function that puts a drawing onto the screen.
*/	
TBool CTicker::Draw()
	{
#ifdef PORTRAIT_MODE
	++iPos.iY;

	if (iPos.iY > iLen)
		{
		iPos.iY = 0;
		return ETrue;
		}
#else
	--iPos.iX;

	if (iPos.iX < -iLen)
		{
		iPos.iX = iRect.iBr.iX;
		return ETrue;
		}

#endif
	
	// Sets the line drawing size for the pen.
	iGc->SetPenSize(TSize(1,1));
	
	// Sets the pen colour.
	iGc->SetPenColor(TRgb(255,255,255,255));
	
	// Sets the line drawing style for the pen
	iGc->SetPenStyle(CGraphicsContext::ESolidPen);
	
	// Sets this context's font.
	iGc->UseFont(iFont);

#ifdef PORTRAIT_MODE
	iGc->DrawTextVertical(iString, iPos, ETrue);
#else
	iGc->DrawText(iString, iPos);
#endif
	
	// Discards a font.
	iGc->DiscardFont();

	return EFalse;
	}
