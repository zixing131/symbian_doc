/*
* ==============================================================================
*  Name        : CoverflowAppui.cpp
*  Part of     : CoverflowApp
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/

// INCLUDE FILES
#include <avkon.hrh>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <CoverflowApp.rsg>
#include <f32file.h>
#include <s32file.h>

#include "CoverflowApp.pan"
#include "CoverflowAppUi.h"
#include "CoverflowAppView.h"
//#include "CoverflowApph"
#include "eglrendering.h"

_LIT( KHelloFileName, "Hello.txt" );

// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// CCoverflowAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CCoverflowAppUi::ConstructL()
    {
    // Create the app framework.
        CAknAppUi::BaseConstructL(ENoAppResourceFile);
        iAppView = new(ELeave) CCoverflowAppView(*this);
        iAppView->ConstructL(ClientRect());
        AddToStackL(iAppView);

        iAppView->ActivateL();
        // Constructs object responsible for Demo.
        iDemo = CEGLRendering::NewL(iAppView->Window());

        iDemo->Start();
        // Construct ticker.
        TRect rcTicker(ClientRect());

    #ifdef PORTRAIT_MODE
        iTicker = CTicker::NewL(TRect(rcTicker.Width() - (KFontHeight + 4), 0, rcTicker.Width(),rcTicker.Height()), KNews);
    #else
        iTicker = CTicker::NewL(TRect(0,rcTicker.Height() - (KFontHeight + 4), rcTicker.Width(),rcTicker.Height()), KNews);
    #endif

        iPlayingTicker = EFalse;

        // Construct the dialogue Box.
        // Get a 212x76 pixel box in the centre of the window.
        TRect rcDialog(ClientRect());

    #ifdef PORTRAIT_MODE
        rcDialog.Shrink((rcDialog.Width() - 76) / 2, (rcDialog.Height() - 212) / 2);
    #else
        rcDialog.Shrink((rcDialog.Width() - 212) / 2, (rcDialog.Height() - 76) / 2);
    #endif

        iDialogBox = CDialogBox::NewL(rcDialog);
        iCallWindow = EFalse;   

    }
// -----------------------------------------------------------------------------
// CCoverflowAppUi::CCoverflowAppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CCoverflowAppUi::CCoverflowAppUi()
    {
    // No implementation required
    }

// -----------------------------------------------------------------------------
// CCoverflowAppUi::~CCoverflowAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CCoverflowAppUi::~CCoverflowAppUi()
    {
    delete iDemo;
    if (iAppView)
        {
        RemoveFromStack(iAppView);
        delete iAppView;
        iAppView = NULL;
        }
    delete iTicker;
    delete iDialogBox;
    }

/**
Processes user input.
@param aKeyEvent The key event details.
@return Indicates whether or not the key event was consumed.
*/
TKeyResponse CCoverflowAppUi::HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
    {
    TKeyResponse response = EKeyWasConsumed;
    switch (aKeyEvent.iCode)
        {
    case EKeyEscape:
        // Exit the application if the escape key is pressed.
        Exit();
        break;

    case EKeyDownArrow:
        // Enable or disable the ticker playback if down arrow key is pressed.
        if(!iPlayingTicker)
            {
            iTicker->Start();
            iPlayingTicker = ETrue;
            }
        else
            {
            iTicker->Stop();
            iPlayingTicker = EFalse;
            }
        break;
    case EKeyUpArrow:
        // Show or hide the call window if up arrow key is pressed.
        if(!iCallWindow)
            {
            iDialogBox->Start();
            iCallWindow = ETrue;
            }
        else
            {
            iDialogBox->Stop();
            iCallWindow = EFalse;
            }
        break;
    case EKeyTab:
        // Show or hide the semi-transparent green window around the call window if tab key is pressed.
        if(iCallWindow)
            {
            if(!iDialogBox->IsSemiTransparent())
                iDialogBox->SetSemiTransparency();
            else
                iDialogBox->RemoveSemiTransparency();
            }
        break;
    case EKeyRightArrow:
    case EKeyLeftArrow:
    case EKeyBackspace:
    case EKeySpace:
        response = iDemo->HandleKeyEventL(aKeyEvent);
        break;
    default:
        response = EKeyWasNotConsumed;
        }
    return response;
    }

// End of File

