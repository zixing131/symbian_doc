/*
* ==============================================================================
*  Name        : CoverflowAppdocument.cpp
*  Part of     : CoverflowApp
*  Interface   : 
*  Description : 
*  Version     : 
*
*  Copyright (c) 2005-2006 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation.
* ==============================================================================
*/

// INCLUDE FILES
#include "CoverflowAppUi.h"
#include "CoverflowAppDocument.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CCoverflowAppDocument::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CCoverflowAppDocument* CCoverflowAppDocument::NewL( CEikApplication&
                                                          aApp )
    {
    CCoverflowAppDocument* self = NewLC( aApp );
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CCoverflowAppDocument::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CCoverflowAppDocument* CCoverflowAppDocument::NewLC( CEikApplication&
                                                           aApp )
    {
    CCoverflowAppDocument* self =
        new ( ELeave ) CCoverflowAppDocument( aApp );

    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

// -----------------------------------------------------------------------------
// CCoverflowAppDocument::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CCoverflowAppDocument::ConstructL()
    {
    // No implementation required
    }

// -----------------------------------------------------------------------------
// CCoverflowAppDocument::CCoverflowAppDocument()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CCoverflowAppDocument::CCoverflowAppDocument( CEikApplication& aApp )
    : CAknDocument( aApp )
    {
    // No implementation required
    }

// ---------------------------------------------------------------------------
// CCoverflowAppDocument::~CCoverflowAppDocument()
// Destructor.
// ---------------------------------------------------------------------------
//
CCoverflowAppDocument::~CCoverflowAppDocument()
    {
    // No implementation required
    }

// ---------------------------------------------------------------------------
// CCoverflowAppDocument::CreateAppUiL()
// Constructs CreateAppUi.
// ---------------------------------------------------------------------------
//
CEikAppUi* CCoverflowAppDocument::CreateAppUiL()
    {
    // Create the application user interface, and return a pointer to it;
    // the framework takes ownership of this object
    return ( static_cast <CEikAppUi*> ( new ( ELeave )
                                        CCoverflowAppUi ) );
    }

// End of File

