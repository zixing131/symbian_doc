// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <FileSharingCreator.rsg>

#include "FileSharingCreatorExternalInterface.h"
#include "FileSharingCreatorAppUi.h"
#include "FileSharingCreatorMainView.h"
#include "FileSharingCreator.hrh"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileSharingCreatorMainView* CFileSharingCreatorMainView::NewLC(CQikAppUi& aAppUi)
	{
	CFileSharingCreatorMainView* self = new (ELeave) CFileSharingCreatorMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CFileSharingCreatorMainView::CFileSharingCreatorMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileSharingCreatorMainView::~CFileSharingCreatorMainView()
	{
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CFileSharingCreatorMainView::ConstructL()
	{
	BaseConstructL();
	}
	
// --------------------------------------------------------------------------
// Called when this view is first time activated.
// --------------------------------------------------------------------------
void CFileSharingCreatorMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_FILESHARINGCREATOR_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EFileSharingCreatorLabelCtrl);
	}

// --------------------------------------------------------------------------
// Returns the identifier of this view.
// --------------------------------------------------------------------------
TVwsViewId CFileSharingCreatorMainView::ViewId()const
	{
	return TVwsViewId(KUidFileSharingCreatorApp, KUidFileSharingCreatorMainView);
	}

// --------------------------------------------------------------------------
// Handles user command.
// In this example, all commands are sent to AppUi because
// we want to have the same code with S60.
// --------------------------------------------------------------------------
void CFileSharingCreatorMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CFileSharingCreatorMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the label has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CFileSharingCreatorMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
