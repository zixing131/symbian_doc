/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

// INCLUDE FILES
#include <aknlists.h>
#include <ImageConversion.h>

#include "ImageConverter.hrh"
#include "EncoderSelectionDialog.h"
#include "ImageConverterEngine.h"

const TInt KNumMessages = 10;
const TInt KMaxEncoderListLength = 80;
const TInt KPeriodicTimerInterval(100000);

// ================= MEMBER FUNCTIONS =======================

// C++ default constructor can NOT contain any code, that
// might leave.
//
CEncoderSelectionDialog::CEncoderSelectionDialog( 
    RImageTypeDescriptionArray& aImageTypes, 
    TInt& aSelectedIdx ) : 
    iImageTypes( aImageTypes ), iSelectedIdx( aSelectedIdx )
    {
    }

CEncoderSelectionDialog::~CEncoderSelectionDialog()
    {
    if(iPeriodic)
        {
        iPeriodic->Cancel();
        }
    delete iPeriodic;
    }


// ----------------------------------------------------------
// CEncoderSelectionDialog::PreLayoutDynInitL()
// Initializing the dialog dynamically
// ----------------------------------------------------------
//
void CEncoderSelectionDialog::PreLayoutDynInitL()
    {
    SetEditableL(ETrue);

    // Initialize component array
    InitComponentArrayL();
    
    // Create a control to display a list of messages
    iListBox = new (ELeave) CAknSingleStyleListBox;
    iListBox->SetContainerWindowL(*this);
    iListBox->ConstructL(this);
    iListBox->SetListBoxObserver(this);
    
    iListBox->CreateScrollBarFrameL(ETrue);
    iListBox->ScrollBarFrame()->
        SetScrollBarVisibilityL(CEikScrollBarFrame::EAuto, 
                                CEikScrollBarFrame::EAuto);

    Components().AppendLC(iListBox);
    CleanupStack::Pop(iListBox);
    
    
    // Create an array to hold the messages
    iMessageList = new (ELeave) CDesCArrayFlat(KNumMessages);

    // Give it to the control
    CTextListBoxModel* model = iListBox->Model();
    model->SetItemTextArray(iMessageList);
    model->SetOwnershipType(ELbmOwnsItemArray); // transfer ownership
    }

void CEncoderSelectionDialog::PostLayoutDynInitL()
    {
    // add the message to the list
    iListBox->SetRect( Rect() );    

    
    _LIT( KTab, "\t" );

    for( TInt i=0; i<iImageTypes.Count(); i++ ) 
        {
        TBuf<KMaxEncoderListLength> desc;

        desc.Append( KTab );
        desc.Append( iImageTypes[i]->Description() );
    
        iMessageList->AppendL( desc );
        }

    // tell the control about the change
    iListBox->HandleItemAdditionL();
    }


// ----------------------------------------------------------
// CEncoderSelectionDialog::OkToExitL()
// This function ALWAYS returns ETrue
// ----------------------------------------------------------
//
TBool CEncoderSelectionDialog::OkToExitL(TInt /*aButtonId*/)
    {
    iSelectedIdx = iListBox->CurrentItemIndex();
    return ETrue;
    }

TInt CEncoderSelectionDialog::CountComponentControls() const
    {
    TInt count = 0;
    if( iListBox )
        count = 1;

    return count;
    }

CCoeControl* CEncoderSelectionDialog::ComponentControl(TInt /*aIndex*/) const
    {
    return iListBox;
    }

TKeyResponse CEncoderSelectionDialog::OfferKeyEventL(
    const TKeyEvent& aKeyEvent,TEventCode aType)
    {
    if( iListBox )
        {
        if (aKeyEvent.iCode == EKeyOK)
            {
            iSelectedIdx = iListBox->CurrentItemIndex();
            TryExitL(1);
       		return( EKeyWasConsumed );
            }
        else
            {
            return( iListBox->OfferKeyEventL(aKeyEvent, aType) );
            }
        }
    else
       return( EKeyWasNotConsumed );
    }

void CEncoderSelectionDialog::SizeChanged()
    {
    iListBox->SetRect(Rect());
    }

void CEncoderSelectionDialog::HandleResourceChange(TInt aType)
    {
    CAknDialog::HandleResourceChange(aType);
    
    if ( aType==KEikDynamicLayoutVariantSwitch )
        {
        TRect rect;
        AknLayoutUtils::LayoutMetricsRect(
        AknLayoutUtils::EMainPane,rect);

        SetRect(rect);
        }
        
    }

void CEncoderSelectionDialog::HandleListBoxEventL(CEikListBox* /*aListBox*/, TListBoxEvent aEventType)
    {
    if (aEventType==EEventEnterKeyPressed || aEventType==EEventItemDoubleClicked)
        {
        iSelectedIdx = iListBox->CurrentItemIndex();
        
        // NOTE: Need to cut method calling flow
        // Wait as asynchronoysly 10ms and call TryExitL() after that  
        if (!iPeriodic)
            {
            iPeriodic = CPeriodic::NewL(CActive::EPriorityIdle);
            iPeriodic->Start(KPeriodicTimerInterval, KPeriodicTimerInterval,TCallBack(PeriodicTimerCallBack, this));
            }
        }
    }


TInt CEncoderSelectionDialog::PeriodicTimerCallBack(TAny* aAny)
    {
    CEncoderSelectionDialog* self = static_cast<CEncoderSelectionDialog*>( aAny );
    self->iPeriodic->Cancel();
    TRAPD(err,
            self->TryExitL(1);
    );
    return KErrNone;
    }



