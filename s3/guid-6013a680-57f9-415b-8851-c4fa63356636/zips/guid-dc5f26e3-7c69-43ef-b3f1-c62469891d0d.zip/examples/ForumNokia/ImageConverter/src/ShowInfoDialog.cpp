/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

// INCLUDE FILES
#include <ImageConversion.h>
#include "ShowInfoDialog.h"

const TInt KMaxInfoDescriptorLength = 100;

CShowInfoDialog::CShowInfoDialog( CFrameInfoStrings* aInfoStrings ) : 
    iInfoStrings( aInfoStrings )
    {
    }

CShowInfoDialog::~CShowInfoDialog()
    {
    iEikonEnv->ScreenDevice()->ReleaseFont(iFont);
    }

void CShowInfoDialog::PreLayoutDynInitL()
    {
    CAknQueryDialog::PreLayoutDynInitL();
    SetEditableL(ETrue);    
    
    // Create font
    _LIT( KSeries60SansB, "Series 60 SansB" );
    TFontSpec fontSpec( KSeries60SansB, 75 );
    fontSpec.iFontStyle.SetBitmapType(EAntiAliasedGlyphBitmap);
    User::LeaveIfError(iEikonEnv->ScreenDevice()->GetNearestFontInTwips( iFont, fontSpec ));
    }

void CShowInfoDialog::PostLayoutDynInitL()
    {
    CalculatePositionAndSize();
    }

TBool CShowInfoDialog::OkToExitL(TInt /*aButtonId*/)
    {
    return ETrue;
    }

TInt CShowInfoDialog::CountComponentControls() const
    {
    return( 0 ); 
    }

CCoeControl* CShowInfoDialog::ComponentControl(TInt /*aIndex*/) const
    {
    return NULL;
    }

void CShowInfoDialog::CalculatePositionAndSize()
    {
    TRect cRect;
    AknLayoutUtils::LayoutMetricsRect(AknLayoutUtils::EMainPane,cRect);
    
    cRect.Shrink(25,25);
    SetExtent(cRect.iTl,cRect.Size());
    }

void CShowInfoDialog::SetSizeAndPosition(const TSize &aSize)
    {
    CAknQueryDialog::SetSizeAndPosition( aSize );
    
    CalculatePositionAndSize();
    }

void CShowInfoDialog::SizeChanged()
    {
    DrawNow();
    }

void CShowInfoDialog::HandleResourceChange(TInt aType)
    {
    CAknQueryDialog::HandleResourceChange(aType);   
    }

void CShowInfoDialog::Draw( const TRect& /*aRect*/ ) const
    {
    // Get the standard graphics context
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle( CGraphicsContext::ENullPen );
    gc.SetBrushColor( KRgbBlack);
    gc.SetBrushStyle( CGraphicsContext::ESolidBrush );

    // Clear screen
    gc.Clear(Rect());
    gc.SetBrushStyle( CGraphicsContext::ENullBrush );
    
    // Draw round rect
    gc.SetPenStyle( CGraphicsContext::ESolidPen );
    gc.SetPenColor(KRgbWhite);
    gc.DrawRect(Rect());

    // Draw image info texts
    gc.UseFont(iFont);
    TBuf<KMaxInfoDescriptorLength> desc;
    TPoint point = Rect().iTl;
    point.iX += 10;
    for( TInt i=0; i<iInfoStrings->Count(); i++ ) 
        {
        point.iY += 20;
        desc.Copy( iInfoStrings->String(i) );
        gc.DrawText(desc,point);
        }
    }




