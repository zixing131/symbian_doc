/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef IMAGECONVERTERAPPUI_H
#define IMAGECONVERTERAPPUI_H

// INCLUDES
#include <eikapp.h>
#include <eikdoc.h>
#include <e32std.h>
#include <coeccntx.h>
#include <aknappui.h>
#include <aknutils.h>

#include "ImageConverterEngine.h"
#include "ImageConverterContainer.h"

const TUid KUidHelpFile = {0x2000e192};  // From help

// FORWARD DECLARATIONS
class CImageConverterContainer;


// CLASS DECLARATION

class CAknListQueryDialog;
class CShowInfoDialog;
class CFrameInfoStrings;

/**
* Application UI class.
* Provides support for the following features:
* - EIKON control architecture
* 
*/
class CImageConverterAppUi : public CAknAppUi, MConverterController
    {
    public: // // Constructors and destructor

        /**
        * EPOC default constructor.
        */      
        void ConstructL();

        /**
        * Destructor.
        */      
        ~CImageConverterAppUi();
        
    public: // New functions
        void ShowMessage(const TDesC& aMsg) const;
        void DoEvent(EPointerEvents aEvent);
        void ReadImage(TInt aDirection);
        TBool IsEngineBusy();
        TInt ImageIndex();
        TInt ImageCount();        
        void ImageName(TFileName& aFilename);
        void PlainImageName(TFileName& aFilename);
        /**
        * From CEikAppUi, takes care of command handling.
        * @param aCommand command to be handled
        */
        void HandleCommandL(TInt aCommand);
        
    public: // Functions from base classes
        // from MConverterController
        void NotifyCompletion( TInt aErr, const TDesC& aMsg  );
        TBool IsAnimating();
        TBool IsOptionsButtonOnTop();
        void SearchOptionsButtonPosition();
        TState EngineState();


        
    private:
        // From MEikMenuObserver
        void DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane);

    private:

        /**
        * From CEikAppUi, handles key events.
        * @param aKeyEvent Event to handled.
        * @param aType Type of the key event. 
        * @return Response code (EKeyWasConsumed, EKeyWasNotConsumed). 
        */
        virtual TKeyResponse HandleKeyEventL(
            const TKeyEvent& aKeyEvent,TEventCode aType);

        CArrayFix<TCoeHelpContext>* HelpContextL() const;
        
    private: // internal methods
        /**
        * Handles Open menu command
        */
        void HandleOpenL();

        /**
        * Handles Save as menu command
        */
        void HandleSaveAsL();
        
        /**
        * Handles Info menu command
        */
        void HandleInfoL();
        
        /**
        * Handles Rotate menu command
        */
        void HandleRotate();
        
        /**
        * Handles Scale menu command
        */
        void HandleScale();
        
        /**
        * Shows an error message.
        */
        void ShowMessageL(const TDesC& aMsg) const;
        
        void ReadImageDirectoryL();
        
        void HandleResourceChangeL( TInt aType );

        
    private: //Data
        /*! @var iImageLoaded true if an image has been opened/decoded
        and is to be shown. 
        Used to enable/disable save as and info menu commands */
        TBool                       iImageLoaded;

        /*! @var iAppContainer A reference to the converter container
        */
        CImageConverterContainer*   iAppContainer; 

        /*! @var iConverter the actuall calls to ICL are done from this engine 
        */
        CImageConverterEngine*      iConverter;
        
        RArray<TFileName>           iFiles;
        TInt                        iOpenFileIndex;
        TBool                       iShiftDown;
        
        TBool                       iOptionButtonOnTop;
        
        CAknListQueryDialog*        iSaveAs;
        CShowInfoDialog*            iInfoDialog;
        CFrameInfoStrings*          iInfoStrings;

    };

#endif

// End of File
