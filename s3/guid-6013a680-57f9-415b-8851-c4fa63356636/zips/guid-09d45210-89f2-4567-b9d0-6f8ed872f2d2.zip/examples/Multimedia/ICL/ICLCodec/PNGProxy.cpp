/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



// Supplies the factory function called by ECom, and factories for
// the PNG decoder and encoder

// Ecom headers
#include <ecom.h>
#include <implementationproxy.h>

// ICL base class
#include <icl/imageconstruct.h>

#include "uids.h"
#include "PNGCodec.h"


//
// Factory for PNG decoder
//
class CPngDecodeConstruct : public CImageDecodeConstruct
	{
public:
	// Constructs the factory
	static CPngDecodeConstruct* NewL();

	// Supplies a new decoder
	// from CImageDecodeConstruct
	CImageDecoderPlugin* NewPluginL() const;
	};

CPngDecodeConstruct* CPngDecodeConstruct::NewL()
	{
	CPngDecodeConstruct* self = new (ELeave) CPngDecodeConstruct;
	return self;
	}

CImageDecoderPlugin* CPngDecodeConstruct::NewPluginL() const
	{
	return CPngDecoder::NewL();
	}


//
// Factory for PNG encoder
//
class CPngEncodeConstruct : public CImageEncodeConstruct
	{
public:
	// Constructs the factory
	static CPngEncodeConstruct* NewL();

	// Supplies a new encoder
	// from CImageEncodeConstruct
	CImageEncoderPlugin* NewPluginL() const;
	};

CPngEncodeConstruct* CPngEncodeConstruct::NewL()
	{
	CPngEncodeConstruct* self = new (ELeave) CPngEncodeConstruct;
	return self;
	}

CImageEncoderPlugin* CPngEncodeConstruct::NewPluginL() const
	{
	return CPngEncoder::NewL();
	}



//
// Exported proxy for ECom instantiation method resolution
//

// Define the factories for the PNG converters
const TImplementationProxy ImplementationTable[] =
	{
		IMPLEMENTATION_PROXY_ENTRY(KExPNGDecoderImplementationUidValue, CPngDecodeConstruct::NewL),
		IMPLEMENTATION_PROXY_ENTRY(KExPNGEncoderImplementationUidValue, CPngEncodeConstruct::NewL)
	};

EXPORT_C const TImplementationProxy* ImplementationGroupProxy(TInt& aTableCount)
	{
	aTableCount = sizeof(ImplementationTable) / sizeof(TImplementationProxy);
	return ImplementationTable;
	}

//
// Global panic function
//
GLDEF_C void Panic(TInt aError)
	{
	_LIT(KPNGPanicCategory, "PNGExConvertPlugin");
	User::Panic(KPNGPanicCategory, aError);
	}

