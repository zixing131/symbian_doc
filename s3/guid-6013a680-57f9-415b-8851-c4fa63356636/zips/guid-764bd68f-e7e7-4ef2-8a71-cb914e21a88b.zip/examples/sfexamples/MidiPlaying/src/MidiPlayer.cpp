// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDE FILES
#include <eikenv.h>
#include "MidiPlayer.h"

// CONSTANTS
const TInt KVolumeDenominator = 2;

// METHODS DEFINITION

CMidiPlayer::CMidiPlayer()
	{
	}

CMidiPlayer::~CMidiPlayer()
	{
	delete iMidiUtility;
	}

CMidiPlayer* CMidiPlayer::NewLC()
	{
	CMidiPlayer* self = new (ELeave) CMidiPlayer();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CMidiPlayer* CMidiPlayer::NewL()
	{
	CMidiPlayer* self = CMidiPlayer::NewLC();
	CleanupStack::Pop(self);
	return self;
	}

void CMidiPlayer::ConstructL()
	{
	iMidiUtility = CMidiClientUtility::NewL(*this);
	}

void CMidiPlayer::Play(const TDesC& aFileName)
	{
	iMidiUtility->Close();
	iMidiUtility->OpenFile(aFileName);
	}

void CMidiPlayer::Stop()
	{
	iMidiUtility->Stop(TTimeIntervalMicroSeconds(0));
	iMidiUtility->Close();
	}

void CMidiPlayer::MmcuoStateChanged(TMidiState aOldState, TMidiState aNewState,
			const TTimeIntervalMicroSeconds& /*aTime*/, TInt aError)
	{
	if (KErrNone == aError)
		{		
	    if (EMidiStateOpenDisengaged == aNewState)
			{
			// Set the volume to half of the maximum volume.
			TRAP_IGNORE(iMidiUtility->SetVolumeL(
					iMidiUtility->MaxVolumeL() / KVolumeDenominator));
			
			// Play the MIDI file.
			iMidiUtility->Play();
			}
		}
	else
		{
		DisplayErrorMessage(aError);
		}
	}

void CMidiPlayer::MmcuoTempoChanged(TInt /*aMicroBeatsPerMinute*/)
	{
	}

void CMidiPlayer::MmcuoVolumeChanged(TInt /*aChannel*/,
		TReal32 /*aVolumeInDecibels*/)
	{
	}

void CMidiPlayer::MmcuoMuteChanged(TInt /*aChannel*/, TBool /*aMuted*/)
	{
	}

void CMidiPlayer::MmcuoSyncUpdate(const TTimeIntervalMicroSeconds& /*aMicroSeconds*/,
			TInt64 /*aMicroBeats*/)
	{
	}

void CMidiPlayer::MmcuoMetaDataEntryFound(const TInt /*aMetaDataEntryId*/,
			const TTimeIntervalMicroSeconds& /*aPosition*/)
	{
	}

void CMidiPlayer::MmcuoMipMessageReceived(
		const RArray<TMipMessageEntry>& /*aMessage*/)
	{
	}

void CMidiPlayer::MmcuoPolyphonyChanged(TInt /*aNewPolyphony*/)
	{
	}

void CMidiPlayer::MmcuoInstrumentChanged(TInt /*aChannel*/, TInt /*aBankId*/,
			TInt /*aInstrumentId*/)
	{
	}

void CMidiPlayer::DisplayErrorMessage(TInt aError)
	{
	const TInt KMaxBuffer = 15;
	_LIT(KErrorMessage, "Error: %d");
	TBuf<KMaxBuffer> buffer;
	buffer.AppendFormat(KErrorMessage, aError);
	TRAP_IGNORE(CEikonEnv::Static()->InfoWinL(KNullDesC, buffer));
	}

// End of File
