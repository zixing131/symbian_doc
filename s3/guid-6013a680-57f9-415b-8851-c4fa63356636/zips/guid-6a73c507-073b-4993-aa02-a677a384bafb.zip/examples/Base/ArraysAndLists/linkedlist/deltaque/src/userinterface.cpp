/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Contains definition of functions defined in the CUserInterface class.� 
*/




/**
 @file
*/

#include "userinterface.h"
/**
The static function to create an object of the CUserInterface class.
@param aConsole The console object.
@param aTimerEntry A pointer to an object of the CTimerEntry class.
@return A CUserInterface object.
*/
CUserInterface* CUserInterface::NewL(CConsoleBase* aConsole,CTimerEntry* aTimerEntry)
	{
	CUserInterface* self = new (ELeave)CUserInterface;
	self->Initialize(aConsole,aTimerEntry);
	return self;
	}

/**
Initialize the data members of the CUserInterface class.
@param aConsole The console object.
@param aTimerEntry A pointer to an object of the CTimerEntry class.
*/
void CUserInterface::Initialize(CConsoleBase* aConsole,CTimerEntry* aTimerEntry)
	{
	iConsole = aConsole;
	iTimerEntry = aTimerEntry;
	CActiveScheduler::Add(this);
	iTimerEntry->IssueRequest();
	}

/**
Constructor.
*/
CUserInterface::CUserInterface():CActive(CActive::EPriorityUserInput)
	{
	}

/**
Handles the key press events from the console.
It stops the active scheduler if any key is pressed.
*/
void CUserInterface::RunL()
	{
	// Get the key code.
	TUint8 option = iConsole->KeyCode();
	// Print the selected option.
	_LIT(KTextFormat,"%c\n");
	iConsole->Printf(KTextFormat,option);
	CActiveScheduler::Stop();
	}

/**
Issues an outstanding request to get a keystroke from the console.
*/
void CUserInterface::ReadFunc()
	{
	// Print the menu.
	_LIT(KTxtOption,"***\nPress any key to stop the scheduler\n***\n");
	iConsole->Printf(KTxtOption);
	// Wait for a key press event.
	iConsole->Read(iStatus);
	SetActive();
	}

/**
Cancel any outstanding request.
*/
void CUserInterface::DoCancel()
	{
	if(IsActive())
		{
		// Cancel any outstanding read requests.
		iConsole->ReadCancel();
		}
	}

/**
Destructor.
*/
CUserInterface::~CUserInterface()
	{
	Cancel();
	}
