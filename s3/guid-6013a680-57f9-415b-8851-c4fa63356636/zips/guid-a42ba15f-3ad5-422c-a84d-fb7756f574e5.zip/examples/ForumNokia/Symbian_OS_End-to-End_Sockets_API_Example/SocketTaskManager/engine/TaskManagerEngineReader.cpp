/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */


// INCLUDE FILES
#include "TaskManager.pan"
#include "TaskManagerEngineReader.h"

#include <securesocket.h>

// ================= MEMBER FUNCTIONS =======================

// Constructor
CTaskManagerEngineReader::CTaskManagerEngineReader( MEngineNotifier& aNotifier )
: CActive( EPriorityStandard ), iSocket( NULL ), iNotifier( aNotifier )
	{
	}

// Destructor
CTaskManagerEngineReader::~CTaskManagerEngineReader()
	{
	Cancel();
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::ConstructL()
// Second-phase constructor
// ----------------------------------------------------
//
void CTaskManagerEngineReader::ConstructL()
	{
	CActiveScheduler::Add( this );
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::NewL()
// Two-phased construction.
// ----------------------------------------------------
//
CTaskManagerEngineReader* CTaskManagerEngineReader::NewL( MEngineNotifier& aNotifier )
	{
	CTaskManagerEngineReader* self = CTaskManagerEngineReader::NewLC( aNotifier );
	CleanupStack::Pop( self );
	return self;
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::NewLC()
// Two-phased construction.
// ----------------------------------------------------
//
CTaskManagerEngineReader* CTaskManagerEngineReader::NewLC( MEngineNotifier& aNotifier )
	{
	CTaskManagerEngineReader* self = new (ELeave) CTaskManagerEngineReader( aNotifier );
	CleanupStack::PushL( self );
	self->ConstructL();
	return self;
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::Start()
// Initiates the reader.
// ----------------------------------------------------
//
void CTaskManagerEngineReader::Start()
	{
	// Initiate a new read from socket into iBuffer
    if (!IsActive())
        {
        IssueRead();
        }
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::DoCancel()
// Cancels an outstanding request.
// ----------------------------------------------------
//
void CTaskManagerEngineReader::DoCancel()
	{
	iSocket->CancelRecv();
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::RunL()
// Handles an active object�s request completion event.
// ----------------------------------------------------
//
void CTaskManagerEngineReader::RunL()
	{
	switch( iStatus.Int() )
		{
		case KErrNone:
			{
			// Something was read from socket. Pass it to upper levels
	        if( iNotifier.PackageReceivedL( iBuffer ) )
	            {
	            IssueRead(); // Immediately start another read
	            }
            
			break;
			}
		default:
		    {
		    Panic( ETaskManagerInvalidState );
		    break;
		    }
		}
	}

// ----------------------------------------------------
// CTaskManagerEngineReader::IssueRead()
// Initiate a single new read from socket.
// ----------------------------------------------------
//
void CTaskManagerEngineReader::IssueRead()
	{
	// This deletion is needed for some reason in S60 3rd Edition (at least for the emulator).
	// Otherwise the data in iBuffer will not get replaced on successive read operations to
	// the secure socket.
	iBuffer.Delete(0, iBuffer.Length());
    iSocket->RecvOneOrMore(iBuffer, iStatus, iDummyLength);
    SetActive();
    }

// ----------------------------------------------------
// CTaskManagerEngineReader::SetSecureSocket()
// Sets a new socket from which to read.
// ----------------------------------------------------
//
void CTaskManagerEngineReader::SetSecureSocket( CSecureSocket* aSocket )
    {
    iSocket = aSocket;
    }
    
// End of file
