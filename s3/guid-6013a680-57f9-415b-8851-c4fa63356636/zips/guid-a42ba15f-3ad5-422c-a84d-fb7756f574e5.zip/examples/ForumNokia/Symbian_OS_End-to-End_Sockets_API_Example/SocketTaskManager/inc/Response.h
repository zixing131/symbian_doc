/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */


#ifndef __CRESPONSE_H
#define __CRESPONSE_H

// INCLUDE FILES
#include "TaskManager.hrh"

#include <e32std.h>
#include <badesca.h>            //CDesCArray

// CLASS DECLARATION

/**
* A wrapper class for handling responses from the server.
*/
class CResponse : public CBase
	{
public: // Constructors and destructor

    /**
    * Enum for following the class' state.
    */
    enum TResponseState
        {
        ENotComplete,
        EComplete,
        EError
        };
	
	/**
	* Two-phased constructor.
	*/
	static CResponse* NewL();

	/**
	* Two-phased constructor.
	*/
	static CResponse* NewLC();

	/**
	* Destructor
	*/
	~CResponse();

    /**
    * Determines what type of response is in question.
    */
	enum TResponseType
		{
		ELoadTasks = 0,
		ETaskComplete
		};

public: // New functions

	/**
	* Constructs this response object from the data received from the server.
	* @param aData the data that was received from the server
	*/
	void ParseDataL( TDesC& aData );
    
	/**
	* Returns whether errors occurred in the server side.
	* @return ETrue if response consist errors, EFalse if not.
	*/
	TBool HasError() const;

	/**
	* Returns the error description.
	* @return the error description.
	*/
	TBuf<KMaxError> Error() const;

	/**
	* Returns the number of tasks received from the server.
	* @return the number of tasks received from the server.
	*/
	TInt TaskCount() const;

	/**
	* Returns the task description.
	* @param aIndex the index of the description.
	* @return the task description.
	*/
	TBuf<KMaxTaskLength> TaskDescription(const TInt& aIndex) const;

	/**
	* Returns the task id.
	* @return the task id.
	*/
	TInt TaskId(const TInt& aIndex) const;

	/**
	* Returns the type of this response. 
	* @return the type of this response.
	*/
	TResponseType ResponseType() const;

    /**
    * Takes in a part of the server message.
    * @param aData part of the message
    */
    void InputDataL( const TDesC8& aData );
    
    /**
    * Returns whether the entire message has been given to CResponse. This
    * function is used specifically by the engine to determine whether or not
    * continue reading from the socket.
    * @return ETrue if message is complete, EFalse if not.
    */
    TResponseState GetState() const;

private: 

    /**
    * This function checks if the already received data forms a valid
    * message, e.g. it is of right size and data is legal.
    */
    void DoCheck();

	/**
	* Symbian OS default constructor
	*/
	CResponse();
	void ConstructL();
	
	/**
	* Message parser state machine states.
	*/
	enum TTaskReadStatus
		{
		EStart = 0,
		EReadId,
		EReadTask
		};

private: // Data members

    // Error informers
	TBuf<KMaxError>	iError;
	
	CDesCArray*		iDescriptions;
	RArray<TInt>	iIds;
	TResponseType	iResponseType;
	
	// Resizable descriptor for storing the message
	HBufC*          iMessageBuffer;
	
	TInt            iExpectedPackageSize;
	TResponseState  iState;
	};

#endif

// End of file


