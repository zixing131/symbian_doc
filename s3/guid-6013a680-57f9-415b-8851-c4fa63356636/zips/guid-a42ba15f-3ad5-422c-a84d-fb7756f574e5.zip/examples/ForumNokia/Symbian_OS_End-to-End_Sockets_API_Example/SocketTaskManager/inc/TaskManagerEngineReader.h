/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */


#ifndef __TASKMANAGERENGINEREADER_H__
#define __TASKMANAGERENGINEREADER_H__

// INCLUDE FILES
#include <in_sock.h>

// FORWARD DECLARATIONS
class CSecureSocket;

// CLASS DECLARATIONS

/**
* A mixin for notifying about received packages
*/
class MEngineNotifier
    {
public:
    virtual TBool PackageReceivedL( const TDesC8& aData ) = 0;
    };


/**
* A socket reader class.
* Is used for reading data from a socket and informing an observer.
*/
class CTaskManagerEngineReader : public CActive
    {
public:

    /**
    * Two-phased constructor.
    */
	static CTaskManagerEngineReader* NewL( MEngineNotifier& aNotifier );
    static CTaskManagerEngineReader* NewLC( MEngineNotifier& aNotifier );

    /**
    * Destructor
    */
	~CTaskManagerEngineReader();

    /**
    * Initiate a read from socket.
    */
	void Start();
	
    /**
    * Sets a secure socket.
    * @param aSocket The secure socket from which to read.
    */	
    void SetSecureSocket( CSecureSocket* aSocket );

protected: // from CActive

    /**
    * Cancel any pending operation
    */
	void DoCancel();

    /**
    * Called when operation complete
    */
	void RunL();	

private:

    /**
    * Perform the first phase of two-phase construction.
    * @param aNotifier Handle to notify the engine.
    */
	CTaskManagerEngineReader( MEngineNotifier& aNotifier );

    /**
    * Perform the second phase construction of a CSocketsReader.
    */
	void ConstructL();

    /**
    * Initiate a read from socket.
    */
	void IssueRead();

private: // Member variables

    // The size of the read buffer in bytes.
    enum { KReadBufferSize = 20 };

    // Socket to read data from.
    CSecureSocket*          iSocket;

    // Buffer for receiving data.
	TBuf8<KReadBufferSize>  iBuffer;

    // Handle to notify engine.
    MEngineNotifier&        iNotifier;
    
    // Stores the amount of bytes read from socket.
    // Must be defined even though it's not used anywhere except when reading.
    TSockXfrLength          iDummyLength;
    };

#endif

// End of file
