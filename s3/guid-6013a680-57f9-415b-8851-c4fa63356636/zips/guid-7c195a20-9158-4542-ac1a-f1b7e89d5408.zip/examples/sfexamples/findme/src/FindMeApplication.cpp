// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Main application class
// 
// 


// INCLUDE FILES
#include "FindMe.hrh"
#include "FindMeDocument.h"
#include "FindMeApplication.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CFindMeApplication::CreateDocumentL()
// Creates CApaDocument object
// -----------------------------------------------------------------------------
//
CApaDocument* CFindMeApplication::CreateDocumentL()
	{
	// Create an FindMe document, and return a pointer to it
	return (static_cast<CApaDocument*>
					( CFindMeDocument::NewL( *this ) ) );
	}

// -----------------------------------------------------------------------------
// CFindMeApplication::AppDllUid()
// Returns application UID
// -----------------------------------------------------------------------------
//
TUid CFindMeApplication::AppDllUid() const
	{
	// Return the UID for the FindMe application
	return KUidFindMeApp;
	}

// End of File
