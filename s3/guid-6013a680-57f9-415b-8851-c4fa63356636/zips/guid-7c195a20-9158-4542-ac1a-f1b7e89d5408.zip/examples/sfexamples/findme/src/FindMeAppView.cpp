// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Application view implementation
// 
// 


// INCLUDE FILES
#include <coemain.h>
#include "FindMeAppView.h"

#include <aknnotewrappers.h>


// Degrees sign delimeter used in formatting methods
_LIT(KDelimDegree,"\xb0"); // "�" symbol

// Dot delimeter used in formatting methods
_LIT(KDelimDot,"\x2e"); // "." symbol

// Plus sign delimeter used in formatting methods
_LIT(KDelimPlus,"\x2b"); // "+" symbol

// Minus sign delimeter used in formatting methods
_LIT(KDelimMinus,"\x2d"); // "-" symbol

// Quotation sign delimeter used in formatting methods
_LIT(KDelimQuot,"\x22"); // "\"" symbol

// Apostrophe sign delimeter used in formatting methods
_LIT(KApostrophe,"\x27"); // "'" symbol

// Not-a-number string
_LIT(KNan,"NaN");


// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CFindMeAppView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFindMeAppView* CFindMeAppView::NewL( const TRect& aRect )
	{
	CFindMeAppView* self = CFindMeAppView::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CFindMeAppView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFindMeAppView* CFindMeAppView::NewLC( const TRect& aRect )
	{
	CFindMeAppView* self = new ( ELeave ) CFindMeAppView;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}

// -----------------------------------------------------------------------------
// CFindMeAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CFindMeAppView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();

	// Set the windows size
	SetRect( aRect );

	// Activate the window, which makes it ready to be drawn
	ActivateL();
	
	iMyPos = CFindMeActive::NewL(this);
	}

// -----------------------------------------------------------------------------
// CFindMeAppView::CFindMeAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CFindMeAppView::CFindMeAppView() : iPosDataFound(EFalse)
	{
	// No implementation required
	}


// -----------------------------------------------------------------------------
// CFindMeAppView::~CFindMeAppView()
// Destructor.
// -----------------------------------------------------------------------------
//
CFindMeAppView::~CFindMeAppView()
	{
	delete iMyPos;
	}


// -----------------------------------------------------------------------------
// CFindMeAppView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CFindMeAppView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();

	// Gets the control's extent
	TRect drawRect( Rect());

	// Clears the screen
	gc.Clear( drawRect );
	
	// If there is new location information found.
	if( iPosDataFound )
		{
		// Get the position information and store it in a TPosition object. 
		TPosition pos;
		iMyPos->iPositionInfo.GetPosition(pos);
  		
		TBuf<20> lat;
		GetDegreesString(pos.Latitude(),lat);
  		TBuf<20> lon;
  		GetDegreesString(pos.Longitude(),lon);
  		
  		// Prepare for writing the lat and long to the screen.
  	    // In this example, we use one of the standard font styles
  		const CFont* fontUsed = CEikonEnv::Static()->LegendFont();
  		gc.UseFont(fontUsed);
  		gc.SetPenColor(KRgbBlack);
  		gc.DrawText(lat, TPoint(25, 25));
  		gc.DrawText(lon, TPoint(25, 50));
  		gc.DiscardFont();
    	}
	}

// -----------------------------------------------------------------------------
// CFindMeAppView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CFindMeAppView::SizeChanged()
	{  
	DrawNow();
	}


// -----------------------------------------------------------------------------
// CFindMeAppView::PrintPos()
// Prints the position of the device in screen
// -----------------------------------------------------------------------------
//
void CFindMeAppView::PrintPos()
	{
	iPosDataFound = ETrue;
	DrawNow();
	iPosDataFound = EFalse;
	}

// -----------------------------------------------------------------------------
// CFindMeAppView::GetDegreesString
//
//  Taken from Nokia LocationRefAppForS60 example
//
// Changes latitude or longitude represented as degrees to a string of 
// a form +DDD'MM''SS.SSSS
// -----------------------------------------------------------------------------
//
void CFindMeAppView::GetDegreesString( const TReal64& aDegrees,
									   TBuf<20>& aDegreesString) const
    {
    const TReal KSecondsInMinute = 60.0;
    const TInt KNumWidth = 3;
    
    // If the aDegree is a proper number
    if ( !Math::IsNaN(aDegrees) )
        {
        // Integer part of the degrees
        TInt intDegrees = static_cast<TInt>(aDegrees);

        // Positive float of the degrees
        TReal64 realDegrees = aDegrees;
        
        // Convert to positive values
        if ( intDegrees < 0 )
            {
            intDegrees = -intDegrees;
            realDegrees = -realDegrees;
            }

        // Minutes
        TReal64 realMinutes = (realDegrees - intDegrees) * KSecondsInMinute;
          
        // Integer part of the minutes
        TInt intMinutes = static_cast<TInt>(realMinutes);

        // Seconds
        TReal64 realSeconds = (realMinutes - intMinutes) * KSecondsInMinute;
        TInt intSeconds = static_cast<TInt>((realMinutes - intMinutes) * KSecondsInMinute);

        // Check the sign of the result
        if ( aDegrees >= 0 )
            {
            aDegreesString.Append(KDelimPlus); 
            }
        else
            {
            aDegreesString.Append(KDelimMinus);
            }

        // Add the degrees
        TInt64 value = intDegrees;
        aDegreesString.AppendNum(value);

        // Add the separator
        aDegreesString.Append(KDelimDegree);
    
        // Add the minutes
        value = intMinutes;
        aDegreesString.AppendNum(value);

        // Add the separator
        aDegreesString.Append(KApostrophe);
        
        // Add the seconds
        value = intSeconds;
        aDegreesString.AppendNum(value);

        // Add the separator
        aDegreesString.Append(KDelimQuot);

        // Add the separator
        aDegreesString.Append(KDelimDot);
        
        // Get six last digits
        realSeconds -= intSeconds;
        realSeconds *= 1000;
        
        // Add the seconds
        aDegreesString.AppendNumFixedWidth(static_cast<TInt>(realSeconds), EDecimal, KNumWidth);
        }
    else
        {
        // The conversion can not be done, return NaN
        aDegreesString = KNan;
        }
    }

// End of File
