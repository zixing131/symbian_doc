// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CFindMeDocument implementation
// 
// 



// INCLUDE FILES
#include "FindMeAppUi.h"
#include "FindMeDocument.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CFindMeDocument::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFindMeDocument* CFindMeDocument::NewL( CEikApplication& aApp )
	{
	CFindMeDocument* self = NewLC( aApp );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CFindMeDocument::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFindMeDocument* CFindMeDocument::NewLC( CEikApplication& aApp )
	{
	CFindMeDocument* self =
		new ( ELeave ) CFindMeDocument( aApp );

	CleanupStack::PushL( self );
	self->ConstructL();
	return self;
	}

// -----------------------------------------------------------------------------
// CFindMeDocument::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CFindMeDocument::ConstructL()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CFindMeDocument::CFindMeDocument()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CFindMeDocument::CFindMeDocument( CEikApplication& aApp )
	: CAknDocument( aApp )
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CFindMeDocument::~CFindMeDocument()
// Destructor.
// ---------------------------------------------------------------------------
//
CFindMeDocument::~CFindMeDocument()
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CFindMeDocument::CreateAppUiL()
// Constructs CreateAppUi.
// ---------------------------------------------------------------------------
//
CEikAppUi* CFindMeDocument::CreateAppUiL()
	{
	// Create the application user interface, and return a pointer to it;
	// the framework takes ownership of this object
	return ( static_cast <CEikAppUi*> ( new ( ELeave )
										CFindMeAppUi ) );
	}

// End of File
