// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declares document class for application.
// 
// 


#ifndef __FINDMEDOCUMENT_h__
#define __FINDMEDOCUMENT_h__

// INCLUDES
#include <akndoc.h>

// FORWARD DECLARATIONS
class CFindMeAppUi;
class CEikApplication;


// CLASS DECLARATION

/**
* CFindMeDocument application class.
* An instance of class CFindMeDocument is the Document part of the
* AVKON application framework for the FindMe example application.
*/
class CFindMeDocument : public CAknDocument
	{
	public: // Constructors and destructor

		/**
		* NewL.
		* Two-phased constructor.
		* Construct a CFindMeDocument for the AVKON application aApp
		* using two phase construction, and return a pointer
		* to the created object.
		* @param aApp Application creating this document.
		* @return A pointer to the created instance of CFindMeDocument.
		*/
		static CFindMeDocument* NewL( CEikApplication& aApp );

		/**
		* NewLC.
		* Two-phased constructor.
		* Construct a CFindMeDocument for the AVKON application aApp
		* using two phase construction, and return a pointer
		* to the created object.
		* @param aApp Application creating this document.
		* @return A pointer to the created instance of CFindMeDocument.
		*/
		static CFindMeDocument* NewLC( CEikApplication& aApp );

		/**
		* ~CFindMeDocument
		* Virtual Destructor.
		*/
		virtual ~CFindMeDocument();

	public: // Functions from base classes

		/**
		* CreateAppUiL
		* From CEikDocument, CreateAppUiL.
		* Create a CFindMeAppUi object and return a pointer to it.
		* The object returned is owned by the Uikon framework.
		* @return Pointer to created instance of AppUi.
		*/
		CEikAppUi* CreateAppUiL();

	private: // Constructors

		/**
		* ConstructL
		* 2nd phase constructor.
		*/
		void ConstructL();

		/**
		* CFindMeDocument.
		* C++ default constructor.
		* @param aApp Application creating this document.
		*/
		CFindMeDocument( CEikApplication& aApp );

	};

#endif // __FINDMEDOCUMENT_h__

// End of File
