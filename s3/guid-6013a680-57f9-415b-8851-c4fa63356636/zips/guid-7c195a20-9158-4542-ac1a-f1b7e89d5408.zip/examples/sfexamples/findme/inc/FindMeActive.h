// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declaration of the asynchronous class to manipulate LBS.
// 
// 



#ifndef FINDMEACTIVE_H_
#define FINDMEACTIVE_H_

#include <e32base.h>
#include <Lbs.h> 	//Location based services API

class CFindMeAppView;


class CFindMeActive : public CActive
	{
	public:
		// First phase constructor
		static CFindMeActive* NewL(CFindMeAppView*);
		
		// C++ constructor
		CFindMeActive();
		
		// Second-phase constructor
		void ConstructL(CFindMeAppView*);
		
		// Destructor
		~CFindMeActive();
	
	private: // From CActive
		// Request completion handle
		void RunL();
		
		// Clean up a request
		void DoCancel();
		
	private:
		// Member variables	
		RPositionServer iPosServer;
		// A pointer to our application�s view class
		CFindMeAppView* iView;
		// Position information holder
		RPositioner iPositioner;
	public:
		// Will be used from the view class
		TPositionInfo iPositionInfo;  
	};

#endif /*FINDMEACTIVE_H_*/
