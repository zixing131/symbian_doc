/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __THREADSERVER_H__
#define __THREADSERVER_H__

#include <e32base.h>
#include <e32std.h>
#include "shutdownserver.h"
#include "threadclientserver.h"
#include "threadserverstart.h"
#include "driver1.h"

class CAsyncHandler; 

/**
	Server interface for thread server.
*/
class CThreadServer : public CServer2
	{
public:
	/**
	Enumeration of the driver states.
	*/
	enum TDriverState
		{
		EStateUnknown,
		EDriverLoaded,
		ELogicalChannelOpened,
		ESendingData,
		ELogicalChannelClosed,
		EDriverUnloaded
		};
	/**
	 Thread entry function.
	 */
	IMPORT_C static TInt StartThread(TAny* aPointer);
	/**
	 First and second phase constructor.
	 */
	static void NewLC();
	/**
	 Destructor.
	 The device driver will be unloaded when the server destructor is called.
	 */
	~CThreadServer();
	/**
	 Create a server-side session object.
	 @see CServer2::NewSessionL().
	 */
	CSession2* NewSessionL(const TVersion& aVersion,const RMessage2& aMessage) const;
	/**
	 Increase reference count and cancel shutdown timer.
	 This function is called when a new session is created.
	 */
	void IncrementRefCount();
	/**
	 Decrease reference count and start shutdown timer.
	 This function is called when a session is destroyed.
	 */
	void DecrementRefCount();
	/**
	 Load device, including sample PDD and LDD.
	 */
	TInt LoadDevice();
	/**
	 Unload device, including sample LDD and PDD.
	 */
	TInt UnloadDevice();
	/**
 	 Open device logical channel.
 	*/
	TInt OpenLogicalChannel();
	/**
 	 Close device logical channel.
 	*/
	void CloseLogicalChannel();
	/**
 	 Send data to device. It is an asynchronous request.
 	*/
	TInt SendDataToDevice(TRequestStatus& aStatus, const TDesC8& aData);
	/**
 	 Cancel send data operation to device driver.
 	*/
	void CancelSendData();
	/**
	 Update device state.
	 */
	void UpdateDriverState(TDriverState aState);
	
	
private:
	CThreadServer();
	void ConstructL();
	
	static void StartThreadL();
	static void RenameServer();
private:
	TInt 					iRefCount;
	CDelayServerShutDown* 	iDelayThreadServerShutDown;
	RDriver1 				iDriver;
	TDriverState			iDriverState;
	};
	


#endif
