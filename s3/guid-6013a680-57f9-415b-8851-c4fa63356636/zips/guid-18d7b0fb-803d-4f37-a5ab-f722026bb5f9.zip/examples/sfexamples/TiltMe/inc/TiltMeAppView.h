/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Declares view class for application.� 
*/  


#ifndef __TILTMEAPPVIEW_h__
#define __TILTMEAPPVIEW_h__

// INCLUDES
#include <coecntrl.h>
#include "RRSensorApi.h"

// CLASS DECLARATION
class CTiltMeAppView : public CCoeControl,  MRRSensorDataListener
	{
	public: // New methods

		/**
		* NewL.
		* Two-phased constructor.
		* Create a CTiltMeAppView object, which will draw itself to aRect.
		* @param aRect The rectangle this view will be drawn to.
		* @return a pointer to the created instance of CTiltMeAppView.
		*/
		static CTiltMeAppView* NewL( const TRect& aRect );

		/**
		* NewLC.
		* Two-phased constructor.
		* Create a CTiltMeAppView object, which will draw itself
		* to aRect.
		* @param aRect Rectangle this view will be drawn to.
		* @return A pointer to the created instance of CTiltMeAppView.
		*/
		static CTiltMeAppView* NewLC( const TRect& aRect );

		/**
		* ~CTiltMeAppView
		* Virtual Destructor.
		*/
		virtual ~CTiltMeAppView();

	public:  // Functions from base classes

		/**
		* From CCoeControl, Draw
		* Draw this CTiltMeAppView to the screen.
		* @param aRect the rectangle of this view that needs updating
		*/
		void Draw( const TRect& aRect ) const;

		/**
		* From CoeControl, SizeChanged.
		* Called by framework when the view size is changed.
		*/
		virtual void SizeChanged();

	private: // Constructors

		/**
		* ConstructL
		* 2nd phase constructor.
		* Perform the second phase construction of a
		* CTiltMeAppView object.
		* @param aRect The rectangle this view will be drawn to.
		*/
		void ConstructL(const TRect& aRect);

		/**
		* CTiltMeAppView.
		* C++ default constructor.
		*/
		CTiltMeAppView();

	private: //From MRRSensorDataListener
		/**
		* From MRRSensorDataListener, HandleDataEventL
		* Callback function for receiving sensor
		* data events
		*
		* @param aSensor identifies sensor that created the event.
		* @param aEvent contains data about created event.
		*/
	    void HandleDataEventL( TRRSensorInfo aSensor, TRRSensorEvent aEvent );
	
	public:
		// Starting the use of the sensor
		void StartSensor();
		// Stopping the use of the sensor
		void StopSensor();
		
	private:
	    // Accelerometer sensor
	    CRRSensorApi* iAccSensor;
	    // Time calculating vars
	    TTime iFirst;
	    TTime iSecond;
	    // Sensor status
	    TBool iSensorFound;
	    // The X,Y,Z orientation values
	    TInt iXAccl;
	    TInt iYAccl;
	    TInt iZAccl;     
	};

#endif // __TILTMEAPPVIEW_h__

// End of File
