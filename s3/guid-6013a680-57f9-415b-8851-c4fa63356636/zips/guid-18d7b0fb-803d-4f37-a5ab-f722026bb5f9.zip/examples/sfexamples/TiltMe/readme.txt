This project requires the use of the Sensor Plug-in for S60 3rd Edition SDK for Symbian OS, for C++, which is available from Forum Nokia at http://www.forum.nokia.com/info/sw.nokia.com/id/4284ae69-d37a-4319-bdf0-d4acdab39700/Sensor_plugin_S60_3rd_ed.exe.html

The SDK plug-in is intended for use of the internal 3D accelerometer sensor on the Nokia 5500 Sport terminal. This plug-in only supports compiling for terminals (i.e. no emulator support is included, so the code will compile but will not link for WINSCW builds) including documentation and example application. 
