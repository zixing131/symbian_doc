// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SQLSRVDEMO_APPLICATION_H__
#define __SQLSRVDEMO_APPLICATION_H__


// INCLUDES
#include <aknapp.h>


// CONSTANTS
// Uid for the application, should match the one in the mmp file
const TUid KUidSqlSrvDemoApp = { 0x20011192 };


// CLASS DECLARATION

/**
* An instance of CSqlSrvDemoApplication is the application part of the AVKON
* application framework for the SqlSrvDemo example application
*/
class CSqlSrvDemoApplication : public CAknApplication
    {

    public:  // from CAknApplication

        /**
        * AppDllUid
        * @return returns application's UID (KUidAknExMenu).
        */
        TUid AppDllUid() const;


    protected: // from CAknApplication


        /**
        * CreateDocumentL
        * Creates CSqlSrvDemoDocument document object.
        * The returned pointer in not owned by the CSqlSrvDemoApplication object.
        * @return A pointer to the created document object.
        */
        CApaDocument* CreateDocumentL();
    };

#endif // __SQLSRVDEMO_APPLICATION_H__

// End of File
