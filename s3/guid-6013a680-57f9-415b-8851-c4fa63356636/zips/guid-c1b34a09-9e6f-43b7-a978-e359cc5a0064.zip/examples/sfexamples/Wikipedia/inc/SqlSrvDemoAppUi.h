// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SQLSRVDEMO_APPUI_H__
#define __SQLSRVDEMO_APPUI_H__


// INCLUDES
#include <aknViewAppUi.h>

// FORWARD DECLARATIONS
class CSearchView;
class CDetailView;
class CAboutView;
class CWikiDb;


// CLASS DECLARATION

/**
* CSqlSrvDemoAppUi application UI class.
* An instance of class CSqlSrvDemoAppUi is the UserInterface part of the AVKON
* application framework for the SqlSrvDemo example application
*/
class CSqlSrvDemoAppUi : public CAknViewAppUi
    {

    public: // Constructors and destructor

        /**
        * ConstructL.
        * 2nd phase constructor.
        */
        void ConstructL();

        /**
         * ~CSqlSrvDemoAppUi
         * Destructor.
         */        
        ~CSqlSrvDemoAppUi();
        
    public: // New functions from CEikAppUi

        /**
        * HandleCommandL
        * Takes care of command handling.
        * @param aCommand Command to be handled.
        */
        void HandleCommandL( TInt aCommand );
        
        /**
        * HandleResourceChangeL()
        * Called by framework when layout is changed.
        * @param aType The type of resources that have changed.
        */
        virtual void HandleResourceChangeL( TInt aType );  
        
        /**
         * WikiEngine()
         * The application's engine to the wikipedia DB
         * @return the wiki engine
         */        
        static CWikiDb& WikiEngine();
    
    private: // Data

        /**
        * iSearchView, The application's search view
        * Not owned by CSqlSrvDemoAppUi object.
        */
        CSearchView* iSearchView;

        /**
        * iDetailView, The application's detail view
        * Not owned by CSqlSrvDemoAppUi object.
        */
        CDetailView* iDetailView;

        /**
        * iAboutView, The application's about view
        * Not owned by CSqlSrvDemoAppUi object.
        */
        CAboutView* iAboutView;
        
        /**
         * iWikiEngine, The application's engine to the wikipedia DB
         */        
        CWikiDb* iWikiEngine;
    };


#endif // __SQLSRVDEMO_APPUI_H__

// End of File