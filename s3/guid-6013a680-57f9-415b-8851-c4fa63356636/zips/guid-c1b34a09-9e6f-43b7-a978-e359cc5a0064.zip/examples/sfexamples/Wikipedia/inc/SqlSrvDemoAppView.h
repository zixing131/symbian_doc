// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SQLSRVDEMO_APPVIEW_H__
#define __SQLSRVDEMO_APPVIEW_H__


// INCLUDES
#include <coecntrl.h>



// CLASS DECLARATION

/**
* CSqlSrvDemoAppView container control class.
* An instance of the Application View object for the
* example application SqlSrvDemo
*/
class CSqlSrvDemoAppView : public CCoeControl
    {
public:     // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Create a CSqlSrvDemoAppView object, which will draw itself to aRect-
        * @param aRect the rectangle this view will be drawn to.
        * @result a pointer to the created instance of CSqlSrvDemoAppView
        */
        static CSqlSrvDemoAppView* NewL( const TRect& aRect );

        /**
        * NewLC.
        * Two-phased constructor.
        * Create a CSqlSrvDemoAppView object, which will draw itself to aRect-
        * @param aRect the rectangle this view will be drawn to.
        * @result a pointer to the created instance of CSqlSrvDemoAppView
        */
        static CSqlSrvDemoAppView* NewLC( const TRect& aRect );

        /**
        * ~CSqlSrvDemoAppView
        * Virtual Destructor.
        */
        virtual ~CSqlSrvDemoAppView();

public:  // from CCoeControl

        /**
        * Draw
        * Draw this CSqlSrvDemoAppView to the screen.
        * @param aRect the rectangle of this view that needs updating
        */
        void Draw( const TRect& aRect ) const;

private: // Constructors and destructor

        /**
        * ConstructL
        * 2nd phase constructor.
        * @param aRect the rectangle this view will be drawn to.
        */
        void ConstructL( const TRect& aRect );

        /**
        * CSqlSrvDemoAppView.
        * C++ default constructor.
        */
        CSqlSrvDemoAppView();
    };

#endif // __SQLSRVDEMO_APPVIEW_H__
