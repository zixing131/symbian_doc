// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



#ifndef __SEARCH_VIEW_H__
#define __SEARCH_VIEW_H__

// INCLUDES
#include <aknview.h>


// FORWARD DECLARATIONS
class CSearchContainer;
class CRecCountContainer;

// CONSTANTS
const TInt KRecCountHeight = 35;

// CLASS DECLARATION

/**
* CSearchView view class.
* An instance of the Application View object for the SqlSrvDemo
* example application
*/
class CSearchView: public CAknView
    {
    public:   // Constructors and destructor

        /**
        * NewL.
        * Two-phased constructor.
        * Construct a CSearchView for the AVKON application aApp.
        * Using two phase construction,and return a pointer to the created object
        * @return a pointer to the created instance of CSearchView
        */
        static CSearchView* NewL();

        /**
        * NewLC.
        * Two-phased constructor.
        * Construct a CSearchView for the AVKON application aApp.
        * Using two phase construction,and return a pointer to the created object
        * @return a pointer to the created instance of CSearchView
        */
        static CSearchView* NewLC();

        /**
        * ~CSearchView.
        * Virtual Destructor.
        */
        virtual ~CSearchView();

    public: // Functions from base classes from CAknView

        /**
        * Id
        * @return Id Uid value
        */
        TUid Id() const;

        /**
        * HandleCommandL
        * From CAknView, takes care of command handling.
        * @param aCommand Command to be handled
        */
        void HandleCommandL( TInt aCommand );
        
        /**
        * HandleSizeChange
        * Called by HandleResourceChangeL() from CSqlSrvDemoAppUi when layout 
        * is changed.
        * @param aType Type of resources that have changed
        */
        void HandleSizeChange( TInt aType );

        /**
        * DoActivateL
        * From CAknExView, activate an AknView.
        * @param aPrevViewId The id of the previous view
        * @param aCustomMessageId message identifier
        * @param aCustomMessage custom message provided when the view is changed
        */
        void DoActivateL( const TVwsViewId& aPrevViewId,
                          TUid aCustomMessageId,
                          const TDesC8& aCustomMessage );

        /**
        * DoDeactivate
        * From AknView, deactivate an AknView
        * Remove the container class instance from the App UI's stack and
        * deletes the instance
        */
        void DoDeactivate();              

    private: // From MEikMenuObserver
    
	    /**
	    * DynInitMenuPaneL
	    * Dynamically initialises a menu pane
	    * @param aResourceId Resource to be handled.
	    */    
    	void DynInitMenuPaneL( TInt aResourceId, CEikMenuPane *aMenuPane );   
    
        
    public: // New functions
    
    	void OpenDetailViewL();
    	
    	void OpenAboutViewL();
    	
    	TRect SearchRect();
    	
    	TRect RecCountRect();
        
    private:   // Constructors and destructor

        /**
        * CSearchView.
        * C++ default constructor.
        */
        CSearchView();

        /**
        * ConstructL.
        * 2nd phase constructor.
        */
        void ConstructL();
    	
    private: // Data

        /**
        * iContainer,container for this view
        * owned by CSearchView object.
        */
        CSearchContainer* iContainer;

        CRecCountContainer* iRecCountContainer;
        
        /** View Identifier **/
        TUid iIdentifier;
    };


#endif // __SEARCH_VIEW_H__


// End of File