// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


// INCLUDE FILES
#include "BrowserContainer.h"
#include "BrowserView.h"
#include "SqlSrvDemoAppUi.h"
#include "BrCtlInterface.h"
#include <charconv.h>

// ========================= MEMBER FUNCTIONS ==================================

// ----------------------------------------------------------------------------
// CBrowserContainer::CBrowserContainer( CBrowserView& aView )
//
// Constructors for abstract class
// ----------------------------------------------------------------------------

CBrowserContainer::CBrowserContainer( CBrowserView& aView ):
	iView( aView )
	{	
	// No implementation
	}

// -----------------------------------------------------------------------------
// CAboutContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//

void CBrowserContainer::ConstructL(const TRect& aRect)
    {
    CreateWindowL();
    SetRect( aRect );
    ActivateL();   
    
    iBrowser = CreateBrowserControlL( this, 
   		TRect( TPoint( 0, 0 ), aRect.Size() ), 
        TBrCtlDefs::ECapabilityDisplayScrollBar | TBrCtlDefs::ECapabilityLoadHttpFw |
        TBrCtlDefs::ECapabilityGraphicalHistory | TBrCtlDefs::ECapabilityGraphicalPage,
        TBrCtlDefs::ECommandIdBase,
        NULL,
        NULL,
        NULL,
        NULL);     
    }

CBrowserContainer::~CBrowserContainer()
	{
	delete iBrowser;
	}

// -----------------------------------------------------------------------------
// CBrowserContainer::CountComponentControls() const
// returns number of controls inside this container.
// -----------------------------------------------------------------------------
//

TInt CBrowserContainer::CountComponentControls() const
    {
    TInt count = 0;
    if ( iBrowser )
        {
        count++;
        }
    return count;
    }

// -----------------------------------------------------------------------------
// CBrowserContainer::ComponentControl() const
// returns pointer of controls inside this container
// -----------------------------------------------------------------------------
//

CCoeControl* CBrowserContainer::ComponentControl( TInt aIndex ) const
    {
    switch ( aIndex )
	    {
	    case 0:
	        return iBrowser;
	    default:
	        return NULL;
	    }
    }

// -----------------------------------------------------------------------------
// CBrowserContainer::SizeChanged
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------

void CBrowserContainer::SizeChanged()
    {
    if ( iBrowser )
        {
        iBrowser->SetRect( Rect() );
        }
    }

// -----------------------------------------------------------------------------
// CBrowserContainer::HandleResourceChange
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//

void CBrowserContainer::HandleResourceChange( TInt aType )
    {
    CCoeControl::HandleResourceChange( aType );
    if ( aType == KEikDynamicLayoutVariantSwitch )
        {
        SetRect((iView).ClientRect() );
        }
     }

void CBrowserContainer::ScrollBrowserToTopL()
	{
    // In some cases the browser displays the record starting in the middle
    // This passes a scroll up event in the browser so that display is at the top
    TKeyEvent keyEvent;
    keyEvent.iCode = EKeyUpArrow;
    keyEvent.iScanCode = 17;
    keyEvent.iModifiers = 32769;
    keyEvent.iRepeats = 0;
    TEventCode type;
    type = EEventKey;
    iBrowser->OfferKeyEventL( keyEvent, type );	
	}
	
// End of File
