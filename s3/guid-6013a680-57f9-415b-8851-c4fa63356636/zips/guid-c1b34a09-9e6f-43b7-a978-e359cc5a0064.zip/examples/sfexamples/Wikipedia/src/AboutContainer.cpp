// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 


// INCLUDE FILES
#include "AboutContainer.h"
#include "AboutView.h"
#include <charconv.h>

#ifdef __WINS__
_LIT(KAboutTextFile, "C:\\Wikipedia\\wikipedia_about.htm");
#else
_LIT(KAboutTextFile, "e:\\Wikipedia\\wikipedia_about.htm");
#endif
// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CAboutContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CAboutContainer* CAboutContainer::NewL( const TRect& aRect, CAboutView& aView )
    {
    CAboutContainer* self = CAboutContainer::NewLC( aRect, aView );
    CleanupStack::Pop( self );
    return self;
    }


// -----------------------------------------------------------------------------
// CAboutContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CAboutContainer* CAboutContainer::NewLC( const TRect& aRect, CAboutView& aView )
    {
    CAboutContainer* self = new ( ELeave ) CAboutContainer( aView );
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
    }

// -----------------------------------------------------------------------------
// CAboutContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CAboutContainer::ConstructL( const TRect& aRect )
    {    
    CBrowserContainer::ConstructL(aRect);
	
    // This S60 code causes a memory leak
    iBrowser->LoadFileL( KAboutTextFile );    	
	
    ScrollBrowserToTopL();	
    }

CAboutContainer::CAboutContainer( CAboutView& aView ):
	CBrowserContainer(aView)
	{	
	// No implementation
	}

// -----------------------------------------------------------------------------
// CAboutContainer::OfferKeyEventL
// 
// (other items were commented in a header).
// -----------------------------------------------------------------------------
//
TKeyResponse CAboutContainer::OfferKeyEventL(
    const TKeyEvent& aKeyEvent, TEventCode aType )
    {
    return iBrowser->OfferKeyEventL( aKeyEvent, aType );
    }

// End of File
