// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include <aknviewappui.h>
#include <aknconsts.h>
#include <aknutils.h> 
#include <SqlSrvDemo.rsg>

#include "SearchView.h"
#include "SearchContainer.h"
#include "RecCountContainer.h"
#include "SqlSrvDemo.hrh"


// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CSearchView::CSearchView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CSearchView::CSearchView()
    {
    // No implementation required
    }


// -----------------------------------------------------------------------------
// CSearchView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSearchView* CSearchView::NewL()
    {
    CSearchView* self = CSearchView::NewLC();
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CSearchView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CSearchView* CSearchView::NewLC()
    {
    CSearchView* self = new ( ELeave ) CSearchView();
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
    }

// -----------------------------------------------------------------------------
// CSearchView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CSearchView::ConstructL()
    {
    BaseConstructL( R_SEARCH_VIEW );
    }

// -----------------------------------------------------------------------------
// CSearchView::~CSearchView()
// Destructor.
// -----------------------------------------------------------------------------
//
CSearchView::~CSearchView()
    {
    delete iContainer;
    iContainer = NULL;
    delete iRecCountContainer;
    iRecCountContainer = NULL;
    }

// -----------------------------------------------------------------------------
// CSearchView::Id()
// Returns View's ID.
// -----------------------------------------------------------------------------
//
TUid CSearchView::Id() const
    {
    return TUid::Uid( ESearchViewId );
    }

// -----------------------------------------------------------------------------
// CSearchView::DoActivateL()
// Activate a CSearchView
// -----------------------------------------------------------------------------
//
void CSearchView::DoActivateL( const TVwsViewId& /*aPrevViewId*/,
                                    TUid /*aCustomMessageId*/,
                                    const TDesC8& /*aCustomMessage*/)
    {
    if ( !iRecCountContainer )
    	{
    	iRecCountContainer = CRecCountContainer::NewL( RecCountRect(), *this );    
    	}
    AppUi()->AddToStackL( iRecCountContainer ); 
    
    if ( !iContainer )
    	{ 	
    	iContainer = CSearchContainer::NewL( SearchRect(), *this, *iRecCountContainer );    
    	}
    AppUi()->AddToStackL( iContainer );
    iContainer->RefreshL();   
    }

// -----------------------------------------------------------------------------
// CSearchView::DoDeactivate()
// DeActivate a CSearchView
// -----------------------------------------------------------------------------
//
void CSearchView::DoDeactivate()
    {
    if ( iRecCountContainer )
        {
        // Remove search view's container form controllStack
        AppUi()->RemoveFromStack( iRecCountContainer );
        } 
    if ( iContainer )
        {
        // Remove search view's container form controllStack
        AppUi()->RemoveFromStack( iContainer );
        }
    }

// -----------------------------------------------------------------------------
// CSearchView::DynInitMenuPaneL()
// Dynamically initialises a menu pane
// -----------------------------------------------------------------------------
//
void CSearchView::DynInitMenuPaneL( TInt aResourceId, CEikMenuPane *aMenuPane )
	{
    if ( aResourceId == R_SQLSRVDEMO_SEARCH_MENU  )
        {
       	aMenuPane->SetItemDimmed( ESqlSrvDemoCmdOpenArticle, iContainer->ZeroItemsInList() );
        }	
	}

// -----------------------------------------------------------------------------
// CSearchView::HandleCommandL()
// Takes care of Command handling.
// -----------------------------------------------------------------------------
//
void CSearchView::HandleCommandL( TInt aCommand )
    {
    switch ( aCommand )
	    {    	
	    case ESqlSrvDemoCmdOpenArticle:
	    	iContainer->HandleSelectCommandL();
	    	break;
	    	
	    case ESqlSrvDemoCmdAbout:
	    	iContainer->RefreshL(ETrue);
	    	OpenAboutViewL();
	    	break;
    	
	    default:
	    	AppUi()->HandleCommandL( aCommand );	
	    	break;
	    }
    }

// -----------------------------------------------------------------------------
// CSearchView::HandleSizeChange()
// Called by HandleResourceChangeL() from CSqlSrvDemoAppUi when layout is 
// changed.
// -----------------------------------------------------------------------------
//
void CSearchView::HandleSizeChange( TInt aType )
    {
    if( iContainer )
        {
        iContainer->HandleResourceChange( aType );
        
        if ( aType==KEikDynamicLayoutVariantSwitch )
            {        
            TRect rect;
            AknLayoutUtils::LayoutMetricsRect( AknLayoutUtils::EMainPane, rect );
            iContainer->SetRect( SearchRect() /* rect */);
            }
        }     
    
    if( iRecCountContainer )
        {
        iRecCountContainer->HandleResourceChange( aType );
        
        if ( aType==KEikDynamicLayoutVariantSwitch )
            {        
            TRect rect;
            AknLayoutUtils::LayoutMetricsRect( AknLayoutUtils::EMainPane, rect );
            iRecCountContainer->SetRect( RecCountRect() /* rect */);
            }
        }     
    }
    
void CSearchView::OpenDetailViewL()
	{
    AppUi()->ActivateLocalViewL( TUid::Uid( EDetailViewId ) );
	}

void CSearchView::OpenAboutViewL()
	{
    AppUi()->ActivateLocalViewL( TUid::Uid( EAboutViewId ) );	
	}

TRect CSearchView::SearchRect()
	{
	return TRect( ClientRect().iTl.iX, ClientRect().iTl.iY, ClientRect().iBr.iX, ClientRect().iBr.iY - KRecCountHeight );

	}

TRect CSearchView::RecCountRect()
	{
	return ClientRect();
	}

// End of File
