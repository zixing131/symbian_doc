// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include <eikstart.h>
 
#include "SqlSrvDemoApplication.h"


// ========================== OTHER EXPORTED FUNCTIONS =========================

// -----------------------------------------------------------------------------
// NewApplication()
// Constructs CAknExMenuApp.
// Create an application, and return a pointer to it
// -----------------------------------------------------------------------------
EXPORT_C CApaApplication* NewApplication()
    {
    return ( static_cast<CApaApplication*> ( new CSqlSrvDemoApplication ) );
    }

// -----------------------------------------------------------------------------
// E32Main()
// Entry point function for Symbian Apps.
// -----------------------------------------------------------------------------
//  
GLDEF_C TInt E32Main()
    {
    return EikStart::RunApplication( NewApplication );
    }
    
// End of File
