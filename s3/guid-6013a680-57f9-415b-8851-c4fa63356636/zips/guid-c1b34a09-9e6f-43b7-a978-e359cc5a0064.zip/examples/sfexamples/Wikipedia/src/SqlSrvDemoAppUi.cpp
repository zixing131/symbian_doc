// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 



// INCLUDE FILES
#include <e32std.h>

#include "SqlSrvDemo.pan"
#include "SqlSrvDemoAppUi.h"
#include "AboutView.h"
#include "SearchView.h"
#include "DetailView.h"
#include "WikiDb.h"

// ========================= MEMBER FUNCTIONS ==================================

// -----------------------------------------------------------------------------
// CSqlSrvDemoAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CSqlSrvDemoAppUi::ConstructL()
    {    
    iWikiEngine = CWikiDb::NewL();    
    
    // Initialise app UI
    BaseConstructL(EAknEnableSkin);

    iSearchView = CSearchView::NewL();
    iDetailView = CDetailView::NewL();
    iAboutView = CAboutView::NewL();

    // Transfer ownership to base class
    AddViewL( iSearchView );
    AddViewL( iDetailView );
    AddViewL( iAboutView );

    SetDefaultViewL( *iSearchView );
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoAppUi::~CSqlSrvDemoAppUi()
// Destructor
// -----------------------------------------------------------------------------
//
CSqlSrvDemoAppUi::~CSqlSrvDemoAppUi()
    {
    delete iWikiEngine;
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CSqlSrvDemoAppUi::HandleCommandL( TInt aCommand )
    {
    switch ( aCommand )
        {
        case EEikCmdExit:
        case EAknSoftkeyExit:
            Exit();
            break;
            
        case EAknSoftkeyEmpty:
        	// Do Nothing
        	break;
        
        default:
            Panic( ESqlSrvDemoBasicUi );
            break;
        }
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoAppUi::HandleResourceChangeL()
// Called by framework when layout is changed.
// -----------------------------------------------------------------------------
//
void CSqlSrvDemoAppUi::HandleResourceChangeL( TInt aType )
    {
    CAknAppUi::HandleResourceChangeL( aType );
       
    if ( aType==KEikDynamicLayoutVariantSwitch )
        {
        iSearchView->HandleSizeChange(aType);
        iDetailView->HandleSizeChange(aType);
        iAboutView->HandleSizeChange(aType);
        }           
    }

// -----------------------------------------------------------------------------
// CSqlSrvDemoAppUi::WikiEngine()
// The application's engine to the wikipedia DB
// -----------------------------------------------------------------------------
//
CWikiDb& CSqlSrvDemoAppUi::WikiEngine()
	{
	CSqlSrvDemoAppUi* appUi = static_cast< CSqlSrvDemoAppUi* >( CCoeEnv::Static()->AppUi() );
	return *appUi->iWikiEngine;
	}
    
// End of File
