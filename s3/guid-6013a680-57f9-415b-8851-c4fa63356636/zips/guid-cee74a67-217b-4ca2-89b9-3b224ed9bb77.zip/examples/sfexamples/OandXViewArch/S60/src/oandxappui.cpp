/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include <avkon.hrh>
#include <aknnotewrappers.h>

#include "OandXAppUi.h"
#include "oandxcontroller.h"
#include "oandxengine.h"
#include "OandXApplication.h"
#include "OandXAppView.h"
#include "OandXHistView.h"
#include "oandxdefs.h"
#include "OandX.hrh"
#include <OandX.rsg>

#define MaxInfoNoteTextLen 40

COandXAppUi::COandXAppUi()
/**
	This empty constructor is defined to ensure that exactly
	one instance is generated.
 */
	{
	// empty.
	}

void COandXAppUi::ConstructL()
/**
	Sets default skin paramters, creates engine and app view.
	
	@see ~COandXAppUi
 */
	{
	// for v1.x SDKs, use no-arg BaseConstructL() overload
	BaseConstructL(EAknEnableSkin);
	iEngine = COandXEngine::NewL();
	iController = COandXController::NewL();
	
	iHistView = COandXHistoryView::NewLC();
	AddViewL(iHistView);
	CleanupStack::Pop(); // history view

	iAppView = COandXGameView::NewLC();
	AddViewL(iAppView);
	CleanupStack::Pop(); // game view
	
    SetDefaultViewL(*iAppView);
   
	ReportWhoseTurn();
	}


COandXAppUi::~COandXAppUi()
/**
	This destructor undoes the secondary initialization in ConstructL.
	
	@see ConstructL
 */
	{
	delete iController;
	delete iEngine;
	}

void COandXAppUi::HandleCommandL(TInt aCommand)
/**
	This function handles commands from menus, softkeys,
	and from the system, e.g. EEikCmdExit.
	
	@param	aCommand		Command identifier.
 */
	{
	_LIT8(KDummy, "");
	switch(aCommand)
		{
	case EEikCmdExit:
	case EAknSoftkeyExit:
		{
		SaveL();
		Exit();
		}
		break;
	case EOandXNewGame:
		{
		iController->Reset();
		iAppView->Container()->ResetView();
		}
		break;
	case EOandXFirstPlayer:
		{
		iController->SwitchTurn();
		}
		break;
	case EOandXDisplayStats:
		{
		if (iHistView->IsActivated())
			{
			iHistView->ChangeDisplayL(EOandXSetStats);
			}
		else
			{
			ActivateViewL(TVwsViewId( KUidOandXApp, KUidOandXHistoryView), TUid::Uid(EHistoryViewDisplayStats), KDummy );
			}
		break;
		}
	case EOandXDisplayHistory:
		{
		if (iHistView->IsActivated())
			{
			iHistView->ChangeDisplayL(EOandXSetHistory);
			}
		else
			{
			ActivateViewL(TVwsViewId(KUidOandXApp, KUidOandXHistoryView), TUid::Uid(EHistoryViewDisplayHistory), KDummy );
			}
		break;
		}
	case EOandXDisplayGame:
		{
		ActivateViewL(TVwsViewId( KUidOandXApp, KUidOandXView)) ;
		break;
		}
	case EOandXResetHistory:
		{
		Controller().ResetStats();
		iHistView->ChangeDisplayL(iHistView->IsDisplayingHistory());
		break;
		}
	default:
		break;
		}
	}

void COandXAppUi::ReportWhoseTurn()
/**
	Tell the user whose turn it is by displaying a nought or cross symbol.
 */
	{
	iAppView->Container()->ShowTurn();
	}

void COandXAppUi::ReportWinnerL(TInt aWinner)
/**
	Tell the user who won the game by displaying the information
	in a platform-specific dialog.
 */
	{
	TBuf<MaxInfoNoteTextLen> text;
	iEikonEnv->ReadResource(text, aWinner==ETileCross ? R_OANDX_X_WINS : R_OANDX_O_WINS);
	CAknInformationNote* infoNote = new (ELeave) CAknInformationNote;
	infoNote->ExecuteLD(text);
	}

TStreamId COandXAppUi::StoreL(CStreamStore& aStore) const
/**
	Store the current game state in the supplied stream store.
	
	@param	aStore			Stream store which will contain new
							stream which encodes the game state.
	@return					The new stream's ID.
	@see RestoreL
 */
	{
	RStoreWriteStream stream;
	TStreamId id = stream.CreateLC(aStore);
	stream << *this; // alternatively, use ExternalizeL(stream)
	stream.CommitL();
	CleanupStack::PopAndDestroy();
	return id;
	}

void COandXAppUi::RestoreL(const CStreamStore& aStore, TStreamId aStreamId)
/**
	Restore the current game state from the supplied stream.
	
	@param	aStore			Stream store which contains a stream
							which contains the externalized game state.
	@param	aStreamId		ID of stream in the store which contains
							the externalize game state.
	@see StoreL
 */
	{
	RStoreReadStream stream;
	stream.OpenLC(aStore,aStreamId);
	stream >> *this; // alternatively use InternalizeL(stream)
	CleanupStack::PopAndDestroy();
	}

void COandXAppUi::ExternalizeL(RWriteStream& aStream) const
/**
	Write the app ui's state, which includes all of the game state,
	to a writable stream.
	
	@param	aStream			Stream to which game state should be written.
 */
	{
	iEngine->ExternalizeL(aStream);
	iController->ExternalizeL(aStream);
	aStream.WriteInt8L(iAppView->Container()->IdOfFocusControl());
	}

void COandXAppUi::InternalizeL(RReadStream& aStream)
/**
	Restore the game state from the supplied readable stream.
	
	@param	aStream			Stream which contains externalized
							game state.
 */
	{
	iEngine->InternalizeL(aStream);
	iController->InternalizeL(aStream);
	ReportWhoseTurn();
	iAppView->Container()->MoveFocusTo(aStream.ReadInt8L());
	}


// Global accessor functions

GLDEF_C COandXAppUi* OandXAppUi()
/**
Accessor function provides access to singleton instance of app ui object.
@return  The application UI, cast to COandXAppUi.
 */
	{
	return static_cast<COandXAppUi*>(CEikonEnv::Static()->AppUi());
	}

GLDEF_C COandXController& Controller()
/**
Return mutable reference to singleton instance of COandXController object.
@return	Singleton COandXController object.
 */
	{
	return *OandXAppUi()->iController;
	}

GLDEF_C COandXEngine& Engine()
/**
Return mutable reference to singleton instance of COandXEngine object.
@return	Singleton COandXEngine object.
 */
	{
	return *OandXAppUi()->iEngine;
	}
