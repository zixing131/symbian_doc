/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include <eikenv.h>
#include <eiklabel.h>
#include <s32mem.h>

#include "oandxcontroller.h"
#include "oandxengine.h"
#include "oandxappui.h"
#include "oandxdefs.h"

COandXController* COandXController::NewL()
/**
	Factory function allocates new instance of COandXController.
	
	@return					New, initialized instance of COandXController.
							This object is owned by the caller.
 */
	{
	COandXController* self=new(ELeave) COandXController;
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
	}

void COandXController::ConstructL()
/**
	Run secondary initialization, clearing the board.
 */
	{
	Engine().Reset();
	iState = ENewGame;
	iCrossTurn = EFalse;
	iLastGameResult = ETileDraw;
	}

COandXController::~COandXController()
/**
	Destructor is defined here to ensure only one
	instance is generated.
 */
	{
	// empty.
	}

// persistence

void COandXController::ExternalizeL(RWriteStream& aStream) const
/**
	Persist the controller's state to the supplied stream.
	Specifically, writes out the state, whose turn it is,
	and which symbol the local player is using.
	
	@param	aStream			Stream to which the controller's state will be
							written.
	@see InternalizeL
 */
	{
	aStream.WriteUint8L(iState);
	aStream.WriteInt8L(iCrossTurn);
	aStream.WriteInt8L(iLastGameResult);
	aStream.WriteUint8L(iNumGames);
	aStream.WriteUint8L(iNumNoughtWins);
	aStream.WriteUint8L(iNumCrossWins);
	for (TInt i=0; i<KNumHistoryRecords; i++)
		{
		aStream.WriteUint8L(iGameRecords[i]);
		}
	}

void COandXController::InternalizeL(RReadStream& aStream)
/**
	Standard stream store internalization function, restores
	state, whose turn, and which symbol the local player is using.
	
	@param	aStream			Stream which contains externalized state.
	@see ExternalizeL
 */
	{
	iState = static_cast<TState>(aStream.ReadUint8L());
	iCrossTurn = static_cast<TBool>(aStream.ReadInt8L());
	iLastGameResult = static_cast<TTileState>(aStream.ReadUint8L());
	iNumGames = aStream.ReadUint8L();
	iNumNoughtWins = aStream.ReadUint8L();
	iNumCrossWins = aStream.ReadUint8L();
	for (TInt i=0; i<KNumHistoryRecords; i++)
		{
		iGameRecords[i] = static_cast<TTileState>(aStream.ReadUint8L());
		}
	}

void COandXController::Reset()
/**
	Cancel the current game, clearing the board and setting
	noughts as the current player.
 */
	{
	Engine().Reset();
	iState = ENewGame;
	if (IsCrossTurn())
		{
		SwitchTurn();
		}
	switch (iLastGameResult)
		{
	case ETileNought:
		iNumNoughtWins += 1;
		break;
	case ETileCross:
		iNumCrossWins += 1;
		break;
	default:
		break;
		}
	for (TInt i=KNumHistoryRecords-1; i>0; i--)
		{
		iGameRecords[i] = iGameRecords[i-1];
		}
	iGameRecords[0]=iLastGameResult;
	iLastGameResult = ETileDraw;
	iNumGames += 1;
	}

void COandXController::ResetStats()
	{
	iNumGames=0;
	iNumNoughtWins=0;
	iNumCrossWins=0;
	for (TInt i=0; i<KNumHistoryRecords;i++)
		{
		iGameRecords[i]=ETileBlank;
		}
	}

TBool COandXController::HitSquareL(TInt aIndex)
	{
	// For Comms, replace this with another function, called
	// when a tile is selected. It should refuse to accept
	// the hit if it is not my move.
	// Add another function, called when the opponent makes a
	// move, and both can call this funtion (renamed from
	// HitSquareL) The logic will need to be modified to handle 
	// the additional comms states and to report which of the
	// two players wins the game (or when the game is drawn).
	if (iState == EFinished)
		{
		return EFalse;
		}
	if (iState == ENewGame)
		{
		iState = EPlaying;
		}
	if (Engine().TryMakeMove(aIndex,IsCrossTurn()))
		{
		SwitchTurn();
		TTileState winner = Engine().GameWonBy();
		if (winner)
			{
			iLastGameResult = winner;
			iState = EFinished;
			OandXAppUi()->ReportWinnerL(winner);
			}
		return ETrue;
		}
	return EFalse;
	}

void COandXController::SwitchTurn()
	{
	iCrossTurn = !iCrossTurn;
	OandXAppUi()->ReportWhoseTurn();
	}

TTileState COandXController::GameRecord(TInt aIndex)
	{
	return iGameRecords[aIndex];
	}
