/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 


#include <eiklabel.h> // CEikLabel
#include <barsread.h>  // for TResourceReader

#include "OandXDefs.h"
#include "OandXAppUi.h"
#include "OandXApplication.h"
#include "OandXController.h"
#include "OandXHistView.h"
#include "OandX.hrh"
#include "OandX.pan"
#include <OandX.rsg>

// View

COandXHistoryView* COandXHistoryView::NewLC()
	{
	COandXHistoryView* self=new(ELeave) COandXHistoryView();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

COandXHistoryView::COandXHistoryView()
	{
	}

/**
Destructor for the view
*/
COandXHistoryView::~COandXHistoryView()
	{
    if (iHistViewStacked)
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
	delete iContainer;
	}

void COandXHistoryView::ConstructL()
	{
    BaseConstructL( R_OANDX_HISTORY_VIEW );
	iContainer = COandXHistViewContainer::NewL(ClientRect())    ;
	}
	

/**
Returns the view Id
*/
TUid COandXHistoryView::Id() const
	{
    return KUidOandXHistoryView;
	}

/*
Sets the appropriate commands in the menu.
*/
void COandXHistoryView::DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane)
	{
	if (aResourceId == R_OANDX_HISTORY_MENU)
		{
		if (IsDisplayingHistory())
			{
			aMenuPane->DeleteMenuItem(EOandXDisplayHistory);
			}
		else
			{
			aMenuPane->DeleteMenuItem(EOandXDisplayStats);
			}
		}
	}

COandXHistViewContainer* COandXHistoryView::Container()
    {
    return iContainer;
    }

/*
Handles all commands in the view
Called by the UI framework when a command has been issued.
The command Ids are defined in the .rss file.
*/
void COandXHistoryView::HandleCommandL(TInt aCommand)
	{
    switch ( aCommand )
        {

        case EAknSoftkeyBack:
            {
            AppUi()->HandleCommandL( EEikCmdExit );
            break;
            }

        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
	}

void COandXHistoryView::HandleViewRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect(ClientRect());
        }
    }

/* 
This function is called by the View Server when the view is activated.
The first time that it is called it constructs the History and Stats controls.
It processes the message to determine which control to show
*/
void COandXHistoryView::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                                    TUid aCustomMessageId,
                                    const TDesC8& /*aCustomMessage*/)
	{
	__ASSERT_ALWAYS(!iHistViewStacked, Panic(EOandXControlAlreadyStacked));
    AppUi()->AddToStackL( *this, iContainer );
    iHistViewStacked = ETrue;
    
	switch ( aCustomMessageId.iUid )
		{		
	// switch using  the message ID
	case EHistoryViewDisplayHistory:
		ChangeDisplayL( ETrue );
		break;
	case EHistoryViewDisplayStats:
		ChangeDisplayL( EFalse );
		break;
	default:
		// display as last time.
		ChangeDisplayL( iDisplayingHistory );
		break ;
		}
	iActivated = ETrue;
	}
	
/*
Called by the View Server when this view is deactivated.
Hides the view (and all of its components ).
There is no data to save
*/
void COandXHistoryView::DoDeactivate()
	{
	__ASSERT_ALWAYS(iHistViewStacked, Panic(EOandXControlNotStacked));
    AppUi()->RemoveFromViewStack( *this, iContainer );
    iHistViewStacked = EFalse;

	iContainer->MakeVisible(EFalse);
	iActivated = EFalse;
	}

/*
Utility function that manages the state of the History and Stats controls
*/	
void COandXHistoryView::ChangeDisplayL( TBool aDisplayHistory )	
	{
	iDisplayingHistory =  aDisplayHistory;
	iContainer->SetContentL(aDisplayHistory);
	iContainer->MakeVisible(ETrue);
	}	


// Container

COandXHistViewContainer* COandXHistViewContainer::NewL(const TRect& aRect)
	{
	COandXHistViewContainer* self = new (ELeave) COandXHistViewContainer();
    CleanupStack::PushL( self );
    self->ConstructL(aRect);
    CleanupStack::Pop(); // self
    return self;
	}

COandXHistViewContainer::~COandXHistViewContainer()
	{
	delete iTitle;
	for (TInt i=0; i< KNumDataLines; i++)
		{
		delete iDataLines[i];
		}
	}

COandXHistViewContainer::COandXHistViewContainer()
	{
	}

void COandXHistViewContainer::ConstructL(const TRect& aRect)
	{
	// Create a window for this application view
	CreateWindowL();
	
	// Create components
   	TResourceReader reader;
	iTitle = new (ELeave) CEikLabel();
    iTitle->SetContainerWindowL( *this );
   	iEikonEnv->CreateResourceReaderLC(reader, R_HISTORY_VIEW_LABEL);
   	iTitle->ConstructFromResourceL(reader);
   	CleanupStack::PopAndDestroy(); // reader
	
 	for (TInt i=0; i< KNumDataLines; i++)
		{
		iDataLines[i] = new (ELeave) CEikLabel();
	    iDataLines[i]->SetContainerWindowL( *this );
    	iEikonEnv->CreateResourceReaderLC(reader, R_HISTORY_VIEW_LABEL);
    	iDataLines[i]->ConstructFromResourceL(reader);
    	CleanupStack::PopAndDestroy(); // reader
		iDataLines[i]->SetLabelAlignment(ELayoutAlignLeft);
		}
    
	iEikonEnv->ReadResourceL(iNumGamesText, R_HISTORY_VIEW_GAMES_TEXT);
	iEikonEnv->ReadResourceL(iNumOWinsText, R_HISTORY_VIEW_OWINS_TEXT);
	iEikonEnv->ReadResourceL(iNumXWinsText, R_HISTORY_VIEW_XWINS_TEXT);
	iEikonEnv->ReadResourceL(iNumDrawsText, R_HISTORY_VIEW_DRAWN_TEXT);
	iEikonEnv->ReadResourceL(iStatOWonText, R_HISTORY_VIEW_O_WINNER_TEXT);
	iEikonEnv->ReadResourceL(iStatXWonText, R_HISTORY_VIEW_X_WINNER_TEXT);
	iEikonEnv->ReadResourceL(iStatDrawText, R_HISTORY_VIEW_NO_WINNER_TEXT);
	iEikonEnv->ReadResourceL(iHistoryTitle, R_HISTORY_VIEW_HISTORY_TITLE);
	iEikonEnv->ReadResourceL(iStatsTitle, R_HISTORY_VIEW_STATS_TITLE);	

	// Set the window's size
	SetRect(aRect); // needs to be after component creation - see SizeChanged()

	// Activate the window, which makes it ready to be drawn
	ActivateL();
	}

void COandXHistViewContainer::SizeChanged()
	{
	TRect rect = Rect();
	
	TInt labelHeight = (rect.iBr.iY - rect.iTl.iY)/(KNumDataLines+1);
	rect.iBr.iY = labelHeight;
	iTitle->SetRect(rect);
	for (TInt i=0; i<KNumDataLines; i++)
		{
		rect.iTl.iY += labelHeight;
		rect.iBr.iY += labelHeight;
		iDataLines[i]->SetRect(rect);
		}
	}

void COandXHistViewContainer::Draw(const TRect& /*aRect*/) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	}

void COandXHistViewContainer::SetContentL( TBool aDisplayHistory )
	{
	CreateNewItemsL(aDisplayHistory);
	DrawNow();
	}
	
void COandXHistViewContainer::CreateNewItemsL(TBool aDisplayHistory)
	{
	// Clear all existing data
	TBuf<KFormatBufSize> itemName;
	iEikonEnv->ReadResourceL(itemName, R_HISTORY_VIEW_NO_DATA_TEXT);
	for (TInt i=0; i<KNumDataLines; i++)
		{
		iDataLines[i]->SetTextL(itemName);
		}

	// Insert the data to be displayed
	TUint played = Controller().GamesPlayed();
	
	if (aDisplayHistory)
		{
		// Set the title
		iTitle->SetTextL(iHistoryTitle);
		// Add all available history data
		for (TInt i=0; i<KNumHistoryRecords; i++)
			{
			switch (Controller().GameRecord(i))
				{
			case ETileNought:
				itemName.Format(iStatOWonText, played - i);
				break;
			case ETileCross:
				itemName.Format(iStatXWonText, played - i);
				break;
			case ETileDraw:
				itemName.Format(iStatDrawText, played - i);
				break;
			default:
				iEikonEnv->ReadResourceL(itemName, R_HISTORY_VIEW_NO_DATA_TEXT);
				break;
				}
			iDataLines[i]->SetTextL(itemName);
			}
		}
	else // Displaying statistics
		{
		// Set the title
		iTitle->SetTextL(iStatsTitle);
		
		// Total games played
		itemName.Format(iNumGamesText, played);
		iDataLines[0]->SetTextL(itemName);

		// Wins by Noughts
		TUint oWins = Controller().WonByO();
		itemName.Format(iNumOWinsText, oWins);
		iDataLines[1]->SetTextL(itemName);

		// Wins by Crosses
		TUint xWins = Controller().WonByX();
		itemName.Format(iNumXWinsText, xWins);
		iDataLines[2]->SetTextL(itemName);
		
		// Drawn (or abandoned) games
		itemName.Format(iNumDrawsText, played - oWins - xWins);
		iDataLines[3]->SetTextL(itemName);
		}
	}

TInt COandXHistViewContainer::CountComponentControls() const
	{
	return KNumDataLines+1;
	}

CCoeControl* COandXHistViewContainer::ComponentControl(TInt aIndex) const
	{
	if (aIndex==0)
		{
		return iTitle;
		}
	else
		{
		return iDataLines[aIndex-1];
		}
	}
