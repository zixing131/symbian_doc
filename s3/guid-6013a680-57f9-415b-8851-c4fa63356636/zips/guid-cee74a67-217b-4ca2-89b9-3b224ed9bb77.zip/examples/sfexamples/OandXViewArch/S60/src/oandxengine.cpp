/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/

#include <e32math.h>

#include "oandxdefs.h"
#include "oandxengine.h"


COandXEngine* COandXEngine::NewL()
/**
	Factory function allocates new instance of COandXEngine.
	
	@return					New game engine, which is owned
							by the caller.  On return every
							tile is marked as blank, which is
							useful for rendering, although
							a game has not been started yet.
 */
	{
	return new(ELeave) COandXEngine;
	}

COandXEngine::COandXEngine()
/**
	This constructor is only defined to ensure there is exactly
	one definition.
 */
	{
	Reset();
	}

COandXEngine::~COandXEngine()
/**
	This destructor is only defined to ensure there is exactly
	one definition.
 */
	{
	// empty.
	}

void COandXEngine::Reset()
/**
	Mark all tiles as blank.  This is an engine-only operation;
	it does not affect any comms connections or the UI.
 */
	{
	for (TInt i=0; i<KNumberOfTiles; i++)
		{
		iTileStates[i] = ETileBlank;
		}
	}

TTileState COandXEngine::TileStatus(TInt aIndex) const
/**
	Return the indexed tile's state.
	
	@param	aIndex			Zero-based tile index.
	@return					Tile state, i.e. ETileBlank,
							ETileNought, or ETileCross.
 */
	{
	return iTileStates[aIndex];
	}

TBool COandXEngine::TryMakeMove(TInt aIndex, TBool aCrossTurn)
/**
	This function is called by the controller when the local or
	remote player wants to select a tile.  If the tile is blank,
	it allows the move.  Note this function does not know whose
	turn it should be - that is the controller's responsibility.
	
	@param	aIndex			Index of tile to update.
	@param	aCrossTurn		Whether it is cross' or nought's turn.
	@return					Whether the board was updated.
 */
	{
	if (iTileStates[aIndex] == ETileBlank)
		{
		iTileStates[aIndex] = aCrossTurn ? ETileCross : ETileNought;
		return ETrue;
		}
	return EFalse;
	}
	
TInt COandXEngine::TileState(TInt aX, TInt aY) const
/**
	Get the state of the tile at the supplied coordinates.

	@param	aX				Tile X coordinate.
	@param	aY				Tile Y coordinate.
	@return					Value of tile at (aX, aY).
 */
	{
	ASSERT(aX >= 0 && aX < KTilesPerSide);
	ASSERT(aY >= 0 && aY < KTilesPerSide);
	
	return iTileStates[aY * KTilesPerSide + aX];
	}

TTileState COandXEngine::GameWonBy() const
/**
	Check if there is a full line of noughts or crosses.
	The line can be horizontal, vertical, or diagonal.
	
	@return					ETileNought if there is a line of noughts;
							ETileCross if there is a line of crosses;
							Zero if there is no complete line.
 */
	{
	const TInt KNoughtWinSum = KTilesPerSide * ETileNought;
	const TInt KCrossWinSum = KTilesPerSide * ETileCross;
	
	// is there a row or column of matching tiles?
	for (TInt i = 0; i < KTilesPerSide; ++i)
		{
		TInt rowSum = 0;
		TInt colSum = 0;
		for (TInt j = 0; j < KTilesPerSide; ++j)
			{
			rowSum += TileState(j, i);
			colSum += TileState(i, j);
			}
		
		if (rowSum == KNoughtWinSum || colSum == KNoughtWinSum)
			{
			return ETileNought;
			}
		if (rowSum == KCrossWinSum || colSum == KCrossWinSum)
			{
			return ETileCross;
			}
		}

	// is there a diagonal of matching tiles?
	TInt blTrSum = 0;		// bottom left to top right
	TInt tlBrSum = 0;		// top left to bottom right
	for (TInt i = 0; i < KTilesPerSide; ++i)
		{
		tlBrSum += TileState(i,i);
		blTrSum += TileState(i,KTilesPerSide - 1 - i);
		}
		
	if (blTrSum == KNoughtWinSum || tlBrSum == KNoughtWinSum)
		{
		return ETileNought;
		}
	
	if (blTrSum == KCrossWinSum || tlBrSum == KCrossWinSum)
		{
		return ETileCross;
		}
	
	return ETileBlank; // No winner
	}


void COandXEngine::ExternalizeL(RWriteStream& aStream) const
/**
	Externalize the board to the supplied stream.
	
	@param	aStream			Stream to which the board's state
							will be written.
	@see InternalizeL
 */
	{
	for (TInt i = 0; i<KNumberOfTiles; i++)
		{
		aStream.WriteInt8L(iTileStates[i]);
		}
	}

void COandXEngine::InternalizeL(RReadStream& aStream)
/**
	Internalize the board from the supplied stream.
	
	@param	aStream			Stream which contains externalized
							board state.
	@see ExternalizeL
 */
	{
	for (TInt i = 0; i<KNumberOfTiles; i++)
		{
		iTileStates[i] = static_cast<TTileState>(aStream.ReadInt8L());
		}
	}
