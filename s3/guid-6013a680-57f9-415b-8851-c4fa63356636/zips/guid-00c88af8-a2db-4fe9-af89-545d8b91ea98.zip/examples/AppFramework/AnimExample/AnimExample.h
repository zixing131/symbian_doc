/*
Copyright (c) 2006-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#ifndef __ANIMEXAMPLE_H
#define __ANIMEXAMPLE_H

#include <coeccntx.h>

#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikmenup.h>
#include <eikstart.h> 
#include <eikon.hrh>
#include <gdi.h>

#include <spriteanimation.h>
#include <iclanimationdataprovider.h>
#include <basicanimation.h>
#include "animMover.h"
#include <animexample.rsg>
#include "AnimExample.hrh"

_LIT(KAnimExStopWatch,"Z:\\resource\\apps\\AnimExample\\stopwatch.gif");

_LIT( KAnimExSpriteLabel, "Sprite Animation" );
_LIT( KAnimExBasicLabel, "Basic Animation" );

const TInt KBasicOffset = 135;
const TInt KSpriteOffset = 25;

const TInt KspriteInterval = 10000;  //Microseconds
const TInt KBasicInterval = 99999; //Microseconds

const TInt KAnimExBasicPositionX = 300;
const TInt KAnimExBasicPositionY = 100;
const TInt KAnimExSpritePositionX = 60;
const TInt KAnimExSpritePositionY = 70;	


enum TAnimOperation
	{
	EAnimPause,
	EAnimResume,	
	EAnimHold,
	EAnimUnhold,
	EAnimFreeze,
	EAnimUnfreeze,
	EAnimStart,
	EAnimStop		
	};


class CAnimationApplication : public CEikApplication
	{
private: 
	// Inherited from class CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};

class CAnimationAppView : public CCoeControl
    {
public:
	static CAnimationAppView* NewL( const TRect& aRect );
	CAnimationAppView();
	~CAnimationAppView();
    void ConstructL( const TRect& aRect );
    
    void ProduceSpriteAnimL();
    void ProduceBasicAnimL();
    void MoveAnimsL();
    void DoSpriteAnimOperationL( TAnimOperation aOperation );
    void DoBasicAnimOperationL( TAnimOperation aOperation );
    void ResetSpriteAnimAndMover();
    void ResetBasicAnimAndMover();

    CSpriteAnimation* iSpriteAnim;
	CBasicAnimation* iBasicAnim;
	
private:
	// From CCoeControl
	void Draw(const TRect& /*aRect*/) const;

private:
	HBufC*  iAnimTestText;
	CSpriteAnimMover* iSpriteAnimMover;
	CBasicAnimMover* iBasicAnimMover;
	
    };

class CAnimationAppUi : public CEikAppUi
    {
public:
    void ConstructL();
	~CAnimationAppUi();

private:
    // Inherited from class CEikAppUi
	void HandleCommandL(TInt aCommand);

private:
	CAnimationAppView* iAppView;
	};


class CAnimationDocument : public CEikDocument
	{
public:
	static CAnimationDocument* NewL(CEikApplication& aApp);
	CAnimationDocument(CEikApplication& aApp);
	void ConstructL();

private: 
	// Inherited from CEikDocument
	CEikAppUi* CreateAppUiL();
	};


#endif


