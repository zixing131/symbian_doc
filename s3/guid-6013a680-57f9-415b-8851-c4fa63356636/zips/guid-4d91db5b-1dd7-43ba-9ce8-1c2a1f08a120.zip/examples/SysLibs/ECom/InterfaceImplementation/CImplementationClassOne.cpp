/*
Copyright (c) 1997-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CImplementationClassOne.h"

// Construction and destruction functions

CImplementationClassOne* CImplementationClassOne::NewL(TAny* aInitParams)
	{
	CImplementationClassOne* self=new(ELeave) CImplementationClassOne(aInitParams);
	CleanupStack::PushL(self);
	self->ConstructL(); 
	CleanupStack::Pop();
	return self;
	}

CImplementationClassOne::~CImplementationClassOne()
	{
	delete iDescriptor;
	}

CImplementationClassOne::CImplementationClassOne(TAny* aInitParams)
// Store input/output parameters
: iInitParams((CExampleInterface::TExampleInterfaceInitParams*)aInitParams)
	{
	// See ConstructL() for initialisation completion.
	}

void CImplementationClassOne::ConstructL()
// Safely complete the initialization of the constructed object	
	{
	// Set up the data on the heap to pass back
	_LIT(KDescriptor, "Using Implementation One\n");
	iDescriptor = KDescriptor().AllocL();
	}


// Implementation of CExampleInterface

void CImplementationClassOne::DoMethodL(TDes& aString)
	{
	aString = *iDescriptor;

	// Set the parameter to something significant
	if (iInitParams)
		iInitParams->integer=1;
	}
	
