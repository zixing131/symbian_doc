/*
Copyright (c) 2001-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __EXAMPLERESOLVER_H__
#define __EXAMPLERESOLVER_H__

#include <resolver.h>
#include <publicregistry.h>

class TEComResolverParams;

// Example resolver's UID
const TUid KExResolverUid = {0x10009DD0};

/**
	Implements a non-default resolver.

	This controls the identification, (resolution), of which implementation 
	will be used to satisfy an interface implementation instantiation.
 */
class CExampleResolver : public CResolver
	{
public:
	// Factory function: 
	static CExampleResolver* NewL(MPublicRegistry & aRegistry);
	~CExampleResolver();

	/**
	Request that the resolver identify the most appropriate interface implementation.
	@param			aInterfaceUid The interface for which implementations are requested
	@param			aAdditionalParameters Data to be used to refine the search further
	@return			The Uid of the best fit interface implementation - KNullUid if no match is found
	*/
	TUid IdentifyImplementationL(TUid aInterfaceUid, 
		const TEComResolverParams& aAdditionalParameters) const;

	/**
	List all the implementations which satisfy the specified interface.
	@param			aInterfaceUid The interface for which implementations are requested
	@param			aAdditionalParameters Data to be used to refine the search further
	@return			Pointer to an array of suitable implementations. Ownership of this array
	is passed to the calling function.
	*/
	RImplInfoArray* ListAllL(TUid aInterfaceUid, 
		const TEComResolverParams& aAdditionalParameters) const;

private:
	// Ctor
	explicit CExampleResolver(MPublicRegistry& aRegistry);

	/**
	Called by IdentifyImplementationL to select an appropriate implementation from a list of possibles
	@param			aImplementationsInfo Information on the potential implementations
	@param			aAdditionalParameters The data to match against to detemine the 
					implementation
	@return			The Uid of the selected implementation - KNullUid if no match is found
 */
	TUid Resolve(const RImplInfoArray& aImplementationsInfo, 
				 const TEComResolverParams& aAdditionalParameters) const;

/**
	Searches for a match of a data type on an implementation type.
	Match returns ETrue if aMatchType is found within aImplementationType according to 
	the following rules:
	1) aImplementationType is treated as a series of descriptors separated by double 
	bars (||). ETrue is returned if aMatchType matches exactly any of the short 
	descriptors.  If no double bar is present then aImplementationType is treated as a
	single descriptor.
	2) If aUseWildcards == ETrue then a '?' in aMatchType will be matched to any single
	character and '*' will be matched to any series of characters.

	@param			aImplementationType The implementation data type to search for a match
	@param			aMatchType The data to search for
	@param			aUseWildcards ETrue if wildcard matching should be allowed
	@return			ETrue if a match was found, EFalse otherwise
 */
	TBool Match(const TDesC8& aImplementationType, 
				const TDesC8& aMatchType, 
				TBool aUseWildcards) const;

private:
	mutable RImplInfoArray* iImplementationInfoArray;
	};

#endif // __EXAMPLERESOLVER_H__

