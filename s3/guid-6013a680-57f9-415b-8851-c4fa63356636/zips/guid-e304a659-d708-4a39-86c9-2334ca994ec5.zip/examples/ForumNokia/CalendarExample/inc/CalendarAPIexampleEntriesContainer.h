/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef CALENDARAPIEXAMPLEENTRIESCONTAINER_H
#define CALENDARAPIEXAMPLEENTRIESCONTAINER_H

// INCLUDE FILES
#include <coecntrl.h>   //CCoeControl
#include <eiktxlbx.h>   //CEikTextListBox
#include "CalendarAPIexampleEntriesView.h"
#include <aknlists.h> //CAknDoubleNumberStyleListBox

#include "CalendarAPIexampleEngine.h"
#include "CalendarAPIexampleEntriesView.h"

// CLASS DECLARATION

class CCalendarAPIexampleEntriesContainer : public CCoeControl,
                                            public MEikListBoxObserver
    {
public: // Constructors and destructor

   /*!
    * Two-phased constructor.
    */
    static CCalendarAPIexampleEntriesContainer* NewL(   
                                    const TRect& aRect,
                                    CCalendarAPIexampleEntriesView& aView,
                                    MCalendarEngineCommandsInterface& aEngine);
   /*!
    * Destructor.
    */
    ~CCalendarAPIexampleEntriesContainer();
    
private:

   /*!
    * Symbian OS Default constructor.
    */
    CCalendarAPIexampleEntriesContainer(CCalendarAPIexampleEntriesView& aView,
        MCalendarEngineCommandsInterface& aEngine);
    void ConstructL(const TRect& aRect);

public: // New functions

   /*!
    * CurrentItemIndex()
    *
    * Returns the index of the entry currently selected on the listbox.
    */
    TInt CurrentItemIndex() const;
    
   /*!
    * PopulateListBoxL()
    *
    * Requests all found entries from model and displays them in the listbox.
    */  
    void PopulateListBoxL();
    
private: // Functions from base classes

   /*!
    * From CoeControl,SizeChanged.
    */
    void SizeChanged();

    void HandleResourceChange(TInt aType);
    
   /*!
    * From CoeControl,CountComponentControls.
    */        
    TInt CountComponentControls() const; 
    
   /*!
    * From CCoeControl,ComponentControl.
    */
    CCoeControl* ComponentControl(TInt aIndex) const;
    
   /*!
    * From CCoeControl,OfferKeyEventL.
    */
    TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType );
    
   /*!
    * From MEikListBoxObserver,HandleListBoxEventL.
    */  
    void HandleListBoxEventL(CEikListBox* aListBox, TListBoxEvent aEventType);
    
private: // Data members
    CAknDoubleNumberStyleListBox*       iEntryListBox;
    CCalendarAPIexampleEntriesView&     iEntriesView;
    MCalendarEngineCommandsInterface&   iEngine;
    };

#endif
