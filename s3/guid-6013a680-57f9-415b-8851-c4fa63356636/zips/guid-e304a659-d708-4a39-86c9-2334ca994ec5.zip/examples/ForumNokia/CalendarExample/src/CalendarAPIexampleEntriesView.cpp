/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

// INCLUDE FILES
#include <aknviewappui.h>
#include <AknQueryDialog.h> // CAknQueryDialog
#include <CalendarAPIexample.rsg>
#include "CalendarAPIexampleEntriesView.h"
#include "CalendarAPIexampleEntriesContainer.h"
#include "CalendarAPIexample.hrh"
#include "CalendarAPIexampleSearchView.h"
#include "CalendarAPIexampleEntryView.h"
#include "CalendarAPIexampleDocument.h"

// CONSTANTS
_LIT(KDeleteConfirmation, "Delete the selected anniversary?");

// ================= MEMBER FUNCTIONS =======================


// Two-phased constructor.
CCalendarAPIexampleEntriesView* CCalendarAPIexampleEntriesView::NewL(MCalendarEngineCommandsInterface& aEngine)
    {
    CCalendarAPIexampleEntriesView* self = CCalendarAPIexampleEntriesView::NewLC(aEngine);
    CleanupStack::Pop(self);
    return self;
    }

// Two-phased constructor.
CCalendarAPIexampleEntriesView* CCalendarAPIexampleEntriesView::NewLC(MCalendarEngineCommandsInterface& aEngine)
    {
    CCalendarAPIexampleEntriesView* self = new (ELeave) CCalendarAPIexampleEntriesView(aEngine);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }


CCalendarAPIexampleEntriesView::CCalendarAPIexampleEntriesView(
    MCalendarEngineCommandsInterface& aEngine) : iEngine(aEngine)
    {
       
    }



// destructor
CCalendarAPIexampleEntriesView::~CCalendarAPIexampleEntriesView()
    {
    delete iContainer;
    iContainer = NULL;
    }
    
// Symbian OS default constructor can leave.
void CCalendarAPIexampleEntriesView::ConstructL()
    {
    BaseConstructL(R_CALENDARAPIEXAMPLE_ENTRIES_VIEW);  
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::Id()
// Returns ID of View
// ----------------------------------------------------
//  
TUid CCalendarAPIexampleEntriesView::Id() const
    {
    return KEntriesViewId;
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::HandleCommandL()
// Takes care of command handling
// ----------------------------------------------------
//  
void CCalendarAPIexampleEntriesView::HandleCommandL( TInt aCommand )
    {
    switch (aCommand)
        {
        case ECalendarAPIexampleCmdEdit:
            DoEditL();
            break;
        case ECalendarAPIexampleCmdDelete:
            DoDeleteL();
            break;
        case EAknSoftkeyBack:
            AppUi()->ActivateLocalViewL(KSearchViewId);
            break;
        default:
            break;
        }
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::DoActivateL()
// Gets called when the view is activated. Creates 
// the entries container, adds it to view control stack
// and sets it visible.
// ----------------------------------------------------
//  
void CCalendarAPIexampleEntriesView::DoActivateL(
                                        const TVwsViewId& /*aPrevViewId*/,
                                        TUid /*aCustomMessageId*/,
                                        const TDesC8& /*aCustomMessage*/ )
    {
    if ( !iContainer )
        {
        iContainer = CCalendarAPIexampleEntriesContainer::NewL(
                                                ClientRect(), *this, iEngine);
        iContainer->SetMopParent(this);

        // Adds Container to View control stack.
        AppUi()->AddToStackL( *this, iContainer );

        // Requires to display the default screen.
        iContainer->MakeVisible( ETrue );        
        }       
    }
    
// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::DoDeactivate()
// Gets called when the view is deactivated. Removes
// the entries container from view control stack and
// deletes it.
// ----------------------------------------------------
//      
void CCalendarAPIexampleEntriesView::DoDeactivate()
    {
    if ( iContainer )
        {
        // Removes Container from View control stack.
        AppUi()->RemoveFromStack(iContainer );
        }

    delete iContainer;
    iContainer = NULL;
    
    }    

// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::DoDeleteL()
// Deletes the selected entry. If the last entry in the
// list was deleted, search view is activated, otherwise
// list is reloaded.
// ----------------------------------------------------
//  Called from This views handleCommandL
void CCalendarAPIexampleEntriesView::DoDeleteL()
    {
    CAknQueryDialog* query = CAknQueryDialog::NewL();
    CleanupStack::PushL(query);
    query->SetPromptL(KDeleteConfirmation);
    CleanupStack::Pop(query);
    if (query->ExecuteLD(R_CALENDARAPIEXAMPLE_CONFIRMATION_QUERY))
        {
        iEngine.DeleteEntryL(iContainer->CurrentItemIndex());
        
        // No more entries exist in the listbox, activate search view
        if (iEngine.EntryCount() == 0)
            {
            AppUi()->ActivateLocalViewL(KSearchViewId);
            }
        // reload listbox after deletion
        else
            {
            iContainer->PopulateListBoxL();
            }
        }
    }

// ----------------------------------------------------
// CCalendarAPIexampleEntriesView::DoEditL()
// Tell model which entry is to be edited and activate
// entry view.
// ----------------------------------------------------
//  
void CCalendarAPIexampleEntriesView::DoEditL()
    {
    iEngine.SetModifyIndex(iContainer->CurrentItemIndex());
    AppUi()->ActivateLocalViewL(KEntryViewId);
    }

// End of File
