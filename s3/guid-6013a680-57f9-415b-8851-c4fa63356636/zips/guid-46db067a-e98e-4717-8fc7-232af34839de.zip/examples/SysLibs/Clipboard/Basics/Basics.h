// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// License: "Symbian Foundation License v1.0" to Symbian Foundation
// members and "Symbian Foundation End User License Agreement v1.0"
// to non-members�at the URL
// "http://www.symbianfoundation.org/legal/licencesv10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// This header file contains the class definitions and local
// function prototypes used by the example
//
	
	
const TUid KExampleClipUid={2306};
 
class CClassA : public CBase
	{
public :
	CClassA();
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);
public :
	TBuf<32> iBuffer;
	TInt     iXA;
	TUint    iYA;
	};

static void doCopyL();

static void doPasteL();

static void doShow(const TDesC& aHeading,const CClassA* anItem);

