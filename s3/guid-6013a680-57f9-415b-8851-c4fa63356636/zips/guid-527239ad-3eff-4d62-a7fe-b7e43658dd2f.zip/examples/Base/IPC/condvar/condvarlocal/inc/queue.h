/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Contains the definition of the CQueue class.� 
*/



/**
 @file 
*/
#ifndef __QUEUE_H__
#define __QUEUE_H__

#include "globals.h"

/**
A wrapper class that implements the queue of integer tokens.
It owns a handle to an integer array. This array is treated as a queue of tokens.
It provides functions to insert, delete and display elements in the queue.
It also owns a  handle to the condition variable and a mutex variable.
@see RCondVar.
@see RMutex.
*/
class CQueue : public CBase
	{
public:
	void Insert();
	void Remove();
	TBool IsEmpty();
	void ConstructL();
	static CQueue* NewL();
	void GetTokens(RArray<TInt>& aArray);
	~CQueue();
private:
	CQueue();
private:
	/**
	The integer array that represents the queue.
	*/
	RArray<TInt> iArray;
	/**
	The mutex variable.
	*/
	RMutex iMutex;
	/**
	The local condition variable.
	*/
	RCondVar iCondVar;
	};

#endif
