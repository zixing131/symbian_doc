/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "COperatorName.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of COperatorName class
*/
COperatorName* COperatorName::NewL(MExecAsync* aController)
	{
	COperatorName* self = new(ELeave) COperatorName(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
COperatorName::~COperatorName()
	{
	Cancel();
	}

/**
Gets the network operator name and stores it in the iOperatorNameV1Pckg
package.
*/
void COperatorName::DoStartRequestL()
	{
	_LIT(KDummyAnswerPanic, "COperatorName Get Method");
	__ASSERT_ALWAYS(!IsActive(), User::Panic(KDummyAnswerPanic, 1));
	iRequestNotify = EFalse;
	
	// Retrieve ICC stored information about the currently registered mobile network
	iTelephony->GetOperatorName(iStatus, iOperatorNameV1Pckg);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
COperatorName::COperatorName(MExecAsync* aController)
	: CISVAPIAsync(aController, KOperatorName),
	  iOperatorNameV1Pckg(iOperatorNameV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void COperatorName::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the operator name to the
console if there is no error.
*/
void COperatorName::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Print the output to console if there is no error
		iConsole->Printf(KOperatorNameMsg);
		iConsole->Printf(iOperatorNameV1.iOperatorName);
		iConsole->Printf(KNewLine);
		ExampleComplete();
		}
	}

/**
Cancels asynchronous request to CTelephony::GetOperatorName().
*/
void COperatorName::DoCancel()
	{
	// Cancels an outstanding asynchronous request
	iTelephony->CancelAsync(CTelephony::EGetOperatorNameCancel);
	}

