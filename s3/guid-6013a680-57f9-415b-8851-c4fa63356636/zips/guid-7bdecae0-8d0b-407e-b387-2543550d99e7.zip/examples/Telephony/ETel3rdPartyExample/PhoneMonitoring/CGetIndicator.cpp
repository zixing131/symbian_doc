/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CGetIndicator.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CGetIndicator class
*/
CGetIndicator* CGetIndicator::NewL(MExecAsync* aController)
	{
	CGetIndicator* self = new(ELeave) CGetIndicator(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CGetIndicator::~CGetIndicator()
	{
	Cancel();
	}

/**
Gets the indicator information (information regarding whether the battery
charger is connected and stores it in the iIndicatorV1Pckg package.
*/
void CGetIndicator::DoStartRequestL()
	{
	_LIT(KDummyAnswerPanic, "CGetIndicator Get Method");
	__ASSERT_ALWAYS(!IsActive(), User::Panic(KDummyAnswerPanic, 1));
	iRequestNotify = EFalse;
	
	// Retrieves the battery charging indicator, the network availability indicator and call-in-progress indicator.
	iTelephony->GetIndicator(iStatus, iIndicatorV1Pckg);
	SetActive();
	}

/**
Default constructor.

@param aController Pointer to an MExecAsync object passed to constructor of
                   CISVAPIBase
*/
CGetIndicator::CGetIndicator(MExecAsync* aController)
	: CISVAPIAsync(aController, KGetIndicator),
	  iIndicatorV1Pckg(iIndicatorV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CGetIndicator::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the inidcator information to
the console if there is no error.
*/
void CGetIndicator::RunL()
	{
	// Print Indicator Info
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
      if(iIndicatorV1.iCapabilities & CTelephony::KIndChargerConnected)
			{
			// We can detect when a charger is connected
			if(iIndicatorV1.iIndicator & CTelephony::KIndChargerConnected)
				{
				// Charger is connected
				iConsole->Printf(_L("Charger connected\n"));
				}
				else
				{
				// Charger is not connected
				iConsole->Printf(_L("Charger not connected\n"));
				}
			}
		else
			{
			// We do not know whether a charger is connected.
			iConsole->Printf(_L("Status of charger unknown\n"));
			}
		if (iRequestNotify)
	    	{
	    	DoRequestNotificationL();
	    	}
		else
	    	{
			ExampleComplete();
	    	}
		}
	}

/**
Requests to receive notifications of change in the indicator information.
*/
void CGetIndicator::DoRequestNotificationL()
   {
	// Panic if this object is already performing an asynchronous operation.
	// Application will panic if you call SetActive() on an already active object.
	_LIT( KNotifyPanic, "CGetIndicator Notify Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = ETrue;
	
	// Registers interest in receiving change notifications for events.
	iTelephony->NotifyChange(	iStatus,
								CTelephony::EIndicatorChange,
								iIndicatorV1Pckg );
	SetActive();
	}

/**
Cancels asynchronous request to CTelephony::GetIndicator().
*/
void CGetIndicator::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EIndicatorChangeCancel);
	}
