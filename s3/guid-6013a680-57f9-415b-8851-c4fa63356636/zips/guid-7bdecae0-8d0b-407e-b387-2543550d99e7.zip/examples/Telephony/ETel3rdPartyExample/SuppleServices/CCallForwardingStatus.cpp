/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CCallForwardingStatus.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CCallForwardingStatus class
*/
CCallForwardingStatus* CCallForwardingStatus::NewL(MExecAsync* aController)
	{
	CCallForwardingStatus* self = new(ELeave) CCallForwardingStatus(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Cancels outstanding requests.
*/
CCallForwardingStatus::~CCallForwardingStatus()
	{
	Cancel();
	}

/**
Retrieves the current forwarding status.
*/
void CCallForwardingStatus::DoStartRequestL()
	{
	_LIT( KNotifyPanic, "CCallForwardingStatus Get Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = EFalse;
	if (iSecondCondition)
		{
		iSecondCondition = EFalse;
		CTelephony::TCallForwardingCondition condition2;
		condition2 = CTelephony::ECallForwardingUnconditional;
		
		// Interrogates the current status of the call forwarding services for first condition.
		iTelephony->GetCallForwardingStatus(iStatus,
											condition2,
											iCallForwardingStatus2V1Pckg);
		}
	else
		{
		iSecondCondition = ETrue;
		CTelephony::TCallForwardingCondition condition1;
		condition1 = CTelephony::ECallForwardingNoReply;
		
		// Interrogates the current status of the call forwarding services for second condition
		iTelephony->GetCallForwardingStatus(iStatus,
											condition1,
											iCallForwardingStatus1V1Pckg);
		}
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CCallForwardingStatus::CCallForwardingStatus(MExecAsync* aController)
	: CISVAPIAsync(aController, KCallForwardingStatus),
	  iCallForwardingStatus1V1Pckg(iCallForwardingStatus1V1),
	  iCallForwardingStatus2V1Pckg(iCallForwardingStatus2V1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CCallForwardingStatus::ConstructL()
	{
	iSecondCondition = EFalse;
	}

/**
Checks the status of the active object and displays the current call forwarding
status if there is no error.
*/
void CCallForwardingStatus::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		if (!iSecondCondition)
			{
			iConsole->Printf(KCallForwardingStatusMsg);
			switch(iCallForwardingStatus1V1.iCallForwarding)
				{
			case CTelephony::EStatusActive:
				iConsole->Printf(_L("Call forwarding status 1 is active.\n"));
				break;
			case CTelephony::ENotActive:
				iConsole->Printf(_L("Call forwarding status 2 is not active.\n"));
				break;
			case CTelephony::ENotProvisioned:
				iConsole->Printf(_L("Call forwarding status 3 is not provisioned.\n"));
				break;
			case CTelephony::ENotAvailable:
				iConsole->Printf(_L("Call forwarding status 4 is not available.\n"));
				break;
			case CTelephony::EUnknown:
			default:
				iConsole->Printf(_L("Call forwarding status 5 is unknown.\n"));
				break;
				}
			switch(iCallForwardingStatus2V1.iCallForwarding)
				{
			case CTelephony::EStatusActive:
				iConsole->Printf(_L("Call forwarding status 2 is active.\n"));
				break;
			case CTelephony::ENotActive:
				iConsole->Printf(_L("Call forwarding status 2 is not active.\n"));
				break;
			case CTelephony::ENotProvisioned:
				iConsole->Printf(_L("Call forwarding status 2 is not provisioned.\n"));
				break;
			case CTelephony::ENotAvailable:
				iConsole->Printf(_L("Call forwarding status 2 is not available.\n"));
				break;
			case CTelephony::EUnknown:
			default:
				iConsole->Printf(_L("Call forwarding status 2 is unknown.\n"));
				break;
				}
			ExampleComplete();
			}
		else
			{
			ExampleNotify();
			}
		}
	}

/**
Cancels the asynchronous call to CTelephony::GetCallForwardingStatus().
*/
void CCallForwardingStatus::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EGetCallForwardingStatusCancel);
	}

