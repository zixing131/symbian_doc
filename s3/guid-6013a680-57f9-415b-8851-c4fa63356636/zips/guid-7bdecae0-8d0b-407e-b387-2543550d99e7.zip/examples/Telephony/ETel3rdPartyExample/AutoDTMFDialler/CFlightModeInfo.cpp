/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CFlightModeInfo.h"

/**
Factory constructor.
@param  aController Pointer to MExecAsync object passed to constructor of
                    CISVAPIBase
@return             Instance of CFlightModeInfo class
*/
CFlightModeInfo* CFlightModeInfo::NewL(MExecAsync* aController)
	{
	CFlightModeInfo* self = new(ELeave) CFlightModeInfo(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Calls Cancel() to cancel outstanding requests.
*/
CFlightModeInfo::~CFlightModeInfo()
	{
	Cancel();
	}

/**
Gets the flight mode status and stores it in the iFlightModeV1Pckg.
*/
void CFlightModeInfo::DoStartRequestL()
	{
	// Retrieves the current flight mode status
	iTelephony->GetFlightMode(iStatus, iFlightModeV1Pckg);
	SetActive();
	}

/**
Constructor called by CFlightModeInfo::NewL().
@param aController Pointer to an MExecAsync object passed to constructor of CISVAPIBase
*/
CFlightModeInfo::CFlightModeInfo(MExecAsync* aController)
	: CISVAPIAsync(aController, KFlightModeInfo),
	  iFlightModeV1Pckg(iFlightModeV1)
	{
	// Empty method
	}

/**
Second phase constructor. Currently empty.
*/
void CFlightModeInfo::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and displays the flight mode
status is there is no error.
*/
void CFlightModeInfo::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		if(iRequestNotify)
			{
			iConsole->ClearScreen();
			iConsole->Printf(_L("*~This is a notifcation\n~*"));
			}
		switch (iFlightModeV1.iFlightModeStatus)
			{
		case CTelephony::EFlightModeOff:
			iConsole->Printf(_L("Flight Status is Off, you can make a call!\n"));
			ExampleComplete();
			break;
		case CTelephony::EFlightModeOn:
			iConsole->Printf(_L("Flight Status is On, you can't make a call!\n"));
			ExampleNotify();
			break;
		default:
			iConsole->Printf(KError);
			}
		}
	}

/**
Requests to receive notifications of changes to the flight mode.
*/
void CFlightModeInfo::DoRequestNotificationL()
	{
	// Panic if this object is already performing an asynchronous operation.
	// Application will panic if you call SetActive() on an already active 
	// object.
	_LIT( KNotifyPanic, "CFlightModeInfo Notify Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = ETrue;

	// Notify if there is any change to line status
	iTelephony->NotifyChange(	iStatus,
								CTelephony::EFlightModeChange,
								iFlightModeV1Pckg );
	SetActive();
	}

/**
Cancels asynchronous request to CTelephony::GetFlightMode()
*/
void CFlightModeInfo::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EFlightModeChangeCancel);
	}

