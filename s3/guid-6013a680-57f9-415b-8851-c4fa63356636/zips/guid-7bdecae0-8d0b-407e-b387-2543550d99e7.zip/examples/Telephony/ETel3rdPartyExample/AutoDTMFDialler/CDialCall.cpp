/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CDialCall.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of
                    CISVAPIBase
@return             Instance of CDialCall class
*/
CDialCall* CDialCall::NewL(MExecAsync* aController)
	{
	CDialCall* self = new(ELeave) CDialCall(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.  Cancels any outstanding requests.
*/
CDialCall::~CDialCall()
	{
	Cancel();
	}

/**
Sets the required parameters and starts dialling the call.

@param aNumber Phone number to dial.
*/
void CDialCall::DoStartRequestL(const TDesC& aNumber)
	{
	CTelephony::TCallParamsV1 callParams;
	callParams.iIdRestrict = CTelephony::ESendMyId;
	CTelephony::TCallParamsV1Pckg callParamsPckg(callParams);
	
	iConsole->Printf(_L("Dialling "));
	
	// Print the number to dial
	iConsole->Printf(aNumber);
	iConsole->Printf(KNewLine);
	
	// Dial a new call to specified phone number
	iTelephony->DialNewCall(iStatus, callParamsPckg, aNumber, iCallId);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to MExecAsync object passed to constructor of CISVAPIBase
*/
CDialCall::CDialCall(MExecAsync* aController)
	: CISVAPIAsync(aController, KDialCall)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CDialCall::ConstructL()
	{
	// Empty method
	}

/**
Checks status of the active object and displays output to console if
there is no error.
*/
void CDialCall::RunL()
	{
	if(iStatus != KErrNone)
		{
		// Return error
		iConsole->Printf(KError);
		
		// Print error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Print 'Dialling' if there is no error
		iConsole->Printf(_L("Dialling...\n"));
		ExampleComplete();
		}
	}

/**
Cancels asynchronous request to CTelephony::DialNewCall().
*/
void CDialCall::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EDialNewCallCancel);
	}
