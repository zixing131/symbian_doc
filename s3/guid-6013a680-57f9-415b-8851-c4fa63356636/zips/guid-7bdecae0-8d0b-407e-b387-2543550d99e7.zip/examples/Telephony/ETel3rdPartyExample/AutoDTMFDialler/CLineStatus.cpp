/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CLineStatus.h"

/**
Factory constructor.
@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CLineStatus class
*/
CLineStatus* CLineStatus::NewL(MExecAsync* aController)
	{
	CLineStatus* self = new(ELeave) CLineStatus(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CLineStatus::~CLineStatus()
	{
	Cancel();
	}

/**
Gets the current line status and displays it to the console.
*/
void CLineStatus::DoStartRequestL()
	{
    iRequestNotify = EFalse;
    CTelephony::TPhoneLine line = CTelephony::EVoiceLine;
   
    // Retrieves the status of the line selected by the argument
	iTelephony->GetLineStatus(line, iLineStatusV1Pckg);
	CTelephony::TCallStatus voiceLineStatus = iLineStatusV1.iStatus;
	switch (voiceLineStatus)
		{
	case CTelephony::EStatusRinging:
		iConsole->Printf(_L("RING RING RING\n"));
		break;
	case CTelephony::EStatusConnected:
		iConsole->Printf(_L("Line Status connected\n"));
		break;
	case CTelephony::EStatusConnecting:
		iConsole->Printf(_L("Line Status connecting\n"));
		break;
	case CTelephony::EStatusAnswering:
		iConsole->Printf(_L("Line Status Answering\n"));
		break;
	case CTelephony::EStatusIdle:
		iConsole->Printf(_L("Line Status Idle\n"));
		break;
	case CTelephony::EStatusDisconnecting:
		iConsole->Printf(_L("Line Status Disconnecting\n"));
		break;
	case CTelephony::EStatusHold:
		iConsole->Printf(_L("Line Status on Hold\n"));
		break;
	default:
		iConsole->Printf(_L("Line status changed\n"));
		break;
		}
	if (voiceLineStatus == CTelephony::EStatusIdle)
		{
		ExampleNotify();
		}
	else
		{
		if (!IsActive())
			{
				RequestNotificationL();
			}
		}
	}

/**
Constructor.
@param aController Pointer to MExecAsync object passed to constructor of CISVAPIBase
*/
CLineStatus::CLineStatus(MExecAsync* aController)
	: CISVAPIAsync(aController, KLineStatus),
	  iLineStatusV1Pckg(iLineStatusV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CLineStatus::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the line status to
the console if there is no error.
*/
void CLineStatus::RunL()
	{
	CTelephony::TCallStatus voiceLineStatus = iLineStatusV1.iStatus;
	// Print Line Info
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		switch (voiceLineStatus)
			{
		case CTelephony::EStatusRinging:
			iConsole->Printf(_L("RING RING RING\n"));
			break;
		case CTelephony::EStatusConnected:
			iConsole->Printf(_L("Line Status: Connected\n"));
			break;
		case CTelephony::EStatusConnecting:
			iConsole->Printf(_L("Line Status: Connecting\n"));
			break;
		case CTelephony::EStatusAnswering:
			iConsole->Printf(_L("Line Status: Answering\n"));
			break;
		case CTelephony::EStatusIdle:
			iConsole->Printf(_L("Line Status: Idle\n"));
			break;
		case CTelephony::EStatusDisconnecting:
			iConsole->Printf(_L("Line Status: Disconnecting\n"));
			break;
		case CTelephony::EStatusHold:
			iConsole->Printf(_L("Line Status: On Hold\n"));
			break;
		default:
			iConsole->Printf(_L("Line status: Changed\n"));
			break;
			}
		if (voiceLineStatus == CTelephony::EStatusIdle )
			{
			ExampleNotify();
			}
		else
			{
			if (!IsActive())
				{
				RequestNotificationL();
				}
			}
		}
	}

/**
Registers interest in receiving change notifications of the
line status by calling CTelephony::NotifyChange().
*/
void CLineStatus::DoRequestNotificationL()
	{
	// Panic if this object is already performing an asynchronous operation. 
	// Application will crash if you call SetActive() on an already active object.
	_LIT( KNotifyPanic, "CLineStatus Notify Method" );
	__ASSERT_ALWAYS( !IsActive(), User::Panic( KNotifyPanic, 1 ));
	iRequestNotify = ETrue;
	
	// Notify if there is any change in line status
	iTelephony->NotifyChange(	iStatus,
								CTelephony::EVoiceLineStatusChange,
								iLineStatusV1Pckg );
	SetActive();
	}
	
/**
Cancels the asynchronous request to CTelephony::GetLineStatus()
*/
void CLineStatus::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EVoiceLineStatusChangeCancel);
	}
