/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CSubscriberId.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CSubscriberId class
*/
CSubscriberId* CSubscriberId::NewL(MExecSync* aController)
	{
	CSubscriberId* self = new(ELeave) CSubscriberId(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests.
*/
CSubscriberId::~CSubscriberId()
	{
	Cancel();
	}

/**
Gets the subscriber Id by calling 3rd party API function CTelephony::GetSubscriberId()
and stores it in the iSubscripberIdV1Pckg package.
*/
void CSubscriberId::DoStartRequestL()
	{
	// Retrieves information about the mobile device's current subscriber
	iTelephony->GetSubscriberId(iStatus, iSubscriberIdV1Pckg);
	SetActive();
	}

/**
Constructor.

@param aController Pointer to an MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CSubscriberId::CSubscriberId(MExecSync* aController)
	: CISVAPISync(aController, KSubscriberId),
	  iSubscriberIdV1Pckg(iSubscriberIdV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CSubscriberId::ConstructL()
	{
	// Empty method
	}

/**
Checks the status of the active object and prints the subscriber information to
the console if there is no error.
*/
void CSubscriberId::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the error status code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Print Subscriber Info.
		TBuf<CTelephony::KIMSISize> subscriberId = iSubscriberIdV1.iSubscriberId;
		iConsole->Printf(KSubscriberIdMsg);
		
		// Print the subscriber information about the phone
		iConsole->Printf(subscriberId);
		iConsole->Printf(KNewLine);

		ExampleComplete();
		}
	}

/**
Cancels the asynchronous request to CTelephony::GetSubscriberId().
*/
void CSubscriberId::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EGetSubscriberIdCancel);
	}

