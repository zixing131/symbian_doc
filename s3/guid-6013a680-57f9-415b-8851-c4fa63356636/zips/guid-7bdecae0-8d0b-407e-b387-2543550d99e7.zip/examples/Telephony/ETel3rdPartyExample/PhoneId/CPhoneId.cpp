/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include "CPhoneId.h"

/**
Factory constructor.

@param  aController Pointer to MExecAsync object passed to constructor of 
                    CISVAPIBase
@return             Instance of CPhoneId class
*/
CPhoneId* CPhoneId::NewL(MExecSync* aController)
	{
	CPhoneId* self = new(ELeave) CPhoneId(aController);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}

/**
Destructor.
Cancels outstanding requests
*/
CPhoneId::~CPhoneId()
	{
	Cancel();
	}

/**
Gets the phone ID by calling 3rd party API function CTelephony::GetPhoneId().
*/
void CPhoneId::DoStartRequestL()
	{
	// Retrieves the model information and unique identification of the mobile device.
	iTelephony->GetPhoneId(iStatus, iPhoneIdV1Pckg);
	SetActive();
	}

/**
Default constructor.

@param aController Pointer to MExecAsync object passed to constructor of 
                   CISVAPIBase
*/
CPhoneId::CPhoneId(MExecSync* aController)
	: CISVAPISync(aController, KPhoneId),
	  iPhoneIdV1Pckg(iPhoneIdV1)
	{
	// Empty method
	}

/**
Second phase constructor.
*/
void CPhoneId::ConstructL()
	{
	// Empty method
	}

/**
Prints phone information to the console.
*/
void CPhoneId::RunL()
	{
	if(iStatus != KErrNone)
		{
		iConsole->Printf(KError);
		
		// Print the status error code
		iConsole->Printf(_L("%d\n"), iStatus.Int());
		}
	else
		{
		// Active object completed with no error, therefore print phone
		// information to the console.
		TBuf<CTelephony::KPhoneManufacturerIdSize> manufacturer = iPhoneIdV1.iManufacturer;
		TBuf<CTelephony::KPhoneModelIdSize> model = iPhoneIdV1.iModel;
		TBuf<CTelephony::KPhoneSerialNumberSize> serialNumber = iPhoneIdV1.iSerialNumber;
		iConsole->Printf(KPhoneIdMsg);
		
		// Print phone manufacturer
		iConsole->Printf(manufacturer);
		iConsole->Printf(KNewLine);
		
		// Print phone model
		iConsole->Printf(model);
		iConsole->Printf(KNewLine);
		
		// Print the IMEI or ESN serial number
		iConsole->Printf(serialNumber);
		iConsole->Printf(KNewLine);
		ExampleComplete();
		}
	}

/**
Cancels asynchronous request to CTelephony::GetPhoneId().
*/
void CPhoneId::DoCancel()
	{
	// Cancels an outstanding asynchronous request.
	iTelephony->CancelAsync(CTelephony::EGetPhoneIdCancel);
	}
