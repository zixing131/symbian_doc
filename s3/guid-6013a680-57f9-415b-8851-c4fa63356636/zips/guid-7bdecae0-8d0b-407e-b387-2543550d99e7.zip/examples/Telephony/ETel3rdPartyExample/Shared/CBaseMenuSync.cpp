/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "CBaseMenuSync.h"

/**
Completes a request so that the RunL() code of the active object is executed.

@param aErr The error code to pass to User::RequestComplete().
*/
void CBaseMenuSync::CompleteOwnRequest(TInt aErr)
	{
	TRequestStatus* s = &iStatus;
	
	// Complete an asynchronous request
	User::RequestComplete(s, aErr);
	}

/**
Starts (this) active object making it active so it can take input and perform
required functionality.
*/
void CBaseMenuSync::Start()
	{
	PostOwnRequest();
	SetActive();
	CompleteOwnRequest(KErrNone);
	}

/**
Sets its own status to KRequestPending.
*/
void CBaseMenuSync::PostOwnRequest()
	{
	iStatus = KRequestPending;
	}

/**
Ends execution of the active object.
*/
void CBaseMenuSync::Terminate()
	{
	iState = EEnd;
	CompleteOwnRequest(KErrNone);
	}

/**
Constructor.

@param aConsole Reference to console object to which output will be displayed
*/
CBaseMenuSync::CBaseMenuSync(CConsoleBase& aConsole)
	: CActive(EPriorityUserInput),
	  iState(EStart),
	  iConsole(&aConsole)
	{
	CActiveScheduler::Add(this);
	}

/**
Sets the active object state to active.
*/
void CBaseMenuSync::ExecComplete()
	{
	SetActive();
	CompleteOwnRequest(KErrNone);
	}

/**
Second phase constructor.
*/
void CBaseMenuSync::ConstructL()
	{
	iTelephony = CTelephony::NewL();
	}

/**
Destructor.
*/
CBaseMenuSync::~CBaseMenuSync()
	{
	delete iTelephony;
	}
