// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// License: "Symbian Foundation License v1.0" to Symbian Foundation
// members and "Symbian Foundation End User License Agreement v1.0"
// to non-members�at the URL
// "http://www.symbianfoundation.org/legal/licencesv10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//


#include "BmpAnimGui.h"

// Creates and returns an instance of the CApaApplication-derived class.
static CApaApplication* NewApplication()
	{
	return new CExampleApplication;
	}
	
// Standard entry point function.
TInt E32Main()
	{
	return EikStart::RunApplication( NewApplication );
	}






