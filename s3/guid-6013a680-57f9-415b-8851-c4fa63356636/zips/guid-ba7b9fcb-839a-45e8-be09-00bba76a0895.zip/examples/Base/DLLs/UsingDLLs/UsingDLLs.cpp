/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: A program which uses dynamically linked DLLs.� 
*/

// standard example header
#include "CommonFramework.h"
// f32 header needed for loading dlls.
#include <f32file.h>

#include "UsingDLLs.h"

_LIT(KTxtHarry,"Harry");
_LIT(KTxtSally,"Sally");
_LIT(KTxtDr1,"PolymorphicDLL1.DLL");
_LIT(KTxtDr2,"PolymorphicDLL2.DLL");

_LIT(KTxt1,"dynamically linked DLL example \n\n");
_LIT(KTxt2,"checking UID\n");
_LIT(KTxt3,"DLL has incorrect UID... \n");

void UseDllL(const TFileName& aDllName, const TDesC& aName);

LOCAL_C void doExampleL()
    {
	// open file server session.
	RFs fs;
	User::LeaveIfError(fs.Connect());
	console->Printf(KTxt1);
	// use each DLL in turn
	TFileName  dll;
	dll = KTxtDr1;
	UseDllL(dll, KTxtHarry);
	dll = KTxtDr2;
	UseDllL(dll, KTxtSally);
	// close the file server session.
	fs.Close();
	}

// how to use a DLL

void UseDllL(const TFileName& aLibraryName, const TDesC& aName)
	{
		// Use RLibrary object to interface to the DLL
	RLibrary library;
		// Dynamically load DLL
	User::LeaveIfError(library.Load(aLibraryName));
		// Check second UID is as expected; leave if not
	console->Printf(KTxt2);
	
	if (library.Type()[1] != KMessengerUid)
		{
		console->Printf(KTxt3);
		User::Leave(KErrGeneral);
		}
		// Function at ordinal 1 creates  new CMessenger
	TLibraryFunction entry=library.Lookup(1);
		// Call the function to create new CMessenger
	CMessenger* messenger=(CMessenger*) entry();
		// Push pointer to CMessenger onto the cleanup stack
	CleanupStack::PushL(messenger);
		// Second-phase constructor for CMessenger
	messenger->ConstructL(console, aName);
		// Use CMessenger object to issue greeting
	messenger->ShowMessage();
		// Pop CMessenger object off cleanup stack and destroy
	CleanupStack::PopAndDestroy();
		// Finished with the DLL
	library.Close();
	}
