/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: 
*/

// GCCE header
//#ifdef __GCCE__
//#include <staticlibinit_gcce.h>
//#endif //__GCCE__

//System headers
#include <string.h>
#include <stdlib.h>

//User-definied headers
#include "stringutils.h"


EXPORT_C wchar_t* tbuf16towchar(TDes& aArg)
{
	return (wchar_t*)aArg.PtrZ();
}
	
EXPORT_C char* tbuf8tochar(TDes8& aArg)
{
	return (char*)aArg.PtrZ();
}

EXPORT_C int tbuf16tochar(TDes& aSrc, char* aDes)
{
	const TUint16 *wideString = aSrc.PtrZ();
	
	TInt ret = wcstombs(aDes, (const wchar_t*)wideString, KMaxFileName );
	
	return ret;
}

EXPORT_C int tbuf8towchar(TDes8& aSrc  ,wchar_t* aDes)
{
	const char *charString = (const char*)aSrc.PtrZ();
	
	TInt ret = mbstowcs(aDes, charString, KMaxFileName );
	
	return ret;
}
	
	
EXPORT_C void tbufC16towchar(TDesC& aSrc ,wchar_t *aDes)
{
	wchar_t *temp = (wchar_t*)aSrc.Ptr();
	const TInt size = aSrc.Size();
	*(temp + size/2 ) = L'\0';
	wcscpy(aDes, temp);
}

EXPORT_C void tbufC8tochar(TDesC8& aSrc, char* aDes)
{
	char *temp = (char*)aSrc.Ptr();
	const TInt size = aSrc.Length();
	*(temp + size) = '\0';
	strcpy(aDes, temp);
}
	
EXPORT_C int tbufC16tochar(TDesC& aSrc, char* aDes)
{
	TUint16* wideString = (TUint16*)aSrc.Ptr();
	const TInt size = aSrc.Length();
	*(wideString + size) = L'\0';
	
	
	TInt ret = wcstombs(aDes, (const wchar_t*)wideString, size*2 );
	return ret;	
}


EXPORT_C int tbufC8towchar(TDesC8& aSrc, wchar_t* aDes)
{
	TUint8* charString = (TUint8*)aSrc.Ptr();
	const TInt size = aSrc.Length();
	*(charString + size) = '\0';
	
	TInt ret = mbstowcs(aDes, (const char*)charString, KMaxFileName );
	return ret;
}

EXPORT_C void wchartotbuf16(const wchar_t *aSrc, TDes16 &aDes)
{
	aDes = (const TUint16*)aSrc;
}

EXPORT_C  int chartotbuf16(const char *aSrc, TDes16 &aDes)
{
	int len = strlen(aSrc);
	wchar_t *buf = new wchar_t[len];
	
	TInt ret = mbstowcs(buf, (const char*)aSrc, len + 1 );
	
	if( ret != -1)
		aDes = (const TUint16*)buf;
	
	delete buf;
	return ret;
}

EXPORT_C int wchartotbuf8(const wchar_t *aSrc, TDes8 &aDes)
{
	int len = wcslen(aSrc);
	char *buf = new char[len];
	
	TInt ret = wcstombs(buf, (const wchar_t*)aSrc, len + 1);
	
	if( ret != -1)
		aDes = (const TUint8*)buf;
	
	delete buf;
	return ret;
}
	
EXPORT_C  void chartotbuf8 (const char *aSrc, TDes8 &aDes)
{
	aDes = (const TUint8*)aSrc;
}

EXPORT_C  void wchartohbufc16 (const wchar_t* aSrc ,HBufC16& aDes )
{
	aDes = (const TUint16*)aSrc;		
}
	
EXPORT_C int chartohbufc16(const char* aSrc, HBufC16& aDes)
{	
	int len = strlen(aSrc);
	wchar_t *buf = new wchar_t[len];
	
	TInt ret = mbstowcs(buf, (const char*)aSrc, len + 1);
	
	if( ret != -1)
		aDes = (const TUint16*)buf;
	
	delete buf;
	return ret;
}
	
EXPORT_C void chartohbufc8(const char* aSrc, HBufC8& aDes)
{
	aDes = (const TUint8*)aSrc;
}
	
EXPORT_C int wchartohbufc8(const wchar_t* aSrc, HBufC8& aDes)
{
	int len = wcslen(aSrc);
	char *buf = new char[len];
	
	TInt ret = wcstombs(buf, aSrc, len + 1 );
	
	if( ret != -1)
		aDes = (const TUint8*)buf;
	
	delete buf;
	return ret;
}

// End of file