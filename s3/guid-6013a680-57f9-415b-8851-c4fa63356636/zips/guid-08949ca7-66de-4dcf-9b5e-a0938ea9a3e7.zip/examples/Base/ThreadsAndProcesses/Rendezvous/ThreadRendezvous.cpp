/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Example to demonstrate the use of Rendezvous() with threads � 
*/



#include "CommonFramework.h"
#include <e32math.h>

//
// Common literal text
//


_LIT(KMsgMyThreadName, "MyThread");
_LIT(KMsgStartThread, "Start thread\n");
_LIT(KMsgThreadRendezvousReached,"Thread rendezvous reached\n");
_LIT(KMsgEndOfTest,"End of test\n");
_LIT(KMsgSomethingIsWrong, "Something is wrong\n");
_LIT(KMsgCreateThreadFailed, "Create thread failed\n");

//Define
const TInt KHeapSize = 0x2000;

//************************************************************
// Declare Thread functions
//************************************************************
TInt MyThread(TAny* aParameter)
	{
		// simulate some processing
	User::After((TInt)aParameter);		
			
			// signal Rendezvous
	RThread::Rendezvous(KErrNone);
	
		// simulate some processing
	User::After((TInt)aParameter);		
	
	return(KErrNone);
	}

//************************************************************
// Main example code function
//************************************************************
LOCAL_C void doExampleL()
	{				  
		// create threads to wait for
	RThread thread;

		// indicate completion status
	TRequestStatus myThreadRendezvousStatus;

		// pass 500 as the parameter to MyThread		
	TInt r=thread.Create(KMsgMyThreadName, MyThread, KDefaultStackSize, KHeapSize,KHeapSize,(TAny*) 2000000, EOwnerThread);	
	if (r!=KErrNone)
		{	
	 	console->Printf(KMsgCreateThreadFailed);
		return;
		}
		// create rendezvous
	thread.Rendezvous(myThreadRendezvousStatus);

		//EXCECUTE THREAD!
	console->Printf(KMsgStartThread);					
	thread.Resume();

	User::WaitForRequest(myThreadRendezvousStatus);
	if(myThreadRendezvousStatus==KErrNone)
		{
		console->Printf(KMsgThreadRendezvousReached);
		}
		else
		{
		console->Printf(KMsgSomethingIsWrong);	
		}	
		
	thread.Close();
	console->Printf(KMsgEndOfTest);		
	
	}


 	



	
	
