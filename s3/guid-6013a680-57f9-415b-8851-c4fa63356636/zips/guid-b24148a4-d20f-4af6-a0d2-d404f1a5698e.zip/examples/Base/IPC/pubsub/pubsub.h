/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Contains the declaration of all constants and the security policy of the property� 
*/



/**
 @file
*/
#ifndef __PUBSUB_H__
#define __PUBSUB_H__

#include <e32base.h>
#include <e32cons.h>
#include <e32property.h>

const TUint KMyPropertyName = 0x0003;
const TUid KMyPropertyCat = {0x10034567};

const TInt KArraySize = 10;
const TInt KBufSize = 20;
_LIT16(KStop,"STOP");

const TInt KMax = 100;
const TInt KTimeInterval = 3000000;

_LIT(KTxtEnter,"Press enter to publish\n");
_LIT(KTxtNewLine,"\n");
_LIT(KTxtSpecPublish,"****        PUBLISH [SPECULATIVE]        ****\n\n");
_LIT(KTxtCreateHandle,"Creating a handle to the property...\n");
_LIT(KTxtPublish,"Publishing the byte-array property...\n");
_LIT(KTxtArray,"Array contents:\n");
_LIT(KTxtArrayElement,"%x\t");
_LIT(KTxtNotFound,"Property Not Found\n");
_LIT(KTxtSpecSub,"*** SUBSCRIBER [SPECULATIVE]        ***\n");
_LIT(KTxtSpecSt,"*** SUBSCRIBER [STANDARD STATE]        ***\n");
_LIT(KTxtStPublish,"****        PUBLISH [STANDARD STATE]        ****\n\n");
_LIT(KTxtDefine,"Defining a byte-array property and allocating memory for the same...\n");
_LIT(KTxtValChange,"Value of the property : %d\n");
_LIT(KTxtPESub,"*** SUBSCRIBER [PURE EVENT] ***\n");
_LIT(KTxtPEPublish,"*** PUBLISHER [PURE EVENT] ***\n");
_LIT(KTxtInt,"Publishing : %d\n");


_LIT(KTxtEPOC32EX,"Project::Publish and Subscribe");
_LIT(KTxtExampleCode,"Publish and Subscribe Example");
_LIT(KFormatFailed,"failed: leave code=%d");
_LIT(KTxtOK,"ok");
_LIT(KTxtPressAnyKey," [press any key]");

static _LIT_SECURITY_POLICY_PASS(KAllowAllPolicy);

_LIT(KTextConsoleTitle, "Console");
_LIT(KTextFailed, " failed, leave code = %d");
_LIT(KTextPressAnyKey, " [press any key]\n");

#endif
