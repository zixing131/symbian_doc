// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <FileStore.rsg>

#include "FileStoreExternalInterface.h"
#include "FileStoreAppUi.h"
#include "FileStoreMainView.h"
#include "FileStore.hrh"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileStoreMainView* CFileStoreMainView::NewLC(CQikAppUi& aAppUi)
	{
	CFileStoreMainView* self = new (ELeave) CFileStoreMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CFileStoreMainView::CFileStoreMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileStoreMainView::~CFileStoreMainView()
	{
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CFileStoreMainView::ConstructL()
	{
	BaseConstructL();
	}
	
// --------------------------------------------------------------------------
// Called when this view is first time activated.
// --------------------------------------------------------------------------
void CFileStoreMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_FILESTORE_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EFileStoreLabelCtrl);
	}

// --------------------------------------------------------------------------
// Returns the identifier of this view.
// --------------------------------------------------------------------------
TVwsViewId CFileStoreMainView::ViewId()const
	{
	return TVwsViewId(KUidFileStoreApp, KUidFileStoreMainView);
	}

// --------------------------------------------------------------------------
// Handles user command.
// In this example, all commands are sent to AppUi because
// we want to have the same code with S60.
// --------------------------------------------------------------------------
void CFileStoreMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CFileStoreMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the label has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CFileStoreMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
