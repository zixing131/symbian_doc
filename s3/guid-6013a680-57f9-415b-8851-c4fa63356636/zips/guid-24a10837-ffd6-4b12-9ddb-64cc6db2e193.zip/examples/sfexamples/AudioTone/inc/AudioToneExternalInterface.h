// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef AUDIOTONEEXTERNALINTERFACE_H
#define AUDIOTONEEXTERNALINTERFACE_H

const TUid KUidAudioToneApp      = { 0xE21EBD4F };

const TUid KUidAudioToneMainView = { 0x00000001 };

#endif // AUDIOTONEEXTERNALINTERFACE_H

// End of File
