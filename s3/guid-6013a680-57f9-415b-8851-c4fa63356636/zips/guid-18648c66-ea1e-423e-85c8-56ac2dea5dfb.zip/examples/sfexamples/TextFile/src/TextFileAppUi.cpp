/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */ 

// INCLUDES
#include <f32file.h>
#include <TextFile.rsg>

#include "TextFileAppUi.h"
#include "TextFileMainView.h"
#include "TextFile.hrh"

// CONSTANTS
const TInt KMaxBuffer = 256;
_LIT(KSourceFileName, "c:\\data\\myfile.txt");

const TChar KDelimiter = '\f';


// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CTextFileAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	
	iMainView = CTextFileMainView::NewL(ClientRect());
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CTextFileAppUi::~CTextFileAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    iBuffer.Close();
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CTextFileAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case ETextFileReadTextFile:
			{
			RFs& fileServer = iCoeEnv->FsSession();
			
			// Delete the old string first.
			iBuffer.Close();
			iBuffer.CreateL(KNullDesC, 0);
			
			// Read the string from the file.
			ReadFromTextFileL(fileServer, KSourceFileName);
			
			// Set the text in the main view to the string.
			iMainView->SetTextL(iBuffer);
			
			iEikonEnv->InfoWinL(
				R_TEXTFILE_CAPTION, R_TEXTFILE_FILEREAD);
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}



// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CTextFileAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


// --------------------------------------------------------------------------
// Reads text file to an array.
// --------------------------------------------------------------------------
void CTextFileAppUi::ReadFromTextFileL(RFs& aFs, const TDesC& aFileName)
	{
	// Open the file for reading.
	RFile file;
	User::LeaveIfError(file.Open(aFs, aFileName, EFileRead | EFileStreamText));
	CleanupClosePushL(file);
	
	// Create a new instance of TFileText that point to file variable.
	TFileText fileText;
	fileText.Set(file);
	
	// Create a buffer to read the text file.
	TBuf<KMaxBuffer> buffer;
	
	// Loop to read the buffer. It read the buffer until err is KErrEof,
	// which means it reached end of file.
	TInt err = KErrNone;
	while (err != KErrEof)
		{
		err = fileText.Read(buffer);
		
		// If the error code is other than KErrNone or KErrEof,
		// leave this function.
		if ((err != KErrNone) && (err != KErrEof))
			{
			User::Leave(err);
			}

		if (KErrNone == err)
			{
			// Do something with the buffer.
			// In this example, we append the buffer to an array.
			iBuffer.ReAllocL(iBuffer.Length() + buffer.Length() + 1);
			iBuffer.Append(buffer);
			iBuffer.Append(KDelimiter);
			}
		}
	
	CleanupStack::PopAndDestroy(&file);
	}

// End of File
