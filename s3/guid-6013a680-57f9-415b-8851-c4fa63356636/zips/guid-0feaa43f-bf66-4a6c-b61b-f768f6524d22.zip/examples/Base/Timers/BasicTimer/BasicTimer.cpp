/*
Copyright (c) 2000-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Show how RTimer, the basic timer class, works� 
*/


#include "CommonFramework.h"


void showTimeL(TTime aTime)
	{
		// Format time, using system default locale settings
		// and then print the time using system default time
		// separator character (':') in 24 hour clock format.

	TBuf<40> timeString; // Holds the formatted date and time
	_LIT(KFormat1,"%:0%H%:1%T%:2%S%:3");
	aTime.FormatL(timeString,KFormat1);
	_LIT(KFormat2,"(24 hr clock) = %S\n");
	console->Printf(KFormat2, &timeString);
	}


void WaitForKey()
	{
	_LIT(KTxtPressAnyKey,"Press any key to continue\n\n");
	console->Printf(KTxtPressAnyKey);
	console->Getch();
	}


LOCAL_C void doExampleL()
    {
	RTimer timer;				 // The asynchronous timer and ...
	TRequestStatus timerStatus;  // ... its associated request status
	timer.CreateLocal();         // Always created for this thread.

		// do some After() requests
	_LIT(KTxt1,"Doing 10 after requests\n");
	console->Printf(KTxt1);
	for (TInt i=0; i<10; i++)
		{
			// issue and wait for single request
		timer.After(timerStatus,1000000);  // wait 1 second
		User::WaitForRequest(timerStatus); // wait for request to complete
			// display the tick count
		_LIT(KFormat3,"Request count %d\n");
		console->Printf(KFormat3, i);
		}

    WaitForKey(); // wait until a key is pressed

		// do an At() request
	TTime time; // time in microseconds since 0AD nominal Gregorian
	_LIT(KTxt2,"The time now is, ");
	console->Printf(KTxt2);
		
		// set and print current time
	time.HomeTime(); 
	showTimeL(time); 
		
		// add 10 seconds to the time
	TTimeIntervalSeconds timeIntervalSeconds(10);
	time += timeIntervalSeconds;
	_LIT(KTxt3,"Doing a request ten seconds from now at, ");
	console->Printf(KTxt3);
	showTimeL(time); // print the time the request should complete
		
		// issue and wait for single request.
		// set timer to go off in 10 seconds
	timer.At(timerStatus,time); 
	
	   // wait for request to complete
	User::WaitForRequest(timerStatus); 
		
		// say it's over, and set and print the time again
	_LIT(KTxt4,"Your 10 seconds are up\nThe time now is, ");
	console->Printf(KTxt4);
	
	   // set time to now
	time.HomeTime(); 
	
	   // print the time
	showTimeL(time); 
		
		// close timer
	timer.Close();
	}

