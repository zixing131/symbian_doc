/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include <eikenv.h>
#include <gdi.h>
#include <AknUtils.h>

#include "DBMSAppView.h"

// ---------------------------------------------------------------------------
// CDBMSAppUi::NewL()
//
// Create instance of this view.
// ---------------------------------------------------------------------------
CDBMSAppView* CDBMSAppView::NewL(const TRect& aRect)
    {
    CDBMSAppView* self = new (ELeave) CDBMSAppView;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    CleanupStack::Pop(self);
    return self;
    }

// ---------------------------------------------------------------------------
// CDBMSAppUi::ConstructL()
//
// Perform the second phase construction.
// ---------------------------------------------------------------------------
void CDBMSAppView::ConstructL(const TRect& aRect)
    {
    // Create a window for this application view
    CreateWindowL();

    // Set the windows size
    SetRect(aRect);

    ActivateL();
    }

// ---------------------------------------------------------------------------
// CDBMSAppUi::CDBMSAppView()
//
// Constructor
// ---------------------------------------------------------------------------
CDBMSAppView::CDBMSAppView()
    {
    // No implementation required
    }


// ---------------------------------------------------------------------------
// CDBMSAppUi::~CDBMSAppView()
//
// Desctructor
// ---------------------------------------------------------------------------
CDBMSAppView::~CDBMSAppView()
    {
    }

// ---------------------------------------------------------------------------
// CDBMSAppUi::Draw()
//
// Draw the view. Show simple "DBMS" text in the center of the view.
// This is called by the framework, when necessary.
// ---------------------------------------------------------------------------
void CDBMSAppView::Draw(const TRect& /*aRect*/) const
    {
    _LIT(KText,"DBMS");

    CWindowGc& gc = SystemGc(); // Window graphics context
    TRect drawRect = Rect();    // Area in which we shall draw
    const CFont* fontUsed = iEikonEnv->TitleFont();
    gc.Clear();                 // Start with a clear screen

    // Draw an outline rectangle slightly smaller than the drawing area.
    drawRect.Shrink(10,10);
    gc.DrawRect(drawRect);
    gc.UseFont(fontUsed);
               // Draw the text in the middle of the rectangle.
    TInt baselineOffset=(drawRect.Height() - fontUsed->HeightInPixels())/2;
    gc.DrawText(KText, drawRect, baselineOffset, CGraphicsContext::ECenter, 0);
               // Finished using the font
    gc.DiscardFont();
    }


