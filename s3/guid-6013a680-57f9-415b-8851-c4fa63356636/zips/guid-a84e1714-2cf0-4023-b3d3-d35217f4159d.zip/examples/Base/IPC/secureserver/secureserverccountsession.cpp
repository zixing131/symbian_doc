/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Contains the implementation of functions described in the CSecureServerSession class.� 
*/



/**
 @file
*/
#include "secureclientandserver.h"
#include "secureserver.h"

/**
Constructor of the CSecureServerSession class.
*/
CSecureServerSession::CSecureServerSession()
	{
	}

/**
Creates the object index and object container for the session.
*/
void CSecureServerSession::CreateL()
	{
	iCountersObjectIndex = CObjectIx::NewL();
	iContainer=((CSecureServer*)Server())->NewContainerL();
	}

/**
Closes the session.
This function deletes the object index and object container.
*/
void CSecureServerSession::CloseSession()
	{
	delete iCountersObjectIndex;
	iCountersObjectIndex = NULL;
	((CSecureServer*)Server())->RemoveContainer(iContainer);
	iContainer = NULL;
	}

/**
Returns the appropriate CCountSubSession object given a client's sub session handle.
@param aMessage The request message.
@param aHandle Client's sub session handle.
@return The CCountSubSession object.
*/
CSecureServerSubSession* CSecureServerSession::CounterFromHandle(const RMessage2& aMessage,TInt aHandle)
	{
	CSecureServerSubSession* counter = (CSecureServerSubSession*)iCountersObjectIndex->At(aHandle);
	if (counter == NULL)
		{
		PanicClient(aMessage, EBadSubsessionHandle);
		}
	return counter;
	}

/**
Handles the servicing of a client request that has been passed to the server.
This function dispatches requests to the appropriate handler.
Some messages are handled by the session itself, and are implemented as CSecureServerSession member functions.
Other messages are handled by the subsession, and are implemented as CSecureServerSubSession member functions.
Note that the server calls this function after a client request has passed the security checks.
@param aMessage The message containing the details of the client request.
*/
void CSecureServerSession::ServiceL(const RMessage2& aMessage)
	{
	// Check if the message is intended to the parent session.
	switch (aMessage.Function())
		{
	case ESecureServerCreateSubSession:
		NewCounterL(aMessage);
		aMessage.Complete(KErrNone);
		return;
	case ESecureServerCloseSession:
		CloseSession();
		aMessage.Complete(KErrNone);
		return;
	case ESecureServerResourceCount:
		NumResourcesL(aMessage);
		aMessage.Complete(KErrNone);
		return;
		}
	// Check if the message is intended to a sub session.
	CSecureServerSubSession* counter=CounterFromHandle(aMessage,aMessage.Int3());
	switch (aMessage.Function())
		{
		case ESecureServerInitSubSession:
			counter->SetFromStringL(aMessage);
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerCloseSubSession:
			DeleteCounter(aMessage.Int3());
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerIncrease:
			counter->Increase();
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerIncreaseBy:
			counter->IncreaseBy(aMessage);
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerDecrease:
			counter->Decrease();
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerDecreaseBy:
			counter->DecreaseBy(aMessage);
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerReset:
			counter->Reset();
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerValue:
			counter->CounterValueL(aMessage);
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerSaveCounter:
			counter->SaveCounterValueL();
			aMessage.Complete(KErrNone);
			return;
		case ESecureServerSetCounterFromFile:
			counter->SetCounterValueFromFileL();
			aMessage.Complete(KErrNone);
			return;
		default:
			PanicClient(aMessage,EBadRequest);
			return;
		}
	}

/**
Creates a new sub session for the current session.
@param aMessage The message containing the details of the client request.
*/
void CSecureServerSession::NewCounterL(const RMessage2& aMessage)
	{
	// Create a sub session object and add it to the container index.
	CSecureServerSubSession* counter = new (ELeave) CSecureServerSubSession(this);
	iContainer->AddL(counter);

	TInt handle=iCountersObjectIndex->AddL(counter);
	TPckgBuf<TInt> handlePckg(handle);
	TRAPD(res,aMessage.WriteL(3,handlePckg));
	if (res!=KErrNone)
		{
		iCountersObjectIndex->Remove(handle);
		PanicClient(aMessage,EDescriptorNonNumeric);
		return;
		}
	// For every new sub session created, increase the resource count.
	iResourceCount++;
	}

/**
Deletes the sub session object.
@param aHandle The handle to the sub session object.
*/
void CSecureServerSession::DeleteCounter(TInt aHandle)
	{
	iCountersObjectIndex->Remove(aHandle);
	// For every new sub session deleted, decrease the resource count.
	iResourceCount --;
	}

/**
Gets the number of resources held by the session.
@return The number of resources held by the session.
*/
TInt CSecureServerSession::CountResources()
	{
	return iResourceCount;
	}

/**
Returns the resource count to the client by writing the resource count value into the client message.
@param aMessage The message containing the details of the client request.
*/
void CSecureServerSession::NumResourcesL(const RMessage2& aMessage)
	{
	TPckgBuf<TInt> resourcesPckg(iResourceCount);
	aMessage.WriteL(0,resourcesPckg);
	}

/**
Panics the client.
@param aMessage The message containing the details of the client request.
@param aPanic The reason for the panic.
*/
void CSecureServerSession::PanicClient(const RMessage2& aMessage,TInt aPanic) const
	{
	_LIT(KTxtServer,"SecureServer");
	aMessage.Panic(KTxtServer,aPanic);
	}
