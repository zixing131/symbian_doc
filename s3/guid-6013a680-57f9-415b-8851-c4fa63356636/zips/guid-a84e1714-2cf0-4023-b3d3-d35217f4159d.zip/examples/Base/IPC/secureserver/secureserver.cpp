/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Contains the implementation of functions described in the CSecureServer class.� 
*/



/**
 @file
*/
#include "secureclientandserver.h"
#include "secureserver.h"

/**
The thread function that makes the server ready for use.
The Symbian platform calls the function when the server thread starts to run.
This is a static function, and it
- creates the server object
- creates the server�s active scheduler
- starts the server�s active scheduler
@return KErrNone.
*/
TInt CSecureServer::ThreadFunction(TAny* /**aStarted*/)
	{
	TInt err;
	CTrapCleanup* cleanup = CTrapCleanup::New();
	if (cleanup == NULL)
		{
		PanicServer(ECreateTrapCleanup);
		}

	CActiveScheduler* pScheduler=new CActiveScheduler;
	__ASSERT_ALWAYS(pScheduler,PanicServer(EMainSchedulerError));
	CActiveScheduler::Install(pScheduler);

	CSecureServer* pServer = NULL;
	TRAP(err,pServer = CSecureServer::NewL(EPriorityStandard));
	__ASSERT_ALWAYS(!err,CSecureServer::PanicServer(EServerCreateServer));

	err = pServer->Start(KSecureServerName);
	if (err != KErrNone)
		{
		CSecureServer::PanicServer(EServerStartServer);
		}

	RThread::Rendezvous(KErrNone);
	CActiveScheduler::Start();

	delete pServer;
	delete pScheduler;
	delete cleanup;

	return KErrNone;
	}

/**
Creates the server thread.
If the server is not running, the function starts the server thread. The function CSecureServer::ThreadFunction() contains the code that is called when the server thread starts.
@param aServerThread The handle to the server thread.
@return KErrNone if successful, or an error code returned by RThread::Create().
@see CSecureServer::ThreadFunction()
*/
EXPORT_C TInt StartThread(RThread& aServerThread)
	{
	TInt res=KErrNone;
	TFindServer findCountServer(KSecureServerName);
	TFullName   name;
	if (findCountServer.Next(name)!=KErrNone)
		{
			res=aServerThread.Create(KSecureServerName,
			CSecureServer::ThreadFunction,
			KDefaultStackSize,
			KDefaultHeapSize,
			KDefaultHeapSize,
			NULL
			);
		if (res==KErrNone)
			{
			TRequestStatus rendezvousStatus;
			aServerThread.SetPriority(EPriorityNormal);
			aServerThread.Rendezvous(rendezvousStatus);
			aServerThread.Resume();
			User::WaitForRequest(rendezvousStatus);
			}
		else
			{
			aServerThread.Close();
			}
		}
	return res;
	}
