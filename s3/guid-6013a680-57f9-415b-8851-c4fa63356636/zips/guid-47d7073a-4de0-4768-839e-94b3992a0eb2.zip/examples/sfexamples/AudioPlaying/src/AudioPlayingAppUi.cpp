// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <eikapp.h>
#include <AudioPlaying.rsg>

#include "AudioPlayingAppUi.h"
#include "AudioPlayingMainView.h"
#include "SimpleAudioPlayer.h"
#include "AudioPlaying.hrh"

// CONSTANTS
_LIT(KFileName, "\\data\\sample.wav");

// METHODS DEFINITION

void CAudioPlayingAppUi::ConstructL()
	{


	BaseConstructL(EAknEnableSkin);
	
	iMainView = CAudioPlayingMainView::NewL(ClientRect());

	
	iAudioPlayer = CSimpleAudioPlayer::NewL();
	}
	
CAudioPlayingAppUi::~CAudioPlayingAppUi()
    {
    delete iAudioPlayer;
    

    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }

    }

void CAudioPlayingAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{

		case EAknSoftkeyExit:

		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EAudioPlayingPlayFromFile:
			{
			// Construct file name.
			// It adds drive letter to KFileName, where drive letter
			// is the same as the application's executable.
			TParsePtrC parseAppPath(Application()->AppFullName());
			TParse parseFileName;
			parseFileName.Set(parseAppPath.Drive(), 0, &KFileName);
			
			// Play the audio file.
			iAudioPlayer->PlayL(parseFileName.FullName());
			break;
			}
			
		case EAudioPlayingPause:
			{
			iAudioPlayer->Pause();
			break;
			}
			
		case EAudioPlayingResume:
			{
			iAudioPlayer->Resume();
			break;
			}
			
		case EAudioPlayingStop:
			{
			iAudioPlayer->Stop();
			break;
			}
			
		case EAudioPlayingRewind:
			{
			iAudioPlayer->Rewind(5);
			break;
			}
			
		case EAudioPlayingFastForward:
			{
			iAudioPlayer->FastForward(5);
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}

	


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CAudioPlayingAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


	
// End of File
