// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <AudioPlaying.rsg>

#include "AudioPlayingExternalInterface.h"
#include "AudioPlayingAppUi.h"
#include "AudioPlayingMainView.h"
#include "AudioPlaying.hrh"

// MEMBER FUNCTIONS

CAudioPlayingMainView* CAudioPlayingMainView::NewLC(CQikAppUi& aAppUi)
	{
	CAudioPlayingMainView* self = new (ELeave) CAudioPlayingMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

CAudioPlayingMainView::CAudioPlayingMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

CAudioPlayingMainView::~CAudioPlayingMainView()
	{
	}

void CAudioPlayingMainView::ConstructL()
	{
	BaseConstructL();
	
	SetExtentToWholeScreen();
	}
	
void CAudioPlayingMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_AUDIOPLAYING_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EAudioPlayingLabelCtrl);
	}

TVwsViewId CAudioPlayingMainView::ViewId()const
	{
	return TVwsViewId(KUidAudioPlayingApp, KUidAudioPlayingMainView);
	}

void CAudioPlayingMainView::HandleCommandL(CQikCommand& aCommand)
	{
	// Handle the user command in the AppUi because we want to have
	// the same code for S60 and UIQ.
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

void CAudioPlayingMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

void CAudioPlayingMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
