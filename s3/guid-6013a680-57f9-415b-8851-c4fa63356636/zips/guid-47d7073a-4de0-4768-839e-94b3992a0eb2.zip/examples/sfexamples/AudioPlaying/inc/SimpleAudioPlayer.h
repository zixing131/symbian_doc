// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef SIMPLEAUDIOPLAYER_H
#define SIMPLEAUDIOPLAYER_H

// INCLUDES
#include <e32std.h>
#include <e32base.h>
#include <MdaAudioSamplePlayer.h>

// CLASS DECLARATION

class CSimpleAudioPlayer : public CBase, public MMdaAudioPlayerCallback
	{
public: // Constructors and destructor
	static CSimpleAudioPlayer* NewL();
	static CSimpleAudioPlayer* NewLC();
	~CSimpleAudioPlayer();

public: // New methods
	void PlayL(const TDesC& aFileName);
	void Resume();
	void Pause();
	void Stop();
	void Rewind(TInt aIntervalInSeconds);
	void FastForward(TInt aIntervalInSeconds);
	
private:
	CSimpleAudioPlayer();
	void ConstructL();

private:// From MMdaAudioPlayerCallback
	void MapcInitComplete(TInt aError,
			const TTimeIntervalMicroSeconds& /*aDuration*/);
	void MapcPlayComplete(TInt aError);

private: // Public methods
	void DisplayErrorMessage(TInt aError);
	
private: // Member variables
	CMdaAudioPlayerUtility* iPlayerUtility;
	};

#endif // SIMPLEAUDIOPLAYER_H

// End of File
