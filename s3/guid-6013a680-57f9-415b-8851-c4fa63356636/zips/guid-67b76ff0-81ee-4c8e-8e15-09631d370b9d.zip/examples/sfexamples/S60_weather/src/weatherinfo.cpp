/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


/*===========================================================================
     This file contains the active object for collecting the weather info
     from the network.

     The sequence of events to collect the temparature is started by the
     GetTemperature() method and issueing the host resolve.  When that is complete
     RunL() is invoked and the next network call in the sequence and is called and so on
     until temperature is retrieved. 
============================================================================*/

#include "weatherinfo.h"

CWeatherInfo* CWeatherInfo::NewL(MWeatherObserver& aObserver)
    {    
    CWeatherInfo* self = new(ELeave) CWeatherInfo(aObserver);
    CActiveScheduler::Add(self);
    return self;
    }

// This isn't a UI object, but is performing background network retrieval so
// doesn't need user input priority...or does it?
CWeatherInfo::CWeatherInfo(MWeatherObserver& aObserver) 
    : CActive(CActive::EPriorityStandard), iObserver(aObserver)
{}


void CWeatherInfo::GetTemperature(const TDesC& aCity)
    {
// if we are already in the middle of getting the temperature, then
// return.
    if (IsActive())
        return;
       
    iCommState=EInitializing;

    TInt res =iSocketSrv.Connect();
    if (res != KErrNone)
        {
        Cleanup(res);  
        return;
        }
   
    iCityCode.Copy(aCity);
/*-------------------------------------------------------------------------------------
   Use the RConnection API to start the network connection if not already started.
------------------------------------------------------------------------------------- */
    res = iConnection.Open(iSocketSrv);
    if (res != KErrNone)
        {
        Cleanup(res);
        return;
        }
    res = iConnection.Start();
    if (res != KErrNone)
        {
        Cleanup(res);
        return;
        }
/*------------------------------------------------------------------------------------
    Open the socket.
------------------------------------------------------------------------------------*/
        iSocket.Open(iSocketSrv,KAfInet,KSockStream,KProtocolInetTcp,iConnection);  
        if (res != KErrNone)
            {
            Cleanup(res); 	  
            return;
            }
      
/* Resolve name, rest handled by RunL() */
 
        res = iResolver.Open(iSocketSrv, KAfInet, KProtocolInetTcp,iConnection);
        if (res != KErrNone)
            {
            Cleanup(res);  
            return;
            }
        iCommState=EResolvingName;
       
        _LIT(KWeatherServerName,"rainmaker.wunderground.com");
        iResolver.GetByName(KWeatherServerName, iNameEntry, iStatus);
        SetActive();       
        }

CWeatherInfo::~CWeatherInfo()
    {
    // Make sure we're cancelled
    Cancel();
    }

void CWeatherInfo::RunL()
    {
    if (iStatus != KErrNone)
        {
        Cleanup(iStatus.Int());  
        }
    else
        {
        switch(iCommState)
            {
            case  EResolvingName:
                {
                TInetAddr destAddr;
                destAddr=iNameEntry().iAddr;
                destAddr.SetPort(3000);

                // Connect to the remote host
                iCommState=EConnecting;
                iSocket.Connect(destAddr,iStatus);
                SetActive();
                break;
                }
            case EConnecting:
                {
                _LIT(KCRLF,"\xD\xA");

                TBuf8<300> getBuff;
                getBuff.Copy(KCRLF);
                getBuff.Append(iCityCode);
                getBuff.Append(KCRLF);
                
                iCommState=ESending;
                iSocket.Send(getBuff,0,iStatus);
                SetActive();
                break;
                }
            case ESending:
                {
              // Start receiving
              
                iCommState=EReceiving;
             
                iSocket.RecvOneOrMore(iNetBuff,0,iStatus,iLen);
                SetActive();
                break;             
                }
           case EReceiving:
                {
/*------------------------------------------------------------------- 
   The rainmaker.wunderground.com line with the temperature starts 
   after a line filled with '='s. 
-------------------------------------------------------------------*/
                _LIT8(KFileTok,"=\xA");
                TInt pos = iNetBuff.FindF(KFileTok);
                TBuf<100> temp;
                if (pos != KErrNotFound)
                    {
                    temp.Copy(iNetBuff.Mid(pos+2,10));
                    temp.Trim();
                    iObserver.TemperatureReport(iCityCode,temp);  
                    Cleanup(KErrNone);
                    } 
                else
                    {                 
                    iSocket.RecvOneOrMore(iNetBuff,0,iStatus,iLen);
                    SetActive();
                    }
                break;
                }  
            default:
                ASSERT(EFalse);	//	Should never get here
            }            
        }
    }

void CWeatherInfo::DoCancel()
    {
    iSocket.CancelAll();
    Cleanup(KErrCancel);
    }

void CWeatherInfo::Cleanup(TInt aError)
    {
    iSocket.Close();
    iResolver.Close();	
    iConnection.Close();
    iSocketSrv.Close();

    TBuf<50> errStr;
    if (aError!=KErrNone)
        {
        switch (iCommState)
            {
            case EInitializing:
                {
                _LIT(KErrStr,"Error initializing communications");
                errStr.Copy(KErrStr);
                break;
                }
            case EResolvingName:
                {
                _LIT(KErrStr,"Error resolving name");
                errStr.Copy(KErrStr);
                break;
                }
            case EConnecting:
                {
                _LIT(KErrStr,"Error connecting to server");
                errStr.Copy(KErrStr);
                break;
                }
            case ESending:
                {
                _LIT(KErrStr,"Error sending request");
                errStr.Copy(KErrStr);
                break;
                }   
            case EReceiving:
                {
                _LIT(KErrStr,"Error receiving data");
                errStr.Copy(KErrStr);
                break;
                }
            default:
                {
                _LIT(KErrStr,"Unknown error");
                errStr.Copy(KErrStr);
                break;
                }
            }
        iObserver.TemperatureError(errStr,aError);
        }
    }   

