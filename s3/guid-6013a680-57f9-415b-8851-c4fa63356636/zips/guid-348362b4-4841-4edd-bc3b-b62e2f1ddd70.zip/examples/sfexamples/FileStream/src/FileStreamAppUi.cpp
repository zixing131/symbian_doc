/*
 * Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */  

// INCLUDES
#include <bautils.h>
#include <FileStream.rsg>

#include "FileStreamAppUi.h"
#include "FileStreamMainView.h"
#include "FileStream.hrh"
#include "employee.h"

// CONSTANTS
_LIT(KInt32FileName,    "c:\\data\\myfile.dat");
_LIT(KEmployeeFileName, "c:\\data\\employee.dat");

_LIT(KName,        "John Doe");
_LIT(KPhoneNumber, "+1-222-333-444");


const TChar KEndOfLine = '\f';


const TInt KMaxNumber = 10;  // maximum length of a number
const TInt KMaxBuffer = 100; // maximum length of buffer

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CFileStreamAppUi::ConstructL()
	{


	BaseConstructL(EAknEnableSkin);
	
	iMainView = CFileStreamMainView::NewL(ClientRect());
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileStreamAppUi::~CFileStreamAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CFileStreamAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
			
		case EFileStreamWriteInt32:
			{
			// Write a TInt32 to the stream.
			const TInt32 x = 12345; // new integer to be written
			WriteInt32ToStreamL(iCoeEnv->FsSession(), KInt32FileName, x);
			
			// Display a message on the main view.
			HBufC* message = iCoeEnv->AllocReadResourceLC(
					R_FILESTREAM_INT32WRITTEN);
			iMainView->SetTextL(*message);
			CleanupStack::PopAndDestroy(message);
			break;
			}
			
		case EFileStreamReadInt32:
			{
			// Read a TInt32 from the stream.
			TInt32 x = ReadInt32FromStreamL(iCoeEnv->FsSession(),
					KInt32FileName);
			
			// Display the number on the main view.
			TBuf<KMaxNumber> buffer;
			buffer.AppendNum(x);
			iMainView->SetTextL(buffer);
			break;
			}
			
		case EFileStreamAppendInt32:
			{
			// Write a TInt32 to the stream.
			const TInt32 x = 98765; // new integer to be appended
			AppendInt32ToStreamL(iCoeEnv->FsSession(), KInt32FileName, x);
			
			// Display a message on the main view.
			HBufC* message = iCoeEnv->AllocReadResourceLC(
					R_FILESTREAM_INT32APPENDED);
			iMainView->SetTextL(*message);
			CleanupStack::PopAndDestroy(message);
			break;
			}
			
		case EFileStreamReadAllInt32:
			{
			// Create an array.
			RArray<TInt> array;
			CleanupClosePushL(array);
			
			// Read all TInt32's from the file.
			ReadAllTInt32FromStreamL(iCoeEnv->FsSession(), KInt32FileName, array);
			
			// Display all TInt32's on the main view.
			RBuf buffer;
			buffer.CreateL(KMaxBuffer);
			CleanupClosePushL(buffer);
			for (TInt i = 0; i < array.Count(); i++)
				{
				// CAUTION: This code does not check whether there is enough
				// space in the buffer. If the buffer is not enough, this code
				// will panic (USER 11).
				buffer.AppendNum(array[i]);
				buffer.Append(KEndOfLine);
				}
			iMainView->SetTextL(buffer);

			CleanupStack::PopAndDestroy(2, &array); // buffer and array
			
			break;
			}
		
		case EFileStreamWriteEmployee:
			{
			CEmployee* employee = new (ELeave) CEmployee();
			CleanupStack::PushL(employee);
			
			// Add a new employee.
			employee->SetIdentifier(1);
			employee->SetName(KName);
			employee->SetPhoneNumber(KPhoneNumber);
			WriteEmployeeToStreamL(iCoeEnv->FsSession(), KEmployeeFileName,
					*employee);
			
			CleanupStack::PopAndDestroy(employee);
			
			// Display a message on the main view.
			HBufC* message = iCoeEnv->AllocReadResourceLC(
					R_FILESTREAM_EMPLOYEEWRITTEN);
			iMainView->SetTextL(*message);
			CleanupStack::PopAndDestroy(message);
			break;
			}
			
		case EFileStreamReadEmployee:
			{
			CEmployee* employee = new (ELeave) CEmployee();
			CleanupStack::PushL(employee);
			
			// Read an employee.
			ReadEmployeeFromStreamL(iCoeEnv->FsSession(), KEmployeeFileName,
					*employee);
			
			// Display a message on the main view.
			RBuf buffer;
			buffer.CreateL(KMaxBuffer);
			CleanupClosePushL(buffer);
			buffer.AppendNum(employee->Identifier());
			buffer.Append(KEndOfLine);
			buffer.Append(employee->Name());
			buffer.Append(KEndOfLine);
			buffer.Append(employee->PhoneNumber());
			buffer.Append(KEndOfLine);
			iMainView->SetTextL(buffer);
			
			CleanupStack::PopAndDestroy(2, employee); // buffer and employee
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}



// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CFileStreamAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


void CFileStreamAppUi::WriteInt32ToStreamL(RFs& aFs,
		const TDesC& aFileName, TInt32 aValue)
	{
	// Open the file stream.
	RFileWriteStream writeStream;
	User::LeaveIfError(writeStream.Replace(aFs, aFileName, EFileWrite));
	writeStream.PushL();
	
	// Write a TInt32 to the stream.
	writeStream.WriteInt32L(aValue);
	
	// Commit the change and close the stream.
	writeStream.CommitL();
	CleanupStack::Pop(&writeStream);
	writeStream.Release();
	}

TInt32 CFileStreamAppUi::ReadInt32FromStreamL(RFs& aFs,
		const TDesC& aFileName)
	{
	// Open the file stream.
	RFileReadStream readStream;
	User::LeaveIfError(readStream.Open(aFs, aFileName, EFileRead));
	CleanupClosePushL(readStream);

	// Read a TInt32 from the stream.
	TInt32 value;
	readStream >> value;
	
	// Close the stream and return the read TInt32.
	CleanupStack::PopAndDestroy(&readStream);
	return value;
	}

void CFileStreamAppUi::AppendInt32ToStreamL(RFs& aFs,
		const TDesC& aFileName, TInt32 aValue)
	{
	// Open the file stream.
	RFileWriteStream writeStream;
	TInt err = KErrNone;
	if (BaflUtils::FileExists(iCoeEnv->FsSession(), aFileName))
		{
		err = writeStream.Open(aFs, aFileName, EFileWrite);
		}
	else
		{
		err = writeStream.Create(aFs, aFileName, EFileWrite);
		}
	User::LeaveIfError(err);
	writeStream.PushL();
	
	// Move the file pointer to the end of file.
	writeStream.Sink()->SeekL(MStreamBuf::EWrite, EStreamEnd, 0);
	
	// Write a TInt32 at the end of file.
	writeStream.WriteInt32L(aValue);
	
	// Commit the change and close the file.
	writeStream.CommitL();
	CleanupStack::Pop(&writeStream);
	writeStream.Release();
	}

void CFileStreamAppUi::ReadAllTInt32FromStreamL(RFs& aFs,
		const TDesC& aFileName, RArray<TInt>& aArray)
	{
	// Open the file stream.
	RFileReadStream readStream;
	User::LeaveIfError(readStream.Open(aFs, aFileName, EFileRead));
	CleanupClosePushL(readStream);

	// Get the EOF position.
	TStreamPos eofPos(readStream.Source()->SizeL());
	
	// Get the current position of file pointer.
	TStreamPos currentPos(0);

	// Read all TInt2's until EOF.
	while (currentPos < eofPos)
		{
		TInt32 value;
		readStream >> value;
		aArray.Append(value);
		
		currentPos = readStream.Source()->TellL(MStreamBuf::ERead);
		}
	
	CleanupStack::PopAndDestroy(&readStream);
	}

void CFileStreamAppUi::WriteEmployeeToStreamL(RFs& aFs, const TDesC& aFileName,
		const CEmployee& aEmployee)
	{
	// Open the file stream.
	RFileWriteStream writeStream;
	User::LeaveIfError(writeStream.Replace(aFs, aFileName, EFileWrite));
	CleanupClosePushL(writeStream);
	
	// Write employee to the stream.
	writeStream << aEmployee;
	
	// Commit the change and close the file.
	writeStream.CommitL();
	CleanupStack::PopAndDestroy(&writeStream);
	}

void CFileStreamAppUi::ReadEmployeeFromStreamL(RFs& aFs, const TDesC& aFileName,
		CEmployee& aEmployee)
	{
	// Open the file stream.
	RFileReadStream readStream;
	User::LeaveIfError(readStream.Open(aFs, aFileName, EFileRead));
	CleanupClosePushL(readStream);
	
	// Read a employee from the stream.
	readStream >> aEmployee;
	
	// Close the stream.
	CleanupStack::PopAndDestroy(&readStream);
	}

// End of File
