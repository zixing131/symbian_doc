/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include <QMenuBar>
#include <QTextEdit>
#include <QAction>

#include "nfctagswindow.h"
#include "nfctagsdiscovery.h"

/*
 * Initialize the window for the application, establish the 
 * necessary connections.
 * Create the wrapper class and establish its connections.
 */
NfcTagsWindow::NfcTagsWindow(QWidget *parent) :
    QMainWindow(parent),mDiscovery(false)
{
    addMenu();
    initializeWindow();
    
    mNfcTagsDiscovery = new NfcTagsDiscovery();
    
    //Connect slots for update of new devices, discovery starting and completion, and errors
    connect(mNfcTagsDiscovery,SIGNAL(showMessage(QString)),this, SLOT(showMessage(QString)));
    connect(mNfcTagsDiscovery,SIGNAL(changeMenu(int)),this, SLOT(changeMenu(int)));
    connect(mNfcTagsDiscovery,SIGNAL(clearText()),this, SLOT(clearText()));
}

/*
 * Add items to the menu of the main window.
 */
void NfcTagsWindow::addMenu() 
{
    // Add menu item, establish connection for it.
    mStartTagDiscovery = new QAction("Start Tag Discovery",this);
    connect(mStartTagDiscovery, SIGNAL(triggered()), this, SLOT(startTagDiscovery()));
    menuBar()->addAction(mStartTagDiscovery);

    
    mStopTagDiscovery = new QAction("Stop Tag Discovery",this);
    connect(mStopTagDiscovery, SIGNAL(triggered()), this, SLOT(stopTagDiscovery()));
    menuBar()->addAction(mStopTagDiscovery);
    // Set to invisible.
    mStopTagDiscovery->setVisible(false);
    
    mStartNdefDiscovery = new QAction("Start Ndef Discovery",this);
    connect(mStartNdefDiscovery, SIGNAL(triggered()), this, SLOT(startNdefDiscovery()));
    menuBar()->addAction(mStartNdefDiscovery);

    
    mStopNdefDiscovery = new QAction("Stop Ndef Discovery",this);
    connect(mStopNdefDiscovery, SIGNAL(triggered()), this, SLOT(stopNdefDiscovery()));
    menuBar()->addAction(mStopNdefDiscovery);  
    mStopNdefDiscovery->setVisible(false);
}

// Close the application.
void NfcTagsWindow::closeEvent(QCloseEvent *event) 
{
    if(mDiscovery){
    // Stop Tag/NDEF discovery
    mNfcTagsDiscovery->stopTagDiscovery();
    }
}

/*
 * Add a text edit widget to the main window.
 * Output text is displayed in this text edit widget.
 */
void NfcTagsWindow::initializeWindow() 
{    
    mDisplayInfo = new QTextEdit();
    mDisplayInfo->setText("Detected nfc tags information is \n"
            "displayed here.");
    mDisplayInfo->setWordWrapMode(QTextOption::WordWrap);
    // This is a read-only text.
    mDisplayInfo->setReadOnly(true);
    setCentralWidget(mDisplayInfo);
}

// Start tag discovery.
void NfcTagsWindow::startTagDiscovery() 
{
    mDiscovery = true;
    mNfcTagsDiscovery->startTagDiscovery();
}

// Stop tag discovery.
void NfcTagsWindow::stopTagDiscovery() 
{
    mDiscovery = false;
    mNfcTagsDiscovery->stopTagDiscovery();
}

// Search for NDEF messages.
void NfcTagsWindow::startNdefDiscovery() 
{
    mDiscovery = true;
    mNfcTagsDiscovery->startNdefDiscovery();
}

// Stop NDEF discovery.
void NfcTagsWindow::stopNdefDiscovery() 
{
    mDiscovery = false;
    mNfcTagsDiscovery->stopNdefDiscovery();
}

void NfcTagsWindow::changeMenu(int option) 
{
   switch(option) 
       {
       case 0:
           mStartTagDiscovery->setVisible(false);
           mStopTagDiscovery->setVisible(true);
           mStartNdefDiscovery->setVisible(false);
           mStopNdefDiscovery->setVisible(false);
           break;
           
       case 1:
           mStartTagDiscovery->setVisible(false);
           mStopTagDiscovery->setVisible(false);
           mStartNdefDiscovery->setVisible(false);
           mStopNdefDiscovery->setVisible(true);
           break;
       
       case 2:
            mStartTagDiscovery->setVisible(false);
            mStopTagDiscovery->setVisible(false);
            mStartNdefDiscovery->setVisible(false);
            mStopNdefDiscovery->setVisible(true);
            break;

       case 3:
       case 4:
           mStartTagDiscovery->setVisible(true);
           mStopTagDiscovery->setVisible(false);
           mStartNdefDiscovery->setVisible(true);
           mStopNdefDiscovery->setVisible(false);
           break;
       };
   
}


// Clear the text in the window.
void NfcTagsWindow::clearText() 
{
    mText.clear();
    mDisplayInfo->setText(mText);
}

// Show the message on the window.
void NfcTagsWindow::showMessage(QString aDisplayMsg)
{ 
   mText.append(aDisplayMsg);
   // Write the text to the text edit item.
   mDisplayInfo->setText(mText);
}
