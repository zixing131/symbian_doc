/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description: Wrapper class.  
 */

#ifndef NFCTAGSDISCOVERY_H_
#define NFCTAGSDISCOVERY_H_

#include <QObject>
#include "nfctagswindow.h"

// FORWARD DECLARATIONS
class NfcTagsDiscoveryPrivate;

/*
 * This is the wrapper class, calls from the UI are routed
 * to the engine through this class methods.
 */
class NfcTagsDiscovery: public QObject
	{
	Q_OBJECT
    
public:
	NfcTagsDiscovery();
    virtual ~NfcTagsDiscovery();
    
    enum StopDiscovery{
        EStopTagDiscovery = 3,
        EStopNdefDiscovery
    };
    
    void startTagDiscovery();
    void stopTagDiscovery();
    void startNdefDiscovery();
    void stopNdefDiscovery();
    
signals: 
    void clearText();
    void changeMenu(int aOption);
	void showMessage(QString aDisplayInfo);

private: 
	NfcTagsDiscoveryPrivate *d_ptr;  //pointer to implementation

private:    // Friend class definitions
    friend class NfcTagsDiscoveryPrivate;
	};


#endif /* NFCTAGSDISCOVERY_H_ */
