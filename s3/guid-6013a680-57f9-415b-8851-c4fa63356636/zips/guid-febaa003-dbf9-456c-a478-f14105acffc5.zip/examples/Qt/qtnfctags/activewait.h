/*
* Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of "Eclipse Public License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.eclipse.org/legal/epl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:  ActiveWait
*
*/


#ifndef C_ACTIVEWAIT_H
#define C_ACTIVEWAIT_H

#include "nfctagsdiscovery_symbian.h"
#include <e32base.h>


/**
 * Active object waits until it is cancelled or completed. 
 * 
 * @lib nfcintegrationtestutils.dll
 */
class CActiveWait : public CActive
    {
public:
    
    /**
     * Two-phase constructor.
     */
    static CActiveWait* NewL(NfcTagsDiscoveryPrivate* privateAPI);
    
    /**
     * Two-phase constructor.
     */
    static CActiveWait* NewLC(NfcTagsDiscoveryPrivate* privateAPI);
    
    
    /**
     * Desctuctor 
     */
    ~CActiveWait();
    

    /**
     * Sets this object active.
     */ 
    IMPORT_C void SetActive();
    
protected: // From CActive
    
    /**
     * @see CActive
     */
    void RunL();
    
    /**
     * @see CActive
     */
    void DoCancel(); 
    
private:
    
    CActiveWait(NfcTagsDiscoveryPrivate* aPrivateAPI);

    /**
     * Second phase constuctor.
     */
    void ConstructL();
    
    
private:
    NfcTagsDiscoveryPrivate* iPrivateAPI;
    
    };


#endif // ACTIVEWAIT_H
