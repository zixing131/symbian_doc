/*
 * Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef NFCDISCOVERY_SYMBIAN_H
#define NFCDISCOVERY_SYMBIAN_H

#include <e32base.h>
#include <nfcserver.h>
#include <nfctag.h>
#include <nfctagsubscription.h>
#include <nfcconnection.h>

#include <nfctagdiscovery.h>
#include <nfctagconnectionlistener.h>
#include <nfcconnectioninfo.h>
#include <ndefmessagelistener.h>
#include <ndefdiscovery.h>
#include <ndefmessage.h>
#include <mifareclassicsector.h>


// FORWARD DECLARATIONS
class NfcTagsDiscovery;
class MNfcConnection;
class CNfcType1Connection;
class CNfcType2Connection;
class CNfcType3Connection;
class CIso14443Connection;
class CMifareClassicConnection;
class CActiveWait;

// CLASS DECLARATION
// A Class that waits for a tag and then opens a connection to it.
class NfcTagsDiscoveryPrivate : public CBase, public MNfcTagConnectionListener,
                                public MNdefMessageListener
  {
public:
    
    static NfcTagsDiscoveryPrivate* NewL(NfcTagsDiscovery *aPublicAPI);
    static NfcTagsDiscoveryPrivate* NewLC(NfcTagsDiscovery *aPublicAPI);
    virtual ~NfcTagsDiscoveryPrivate();

    enum TDiscoveryOptions
        {
        ETagDiscovery =0,
        ENdefDiscovery,
        EExchangeData
        };
    enum TTagOperations
        {
        EExchangeDataWithIso14443Tag,
        EWriteToClass1Tag,
        EReadFromClass1Tag,
        EWriteToClass2Tag,
        EReadFromClass2Tag,
        EUpdateClass3Tag,
        ECheckClass3Tag,
        EWriteToMifareTag,
        EReadFromMifareTag,
        };
public:    
    // Search for NDEF messages.
    void StartNdefDiscovery(); 
    
    // Search for tags.
    void StartTagDiscovery();
    
    // Stop discovering tags/NDEF messages.
    void StopTagDiscovery();
    void StopNdefDiscovery();
    
    void TagOperationCompleted();
    
private:    
    NfcTagsDiscoveryPrivate(NfcTagsDiscovery *aPublicAPI);
    void ConstructL(NfcTagsDiscovery *aPublicAPI);

    // From MNfcTagConnectionListener. 
    void TagDetected( MNfcTag* aNfcTag );  
    void TagLost();
       
    // From MNdefMessageListener.
    void MessageDetected( CNdefMessage* aMessage );
    
    // Exchange data between NFC enabled device and Iso14443 tag.
    void ExchangeDataWithIso14443Tag();
    
    // Read/Write data to Class1 tag.
    void WriteToClass1Tag();
    void ReadFromClass1Tag();
    
    // Read/Write to Class2 Tag.
    void WriteToClass2Tag();
    void ReadFromClass2Tag();
    
    // Update/Check information in Class3 Tag.
    void UpdateClass3Tag();
    void CheckClass3Tag();
    
    // Read/Write to Data Blocks of Mifare Tag.
    void WriteToMifareTag();
    void ReadFromMifareTag();
   
    // Display the information read from the tag.
    void ShowTagInformation();
    
public:
    RBuf8 iWriteBuffer; 
    RBuf8 iReadBuffer; 
    TInt iTagOperation;
    NfcTagsDiscovery* iPublicAPI;
    
private:
    RNfcServer iServer;
    CNfcTagDiscovery* iNfcTagDiscovery;  
    CNdefDiscovery* iNdefDiscovery; 
    TRequestStatus iStatus;
    CIso14443Connection* iIso14443Connection; 
    CNfcType1Connection* iNfcType1Connection;
    CNfcType2Connection* iNfcType2Connection;
    CNfcType3Connection* iNfcType3Connection;
    CMifareClassicConnection* iMifareClassicConnection;
    CNfcTagSubscription* iSubscription;
    CMifareClassicSector* iMifareClassicDataSector;
    CActiveWait* iWriteWait;
    CActiveWait* iReadWait;
    CActiveSchedulerWait* iWait;
    };

#endif //NFCDISCOVERY_SYMBIAN.H

