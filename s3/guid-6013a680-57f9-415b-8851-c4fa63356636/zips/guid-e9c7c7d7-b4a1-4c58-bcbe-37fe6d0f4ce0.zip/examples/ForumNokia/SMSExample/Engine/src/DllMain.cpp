/*
 * Copyright � 2008 Nokia Corporation.
 */
 
//  EXTERNAL INCLUDES
#include <e32std.h>

// DLL entry point
GLDEF_C TInt E32Dll()
    {
    return KErrNone;
    }

//  End of file