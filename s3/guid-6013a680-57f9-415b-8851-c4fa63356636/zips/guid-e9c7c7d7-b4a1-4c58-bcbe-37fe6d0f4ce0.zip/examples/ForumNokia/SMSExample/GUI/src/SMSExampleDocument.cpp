/*
 * Copyright � 2008 Nokia Corporation.
 */

// INCLUDE FILES
#include "SMSExampleDocument.h"
#include "SMSExampleAppui.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CSMSExampleDocument::CSMSExampleDocument(CEikApplication& aApp)
: CAknDocument(aApp)    
    {
    }

// destructor
CSMSExampleDocument::~CSMSExampleDocument()
    {
    }

// EPOC default constructor can leave.
void CSMSExampleDocument::ConstructL()
    {
    }

// Two-phased constructor.
CSMSExampleDocument* CSMSExampleDocument::NewL(
        CEikApplication& aApp)     // CSMSExampleApp reference
    {
    CSMSExampleDocument* self = new (ELeave) CSMSExampleDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }
    
// ----------------------------------------------------
// CSMSExampleDocument::CreateAppUiL()
// constructs CSMSExampleAppUi
// ----------------------------------------------------
//
CEikAppUi* CSMSExampleDocument::CreateAppUiL()
    {
    return new (ELeave) CSMSExampleAppUi;
    }

// End of File  
