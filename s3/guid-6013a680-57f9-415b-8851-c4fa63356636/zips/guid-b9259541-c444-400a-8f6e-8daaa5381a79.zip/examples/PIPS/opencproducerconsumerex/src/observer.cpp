/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/

// INCLUDE FILES
#include <e32std.h>
#include <f32file.h>

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <pthread.h>

#include "CommanHeader.h"

_LIT(KObserverLogFile, "C:\\ObserverLogFile.txt");

/*****************************************************************************
*  ObserverThreadL
*  Function: Observer Thread that does the logging of all the events sent by 
*  Producer and Consumers
*******************************************************************************/

TInt ObserverThreadL( TInt aNoOfMsg ) 
	{
	TInt retVal = KErrNone;

	//Connect to Symbian File Server and open a file for logging
	RFs fileSession;
	User::LeaveIfError(fileSession.Connect());
	RFile logFile;
	retVal = logFile.Open(fileSession, KObserverLogFile, EFileWrite);
	if(retVal)
		{
		retVal = logFile.Create(fileSession, KObserverLogFile, EFileWrite);
		}
	User::LeaveIfError(retVal);

	//Create the MRT STDLIBS Message Q
    key_t msgQFd = msgget(KMSGQKEY, IPC_CREAT);
    if (msgQFd == -1)
    	{
    	logFile.Write(_L8("Msg Q Creation Failed\r"));
    	return -1;
    	}
   logFile.Write(_L8("Observer is Up and Running\r"));

	//Construct the message to be send thru msg q
	struct msgbuf* recvMsg = (struct msgbuf*)malloc(KMAXSENDMSG);
	TBuf8<KMAXSENDMSG> logData;
	
	
	for(int msgCount = 0; msgCount<aNoOfMsg; msgCount++ )
		{
		retVal = msgrcv(msgQFd, recvMsg, KMAXSENDMSG, 0, 0);
		if(retVal > 0 )
			{
			logData.Copy((const TUint8 *)recvMsg->mtext, retVal-4);
			logFile.Write(logData);
			//Also flush the info on to console
			recvMsg->mtext[retVal-4] = '\0';
			printf("Observer: %s\n", recvMsg->mtext);
			}
		}
	
	//Close the Message Q
	retVal = msgctl(msgQFd, IPC_RMID, NULL);
	free(recvMsg);
	
	logFile.Close();
	fileSession.Close();		
	return retVal;
	}

/*****************************************************************************
*  ObserverThreadEntryPoint
*  Function: Observer Thread Entry Point
*  As its Symbian Thread, it has to create a cleanup stack and should have
*  TOP level TRAP
*******************************************************************************/

TInt ObserverThreadEntryPoint( TAny* aParam ) 
	{
	TInt retVal = KErrNone;
	
	// Create a Cleanup Stack for this Thread
	CTrapCleanup* cleanupStack = CTrapCleanup::New();
	if(cleanupStack)
		{
		//Have a top level TRAP
		TRAP( retVal, retVal = ObserverThreadL( (int)aParam ));
		delete cleanupStack;
		}
	else
		{
		retVal = KErrNoMemory;
		}
	return retVal;
	}

extern "C" {

/*****************************************************************************
*  CreateObserverThread
*  Function: Function that creats Observing Thread (Symbian Thread)
*******************************************************************************/

void CreateObserverThread( int aNoOfMsg )
	{
	RThread thread;
	TInt stackSize = 0x8000; //Set the stack size for this thread as 8K
	thread.Create(_L("ObserverThread"), ObserverThreadEntryPoint, stackSize, NULL, (TAny*)aNoOfMsg);
	TRequestStatus stat;
	thread.Logon(stat);

	//Start executing the thread.
	thread.Resume();

	//Wait for the thread to Terminate.
	User::WaitForRequest(stat);
	}

} //extern "C"

//  End of File
