/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/



/* INCLUDE FILES */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <stdio.h>

#include "CommanHeader.h"

#define MIN(X, Y) (X < Y) ? X : Y;

/*****************************************************************************
*  ProducerThreadEntryPoint
*  Function: Producer Thread that produces M number of items at a time 
*  where M is number of Consumers.
*  This thread will produce N number of items where N is total number of items 
*  needed by all the Consumers.
*  It also informs the Observer thread about item production
*******************************************************************************/

void* ProducerThreadEntryPoint( void* aParam ) 
{
	ThreadParam* args = (ThreadParam*) aParam;
	int yetToProduce = args->noOfItems;
	int produceNow = 0;
	int noOfConsumers = args->noOfConsumers;
	ProducedItem item;
	key_t msgQFd = -1;
	int ret = 0;
	/* Construct the message to be send thru msg q */
	struct msgbuf* sendMsg = (struct msgbuf*)malloc(KMAXSENDMSG);
	sendMsg->mtype = 1;
	
	/* Get the Handler to Observer Msg Q */
	msgQFd = msgget(KMSGQKEY, IPC_CREAT);

	item.itemNum = 1;

	while (yetToProduce != 0) 
	{
		produceNow = MIN(yetToProduce, noOfConsumers);
		yetToProduce -= produceNow;

		/* Acquire the Lock so that Producer can Produce "produceNow" items once. */
		sem_wait(&args->itemLock);
		for(;produceNow != 0; produceNow--) 
		{
			sprintf(item.itemName, "Item-Number: #%d", item.itemNum);
			/* Push this item on to Stack so that Consumetrs can take it.*/
			PushOntoStack(&item);
			item.itemNum++;
			/* Inform the Observer about Item Production */
			sprintf(sendMsg->mtext, " Producer Produced %s\0", item.itemName);
			ret = msgsnd(msgQFd, sendMsg, strlen(sendMsg->mtext)+4, 0);
		}
		/* Release the Lock so that Consumers can consume produced items. */
		sem_post(&args->itemLock);
	}

	free( sendMsg );
	return (int*)0;
}

/*  End of File */
