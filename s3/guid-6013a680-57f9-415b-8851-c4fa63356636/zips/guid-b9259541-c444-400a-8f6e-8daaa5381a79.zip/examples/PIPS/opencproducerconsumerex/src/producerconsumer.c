/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/



/* INCLUDE FILES */
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
//#include <staticlibinit_gcce.h>
#include "CommanHeader.h"

int main() 
{
	ThreadParam threadParams[MAX_CLIENTS + 1];
	pthread_t threadID[MAX_CLIENTS + 1];
	int i = 0;
	int noOfConsumers = 0;
	int noOfItems = 0;
	int totalItems = 0;
	int ret = 0;
	int exitReason = 0;
	sem_t semLock;
	pthread_attr_t threadAttr;

	if( sem_init( &semLock, 0, 1 ) != 0 ) 
	{
		printf("Error Creating semaphore");
		exit(-1);
	}

	/* Read all the inputs needed */
	printf("Enter Number of Consumers : ");
	scanf("%d", &noOfConsumers);

	if(MAX_CLIENTS < noOfConsumers) 
	{
		noOfConsumers = MAX_CLIENTS;
	}

	for(i=1; i<=noOfConsumers; i++) 
	{
		printf("Items Needed by Consumer-%d : ", i);
		scanf("%d", &noOfItems);
		totalItems += noOfItems;

		threadParams[i].noOfItems = noOfItems;
		threadParams[i].itemLock = semLock;
		threadParams[i].noOfConsumers = i;
	}

	/* For the Producer	 */
	threadParams[0].noOfItems = totalItems;
	threadParams[0].noOfConsumers = noOfConsumers;
	threadParams[0].itemLock = semLock;

	pthread_attr_init( &threadAttr );
	pthread_attr_setdetachstate( &threadAttr, PTHREAD_CREATE_JOINABLE );
	
	/* Create a Producer thread now */
	ret = pthread_create( &threadID[0], &threadAttr, ProducerThreadEntryPoint, 
		(void*)&threadParams[0] );

	if(ret != 0) 
	{
		printf("Error Creating Producer Thread");
		exit(-1);
	}

	/* Create a Consumer Threads now */
	for(i=1; i <= noOfConsumers; i++) 
	{
		ret = pthread_create( &threadID[i], &threadAttr, ConsumerThreadEntryPoint, 
			(void*)&threadParams[i] );

		if(ret != 0) 
		{
			printf("Error Creating Consumer Thread %d", i);
			exit(-1);
		}
	}

	/* Call C++ function that creats Observer Thread */
	CreateObserverThread (totalItems * 2);

	/* Wait for the completion of all the threads */
	for(i=0; i<=noOfConsumers; i++) 
	{
		ret = pthread_join(threadID[i], (void**)&exitReason );
	}

	/* Destroy the semaphore */
	sem_destroy( &semLock );
	printf("Completed the Production/Consumption..\n Press Any Key to Exit");
	getchar();
	getchar();
	return 0;
}

/*  End of File */
