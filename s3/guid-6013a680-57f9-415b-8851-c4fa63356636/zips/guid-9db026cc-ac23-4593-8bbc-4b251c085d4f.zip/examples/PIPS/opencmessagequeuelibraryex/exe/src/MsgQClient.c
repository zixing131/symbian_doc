/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/



# include <pthread.h>
# include <stdio.h>
# include <string.h>
# include <unistd.h>
//# include <staticlibinit_gcce.h>
# include "MsgQLib.h"

ULONG q1 = 1;
ULONG q2 = 2;
const int KMaxMsg = 10;

/**
 Entry point for threads
 This will send message to one queue and wait for some messages from other queue
*/
void ThreadFunction(int *id) {
	int i = 2;
	int err = 0;
	int result = 0;
	int pri = MSG_PRI_NORMAL;
	int timeout = NO_WAIT;
	int len = 100;
	int nBytes;
	char smsg[] =  "Sending Some Data through MsgQ";
	char rmsg[100];
	ULONG queueOne = q1;
	ULONG queueTwo = q2;
	
	//If 2nd Thread
	if(*id == q2) {
		queueOne = q2;
		queueTwo = q1;
		}

	printf("Thread %d: Started..\n", *id);

	/* Try to Create queueOne again, this will create the queue again,
	   this will just return as its already created by main thread */
	result = MsgQCreate(queueOne, KMaxMsg, MSG_Q_FIFO, &err);
	printf("Thread %d: Q CREATE result = %d\n", *id, result);

	while(i>=0) {
	
		nBytes = strlen(smsg); 
		/* Send Message to queueOne */
		result = MsgQSend(queueOne, smsg, nBytes, pri, timeout, &err); 
		printf("Thread %d: Q SEND result = %d\n", *id, result);

		sleep(1);
		rmsg[0] = '\0';
		/* Receive Message from queueTwo */
		result = MsgQReceive(queueTwo, rmsg, len, timeout, &err); 
		rmsg[result] = '\0';
		printf("Thread %d: Q RECEIVE result = %d\n", *id, result);
		printf("Thread %d: Message Received from Message Queue 2 is : %s\n", *id, rmsg);
		i--;
	}
	sleep(2);
	
	/* delete message queueOne */
	result=MsgQDelete(queueOne, &err);
	printf("Thread %d: Q DELETE result = %d\n", *id, result);
}


int main() {
	int result;
	int err;
	pthread_t thread1;
	pthread_t thread2;

	printf("Main Thread: Started..\n");

	/* Create 2 Message Queues */
	result = MsgQCreate(q1, KMaxMsg, MSG_Q_FIFO, &err);
	printf("Main Thread: Q CREATE result = %d\n",result);

	result = MsgQCreate(q2, KMaxMsg, MSG_Q_FIFO, &err);
	printf("Main Thread: Q CREATE result = %d\n",result);


	/* Create 2 Threads */
	if(pthread_create(&thread1, NULL, (thread_begin_routine)ThreadFunction, (void*) &q1) != 0) {
		printf("Main Thread: Failed to create the threadOne\n");
	}

	if(pthread_create(&thread2, NULL, (thread_begin_routine)ThreadFunction, (void*) &q2) != 0) {
		printf("Main Thread: Failed to create the threadTwo\n");
	}

	/* Wait for the threads to complete */
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
	printf("Main Thread: Exiting from Main() \nMain Thread: Enter a Key to Exit");
	getchar();
	return 0;
}
