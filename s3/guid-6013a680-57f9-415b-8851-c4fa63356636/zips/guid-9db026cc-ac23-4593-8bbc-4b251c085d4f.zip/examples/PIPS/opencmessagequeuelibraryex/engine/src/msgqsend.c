/*
Copyright (c) 2007-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:  
*/

#include <errno.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <string.h>
#include "MsgQInternal.h"


/*******************************************************************************
* MsgQSend (qName, msg, nBytes, priority, timeout, err)
* Description:  Function for sending a message with internal copy
*********************************************************************************/

EXPORT_C int MsgQSend(ULONG qName, char* msg, ULONG nBytes, ULONG priority, int timeout, int* err)
{
	MSGQ_INFO* pMsgQInfo = NULL;

	struct {
		long mtype;
		char mtext[MAX_MSG_LEN];
	} message;

	/* structure used for semaphore post operation */
	struct sembuf op;
	
	/* init the  semop () structure which is used for wait and signal operations */
	op.sem_num = 0;
	op.sem_op = -1;
	op.sem_flg = SEM_UNDO;

	/* check parameters */
	if ((priority == MSG_PRI_NORMAL) || (priority == MSG_PRI_URGENT)) {
		if((pMsgQInfo = MsgQTableLookup(qName)) != NULL) {
			if (pMsgQInfo->sendState == MSG_Q_READY) {
				op.sem_flg = op.sem_flg | timeout;
				if((semop(pMsgQInfo->semId, &op, 1)) == OK) {
					pMsgQInfo->numMsgs++;
					if(pMsgQInfo->maxNumMsgs < pMsgQInfo->numMsgs)          
					pMsgQInfo->maxNumMsgs = pMsgQInfo->numMsgs;

					message.mtype = 1;
					bcopy(msg, message.mtext, nBytes);
					message.mtext[nBytes] = '\0';

					if(msgsnd (pMsgQInfo->qId, &message, (size_t)nBytes+4, timeout) == OK) {
						*err = OK;
						/* After successfull send, unlock the message queue by using post operation on semaphore.*/
						op.sem_op = 1;
						semop(pMsgQInfo->semId, &op, 1);
						return (OK);
					}
					else {
						*err = errno;
						pMsgQInfo->numMsgs--;
						op.sem_op = 1;
						semop(pMsgQInfo->semId, &op, 1);
					}
				}
				else
					*err = errno;
			}
			else
				*err = KMsgQLibQFlushErr;
		}
		else
			*err = KMsgQLibQIdErr;
	}
	else
		*err = KMsgQLibParamErr;

	return(ERROR);
}


