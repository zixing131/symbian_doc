/*
Copyright (c) 2009-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/



#include <e32base.h>
#include <e32cons.h>
#include "rconnection.h"


_LIT(KRow01,"*****************************************\n");
_LIT(KRow02,"*     Welcome to RConnection Example    *\n");
_LIT(KRow03,"*****************************************\n");
_LIT(KRow04,"Press a Key to step through the Example\n");
_LIT(KNewLine,"\n");

static void DoStartL(CConsoleBase* aConsole); 
static void WelcomeScreen(CConsoleBase* aConsole);
static void CallExampleL(); // initialize with cleanup stack, then do example

static void DoStartL(CConsoleBase* aConsole)
	{
	// Create active scheduler (to run active objects).
	CActiveScheduler* scheduler = new (ELeave) CActiveScheduler();
	CleanupStack::PushL(scheduler);
	CActiveScheduler::Install(scheduler);

	CRConnection* example = new (ELeave) CRConnection(aConsole);
	CleanupStack::PushL(example);
	
	WelcomeScreen(aConsole);
	
	example->DemoApiWithoutDbOverrideL();	
	
	example->DemoApiWithDbOverrideL();
	
	example->AttachToExistingInterfaceL();
	
	CleanupStack::PopAndDestroy(example);

	// Delete active scheduler.
	CleanupStack::PopAndDestroy(scheduler);	
	}

static void CallExampleL() // initialize and call example code under cleanup stack
    {
    _LIT(KTxtExampleCode,"Symbian platform Example Code");
    _LIT(KFormatFailed,"failed: leave code=%d");
    _LIT(KTxtOK,"ok");
    _LIT(KTxtPressAnyKey," [press any key to exit]");
    
	CConsoleBase* console=Console::NewL(KTxtExampleCode,TSize(KConsFullScreen,KConsFullScreen));
	CleanupStack::PushL(console);
	
	TRAPD(error,DoStartL(console)); // perform example
	
	if (error)
		console->Printf(KFormatFailed, error);
	else
		console->Printf(KTxtOK);
	
	console->Printf(KTxtPressAnyKey);
	console->Getch(); // get and ignore character
	
	CleanupStack::PopAndDestroy(); // close console
    }

extern TInt E32Main() // main function called by E32
    {
    _LIT(KEgPanicCat,"EXAMPLES");
	__UHEAP_MARK;
	CTrapCleanup* cleanup=CTrapCleanup::New(); // create clean-up stack
	TRAPD(error,CallExampleL()); // do example
	__ASSERT_ALWAYS(!error,User::Panic(KEgPanicCat,error));
	delete cleanup; // destroy clean-up stack
	__UHEAP_MARKEND;
	return 0; // and return
    }

//Display for welcome screen.
static void WelcomeScreen(CConsoleBase* aConsole)
	{
	aConsole->ClearScreen();
	aConsole->Printf(KRow01);
	aConsole->Printf(KRow02);
	aConsole->Printf(KRow03);
	aConsole->Printf(KNewLine);
	aConsole->Printf(KRow04);
	aConsole->Getch();	
	}

