
Archive Version: v0.1.08

Release Date: December 29, 2008.

Port of Community Version:
 - libvorbis1.1.2
 - libogg1.1
 - tremor1.0.2
 
Symbian OS Requirements: Symbian OS v9.5 and upwards.


Archive Contents:
=================
This archive contains a port of oggvorbis codec source code to Symbian OS.
This will allow playback of oggvorbis encoded audio files on Symbian devices.



How to Build:
=============
1) Extract to a drive with a compatible Symbian OS environment installed.
2) cd to the 'group' directory and run the following commands:
   > bldmake bldfiles
   > abld reallyclean
   > abld build
   
3) The code is now built and installed!

Change history
==============
1. v0.1 - first release
2. v0.1.01 
   DEF087152:Devsound test failures - Not passing back the expected zero-length buffer.
   Changes to include OmxVorbisdecoder and OmxVorbisencoder in ROM image.
3. v0.1.02
   DEF107345:Devsound test failures - PU case: not playing any ogg file
   Ogg framing moved from controller to codec.
   When playing is stopped, all accumulated buffers from the decoder are retrieved.

4. v0.1.03
Contains PREQ1509 OpenMAX IL 1.1. changes for oggvorbis

5. v0.1.04
CR1424 changes.

6. v0.1.05
Changes for SMP project.

7. v0.1.06
DEF125715:MM-MVS-AUDIOAGENT-I-0004-HP test fails with "Record Duration does not match"

8. v0.1.07
DEF125498: Old vorbis codec cannot be restarted without InitializeL()

9. v0.1.08
DEF131735: fix filename case errors
