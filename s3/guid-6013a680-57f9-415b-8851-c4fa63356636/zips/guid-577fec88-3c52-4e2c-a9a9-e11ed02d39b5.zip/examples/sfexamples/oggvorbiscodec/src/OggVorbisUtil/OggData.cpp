// OggData.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//

#include <e32base.h>
#include <oggutil.h>
#include "OggUtilBody.h"


#ifdef SYMBIAN_CODEC_FLOAT_POINT
#include "ogg/ogg.h"
#else
#include "tremor/ogg.h"
#endif



void OggUtil::Make_ogg_page(const TOggPage& aPage, ogg_page& aOggPage)
    {

#ifdef SYMBIAN_CODEC_FLOAT_POINT
    aOggPage.header = const_cast<unsigned char*>(aPage.iHead.Ptr());
    aOggPage.body = const_cast<unsigned char*>(aPage.iBody.Ptr());
#else
	aOggPage.header = reinterpret_cast<ogg_reference*>(const_cast<unsigned char*>(aPage.iHead.Ptr()));
    aOggPage.body = reinterpret_cast<ogg_reference*>(const_cast<unsigned char*>(aPage.iBody.Ptr()));	
#endif
    aOggPage.header_len = aPage.iHead.Length();
    aOggPage.body_len = aPage.iBody.Length();
    }
    
void OggUtil::Make_ogg_packet(const TOggPacket& aSrc, ogg_packet& aDst)
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	aDst.packet = const_cast<unsigned char*>(aSrc.iData.Ptr());
#else
	aDst.packet     = reinterpret_cast<ogg_reference*>(const_cast<unsigned char*>(aSrc.iData.Ptr()));
#endif

    aDst.bytes      = aSrc.iData.Length();
    aDst.b_o_s      = aSrc.iBOS;
    aDst.e_o_s      = aSrc.iEOS;
    aDst.granulepos = I64LOW(aSrc.iGranulePos) | ((TInt64)(I64HIGH(aSrc.iGranulePos))<<32);
    aDst.packetno = I64LOW(aSrc.iPacketNo) | (((TInt64)I64HIGH(aSrc.iPacketNo))<<32);
    }
    
void OggUtil::MakeOggPage(const ogg_page& aSrc, TOggPage& aDest)
    {
    aDest.iHead.Set(reinterpret_cast<unsigned char*>(aSrc.header), aSrc.header_len, aSrc.header_len);
    aDest.iBody.Set(reinterpret_cast<unsigned char*>(aSrc.body), aSrc.body_len, aSrc.body_len);
    }
    
void OggUtil::MakeOggPacket(const ogg_packet& aSrc, TOggPacket& aDest)   
    {
    aDest.iBOS = aSrc.b_o_s;
    aDest.iEOS = aSrc.e_o_s;
    aDest.iGranulePos = MAKE_TINT64(aSrc.granulepos>>32,aSrc.granulepos&0xffffffffL);
    aDest.iPacketNo = MAKE_TINT64(aSrc.packetno>>32>>32,aSrc.packetno&0xffffffffL);
    aDest.iData.Set(reinterpret_cast<unsigned char*>(aSrc.packet), aSrc.bytes, aSrc.bytes);
    }

EXPORT_C TOggPage::TOggPage(const TPtr8& aHead, const TPtr8& aBody)
    : iHead(aHead), iBody(aBody)
    {
    }
    
EXPORT_C TOggPage::TOggPage()
    : iHead(NULL, 0), iBody(NULL, 0)
    {
    }
    
EXPORT_C TInt TOggPage::Version() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_version(&op);
    }
    
EXPORT_C TBool TOggPage::Continued() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_continued(&op);
    }
    
EXPORT_C TInt TOggPage::Packets() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_packets(&op);
    }
    
EXPORT_C TInt TOggPage::BOS() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_bos(&op);
    }
    
EXPORT_C TInt TOggPage::EOS() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_eos(&op);
    }
    
EXPORT_C TInt TOggPage::GranulePos() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_granulepos(&op);
    }
    
EXPORT_C TInt TOggPage::SerialNo() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_serialno(&op);
    }
    
EXPORT_C TInt TOggPage::PageNo() const
    {
    ogg_page op;
    OggUtil::Make_ogg_page(*this, op);
    return ogg_page_pageno(&op);
    }
    

//--------------------------- TOggPacket ---------------------------

EXPORT_C TOggPacket::TOggPacket()
    : iData(NULL, 0), iBOS(EFalse), iEOS(EFalse), iGranulePos(0), iPacketNo(0)
    {
    }
#ifndef SYMBIAN_CODEC_FLOAT_POINT    
EXPORT_C void TOggPacket::GetOggData(TPtr8& aDataStore)
    {
	//declare new ogg_packet structure 
    ogg_packet testpckt;
    testpckt.packet = reinterpret_cast<ogg_reference*>(const_cast<unsigned char*>(iData.Ptr()));
    testpckt.bytes  = iData.Length();
    
    //Get values from ogg packet structure, ogg_packet contains ogg_refernce which contains ogg_buffer
    TInt begin = testpckt.packet->begin; //position in buffer for start of packet
    TInt length = testpckt.packet->length; //length of packet
    
    ogg_buffer *buffer = testpckt.packet->buffer; //pointer to buffer
    ogg_reference *next = testpckt.packet->next;	//pointer to next ogg reference if needed
    
    //buffer details 
    unsigned char *data = buffer->data;
    //Keep record of how far through data buffer 
    TInt ptr_count = 0;
    
    //read data from first buffer 
    for(TInt i = 0;i < length; i++)
    	{
    	aDataStore[i] = data[begin+i];
    	}
    
    ptr_count += length;
	
	//data is not always in one buffer may be spread over several so repeat while is still next buffer 
	while(next)
		{
		//was next ogg_reference assign this to packet and reset variables
		testpckt.packet = next;
		
		//New variable values as assigned to next refernce 
		begin = testpckt.packet->begin; //position in buffer for start of packet
   		length = testpckt.packet->length; //length of packet
   		
   		buffer = testpckt.packet->buffer; //pointer to buffer
    	next = testpckt.packet->next;	//pointer to next ogg reference if needed
    
        data = buffer->data;
        
		//read data 
        for(TInt i = 0;i < length; i++)
    		{
    		aDataStore[i+ptr_count] = data[begin+i];
    		}
    		
    	ptr_count += length;
		
		}
    }
#endif
