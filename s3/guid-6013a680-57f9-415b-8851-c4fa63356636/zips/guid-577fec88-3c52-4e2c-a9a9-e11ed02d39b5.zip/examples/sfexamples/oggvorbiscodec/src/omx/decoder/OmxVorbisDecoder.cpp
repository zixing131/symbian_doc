// OmxVorbisDecoder.cpp
//
// Copyright (c) 2007-2008 Symbian Software Ltd. All rights reserved.
//

/**
@file
@internalComponent
*/

#include <e32debug.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <OMX_Core.h>
#include <OMX_Audio.h>

#include "OmxImpl.h"
#include "OmxVorbisDecoder.h"
#include "VorbisDecoder.h"

const TInt KIndexInputPort = 0;
const TInt KIndexOutputPort = 1;

// Vorbis decoder requires 8k input and 16k output buffer
const TInt KVorbisDecoderInputBufferSize 	= 0x2000;
const TInt KVorbisDecoderOutputBufferSize 	= 0x4000;

const TInt KThreadStackSize = 16384; 

const TInt KDefaultOutputBitsPerSample = 16;
const OMX_NUMERICALDATATYPE KDefaultOutputDataType = OMX_NumericalDataSigned;

_LIT(KVorbisDecoder, "VorbisDecoder");
							
TInt ProcessingThread(TAny* aComponent)
	{
	// get our class
	CCodecProcessor* codecprocessor = static_cast<CCodecProcessor*>(aComponent);
	// run the thread
	TRAPD(err, codecprocessor->RunThreadL());
	// thread has exited or failed to start so return error to the client. 
	return err;
	}


TInt COmxVorbisDecoder::CreateComponent(OMX_HANDLETYPE hComponent)
	{
	COmxVorbisDecoder* self = new COmxVorbisDecoder(hComponent);
	if (self==NULL)
		return KErrNoMemory;
	TRAPD(err, self->ConstructL());
	// self is stored in the handle, so we won't return it
	return err;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::GetComponentVersion(
       OMX_STRING /*pComponentName*/,
       OMX_VERSIONTYPE* /*pComponentVersion*/,
       OMX_VERSIONTYPE* /*pSpecVersion*/,
       OMX_UUIDTYPE* /*pComponentUUID*/)
	{
// to be implemented
	return OMX_ErrorNone;
	}

void COmxVorbisDecoder::ConstructL()
	{
	iCodecProcessor = CCodecProcessor::NewL(*this);	
	iState = OMX_StateLoaded;
	}

COmxVorbisDecoder::COmxVorbisDecoder(OMX_HANDLETYPE hComponent)
	:COmxComponentImpl(hComponent)
	{
	}
	
COmxVorbisDecoder::~COmxVorbisDecoder()
	{
	if (iState == OMX_StateExecuting)
		{
		iCodecProcessor->Stop();
		iState = OMX_StateIdle;
		}

	if (iCreatedThread)
		{
		iCodecProcessor->Exit();
		TRequestStatus status;
		iProcessingThread.Logon(status);
		User::WaitForRequest(status);
		iProcessingThread.Close();
		}
	delete iCodecProcessor;
	}

OMX_ERRORTYPE COmxVorbisDecoder::SendCommand(
       OMX_COMMANDTYPE Cmd,
       TUint32 nParam1,
       TAny* /*pCmdData*/)
	{
	OMX_ERRORTYPE error = OMX_ErrorNone;
	switch (Cmd)
		{
	case OMX_CommandStateSet:
		OMX_STATETYPE state = (OMX_STATETYPE)nParam1;
		if (state == iState)
			{
			error = OMX_ErrorSameState;
			}
		else
			{
			// notify client of the state change
			switch (state)
				{
			case OMX_StateIdle:
				{
				if (iState == OMX_StateExecuting)
					{
					iCodecProcessor->Stop();
					}
				break;
				}
			case OMX_StateExecuting:
				StartExecution();
				break;
				};
	
			iState = state;
			
			EventHandlerCallback(
				OMX_EventCmdComplete,
				OMX_CommandStateSet,
				iState,
				NULL);	
			break;
			}
		};	
	return error;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::GetParameter(
       OMX_INDEXTYPE nParamIndex,  
       TAny* ComponentParameterStructure)
	{
	switch (nParamIndex)
		{
	case OMX_IndexParamAudioInit :
		{
		OMX_PORT_PARAM_TYPE* param = static_cast<OMX_PORT_PARAM_TYPE*>(ComponentParameterStructure);
		param->nPorts = 2;
		}
		break;
	case OMX_IndexParamPortDefinition:
		{
		OMX_PARAM_PORTDEFINITIONTYPE* portDef = static_cast<OMX_PARAM_PORTDEFINITIONTYPE*>(ComponentParameterStructure);
		if (portDef->nPortIndex==0)	
			{
			portDef->eDir = OMX_DirInput;	
			portDef->nBufferSize = KVorbisDecoderInputBufferSize;
			}
		else
			{
			portDef->eDir = OMX_DirOutput;
			portDef->nBufferSize = KVorbisDecoderOutputBufferSize;
			}
		}
		break;
	default:
		return OMX_ErrorUnsupportedIndex;
		}
	return OMX_ErrorNone;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::SetParameter(
       OMX_INDEXTYPE nIndex,
       TAny* ComponentParameterStructure)
	{
	ASSERT(iState == OMX_StateLoaded);
	switch (nIndex)
		{
		case OMX_IndexParamAudioVorbis:
			{
			OMX_AUDIO_PARAM_VORBISTYPE* param = static_cast<OMX_AUDIO_PARAM_VORBISTYPE*>(ComponentParameterStructure);
			switch(param->nPortIndex)
				{
				case 0: // Input port = Vorbis
					{
					// nothing to set
					return OMX_ErrorNone;
					}			
				case 1: // Output port
				default:
					{
					return OMX_ErrorUnsupportedIndex;	
					}
				};
			}
		case OMX_IndexParamAudioPcm:
			{
			OMX_AUDIO_PARAM_PCMMODETYPE* param = static_cast<OMX_AUDIO_PARAM_PCMMODETYPE*>(ComponentParameterStructure);
			switch(param->nPortIndex)
				{
				case 1: // Output port = PCM
					{
					iCodecProcessor->SetOutputBitsPerSample(param->nBitPerSample);
					iCodecProcessor->SetOutputDataType(param->eNumData);
					return OMX_ErrorNone;
					}
				case 0: // Input port
				default:
					{
					return OMX_ErrorUnsupportedIndex;	
					}
				};
			}
		default:
			{
			return OMX_ErrorUnsupportedIndex;
			}
		};		
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::GetConfig(
       OMX_INDEXTYPE /*nIndex*/, 
       TAny* /*value*/)
	{
	return OMX_ErrorUnsupportedIndex;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::SetConfig(
       OMX_INDEXTYPE /*nIndex*/, 
       TAny* /*value*/)
	{
	return OMX_ErrorUnsupportedIndex;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::GetExtensionIndex(
       OMX_STRING /*ParameterName*/,
       OMX_INDEXTYPE* /*pIndexType*/)
	{
	return OMX_ErrorNotImplemented;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::GetState(
       OMX_STATETYPE* pState)
	{
	*pState = iState;
	return OMX_ErrorNone;
	}
	
// To be implemented for DM4
OMX_ERRORTYPE COmxVorbisDecoder::ComponentTunnelRequest(
		OMX_HANDLETYPE /*hInput*/,
		TUint32 /*nInputPort*/,
		OMX_HANDLETYPE /*hOutput*/,
		TUint32 /*nOutputPort*/,
		OMX_TUNNELSETUPTYPE* /*pTunnelSetup*/)
	{
	return OMX_ErrorNotImplemented;
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::UseBuffer(
       OMX_BUFFERHEADERTYPE** ppBufferHeader,
       TUint32 nPortIndex,
       TAny* pAppPrivate,
       TUint32 nSizeBytes,
       TUint8* pBuffer)
	{
	ASSERT(iState == OMX_StateLoaded);
	*ppBufferHeader = new OMX_BUFFERHEADERTYPE;
	if (*ppBufferHeader != NULL)
		{
		(*ppBufferHeader)->pBuffer = pBuffer;
		(*ppBufferHeader)->pAppPrivate = pAppPrivate;
		(*ppBufferHeader)->nAllocLen = nSizeBytes;
		(*ppBufferHeader)->nFilledLen = 0;
		(*ppBufferHeader)->nFlags = 0;
		(*ppBufferHeader)->pInputPortPrivate = NULL;
		(*ppBufferHeader)->pOutputPortPrivate = NULL;
		}


		
	if (*ppBufferHeader)
		{
		TPtr8 ptr(pBuffer,nSizeBytes,nSizeBytes);
		CMMFBuffer* buffer = NULL;
		TRAPD(err, buffer = CMMFPtrBuffer::NewL(ptr));
		if (err != KErrNone)
			{
			return OMX_ErrorInsufficientResources;
			}
		switch (nPortIndex)
			{
		case KIndexInputPort:
				{
				(*ppBufferHeader)->pInputPortPrivate = buffer;
				(*ppBufferHeader)->nInputPortIndex = nPortIndex;
				}
				break;
			case KIndexOutputPort:
				{
				(*ppBufferHeader)->pOutputPortPrivate = buffer;	
				(*ppBufferHeader)->nOutputPortIndex = nPortIndex;
				}
				break;
			
			}
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorInsufficientResources;
		}
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::AllocateBuffer(
		OMX_BUFFERHEADERTYPE** pBuffer,
		TUint32 nPortIndex,
		TAny* pAppData,
		TUint32 nSizeBytes)
	{
	ASSERT(iState == OMX_StateLoaded);
	
	*pBuffer = new OMX_BUFFERHEADERTYPE;
	if (*pBuffer != NULL)
		{
		CMMFDescriptorBuffer* buffer = NULL;
		TRAPD(err, buffer = CMMFDescriptorBuffer::NewL(nSizeBytes));
		if (err != KErrNone)
			{
			return OMX_ErrorInsufficientResources;
			}
		(*pBuffer)->pBuffer = const_cast<TUint8*>(buffer->Data().Ptr());
		// store our allocated memory in component's private store
		switch (nPortIndex)
			{
		case KIndexInputPort:
			(*pBuffer)->pInputPortPrivate = buffer;
			(*pBuffer)->pOutputPortPrivate = NULL;
			break;
		case KIndexOutputPort:
			(*pBuffer)->pOutputPortPrivate = buffer;
			(*pBuffer)->pInputPortPrivate = NULL;
			break;
			};
		
		
		(*pBuffer)->nAllocLen = nSizeBytes;
		(*pBuffer)->nFilledLen = 0;
		(*pBuffer)->pAppPrivate = pAppData;
		}
		
	if (*pBuffer && (*pBuffer)->pBuffer)
		{
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorInsufficientResources;
		}
	}

OMX_ERRORTYPE COmxVorbisDecoder::FreeBuffer(
		TUint32 nPortIndex,
       OMX_BUFFERHEADERTYPE* pBuffer)
	{
	switch (nPortIndex) 
		{		
		case KIndexInputPort:
			{
			delete (static_cast<CMMFBuffer*>(pBuffer->pInputPortPrivate));
			pBuffer->pInputPortPrivate = NULL;
			break;
			}
		case KIndexOutputPort:
			delete (static_cast<CMMFBuffer*>(pBuffer->pOutputPortPrivate));
			pBuffer->pOutputPortPrivate = NULL;
			break;	
			
		}
	delete pBuffer;
	return OMX_ErrorNone;
	}
OMX_ERRORTYPE COmxVorbisDecoder::EmptyThisBuffer(
       OMX_BUFFERHEADERTYPE* pBuffer)
	{
	ASSERT(iState == OMX_StateExecuting ||
			iState == OMX_StateIdle ||
			iState == OMX_StatePause);
	return iCodecProcessor->EmptyThisBuffer(pBuffer);
	}
OMX_ERRORTYPE COmxVorbisDecoder::FillThisBuffer(
           OMX_BUFFERHEADERTYPE* pBuffer)
	{
	ASSERT(iState == OMX_StateExecuting ||
			iState == OMX_StateIdle ||
			iState == OMX_StatePause);
	return iCodecProcessor->FillThisBuffer(pBuffer);	
	}
	
OMX_ERRORTYPE COmxVorbisDecoder::SetCallbacks(
           OMX_CALLBACKTYPE* pCallbacks, 
           TAny* pAppData)
	{
	iCallback = pCallbacks;
	iAppData = pAppData;
	return OMX_ErrorNone;
	}
	
CCodecProcessor::CCodecProcessor(COmxVorbisDecoder& aParent) 
	: iParent(&aParent)
	{
	}

void CCodecProcessor::RunThreadL()
	{
	iQueueStatus = KRequestPending;
	iMessageQueue.NotifyDataAvailable(iQueueStatus);
	
	for (;;)
		{
		User::WaitForRequest(iQueueStatus);
		TCodecMessage msg;
		
		TBool exit = EFalse;
		
		while (iMessageQueue.Receive(msg)==KErrNone)
			{
			switch (msg.iType)
				{
				case EStopProcessing:
					iStarted = EFalse;
					iLastInputBuffer = EFalse;
					iBuffersToEmpty.Reset();
					iBuffersToFill.Reset();
					break;
				case EExit:
					exit = ETrue;
					break;
				case EInputBuffer:
					iBuffersToEmpty.Append(msg.iBuffer); 
					break;
				case EOutputBuffer:
					iBuffersToFill.Append(msg.iBuffer);
					break;
				}
			}
			
		if (exit)
			{
			break;
			}
		else
			{
			// process all available buffers
			ProcessAvailableBuffers();	
			
			// request notification of further queue events
			iQueueStatus = KRequestPending;
			iMessageQueue.NotifyDataAvailable(iQueueStatus);
			}
		}
	}

CCodecProcessor* CCodecProcessor::NewL(COmxVorbisDecoder& aParent) 
	{
	CCodecProcessor* self = new (ELeave) CCodecProcessor(aParent);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}	
	
	
void CCodecProcessor::ConstructL()
	{
	User::LeaveIfError(iMessageQueue.CreateLocal(10));

	// set the default case
	// input = Vorbis, output = PCM16
	iOutputBitsPerSample = KDefaultOutputBitsPerSample;
	iOutputDataType = KDefaultOutputDataType;

	// create the Vorbis codec
	iCodec = CVorbisDecoderProcessor::NewL();	
	
	// create a dummy buffer used if there are no more encoded data to process
	iDummyBuffer = (CMMFDataBuffer*)CMMFDescriptorBuffer::NewL();
	iDummyBuffer->SetStatus(EUnAvailable);
	}
	
OMX_ERRORTYPE CCodecProcessor::EmptyThisBuffer( 
		OMX_BUFFERHEADERTYPE* pBuffer) 
	{
	TCodecMessage message;
	message.iType = EInputBuffer;
	message.iBuffer = pBuffer;
	if (iMessageQueue.Send(message) == KErrNone)
		{
		return OMX_ErrorNone;	
		}
	else
		{
		return OMX_ErrorUndefined;
		}
	}
	
void CCodecProcessor::Stop()
	{
	TCodecMessage message;
	message.iType = EStopProcessing;
	message.iBuffer = NULL;
	iMessageQueue.Send(message);
	}
	
void CCodecProcessor::Exit()
	{
	TCodecMessage message;
	message.iType = EExit;
	message.iBuffer = NULL;
	iMessageQueue.Send(message);
	}
	
OMX_ERRORTYPE CCodecProcessor::FillThisBuffer(
									OMX_BUFFERHEADERTYPE* pBuffer) 
	{
	TCodecMessage message;
	message.iType = EOutputBuffer;
	message.iBuffer = pBuffer;
	if (iMessageQueue.Send(message)== KErrNone)
		{
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorUndefined;
		}
	}
	
void CCodecProcessor::SetOutputBitsPerSample(TInt aOutputBitsPerSample)
	{
	iOutputBitsPerSample = aOutputBitsPerSample;
	}
	
void CCodecProcessor::SetOutputDataType(OMX_NUMERICALDATATYPE aType)
	{
	iOutputDataType = aType;
	}
	
void CCodecProcessor::ProcessAvailableBuffers()
	{
	// Setup wait for data in queue
	while (iBuffersToFill.Count()>0 && (iBuffersToEmpty.Count()>0 || iLastInputBuffer))
		{
		if (!iStarted)
			{
			iStarted = ETrue;
			}
		
		OMX_BUFFERHEADERTYPE* srcBuffer = NULL;
		CMMFDataBuffer* mmfSrcBuffer = NULL;
		
		TBool useSrcBuffer = iBuffersToEmpty.Count()>0;
		if (useSrcBuffer)
			{			
			srcBuffer = iBuffersToEmpty[0];	
			if (srcBuffer->nFlags & OMX_BUFFERFLAG_EOS)
				{
				iLastInputBuffer = ETrue;
				}
				
			// the buffer contains an ogg packet.
			// no need to pre-calculate samples as in PCM->PCM
			// set up CMMFDataBuffers from the source and dest
			mmfSrcBuffer = (CMMFDataBuffer*)(srcBuffer->pInputPortPrivate);
			mmfSrcBuffer->Data().SetLength(srcBuffer->nFilledLen);
			}
		else
			{
			if (!iLastInputBuffer)
				{ // need more input data
				return;
				}
			// otherwise we can go on with a dummy input buffer to extract output	
			mmfSrcBuffer = iDummyBuffer;
			}
			
		OMX_BUFFERHEADERTYPE* destBuffer = iBuffersToFill[0];
		CMMFDataBuffer* mmfDestBuffer = (CMMFDataBuffer*)(destBuffer->pOutputPortPrivate);
		mmfDestBuffer->Data().SetLength(destBuffer->nFilledLen);
		const TDesC8& srcData = mmfSrcBuffer->Data();
		const TUint8* srcDataPtr = srcData.Ptr();

		CVorbisDecoderProcessor::TProcessResult processResult;
		TUint bytesRead = 0;
		TUint bytesWritten = 0;		
		TRAPD(err, iCodec->ProcessL(*mmfSrcBuffer,
									*mmfDestBuffer, 
									processResult,
									bytesRead,
									bytesWritten) );
		if(err)  
			{
			// we couldn't process the buffer	
			// TO DO : set error condition?
			}
		if (useSrcBuffer)
			{
			srcBuffer->nFilledLen = 0;
			iBuffersToEmpty.Remove(0);			
			iParent->EmptyBufferDoneCallback(srcBuffer);
			}
			
		destBuffer->nFilledLen = bytesWritten;
		iBuffersToFill.Remove(0);
		
		if (iLastInputBuffer && (bytesWritten == 0))
			{
			// clear all remaining read requests
			iBuffersToFill.Reset();
			destBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
			// propagate the EOS flag
			iParent->EventHandlerCallback(
						OMX_EventBufferFlag,
						0,
						destBuffer->nFlags,
						NULL);	
			}
		iParent->FillBufferDoneCallback(destBuffer);
		}
	}
	
CCodecProcessor::~CCodecProcessor()
	{
	iBuffersToEmpty.Close();
	iBuffersToFill.Close();
	iMessageQueue.Close();
	
	// delete the codec
	delete iCodec;
	iCodec = NULL;
	
	delete iDummyBuffer;
	iDummyBuffer = NULL;
	}
	
TInt COmxVorbisDecoder::StartExecution()
	{
	// create thread with current thread's heap
	// we can thus allocate and free memory across threads
	if (!iCreatedThread)
		{
		// create thread with unique name, as two decoders may
		// exist at once
		TTime threadTime;
		threadTime.HomeTime();
        TName threadName;
        threadName.Copy(KVorbisDecoder);
        threadName.AppendNum(threadTime.Int64(), EHex);

		TInt err = iProcessingThread.Create(threadName, 
							&ProcessingThread, 
							KThreadStackSize, 
							&User::Heap(),
							iCodecProcessor);
							
		if (err!=KErrNone)
			{
			return err;
			}
		iCreatedThread = ETrue;
		iThreadDeath = KRequestPending;
		iProcessingThread.Resume();
		}

	return KErrNone;						
	}

// Callbacks for the Vorbis Decoder
void COmxVorbisDecoder::EventHandlerCallback( 
        			OMX_OUT OMX_EVENTTYPE eEvent, 
        			OMX_OUT TUint32 nData1,
        			OMX_OUT TUint32 nData2,
        			OMX_OUT OMX_STRING cExtraInfo)
	{
	iCallback->EventHandler(
			this,
			iAppData,
			eEvent,
			nData1,
			nData2,
			cExtraInfo);	
	}
	
void COmxVorbisDecoder::FillBufferDoneCallback(OMX_BUFFERHEADERTYPE* aBuffer)
	{
	iCallback->FillBufferDone(
		*this,
		iAppData,
		aBuffer);
	}
	
void COmxVorbisDecoder::EmptyBufferDoneCallback(OMX_BUFFERHEADERTYPE* aBuffer)
	{
	iCallback->EmptyBufferDone(
		*this,
		iAppData,
		aBuffer);		
	}
	
// Component Entry Point
OMX_ERRORTYPE OMX_ComponentInit(OMX_HANDLETYPE hComponent)
	{
	TInt err = COmxVorbisDecoder::CreateComponent(hComponent);
	if (err == KErrNone)
		return OMX_ErrorNone;
	else 
		{
		// return some problem
		return OMX_ErrorInsufficientResources;
		
		}
	}
