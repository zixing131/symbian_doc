// OggUtilBody.h
//
// Copyright (c) Symbian Software Ltd 2005-2006.  All rights reserved.
//

#ifndef OGGUTILBODY_H
#define OGGUTILBODY_H

#ifdef SYMBIAN_CODEC_FLOAT_POINT
	#include "vorbis/codec.h" //main libvorbis header
#else
	#include "ivorbiscodec.h" //main tremor header
#endif

class OggUtil;
/**
@internalComponent

Utility class to avail the conversion between TOggPage to oggpage and TOggPacket and oggpacket and viceversa.
*/
NONSHARABLE_CLASS(OggUtil)
    {
public:
    // from TOggPage to ogg_page:
    static void Make_ogg_page(const TOggPage& aSrc, ogg_page& aDest);
    // from TOggPacket to ogg_packet:
    static void Make_ogg_packet(const TOggPacket& aSrc, ogg_packet& aDst);
    // from ogg_page to TOggPage:
    static void MakeOggPage(const ogg_page& aSrc, TOggPage& aDest);
    // from ogg_packet to TOggPacket:
    static void MakeOggPacket(const ogg_packet& aSrc, TOggPacket& aDest);
    };

/**
@internalComponent

Body class for COggPager
*/
NONSHARABLE_CLASS(COggPager::CBody) : public CBase
    {
friend class COggPager;
private:
    CBody();
    void ConstructL();
    ~CBody();

    void Reset();
    TInt GetBuffer(TPtr8& aBuf, TInt aSize);
    TInt DataWritten(const TDes8& aBuf);
    TInt NextPage(TOggPage& aPage);
private:
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	ogg_sync_state iOggSyncState;
#endif
    ogg_sync_state* iSyncState;
    TPtr8 iBuf;
    };

/**
@internalComponent

Body class for COggStream
*/
NONSHARABLE_CLASS(COggStream::CBody) : public CBase
    {
friend class COggStream;
private:
    CBody();
    void ConstructL();
    ~CBody();
	TInt PageIn(TOggPage& aPage);
    TInt PacketOut(TOggPacket& aDst);
    void Reset();
    TInt GetSerialNo();
private:
    TBool iStreamLocked;//used to indicate that the stream is initialized.
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	ogg_stream_state iOggStreamState;
#endif
    ogg_stream_state* iStreamState;
    ogg_page iPage;
    ogg_packet iPacket;
    };

#endif

