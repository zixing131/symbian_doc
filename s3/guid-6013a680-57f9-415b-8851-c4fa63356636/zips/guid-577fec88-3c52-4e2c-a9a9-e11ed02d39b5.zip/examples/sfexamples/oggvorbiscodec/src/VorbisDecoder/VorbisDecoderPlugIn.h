// VorbisDecoderPlugIn.h
//
// Copyright (c) Symbian Software Ltd 2005-2006.  All rights reserved.
//


#ifndef VORBISDECODERPLUGIN_H
#define VORBISDECODERPLUGIN_H

#include <mmf/server/mmfswcodecwrapper.h>

class CVorbisDecoderProcessor;
class CVorbisDecoderPlugInWrapper;

/*
 This class is responsible for taking the input buffer with vorbis data and producing a decoded
 Output buffer with pcm data.
 */
class CVorbisDecoderPlugIn : public CMMFSwCodec
    {
public:
    static CVorbisDecoderPlugIn* NewL();
    virtual ~CVorbisDecoderPlugIn();
    
    //from CMMFSwCodec
    TCodecProcessResult ProcessL
            (const CMMFBuffer& aSource, CMMFBuffer& aDest);
    TUint SourceBufferSize();
    TUint SinkBufferSize();
private:
    CVorbisDecoderPlugIn();
    void ConstructL();
private:
    CVorbisDecoderProcessor* iProc;
    };

/*
 This is a framework class which creates the Codec class above and supports setting the Vbr flag
 in SwCodecWrapper during starting of the Hardware device.
 */
class CVorbisDecoderPlugInWrapper : public CMMFSwCodecWrapper
    {
public:
    static CVorbisDecoderPlugInWrapper* NewL();
    virtual ~CVorbisDecoderPlugInWrapper();
       
	//from CMMFSwCodecWrapper
    TInt Start(TDeviceFunc aFuncCmd, TDeviceFlow aFlowCmd);
    CMMFSwCodec& Codec();
private:
    CVorbisDecoderPlugInWrapper();
    void ConstructL();
private:
    CVorbisDecoderPlugIn* iDevice;
    TBool iCodecReturned; //flag recording if ownership of codec has been transeferred to client
    };

#endif //VORBISDECODERPLUGIN_H
