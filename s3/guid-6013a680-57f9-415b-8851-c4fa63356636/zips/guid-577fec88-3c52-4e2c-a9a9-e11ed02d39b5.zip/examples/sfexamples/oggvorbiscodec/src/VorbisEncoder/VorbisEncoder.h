// VorbisEncoder.h
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//

#ifndef VORBISENCODER_H
#define VORBISENCODER_H

#include <mmf/server/mmfdatabuffer.h>
#include <oggutil.h>
#include <vorbisinfo.h>
#include "vorbis/vorbisenc.h"
#include "vorbis/codec.h"

#ifdef SYMBIAN_VORBIS_DEBUG
#define DEBUG(x) RDebug::Print(_L(x))
#define DEBUG1(x,x1) RDebug::Print(_L(x),x1)
#else
#define DEBUG(x)
#define DEBUG1(x,x1)
#endif

const TInt KOggVorbisMinBitrate = 45000; //see http://en.wikipedia.org/wiki/Vorbis
// see for the derivation of these constants http://en.wikipedia.org/wiki/Vorbis
const TInt KVorbisQualityMinus1 = 45000;
const TInt KVorbisQuality0 = 64000;
const TInt KVorbisQuality1 = 80000;
const TInt KVorbisQuality2 = 96000;
const TInt KVorbisQuality3 = 112000;
const TInt KVorbisQuality4 = 128000;
const TInt KVorbisQuality5 = 160000;
const TInt KVorbisQuality6 = 192000;
const TInt KVorbisQuality7 = 224000;
const TInt KVorbisQuality8 = 256000;
const TInt KVorbisQuality9 = 320000;
const TInt KVorbisQuality10 = 500000;
//note that the Vorbis libraries can crash below this limit                                             

//Central encoding class - talks to the Xiph vorbis libraries
class CVorbisEncoder : public CBase
    {
public:
    static CVorbisEncoder* NewL();
    ~CVorbisEncoder();
    TInt PageOutL(CMMFDataBuffer& aBuf);
    void PcmInL(const CMMFDataBuffer& aBuf);
    void Reset();
	TInt BitRateL();
    void SetBitRateL(TInt aBitRate);
    void InitializeVorbisStreamL();
    void ConfigureL(TInt aSampleRate, TInt aChannels);
    void ConvertBitRateToQuality(TInt aBitRate, TReal32& aQuality);
private:
	CVorbisEncoder();
	void ConstructL();
	void PrepareHeadersL();
	TInt TranslateOggVorbisError(TInt aError);
    enum TCodecState
        {
        ENotReady,
        EInitialized,
        EReady
        };
    TCodecState iState;
    // struct that stores all the static vorbis bitstream settings
    vorbis_info iInfo; 
    // struct that stores all the user comments
    vorbis_comment iComment;
     // central working state for the packet->PCM decoder
    vorbis_dsp_state iDspState;
    //local working space for packet->PCM decode 
    vorbis_block iBlock;
    ogg_stream_state iStream;
    TInt iBitRate;
    //Encode quality to be used.
    TReal32 iQuality;
    TInt iSampleRate;
    TInt iChannels;
    TInt iPageCount;
    TBool iLastBuffer;
    };

/*
 This class is responsible for encoding the raw data obtained from the CVorbisEncoderPlugInWrapper into
 vorbis data. It also returns the result of the operation
 */
class CVorbisProcessor : public CBase
    {
public:
    enum TProcessResult
        {
        EComplete,
        EIncomplete,
        EDestNotFilled
        };

    static CVorbisProcessor* NewL();
    virtual ~CVorbisProcessor();

    void ProcessL(const CMMFBuffer& aSource,
                           CMMFBuffer& aDest,
                           TProcessResult& aRes,
                           TUint& aSourceUsed,
                           TUint& aDestWritten);
    TInt BitRateL();
    void SetBitRateL(TInt aBitRate);
    void ConfigureL(TInt aSampleRate, TInt aChannels);
private:
    CVorbisProcessor();
    void ConstructL();
private:
    CVorbisEncoder* iEncoder;
#ifdef SYMBIAN_SEP_HEAP    
    RHeap* iDefaultHeap;
    RHeap* iVorbisHeap;
    RChunk iVorbisChunk;
#endif
    };

#endif //VORBISENCODER_H
