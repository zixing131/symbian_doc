// VorbisDecoder.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//

#include <e32base.h>
#include <mmf/server/mmfdatabuffer.h>
#include "ivorbiscodec.h" 
#include <oggutil.h>
#include <vorbisinfo.h>
#include "VorbisDecoder.h"
#include "../OggVorbisUtil/OggUtilBody.h"
#include <e32debug.h>

const TInt KMaxPcmOutFromPacket = 8000;//Maximum pcm data from a single packet.
const TInt KEndOfStreamBytePos = 5;
const TUint KEndOfStreamFlag = 0x0004;
const TInt KInitDataPage = 3;
_LIT8(KOggS, "OggS");

CVorbisDecoder* CVorbisDecoder::NewL()
    {
    CVorbisDecoder* self = new(ELeave)CVorbisDecoder;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }
    
CVorbisDecoder::CVorbisDecoder()
    {
    }

void CVorbisDecoder::ConstructL()
    {
    vorbis_info_init(&iInfo);
    vorbis_comment_init(&iComment);
    
    iSyncState = ogg_sync_create();
    
    //stream with negative serial indicates it is not initialized. We do this during playing because we 
	//get the serial number from the clip.
	iStreamState = ogg_stream_create(-1);
    }

CVorbisDecoder::~CVorbisDecoder()
    {
    if (iState==EReady)
        {
        vorbis_block_clear(&iBlock);
        vorbis_dsp_clear(&iDspState);
        }
    vorbis_comment_clear(&iComment);
    vorbis_info_clear(&iInfo);
    ogg_packet_release(&iPacket);
    ogg_page_release(&iPage);
	ogg_sync_destroy(iSyncState);
    ogg_stream_destroy(iStreamState);
    }
    
/**
This method takes an oggpacket as an input and submits into the vorbis synthesis block which is owned 
by the tremor. This method can be repeatedly called by the client during initialisation until 3 packets have been found,
at which point the vorbis libraries are initialised.

@param  aPacket
       An ogg_packet.
@leave Leaves with KErrNotSupported when the data does not belong to the vorbis stream, KErrCorrupt if header is corrupted
		and any of the system wide error codes.
*/
void CVorbisDecoder::PacketInL(ogg_packet aPacket)
    {
    if (iState == EBadStream) 
    	{
    	User::Leave(KErrCorrupt);	
    	}
    else if (iState == ENotVorbis) 
    	{
    	User::Leave(KErrNotSupported);	
    	}	
	iPacket = aPacket;
    if (iState == EInitializing) // not finished reading header yet
        {
      	TInt res = vorbis_synthesis_headerin(&iInfo, &iComment, &iPacket);
        if (res < KErrNone) // some error
            {
            if (res == OV_ENOTVORBIS)
                {
                iState = ENotVorbis;
                User::Leave(KErrNotSupported);
                }
            else
                {
                iState = EBadStream;
                User::Leave(KErrCorrupt);
                }
            }
        ++iPacketCount;
        // a vorbis header consists of 3 packets:
        if (iPacketCount == 3) 
            {
            vorbis_synthesis_init(&iDspState, &iInfo);
            vorbis_block_init(&iDspState, &iBlock);
            iState = EReady;
            }
        }
    else if (iState == EReady)
        {
        TInt res = vorbis_synthesis(&iBlock, &iPacket, 1);
        if (res == KErrNone) 
        	{
        	vorbis_synthesis_blockin(&iDspState, &iBlock);	
        	}
        else 
        	{
        	User::Leave(KErrCorrupt);	
        	}
        }
    else 
    	{
    	User::Leave(KErrGeneral);
    	}
    }
    
/**
This method decodes the oggpacket submitted during PacketInL() into 
pcmdata and fills the destination buffer.	
@param  aBuf
        The buffer in which the pcmdata is submitted.

@leave Leaves with KErrNotSupported when the data does not belong to the vorbis stream, KErrCorrupt if header is corrupted
		and any of the system wide error codes.

*/
void CVorbisDecoder::PcmOutL(TDes8& aBuf)
    {
    if (iState == ENotVorbis) 
    	{
    	User::Leave(KErrNotSupported);
    	}
    else if (iState == EBadStream) 
    	{
    	User::Leave(KErrCorrupt);	
    	}
    else if (iState == EInitializing)
        {
        aBuf.SetLength(0);
        }
    else if (iState == EReady)
        {
	    TInt** pcm;
        TInt samples = vorbis_synthesis_pcmout(&iDspState, &pcm);
        while ( samples > 0)
	        {
	        TInt bytesPerSample = 2*iInfo.channels; // 16-bit
	        if (bytesPerSample == 0)
		        {
		        User::Leave(KErrCorrupt);	
		        }
	        TInt data = aBuf.Length();
	        TInt newLength = 0;
	        if ( data == 0)
		        {
		        newLength = aBuf.MaxLength(); 	
		        }
		    else
			    {
			    newLength = aBuf.MaxLength() - data;	
			    }
	        TInt bufSamples = newLength/bytesPerSample; // max samples in aBuf
	        TInt toConv = (samples>bufSamples) ? bufSamples : samples;
	        TInt length = data + (toConv*bytesPerSample);
	        if(length <= aBuf.MaxLength())
		        {
		        aBuf.SetLength(length);	
		        }
		    else
			    {
			    User::Leave(KErrOverflow);	
			    }
	        TInt16* bufptr = reinterpret_cast<TInt16*>(&aBuf[data + 0]);
	        // clip samples to pcm16 and interleave
	        for (TInt c=0; c<iInfo.channels; ++c)
	            {
	            TInt* mono = pcm[c];
	            TInt16* dest = &bufptr[c];
	            for (TInt i=0; i<toConv; i++)
	                {
	                TInt s = mono[i]>>9; // pcm values from the decoder are from -1 to 1. Need to transform them
	                // to the integer range by multiplying or bitshifting
	                // clip just in case
	                if (s>KMaxTInt16) //see /libvorbis/examples/decoder_example.c
	                    {
	                    s = KMaxTInt16; 
	                    }
	                else if (s<KMinTInt16)
	                    {
	                    s = KMinTInt16;
	                    }
	                dest[i*iInfo.channels] = s;
	                }
	            }
	        vorbis_synthesis_read(&iDspState, toConv);
	        samples = vorbis_synthesis_pcmout(&iDspState, &pcm);
	        }
		}
    else 
    	{
    	User::Leave(KErrGeneral);	
    	}
    }

void CVorbisDecoder::Reset()
    {
    if (iState==EReady)
        {
        vorbis_block_clear(&iBlock);
        vorbis_dsp_clear(&iDspState);
        }
    vorbis_comment_clear(&iComment);
    vorbis_info_clear(&iInfo);
    vorbis_info_init(&iInfo);
    vorbis_comment_init(&iComment);
    iPacketCount = 0;
    iPageNumber = 0;
    iState = EInitializing;
    }
/**
This method extracts all ogg pages and packets from source buffer and sends 
each packet to PacketInL() for decoding. 
pcmdata and fills the destination buffer.	
@param  aBuf
        The source buffer contains encoded data.
@param  aDstBuf
        The destination buffer in which the pcmdata is submitted.

@leave  Leaves with any system wide error code.
*/ 
void CVorbisDecoder::DecoderL(const CMMFDataBuffer& aBuf, TDes8& aDstBuf)
    {
 	CMMFDataBuffer& srcBuf = const_cast<CMMFDataBuffer&>(aBuf);//we need this because Status() is not a const function.
 	if(srcBuf.Status()!= EUnAvailable)
 		{
	 	unsigned char* buf = ogg_sync_bufferin(iSyncState, aBuf.BufferSize());
		TPtr8 bufPtr(buf, 0, aBuf.BufferSize());
		bufPtr.Copy(aBuf.Data());
		ogg_sync_wrote(iSyncState, aBuf.BufferSize());
 		if(iPageNumber > KInitDataPage && IsLastPage(srcBuf))
 			{
 			srcBuf.SetStatus(EUnAvailable);
 			}
 		}
	TInt res = 0;
    while(ETrue)
	    {
	    res = ogg_stream_packetout(iStreamState, &iPacket);//Find packet
		if (res > 0) //found one
		    {
			PacketInL(iPacket);
		    if(iState != EInitializing)
		    	{  	 
				PcmOutL(aDstBuf);
				//Check if destination buffer atleast has 8k space to add pcm data.
		    	//If not destination buffer is full and send filled buffer.
				if (aDstBuf.MaxLength() - aDstBuf.Length() < KMaxPcmOutFromPacket) 
			    	{
			    	break;	
			    	}
		    	}
		    }
		else if(res == 0) //no packet in the stream
		    {
		    //Get the page
		    TInt length = ogg_sync_pageseek(iSyncState, &iPage);		    
		    if ( length < 0 )
				{
			    continue;	
			    }
		    else if ( length > 0 ) //we have one so submit into the stream
		    	{
		        if(iPageNumber == 0)//First page should get serial number
				    {
				    ogg_stream_reset_serialno(iStreamState, ogg_page_serialno(&iPage));	
				    }
		        ++iPageNumber;
		        
		        ogg_stream_pagein(iStreamState, &iPage);
		     	}
		     else
			 	{
			    break;
			 	}
			 }
	    }
    }

TBool CVorbisDecoder::IsLastPage(CMMFDataBuffer& aSrcBuf)
	{
	if(iPageNumber > KInitDataPage)
		{
		TInt pos = aSrcBuf.Data().Find(KOggS);
		if(pos != KErrNotFound)
			{
			if(pos + KEndOfStreamBytePos < aSrcBuf.BufferSize())
	   			{
	   			TInt flag = aSrcBuf.Data()[pos + KEndOfStreamBytePos] & KEndOfStreamFlag;
		  		if(flag)
		  			{
		  			return ETrue;
		  			}
		  		}
			}
		}
	return EFalse;
	}
//--------------------------------------------------------------------    
//---------------------------- Processor -----------------------------    
//--------------------------------------------------------------------    

CVorbisDecoderProcessor* CVorbisDecoderProcessor::NewL()
    {
    CVorbisDecoderProcessor* self = new(ELeave)CVorbisDecoderProcessor;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }
    
CVorbisDecoderProcessor::CVorbisDecoderProcessor()
    {
    }
    
void CVorbisDecoderProcessor::ConstructL()
    {
#ifdef SYMBIAN_SEP_HEAP
    User::LeaveIfError(iVorbisChunk.CreateLocal(KInitialChunkSize, KMaxChunkSize, EOwnerThread));
    iVorbisHeap = User::ChunkHeap(iVorbisChunk, KMinHeapLength);
    iDefaultHeap = &User::Heap();
#endif
    VORBIS_TRAPD(leaveErr, iDecoder = CVorbisDecoder::NewL());
    User::LeaveIfError(leaveErr);
    }
    
CVorbisDecoderProcessor::~CVorbisDecoderProcessor()
    {
#ifdef SYMBIAN_SEP_HEAP
	if(iVorbisHeap)
		{
		User::SwitchHeap(iVorbisHeap);
		}
#endif
    delete iDecoder;
#ifdef SYMBIAN_SEP_HEAP
	if(iVorbisHeap)
		{
		iVorbisChunk.Close();
    	User::SwitchHeap(iDefaultHeap);
		}
#endif
    }

/**
This method makes a request to OggVorbis decoder to convert source chunk in to PCM data.
Vorbis DecoderL function will return back the destination buffer filled with PCM data.	
@param  aSource
        The source buffer contains encoded data.
@param  aDst
        The destination buffer in which the pcmdata is submitted.
@param  aRes
        Status of decoding.
@param  aSourceUsed
        Length of the source data converted in to PCM data.
@param  aDestWritten
        The destination buffer length.

@leave  Leaves with any system wide error code.
@return None.
*/  
void CVorbisDecoderProcessor::ProcessL(const CMMFBuffer& aSource, 
                                CMMFBuffer& aDst,
                                TProcessResult& aRes,
                                TUint& aSourceUsed,
                                TUint& aDestWritten)
    {
    // check that buffers are instances of CMMFDataBuffer
    if (!CMMFBuffer::IsSupportedDataBuffer(aSource.Type())) 
    	{
    	User::Leave(KErrNotSupported);
    	}
    if (!CMMFBuffer::IsSupportedDataBuffer(aDst.Type())) 
    	{
    	User::Leave(KErrNotSupported);
    	}
    const CMMFDataBuffer& src = static_cast<const CMMFDataBuffer&>(aSource);
    if((src.LastBuffer()) && (src.Data().Length() == 0 ))
    	{
    	//last buffer and is of length zero. just return
    	aDestWritten = 0;
        aSourceUsed = 0;
        aRes = EComplete;
        return;
    	}
    CMMFDataBuffer& dstBuf = static_cast<CMMFDataBuffer&>(aDst);
    if ((aSource.FrameNumber()<2) && (aSource.FrameNumber()<iLastFrame)) 
    	{
    	#ifdef SYMBIAN_SEP_HEAP
			User::SwitchHeap(iVorbisHeap);
		#endif
    	iDecoder->Reset(); // process header again	
    	#ifdef SYMBIAN_SEP_HEAP
			iVorbisChunk.Close();
		#endif
    	}
    dstBuf.Data().SetLength(0);
    //Send the source buffer to decoder.
    VORBIS_TRAPD(leaveErr, iDecoder->DecoderL(src,dstBuf.Data()));
	User::LeaveIfError(leaveErr);
    aDestWritten = dstBuf.Data().Length();
    dstBuf.Data().SetLength(dstBuf.Data().Length());
    aSourceUsed = src.Data().Length()-aSource.Position();
    aRes = ( aDestWritten==0) ? EDestNotFilled : EComplete ;
    iLastFrame = aSource.FrameNumber();
  	if( aDestWritten==0 && src.LastBuffer() )
  	    { //means end of play
  	    #ifdef SYMBIAN_SEP_HEAP
			RHeap* oldHeap = User::SwitchHeap(iVorbisHeap);
		#endif
  	        iDecoder->Reset();
  	    #ifdef SYMBIAN_SEP_HEAP
			User::SwitchHeap(oldHeap);
		#endif
  	    }
    }
    
