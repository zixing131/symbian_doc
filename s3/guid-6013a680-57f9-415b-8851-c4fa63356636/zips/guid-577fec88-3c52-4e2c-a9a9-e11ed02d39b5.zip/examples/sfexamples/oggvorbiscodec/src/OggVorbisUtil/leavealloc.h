// leavealloc.h
//
// Copyright (c) Symbian Software Ltd 2005-2006.  All rights reserved.
//


#ifndef __LEAVEALLOC_H__
#define __LEAVEALLOC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
/*
 To make the calls in oggvorbis libraries leave safe, all the methods used for memory allocation
 are modified to leave with KErrNoMemory with there is no memory to allocate.
 */
void* mallocL(size_t _size);

void* callocL(size_t _nmemb, size_t _size);

void* reallocL(void * _r, size_t _size);

void freeL(void *);


#ifdef __cplusplus
}
#endif


#endif
