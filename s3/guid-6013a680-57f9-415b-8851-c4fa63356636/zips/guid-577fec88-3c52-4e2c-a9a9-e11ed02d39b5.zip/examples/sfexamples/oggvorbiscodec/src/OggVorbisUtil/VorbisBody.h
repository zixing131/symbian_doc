// VorbisBody.h
//
// Copyright (c) Symbian Software Ltd 2005-2006.  All rights reserved.
//

#ifndef VORBISBODY_H
#define VORBISBODY_H

/**
@internalComponent

Body class for CVorbisInfo
*/
NONSHARABLE_CLASS(CVorbisInfo::CBody) : public CBase
    {
friend class CVorbisInfo;
private:
    CBody();
    ~CBody();
    void Construct3L();
    
    void InitializeL(const TOggPacket& aNextPacket);
    void InitializeL(TUint aSampleRate, TUint aBitRate, TUint aNumChannels);
    TInt SampleRate();
    TInt Channels();
    TDesC& Vendor();
    TInt Comments();
    CVorbisComment& GetComment(TInt aIndex);
    TInt BitRateNominal();
    TInt BitRateUpper();
    TInt BitRateLower();
    void ConvertCommentDataL();
    TInt TranslateOggVorbisError(TInt aError);
	void SetSampleRate(TUint aSampleRate);
	void SetBitRate(TUint aBitRate);
	void SetChannels(TUint aChannels);
private:
    static const TInt KPcktsRqrd = 3;
    TInt iPcktsRcvd;
    vorbis_info iInfo;
    vorbis_comment iComment;
#ifdef SYMBIAN_CODEC_FLOAT_POINT
    vorbis_dsp_state iDspState; 
    vorbis_block iBlock;
#endif    
    CArrayPtrFlat<CVorbisComment>* iComments;
    HBufC* iVendor;
    };

#endif
