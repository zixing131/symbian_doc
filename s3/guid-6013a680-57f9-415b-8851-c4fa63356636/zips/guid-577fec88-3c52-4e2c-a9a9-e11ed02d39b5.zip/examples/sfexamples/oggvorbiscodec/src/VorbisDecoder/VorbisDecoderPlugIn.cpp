// VorbisDecoderPlugIn.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//


#include <e32base.h>
#include <ecom/implementationproxy.h>
#include "VorbisDecoderPlugIn.h"
#include "VorbisDecoderUIDs.hrh"
#include "VorbisDecoder.h"

const TInt KSourceBufferSize = 0x1000;//enough to accomodate atleast one oggpacket
const TInt KSinkBufferSize = 0x8000; //Good enough to accomodate the pcm obtained after processing one oggpacket

CVorbisDecoderPlugInWrapper* CVorbisDecoderPlugInWrapper::NewL()
    {
    CVorbisDecoderPlugInWrapper* self = new(ELeave)CVorbisDecoderPlugInWrapper;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

CVorbisDecoderPlugInWrapper::~CVorbisDecoderPlugInWrapper()
    {
    // just in case the codec was never asked for:
    if (!iCodecReturned) 
    	{
    	delete iDevice;
    	}
    }

CVorbisDecoderPlugInWrapper::CVorbisDecoderPlugInWrapper()
    : iCodecReturned(EFalse)
    {
    }

void CVorbisDecoderPlugInWrapper::ConstructL()
    {
    iDevice = CVorbisDecoderPlugIn::NewL();
    }
    
/**
This method returns a CVorbisDecoderPlugIn (CMMFSwCodec) used by this
class .  
	
@return The CMMFSwCodec used by the derived CMMFSwCodecWrapper
*/
CMMFSwCodec& CVorbisDecoderPlugInWrapper::Codec()
    {
    iCodecReturned=ETrue;
    return *iDevice; // this is owned by the SwWrapper
    }

/**
This method mainly added to set the Vbr flag in the Datapath after starting the 
the hardware device. 
	
@return Any System wide error code
*/
TInt CVorbisDecoderPlugInWrapper::Start(TDeviceFunc aFuncCmd, TDeviceFlow aFlowCmd)
	{
	TInt err = CMMFSwCodecWrapper::Start(aFuncCmd, aFlowCmd);
	if(err == KErrNone)
		{
		SetVbrFlag();
		}
	return err;
	}
	
CVorbisDecoderPlugIn* CVorbisDecoderPlugIn::NewL()
    {
    CVorbisDecoderPlugIn* self = new(ELeave)CVorbisDecoderPlugIn();
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

CVorbisDecoderPlugIn::CVorbisDecoderPlugIn()
    {
    }

CVorbisDecoderPlugIn::~CVorbisDecoderPlugIn()
    {
    delete iProc;
    }

void CVorbisDecoderPlugIn::ConstructL()
    {
    iProc = CVorbisDecoderProcessor::NewL();
    }

/**
This method decodes the oggpacket in the source buffer into pcm data and writes it into the destination buffer 
passed to it.

This function is synchronous, when the function returns the data has been processed.

@param	aSource
		The source buffer containing the oggpacket to decode.
@param	aDest
 		The destination buffer to hold the pcm data after decoding.
@return	The result of the processing.

@see    TCodecProcessResult
*/
CMMFSwCodec::TCodecProcessResult CVorbisDecoderPlugIn::ProcessL(const CMMFBuffer& aSource, CMMFBuffer& aDst)
    {
    CMMFSwCodec::TCodecProcessResult res;
    CVorbisDecoderProcessor::TProcessResult status;
    iProc->ProcessL(aSource, aDst, status, res.iSrcBytesProcessed, res.iDstBytesAdded);
    switch (status)
        {
    case CVorbisDecoderProcessor::EComplete:
        res.iCodecProcessStatus = TCodecProcessResult::EProcessComplete;
        break;
    case CVorbisDecoderProcessor::EIncomplete:
        res.iCodecProcessStatus = TCodecProcessResult::EProcessIncomplete;
        break;
    case CVorbisDecoderProcessor::EDestNotFilled:
        res.iCodecProcessStatus = TCodecProcessResult::EDstNotFilled;
        break;
    default:
    	User::Leave(KErrNotSupported);
        }
    return res;
    }

TUint CVorbisDecoderPlugIn::SourceBufferSize()
    {
    //enough to accomodate one oggpacket
    return KSourceBufferSize;
    }

TUint CVorbisDecoderPlugIn::SinkBufferSize()
    {
    //enough to accomodate the pcm obtained after processing one oggpacket
    return KSinkBufferSize;
    }

// __________________________________________________________________________
// Exported proxy for instantiation method resolution
// Define the interface UIDs

const TImplementationProxy ImplementationTable[] =
	{
	IMPLEMENTATION_PROXY_ENTRY(KVorbisHwDecodeUid,	CVorbisDecoderPlugInWrapper::NewL),
	};

EXPORT_C const TImplementationProxy* ImplementationGroupProxy(TInt& aTableCount)
	{
	aTableCount = sizeof(ImplementationTable) / sizeof(TImplementationProxy);

	return ImplementationTable;
	}
