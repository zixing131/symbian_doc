// VorbisEncoderPlugIn.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//


#include <e32base.h>
#include <ecom/implementationproxy.h>
#include <mmf/server/mmfswcodecwrapper.h>
#include "VorbisEncoder.h"
#include "VorbisEncoderUIDs.hrh"
#include "VorbisEncoderPlugIn.h"

/*taken from encoder_example.c in libvorbis\examples\encoder_example.c. These values
taken such a way that we usually get an oggpage generated for the given KSourceBufferSize.*/
const TInt KSourceBufferSize = 0x4000;// = KSamplesToRead/2(channels)*2(16-bit)
const TInt KSinkBufferSize = 0x4000; //enough to accomodate two oggpages which is rare
	
CVorbisEncoderPlugInWrapper* CVorbisEncoderPlugInWrapper::NewL()
    {
    DEBUG("CVorbisHwDeviceWrapper2::NewL");
    CVorbisEncoderPlugInWrapper* self = new(ELeave)CVorbisEncoderPlugInWrapper;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

void CVorbisEncoderPlugInWrapper::ConstructL()
	{
	iDevice = CVorbisEncoderPlugIn::NewL();
	}
	
CVorbisEncoderPlugInWrapper::~CVorbisEncoderPlugInWrapper()
    {
    DEBUG("CVorbisEncoderPlugInWrapper::~CVorbisEncoderPlugInWrapper");
    // just in case the codec was never asked for:
    if (!iCodecReturned) 
    	{
    	delete iDevice;
    	}
    }

CVorbisEncoderPlugInWrapper::CVorbisEncoderPlugInWrapper()
    {
    }

TInt CVorbisEncoderPlugInWrapper::SetConfig(TTaskConfig& aConfig)
	{
	TInt err = CMMFSwCodecWrapper::SetConfig(aConfig);
	if (err != KErrNone)
		{
		return err;
		}
	err = static_cast<CVorbisEncoderPlugIn* >(iCodec)->Configure(iSampleRate, iChannels);
	return err;
	}

/**
This method returns a CVorbisEncoderPlugIn (CMMFSwCodec) used by this
class .  
	
@return The CMMFSwCodec used by the derrived CMMFSwCodecWrapper
*/
CMMFSwCodec& CVorbisEncoderPlugInWrapper::Codec()
    {
    DEBUG("CVorbisHwDeviceWrapper2::Codec");
    iCodecReturned=ETrue;
    return *iDevice; // this is owned by the SwWrapper
    }


TInt CVorbisEncoderPlugInWrapper::Start(TDeviceFunc aFuncCmd, TDeviceFlow aFlowCmd)
	{
	TInt err = CMMFSwCodecWrapper::Start(aFuncCmd, aFlowCmd);
	if(err == KErrNone)
		{
	SetVbrFlag();
		}
	return err;
	}
	
/**
This must provide an implementation as defined by CMMFDevSound::CustomInterface(TUid aInterfaceId)
	
@param  aInterfaceId
        The interface UID, defined with the custom interface.

@return A pointer to the interface implementation, or NULL if the device does not
        implement the interface requested. The return value must be cast to the
        correct type by the user.
	        
@see CMMFDevSound::CustomInterface(TUid aInterfaceId)
	*/
TAny* CVorbisEncoderPlugInWrapper::CustomInterface(TUid aInterfaceId)
	{
	// if this is the bitrate interface then
	// we support this natively
	if (aInterfaceId == KUidCustomInterfaceDevSoundBitRate)
		{
		return static_cast<MMMFDevSoundCustomInterfaceBitRate*> (this);
		}
	else
		{
		// otherwise pass the interface call onto the base class
		return CMMFSwCodecWrapper::CustomInterface(aInterfaceId);
		}
	}
/**
Gets the bit rates that are supported by DevSound in its current configuration.

@param  aSupportedBitRates
The supported bit rates, in bits per second, shall be appended to this array. Note that 
the array shall be reset by this method.
*/
void CVorbisEncoderPlugInWrapper::GetSupportedBitRatesL(RArray<TInt>& aSupportedBitRates)
	{
	aSupportedBitRates.Reset();
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQualityMinus1));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality0));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality1));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality2));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality3));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality4));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality5));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality6));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality7));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality8));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality9));
	User::LeaveIfError(aSupportedBitRates.Append(KVorbisQuality10));
 	}

/**
Returns	the current bit rate.

@return	The current bit rate, in bits per second.
*/
TInt CVorbisEncoderPlugInWrapper::BitRateL()
	{
	return static_cast<CVorbisEncoderPlugIn* >(iCodec)->BitRateL();
	}

/**
Sets the bit rate to a new value.

@param  aBitRate
The new bit rate, in bits per second.
*/
void CVorbisEncoderPlugInWrapper::SetBitRateL(TInt aBitRate)
	{
	static_cast<CVorbisEncoderPlugIn* >(iCodec)->SetBitRateL(aBitRate);
	}


CVorbisEncoderPlugIn* CVorbisEncoderPlugIn::NewL()
    {
    DEBUG("CVorbisEncoderPlugIn::NewL");
    CVorbisEncoderPlugIn* self = new(ELeave)CVorbisEncoderPlugIn;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

CVorbisEncoderPlugIn::CVorbisEncoderPlugIn()
    {
    }

CVorbisEncoderPlugIn::~CVorbisEncoderPlugIn()
    {
    DEBUG("CVorbisEncoderPlugIn::~CVorbisEncoderPlugIn");
    delete iProc;
    }

void CVorbisEncoderPlugIn::ConstructL()
    {
    iProc = CVorbisProcessor::NewL();
    }
/**
Processes the data in the specified source buffer and writes the processed data to
the specified destination buffer.

This function is synchronous, when the function returns the data has been processed.
This is a virtual function that each derived class must implement.

@param	aSource
		The source buffer containing data to encode or decode.
@param	aDest
 		The destination buffer to hold the data after encoding or decoding.
@return	The result of the processing.

@see    TCodecProcessResult
*/
	
CMMFSwCodec::TCodecProcessResult CVorbisEncoderPlugIn::ProcessL(const CMMFBuffer& aSource, CMMFBuffer& aDst)
    {
    //DEBUG("CVorbisEncoderPlugIn::ProcessL");
    CMMFSwCodec::TCodecProcessResult res;
    CVorbisProcessor::TProcessResult status;
    iProc->ProcessL(aSource, aDst, status, res.iSrcBytesProcessed, res.iDstBytesAdded);
    switch (status)
        {
    case CVorbisProcessor::EComplete:
        res.iCodecProcessStatus = TCodecProcessResult::EProcessComplete;
        break;
    case CVorbisProcessor::EIncomplete:
        res.iCodecProcessStatus = TCodecProcessResult::EProcessIncomplete;
        break;
    case CVorbisProcessor::EDestNotFilled:
        res.iCodecProcessStatus = TCodecProcessResult::EDstNotFilled;
        break;
        }
    return res;
    }

TUint CVorbisEncoderPlugIn::SourceBufferSize()
    {
    return KSourceBufferSize; 
    }

TUint CVorbisEncoderPlugIn::SinkBufferSize()
    {
    return KSinkBufferSize; 
    }
	
TInt CVorbisEncoderPlugIn::BitRateL()
	{
	return iProc->BitRateL();
	}
	
void CVorbisEncoderPlugIn::SetBitRateL(TInt aBitRate)
	{
	iProc->SetBitRateL(aBitRate);
	}
	
TInt CVorbisEncoderPlugIn::Configure(TInt aSampleRate, TInt aChannels)
	{
	TRAPD(err, iProc->ConfigureL(aSampleRate, aChannels));
	return err;
	}
// __________________________________________________________________________
// Exported proxy for instantiation method resolution
// Define the interface UIDs

const TImplementationProxy ImplementationTable[] =
	{
	IMPLEMENTATION_PROXY_ENTRY(KVorbisHwEncodeUid,	CVorbisEncoderPlugInWrapper::NewL),
	};

EXPORT_C const TImplementationProxy* ImplementationGroupProxy(TInt& aTableCount)
	{
	aTableCount = sizeof(ImplementationTable) / sizeof(TImplementationProxy);

	return ImplementationTable;
	}
