// OggPages.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//


#include <e32base.h>
#include <e32debug.h>
#include <stdlib.h>
#include <string.h>

#ifdef SYMBIAN_CODEC_FLOAT_POINT
#include "ogg/ogg.h"
#endif
#include <oggutil.h>
#include "OggUtilBody.h"

//--------------------------- COggPager ---------------------------

EXPORT_C COggPager* COggPager::NewL()
    {
    COggPager* self = new(ELeave)COggPager;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

COggPager::COggPager()
    {
    }

COggPager::~COggPager()
    {
    delete iBody;
    }

void COggPager::ConstructL()
    {
    iBody = new(ELeave) COggPager::CBody;
    iBody->ConstructL();
    }

EXPORT_C void COggPager::Reset()
    {
    iBody->Reset();
    }

EXPORT_C TInt COggPager::GetBuffer(TPtr8& aBuf, TInt aSize)
    {
    return iBody->GetBuffer(aBuf, aSize);
    }

EXPORT_C TInt COggPager::DataWritten(TDes8& aBuf)
    {
    return iBody->DataWritten(aBuf);
    }

EXPORT_C TInt COggPager::NextPage(TOggPage& aPage)
    {
    return iBody->NextPage(aPage);
    }


//----------------------- COggPager::CBody ------------------------

COggPager::CBody::CBody()
    : iBuf(NULL, 0)
    {
    }

void COggPager::CBody::ConstructL()
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
  	iSyncState = &iOggSyncState;
  	ogg_sync_init(iSyncState);
#else
	iSyncState = ogg_sync_create();
    if (!iSyncState) 
    	{
    	User::Leave(KErrNoMemory);	
    	}
#endif
    }

COggPager::CBody::~CBody()
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	ogg_sync_clear(iSyncState);
#else
	ogg_sync_destroy(iSyncState);
#endif
    }

void COggPager::CBody::Reset()
    {
    ogg_sync_reset(iSyncState);
    }

/**
This method gets a buffer from ogg_sync_state to write data from source clip.

@param  aBuf
        The buffer from ogg_sync_state
@param  aSize
		The size of the required buffer
@return Any of the system wide error codes. KErrNoMemory when there is no memory to create a buffer.
*/
TInt COggPager::CBody::GetBuffer(TPtr8& aBuf, TInt aSize)
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	char* buf = ogg_sync_buffer(iSyncState, aSize);
#else
	unsigned char* buf = ogg_sync_bufferin(iSyncState, aSize);
#endif

    if (buf==NULL) 
    	{
    	return KErrNoMemory;
    	}
    iBuf.Set((unsigned char*)buf, 0, aSize);
    aBuf.Set(iBuf);
    return KErrNone;
    }

/**
This method indicates ogg_sync_state that data has been written into its buffer.

@param  aBuf
        The buffer from ogg_sync_state

@return Any of the system wide error codes.
*/
TInt COggPager::CBody::DataWritten(const TDes8& aBuf)
    {
    // check it's the right buffer
    if (aBuf.Ptr()!=iBuf.Ptr()) 
    	{
    	return KErrArgument;	
    	}
    if (aBuf.Length()>iBuf.MaxLength()) 
    	{
    	return KErrOverflow;	
    	}
    if (ogg_sync_wrote(iSyncState, aBuf.Length())<0) 
    	{
    	return KErrOverflow;	
    	}
    else 
    	{
    	return KErrNone;	
    	}
    }

/**
This method tries to retrieve the next oggpage from the data with the ogg_sync_state

@param  aPage
        The oggpage that is fetched

@return Any of the system wide error codes. Returns KErrNotFound if it cannot form the oggpage
*/
TInt COggPager::CBody::NextPage(TOggPage& aPage)
    {
    ogg_page page;
    memset(&page, 0, sizeof(page));
    while (ETrue)
        {
        TInt len = ogg_sync_pageseek(iSyncState, &page);
        if (len<0) // skipped -len bytes for next possible page start
            {
            RDebug::Printf("missing or corrupt data at this page position...continue\n");
            // go round again
            }
        else if (len==0)
            {
            return KErrNotFound; // need more data!
            }
        else
            { // len>0 --> found a page of length len bytes
            // copy from page to aPage
            OggUtil::MakeOggPage(page, aPage);
            return KErrNone;
            }
        }
    }
