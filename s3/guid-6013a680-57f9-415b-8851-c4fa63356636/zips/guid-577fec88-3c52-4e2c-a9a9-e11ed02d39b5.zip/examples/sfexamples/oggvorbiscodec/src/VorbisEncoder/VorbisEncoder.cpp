// VorbisEncoder.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//

#include <e32base.h>
#include <e32debug.h>
#include <e32math.h>
#include "VorbisEncoder.h"

const TInt KDefaultBitRate = 64000;
const TInt KDefaultQuality = 0.0;

//--------------------------------------------------------------------
//----------------------------- Encoder ------------------------------
//--------------------------------------------------------------------

 CVorbisEncoder* CVorbisEncoder::NewL()
    {
    CVorbisEncoder* self = new(ELeave)CVorbisEncoder;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }
    
CVorbisEncoder::CVorbisEncoder(): iState(ENotReady), iBitRate(KDefaultBitRate), iQuality(KDefaultQuality)
    {
    }

void CVorbisEncoder::ConstructL()
    {
    vorbis_info_init(&iInfo);
    ogg_stream_init(&iStream,10);
    }

CVorbisEncoder::~CVorbisEncoder()
    {
	if (iState != ENotReady)
        {
        vorbis_block_clear(&iBlock);
        vorbis_dsp_clear(&iDspState);
        }
    ogg_stream_clear(&iStream);
    vorbis_comment_clear(&iComment);
    vorbis_info_clear(&iInfo);
    }

/**
This method takes raw data as an input and puts into the vorbis analysis buffer which is owned 
by the libvorbis. It also updates libvorbis with how many bytes of PCM is written into the buffer.

@param  aBuf
        The Source buffer with PCM data
*/
void CVorbisEncoder::PcmInL(const CMMFDataBuffer& aBuf)
    {
    TPtrC8 data = aBuf.Data();
    TInt bytes = data.Length();
    TInt ret = KErrNone;
    if (iState == ENotReady)
    	{
    	User::Leave(KErrNotReady);
    	}
    
    iLastBuffer = aBuf.LastBuffer();
    
    if(bytes==0)
    	{
      	ret = vorbis_analysis_wrote(&iDspState,0);
        DEBUG1("Called vorbis_analysis_wrote zero bytes = %d",bytes);
        if (ret != KErrNone)
        	{
        	User::Leave(TranslateOggVorbisError(ret));
        	}
        }
    else
    	{
    	TReal32** buffer;
    	TInt bytesPerSample = 2*iInfo.channels; // 16-bit assumed (most likely 2 channels)
    	TInt bufSamples = bytes/bytesPerSample;
    	buffer = vorbis_analysis_buffer(&iDspState,bufSamples);
    	TInt i = 0;
    	if(iInfo.channels == 1)
    		{
    		for(i = 0 ; i < bufSamples ; i++)
    			{
    			buffer[0][i]=((static_cast<TInt8>(data[i*2+1])<<8)|(0x00ff&static_cast<TInt16>(data[i*2])))/32768.f;
    			}
	    	}
    	else
    		{
    		for(i=0;i<bufSamples;i++)
    			{
    			//16 bits either side of the | 
    			buffer[0][i]=((static_cast<TInt8>(data[i*4+1])<<8)|(0x00ff&static_cast<TInt16>(data[i*4])))/32768.f;
				buffer[1][i]=((static_cast<TInt8>(data[i*4+3])<<8)|(0x00ff&static_cast<TInt16>(data[i*4+2])))/32768.f;
    			}	
    	}

    	ret = vorbis_analysis_wrote(&iDspState,i);
    	if (ret != KErrNone)
        	{
        	User::Leave(TranslateOggVorbisError(ret));
        	}
    	DEBUG1("Called vorbis_analysis_wrote with vals = %d",i);
      	}
     }

/**
This method tries to frame an oggpage out of the pcm data in the vorbis analysis buffer and writes it into
the destination buffer aDst..
	
@param  aDst
        The buffer in which the oggpage is to be placed.

@return The length of the encoded data written into aDst.

*/
TInt CVorbisEncoder::PageOutL(CMMFDataBuffer& aDst)
    {
    TDes8* dst = &aDst.Data();
    dst->SetLength(0);
    ogg_packet  op; // one raw packet of data to output 
    ogg_page og;
    TInt pageCount = 0;
    if(iState == EInitialized)
    	{
    	while(ogg_stream_flush(&iStream,&og))
			{
			dst->Append(og.header, og.header_len);
			dst->Append(og.body, og.body_len);
			DEBUG1("HeaderPageLength %d",og.header_len + og.body_len);
			iState = EReady;
			}
    	}
    DEBUG("about to call vorbis_analysis_blockout");
	if(iLastBuffer)
		{
		while (vorbis_analysis_blockout(&iDspState,&iBlock) == 1)
			{
			vorbis_analysis(&iBlock,NULL);
			vorbis_bitrate_addblock(&iBlock);

			while (vorbis_bitrate_flushpacket(&iDspState,&op))
				{
				ogg_stream_packetin(&iStream,&op);
				}
			}
		while(ogg_stream_flush(&iStream,&og))
    		{
    		dst->Append(og.header, og.header_len);
    		dst->Append(og.body, og.body_len);
    		DEBUG("Last Buffer flag is set");
    		DEBUG1("PageLength %d",og.header_len + og.body_len);
    		DEBUG1("PageCount %d",++iPageCount);
    		}
		aDst.SetLastBuffer(ETrue);
    	}
	else 
		{
		while (vorbis_analysis_blockout(&iDspState,&iBlock) == 1)
			{
			// got a block of vorbis data, analyse it
			DEBUG("called vorbis_analysis_blockout with return of 1");
			vorbis_analysis(&iBlock,NULL);
			vorbis_bitrate_addblock(&iBlock);
			DEBUG1("called  packet vorbis_bitrate_flushpacket",(*dst).Length());
			while (vorbis_bitrate_flushpacket(&iDspState,&op))
				{
				ogg_stream_packetin(&iStream,&op);
				DEBUG1("CVorbisEncoder::PacketOut packet of length %d added to cache",op.bytes);
				while(ogg_stream_pageout(&iStream, &og))
					{
					dst->Append(og.header, og.header_len);
					dst->Append(og.body, og.body_len);
				
					DEBUG1("PageLength %d",og.header_len + og.body_len);
					DEBUG1("PageCount %d",++iPageCount);
					pageCount++;
					if(ogg_page_eos(&og))
						{
						aDst.SetLastBuffer(ETrue);
						DEBUG1("LastPageLength %d",og.header_len + og.body_len);
						return dst->Length();
						}
					}
				}
			}
		}
	return dst->Length();
    }

/**
This method generates the header packets for vorbis data.
*/    
void CVorbisEncoder::PrepareHeadersL()
	{
	ogg_packet op1,op2,op3;
	TInt ret = KErrNone;
	ret = vorbis_analysis_headerout(&iDspState,&iComment,&op1,&op2,&op3);
	if (ret != KErrNone)
		{
		User::Leave(TranslateOggVorbisError(ret));	
		}
	ogg_stream_packetin(&iStream,&op1);
	ogg_stream_packetin(&iStream,&op2);	
	ogg_stream_packetin(&iStream,&op3);
	}

void CVorbisEncoder::Reset()
    {
    if (iState==EReady)
        {
        vorbis_block_clear(&iBlock);
        vorbis_dsp_clear(&iDspState);
        }
    vorbis_comment_clear(&iComment);
    vorbis_info_clear(&iInfo);
    vorbis_info_init(&iInfo);
    vorbis_comment_init(&iComment);
    iLastBuffer = EFalse;
    iState = ENotReady;
    }

TInt CVorbisEncoder::BitRateL()
	{
	return iBitRate;
	}
	
void CVorbisEncoder::SetBitRateL(TInt aBitRate)
	{
	if (aBitRate < KOggVorbisMinBitrate)
		{
		aBitRate = KOggVorbisMinBitrate;
		}
	iBitRate = aBitRate;
	ConvertBitRateToQuality(iBitRate, iQuality);
	}
/**
This method initializes the vorbis stream depending on the configuration set on the encoder and prepares
the header packets using PrepareHeadersL().

@return Any Systemwide error code.
*/ 
void CVorbisEncoder::InitializeVorbisStreamL()
	{
	TInt ret = KErrNone;
	ret = vorbis_encode_init_vbr(&iInfo,iChannels,iSampleRate,iQuality);
	if(ret == KErrNone)
   		{
   		vorbis_comment_init(&iComment);
   		//Custom interface could allow user to set up iComments in future
    	vorbis_comment_add_tag(&iComment,"ENCODER","Reference Vorbis Encoder");
   		vorbis_analysis_init(&iDspState,&iInfo);	
   		vorbis_block_init(&iDspState,&iBlock);
		PrepareHeadersL();
		iState = EInitialized;	
		}
	if(ret)
		{
		User::Leave(TranslateOggVorbisError(ret));	
		}
	}
/**
This method sets the samplerate and channels on the encoder and initializes the vorbis stream.

@return Any Systemwide error code.
*/ 	
void CVorbisEncoder::ConfigureL(TInt aSampleRate, TInt aChannels)
	{
	iSampleRate = aSampleRate;
	iChannels = aChannels;
	InitializeVorbisStreamL();
	}
	
TInt CVorbisEncoder::TranslateOggVorbisError(TInt aError)
	{
	//reference libvorbis\doc\vorbis-errors.txt
	switch (aError)
		{
		case OV_EIMPL:
			return KErrNotSupported;
		case OV_EINVAL:
			return KErrArgument;
		default:
    		return KErrUnknown;
		}	
	}

/**
This method selects the quality corresponding to the bitrate.
	
@param  aBitRate
        The Bitrate(input)
@param  aQuality(output)
        The quality corresponding to the aBitRate
*/
void CVorbisEncoder::ConvertBitRateToQuality(TInt aBitRate, TReal32& aQuality)
	{
	switch (aBitRate)
		{
		case KVorbisQuality0:
			aQuality = 0.0;
			break;
		case KVorbisQuality1:
			aQuality = 0.1;
			break;
		case KVorbisQuality2:
			aQuality = 0.2;
			break;
		case KVorbisQuality3:
			aQuality = 0.3;
			break;
		case KVorbisQuality4:
			aQuality = 0.4;
			break;
		case KVorbisQuality5:
			aQuality = 0.5;
			break;
		case KVorbisQuality6:
			aQuality = 0.6;
			break;
		case KVorbisQuality7:
			aQuality = 0.7;
			break;
		case KVorbisQuality8:
			aQuality = 0.8;
			break;
		case KVorbisQuality9:
			aQuality = 0.9;
			break;
		case KVorbisQuality10:
			aQuality = 1.0;
			break;	
		default:
    		aQuality = -0.1;
    		break;
		}	
	}
//--------------------------------------------------------------------
//---------------------------- Processor -----------------------------
//--------------------------------------------------------------------

CVorbisProcessor* CVorbisProcessor::NewL()
    {
    CVorbisProcessor* self = new(ELeave)CVorbisProcessor;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

CVorbisProcessor::CVorbisProcessor()
    {
    }

void CVorbisProcessor::ConstructL()
    {
#ifdef SYMBIAN_SEP_HEAP    
    User::LeaveIfError(iVorbisChunk.CreateLocal(KInitialChunkSize, KMaxChunkSize, EOwnerThread));
    iVorbisHeap = User::ChunkHeap(iVorbisChunk, KMinHeapLength);
    iDefaultHeap = &User::Heap();
#endif
    VORBIS_TRAPD(leaveErr, iEncoder = CVorbisEncoder::NewL());
    User::LeaveIfError(leaveErr);
    }
    
CVorbisProcessor::~CVorbisProcessor()
    {
#ifdef SYMBIAN_SEP_HEAP
	if(iVorbisHeap)
		{
		User::SwitchHeap(iVorbisHeap);
		}
#endif
    delete iEncoder;
#ifdef SYMBIAN_SEP_HEAP
    if(iVorbisHeap)
    	{
    	iVorbisChunk.Close();
    	User::SwitchHeap(iDefaultHeap);
    	}
#endif
    }

void CVorbisProcessor::ProcessL(const CMMFBuffer& aSource,
                                CMMFBuffer& aDst,
                                TProcessResult& aRes,
                                TUint& aSourceUsed,
                                TUint& aDestWritten)
    {
    // check that buffers are instances of CMMFDataBuffer
    if (!CMMFBuffer::IsSupportedDataBuffer(aSource.Type())) 
    	{
    	User::Leave(KErrNotSupported);
    	}
    if (!CMMFBuffer::IsSupportedDataBuffer(aDst.Type())) 
    	{
    	User::Leave(KErrNotSupported);
    	}
	const CMMFDataBuffer& src = static_cast<const CMMFDataBuffer&>(aSource);
    CMMFDataBuffer& dstBuf = static_cast<CMMFDataBuffer&>(aDst);
    VORBIS_TRAPD(leaveErr, iEncoder->PcmInL(src));
    User::LeaveIfError(leaveErr);
    VORBIS_TRAP(leaveErr, iEncoder->PageOutL(dstBuf));
    User::LeaveIfError(leaveErr);
    aDestWritten = dstBuf.Data().Length();
    aSourceUsed = src.Data().Length();
    aRes = ( aDestWritten > 0 ? EComplete : EDestNotFilled);
    }
    
TInt CVorbisProcessor::BitRateL()
	{
	return iEncoder->BitRateL();
	}
	
void CVorbisProcessor::SetBitRateL(TInt aBitRate)
	{
	iEncoder->SetBitRateL(aBitRate);
	}

void CVorbisProcessor::ConfigureL(TInt aSampleRate, TInt aChannels)
	{
	VORBIS_TRAPD(leaveErr, iEncoder->ConfigureL(aSampleRate, aChannels));
	User::LeaveIfError(leaveErr);
	}
