
extern "C"
{

int s_main();

}


int E32Main()
    {
    return s_main();
    }