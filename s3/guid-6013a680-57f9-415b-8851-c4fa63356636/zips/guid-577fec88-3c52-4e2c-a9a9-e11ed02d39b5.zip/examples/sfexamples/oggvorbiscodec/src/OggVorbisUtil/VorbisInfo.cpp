// VorbisInfo.cpp
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//


#include <e32base.h>

#include <oggutil.h>
#include "OggUtilBody.h"
#include <vorbisinfo.h>
#include "VorbisBody.h"

#ifdef SYMBIAN_CODEC_FLOAT_POINT
#include "vorbis/codec.h"
#include "vorbis/vorbisenc.h"
#else
#include "tremor/ivorbiscodec.h"
#endif

//-------------------------- CVorbisInfo --------------------------

EXPORT_C CVorbisInfo* CVorbisInfo::NewL()
    {
    CVorbisInfo* self = new(ELeave)CVorbisInfo;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

CVorbisInfo::CVorbisInfo()
    {
    }

void CVorbisInfo::ConstructL()
    {
    iBody = new(ELeave)CBody;
    iBody->Construct3L();
    }

CVorbisInfo::~CVorbisInfo()
    {
    delete iBody;
    }

EXPORT_C void CVorbisInfo::InitializeL(const TOggPacket& aPckt1,
                                       const TOggPacket& aPckt2,
                                       const TOggPacket& aPckt3)
    {
    iBody->InitializeL(aPckt1);
    iBody->InitializeL(aPckt2);
    iBody->InitializeL(aPckt3);
    }

EXPORT_C void CVorbisInfo::InitializeL(const TOggPacket& aNextPacket)
    {
    iBody->InitializeL(aNextPacket);
    }

EXPORT_C void CVorbisInfo::InitializeL(TUint aSampleRate, TUint aBitRate, TUint aNumChannels)
    {
    return iBody->InitializeL(aSampleRate, aBitRate, aNumChannels);
    }
    
EXPORT_C TInt CVorbisInfo::SampleRate()
    {
    return iBody->SampleRate();
    }

EXPORT_C TInt CVorbisInfo::Channels()
    {
    return iBody->Channels();
    }

EXPORT_C TDesC& CVorbisInfo::Vendor()
    {
    return iBody->Vendor();
    }

EXPORT_C TInt CVorbisInfo::Comments()
    {
    return iBody->Comments();
    }

EXPORT_C CVorbisComment& CVorbisInfo::GetComment(TInt aIndex)
    {
    return iBody->GetComment(aIndex);
    }

EXPORT_C TInt CVorbisInfo::BitRateNominal()
    {
    return iBody->BitRateNominal();
    }

EXPORT_C TInt CVorbisInfo::BitRateUpper()
    {
    return iBody->BitRateUpper();
    }

EXPORT_C TInt CVorbisInfo::BitRateLower()
    {
    return iBody->BitRateLower();
    }

EXPORT_C void CVorbisInfo::SetSampleRate(TUint aSampleRate)
    {
    iBody->SetSampleRate(aSampleRate);
    }
EXPORT_C void CVorbisInfo::SetChannels(TUint aChannels)
    {
    iBody->SetChannels(aChannels);
    }
EXPORT_C void CVorbisInfo::SetBitRate(TUint aBitRate)
    {
    iBody->SetBitRate(aBitRate);
    }

//---------------------- CVorbisInfo::CBody -----------------------

CVorbisInfo::CBody::CBody()
    : iPcktsRcvd(0)
    {
    }

CVorbisInfo::CBody::~CBody()
    {
    #ifdef SYMBIAN_CODEC_FLOAT_POINT
    vorbis_block_clear(&iBlock);
  	vorbis_dsp_clear(&iDspState);
    #endif
    vorbis_comment_clear(&iComment);
    vorbis_info_clear(&iInfo);

    for (TInt i=0; i<iComments->Count(); ++i)
    	{
    	delete (*iComments)[i];	
    	}
    delete iComments;
    delete iVendor;
    }

void CVorbisInfo::CBody::Construct3L()
    {
    vorbis_comment_init(&iComment);
    vorbis_info_init(&iInfo);

    iComments = new(ELeave)CArrayPtrFlat<CVorbisComment>(1);
    }

void CVorbisInfo::CBody::InitializeL(const TOggPacket& aNextPacket)
    {
    if (iPcktsRcvd==KPcktsRqrd) 
    	{
    	User::Leave(KErrAlreadyExists);	
    	}
    ogg_packet packet;
    OggUtil::Make_ogg_packet(aNextPacket, packet);
    TInt err = vorbis_synthesis_headerin(&iInfo, &iComment, &packet);
    
    if (err != KErrNone)
        {
        User::Leave(TranslateOggVorbisError(err));
        }
    ++iPcktsRcvd;
    if (iPcktsRcvd==KPcktsRqrd) 
    	{
    	ConvertCommentDataL();	
    	}
    }

void CVorbisInfo::CBody::InitializeL(TUint aSampleRate, TUint aBitRate, TUint aNumChannels)
    {
    iInfo.rate = aSampleRate;
    iInfo.bitrate_nominal = aBitRate;
    iInfo.channels = aNumChannels;
    }
    
void CVorbisInfo::CBody::ConvertCommentDataL()
    {
    iComments->SetReserveL(iComment.comments);
    for (TInt i=0; i<iComment.comments; ++i)
        {
        iComments->ExtendL() =
          CVorbisComment::NewL(iComment.user_comments[i],
                               iComment.comment_lengths[i]);
        }

    // convert vendor to a descriptor...
    // work out how long it is
    TInt length = 0;
    while (iComment.vendor[length]) 
    	{
    	++length;	
    	}
    // allocate space
    iVendor = HBufC::NewL(length);
    TPtr ven = iVendor->Des();
    ven.SetLength(length);
    // copy and convert to 16-bit
    for (TInt i=0; i<length; ++i) 
    	{
    	ven[i]=iComment.vendor[i];	
    	}
    }


TInt CVorbisInfo::CBody::SampleRate()
    {
    return iInfo.rate;
    }

TInt CVorbisInfo::CBody::Channels()
    {
    return iInfo.channels;
    }

TDesC& CVorbisInfo::CBody::Vendor()
    {
    return *iVendor;
    }

TInt CVorbisInfo::CBody::Comments()
    {
    return iComments->Count();
    }

CVorbisComment& CVorbisInfo::CBody::GetComment(TInt aIndex)
    {
    return *(iComments->At(aIndex));
    }

TInt CVorbisInfo::CBody::BitRateNominal()
    {
    return iInfo.bitrate_nominal;
    }

TInt CVorbisInfo::CBody::BitRateUpper()
    {
    return iInfo.bitrate_upper;
    }

TInt CVorbisInfo::CBody::BitRateLower()
    {
    return iInfo.bitrate_lower;
    }

/*
 This translates the errors returned by the ogglibaries into the Symbian errors
 */
TInt CVorbisInfo::CBody::TranslateOggVorbisError(TInt aError)
	{
	//reference libvorbis\doc\vorbis-errors.txt
	switch (aError)
		{
		case OV_EIMPL:
			return KErrNotSupported;
		case OV_EINVAL:
			return KErrArgument;
		default:
    		return KErrUnknown;
		}	
	}

void CVorbisInfo::CBody::SetSampleRate(TUint aSampleRate)
    {
    iInfo.rate = aSampleRate;
    }
void CVorbisInfo::CBody::SetChannels(TUint aNumChannels)
    {
    iInfo.channels = aNumChannels;
    }
void CVorbisInfo::CBody::SetBitRate(TUint aBitRate)
    {
    iInfo.bitrate_nominal = aBitRate;
    }

//------------------------ CVorbisComment -------------------------

CVorbisComment* CVorbisComment::NewL(TDesC& aName, TDesC& aValue)
    {
    CVorbisComment* self = new(ELeave)CVorbisComment;
    CleanupStack::PushL(self);
    self->ConstructL(aName, aValue);
    CleanupStack::Pop(self);
    return self;
    }

CVorbisComment* CVorbisComment::NewL(char* aComment, int aLength)
    {
    CVorbisComment* self = new(ELeave)CVorbisComment;
    CleanupStack::PushL(self);
    self->ConstructL(aComment, aLength);
    CleanupStack::Pop(self);
    return self;
    }

CVorbisComment::CVorbisComment()
    {
    }

CVorbisComment::~CVorbisComment()
    {
    delete iName;
    delete iValue;
    }

void CVorbisComment::ConstructL(TDesC& aName, TDesC& aValue)
    {
    iName = aName.AllocL();
    iValue = aValue.AllocL();
    }

void CVorbisComment::ConstructL(char* aComment, int aLength)
    {
    // find the '='
    TInt eqPos = -1;
    TInt sp = 0;
    while ((eqPos<0)&&(sp<aLength))
        {
        if (aComment[sp]=='=') eqPos=sp;
        ++sp;
        }
    if (eqPos<0) 
    	{
    	//comments are in wrong format. So leave with KErrCorrupt
    	User::Leave(KErrCorrupt);	
    	}
    // allocate memory
    iName = HBufC::NewL(eqPos);
    iValue = HBufC::NewL(aLength-eqPos-1);

    TPtr name = iName->Des();
    TPtr val = iValue->Des();

    // copy data, converting from 8 to 16 bit
    name.SetLength(eqPos);
    for (TInt i=0; i<eqPos; ++i)
        {
        name[i]=aComment[i];
        }

    val.SetLength(aLength-eqPos-1);
    for (TInt i=0; i<val.Length(); ++i)
        {
        val[i]=aComment[i+eqPos+1];
        }
    }

EXPORT_C TDesC& CVorbisComment::Name()
    {
    return *iName;
    }

EXPORT_C TDesC& CVorbisComment::Value()
    {
    return *iValue;
    }
