// OmxVorbisEncoderComponent.cpp
//
// Copyright (c) Symbian Software Ltd 2008.  All rights reserved.
//

#include <ecom/implementationproxy.h>
#include <omxilsymbiancomponentif.h>

#include "OmxVorbisEncoder.hrh"

OMXIL_COMPONENT_ECOM_ENTRYPOINT(KUidOmxVorbisEncoder);




