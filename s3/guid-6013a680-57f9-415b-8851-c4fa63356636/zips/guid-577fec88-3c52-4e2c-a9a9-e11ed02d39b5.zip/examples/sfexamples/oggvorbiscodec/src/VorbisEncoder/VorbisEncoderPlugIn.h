// VorbisEncoderPlugIn.h
//
// Copyright (c) Symbian Software Ltd 2005-2008.  All rights reserved.
//


#ifndef VORBISENCODERPLUGIN_H
#define VORBISENCODERPLUGIN_H

// for the bitrate custom interface
#include <mmf/server/devsoundstandardcustominterfaces.h>

//This class is responsible for taking the input buffer and producing an encoded
//Output buffer
class CVorbisEncoderPlugIn : public CMMFSwCodec
    {
public:
    static CVorbisEncoderPlugIn* NewL();
    virtual ~CVorbisEncoderPlugIn();
    //from CMMFSwCodec
    virtual TCodecProcessResult ProcessL
            (const CMMFBuffer& aSource, CMMFBuffer& aDest);
	virtual TUint SourceBufferSize();
    virtual TUint SinkBufferSize();
    TInt Configure(TInt aSampleRate, TInt aChannels);
    // required functions for bit rate management    
    void GetSupportedBitRatesL(RArray<TInt>& aSupportedBitRates);
    TInt BitRateL();
    void SetBitRateL(TInt aBitRate);
private:
    CVorbisEncoderPlugIn();
    void ConstructL();
private:
    CVorbisProcessor* iProc;
    };

//This is a framework class which creates the Codec class above and supports the bitrate
//custom interface
class CVorbisEncoderPlugInWrapper : public CMMFSwCodecWrapper, public MMMFDevSoundCustomInterfaceBitRate
    {
public:
    static CVorbisEncoderPlugInWrapper* NewL();
    virtual ~CVorbisEncoderPlugInWrapper();
    //from CMMFSwCodecWrapper
    TInt Start(TDeviceFunc aFuncCmd, TDeviceFlow aFlowCmd);
    TInt SetConfig(TTaskConfig& aConfig);
    //from CMMFSwCodecWrapper
    CMMFSwCodec& Codec();
    // from CMMFHwDevice
    TAny* CustomInterface(TUid aInterfaceId);
    //from MMMFDevSoundCustomInterfaceBitRate
    void GetSupportedBitRatesL(RArray<TInt>& aSupportedBitRates);
    TInt BitRateL();
    void SetBitRateL(TInt aBitRate);
private:
    CVorbisEncoderPlugInWrapper();
    void ConstructL();
private:
    CVorbisEncoderPlugIn* iDevice;
    TBool iCodecReturned; //flag recording if ownership of codec has been transeferred to client
    };

#endif //VORBISENCODERPLUGIN_H
