// OggPackets.cpp
//
// Copyright � Symbian Software Ltd 2005 - 2008.  All rights reserved.
//


#include <e32base.h>
#include <e32debug.h>
#include <oggutil.h>
#include "OggUtilBody.h"

//-------------------------- COggStream --------------------------

EXPORT_C COggStream* COggStream::NewL()
    {
    COggStream* self = new(ELeave)COggStream;
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop(self);
    return self;
    }

COggStream::COggStream()
    {
    }

COggStream::~COggStream()
    {
    delete iBody;
    }

void COggStream::ConstructL()
    {
    iBody = new(ELeave) COggStream::CBody;
    iBody->ConstructL();
    }

EXPORT_C TInt COggStream::PageIn(TOggPage& aPage)
    {
    return iBody->PageIn(aPage);
    }

EXPORT_C TInt COggStream::PacketOut(TOggPacket& aDst)
    {
    return iBody->PacketOut(aDst);
    }

EXPORT_C void COggStream::Reset()
    {
    iBody->Reset();
    }

EXPORT_C TInt COggStream::GetSerialNo()
    {
    return iBody->GetSerialNo();
    }

//---------------------- COggStream::CBody -----------------------


COggStream::CBody::CBody()
    : iStreamLocked(EFalse)
    {
    }

void COggStream::CBody::ConstructL()
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	iStreamState = &iOggStreamState;
	//during recording we give a random serial number to the stream.
	const TInt KStreamSerialNumber = 10;
	ogg_stream_init(iStreamState, KStreamSerialNumber);
#else
	//stream with negative serial indicates it is not initialized. We do this during playing because we 
	//get the serial number from the clip.
	iStreamState = ogg_stream_create(-1);
#endif

    }

COggStream::CBody::~CBody()
    {
#ifdef SYMBIAN_CODEC_FLOAT_POINT
	ogg_stream_clear(&iOggStreamState);
#else
	ogg_packet_release(&iPacket);
    ogg_page_release(&iPage);
    ogg_stream_destroy(iStreamState);
#endif
    }

/**
This method submits an oggpage into the oggstream(decoding).

@param  aPage
        The oggpage that is to be placed into the stream.

@return Any of the system wide error codes.
*/
TInt COggStream::CBody::PageIn(TOggPage& aPage)
    {
    OggUtil::Make_ogg_page(aPage, iPage); // get an ogg_page from the TOggPage
    if (!iStreamLocked)
        {
        ogg_stream_reset_serialno
            (iStreamState, ogg_page_serialno(&iPage));
        iStreamLocked=ETrue;
        }
     if (ogg_page_serialno(&iPage)==iStreamState->serialno)
        {
        ogg_stream_pagein(iStreamState, &iPage);
        return KErrNone;
        }
     else 
     	{
     	return KErrArgument;// this page does not belong to our stream
     	}
    }

/**
This method tries an form an oggpacket from the data in the oggstream(Decoding). 

@param  aPacket
        The oggpacket that is fetched

@return Any of the system wide error codes. Returns KErrNotFound if cannot form an oggpacket
*/
TInt COggStream::CBody::PacketOut(TOggPacket& aPacket)
    {
    while (ETrue)
        {
        TInt res = ogg_stream_packetout(iStreamState, &iPacket);
        if (res<0) // out of sync/gap in data
            {
            //Usually this will not be a fatal error so continue. This happens during seeking
            RDebug::Printf("out of sync and there is a gap in the data...continue\n");
            //resync
            }
        else if (res==0) // need more data
            {
            return KErrNotFound;
            }
        else // have a packet
            {
            OggUtil::MakeOggPacket(iPacket, aPacket);
            return KErrNone;
            }
        }
    }

void COggStream::CBody::Reset()
    {
    ogg_stream_reset(iStreamState);
    }

TInt COggStream::CBody::GetSerialNo()
    {
    return iStreamState->serialno;
    }
