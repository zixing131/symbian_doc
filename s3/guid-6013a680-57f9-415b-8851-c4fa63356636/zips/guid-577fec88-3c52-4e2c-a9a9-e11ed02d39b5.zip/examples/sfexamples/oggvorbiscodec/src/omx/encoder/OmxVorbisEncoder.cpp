// OmxVorbisEncoder.cpp
//
// Copyright (c) 2006 Symbian Software Ltd. All rights reserved.
//

/**
@file
@internalComponent
*/

#include <e32debug.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <OMX_Core.h>
#include <OMX_Audio.h>

#include "OmxImpl.h"
#include "OmxVorbisEncoder.h"
#include "VorbisEncoder.h"

const TInt KIndexInputPort = 0;
const TInt KIndexOutputPort = 1;
// Vorbis encoder requires 4k input and 8k output buffer
const TInt KVorbisEncoderInputBufferSize 	= 0x1000;
const TInt KVorbisEncoderOutputBufferSize 	= 0x2000;

const TInt KThreadStackSize = 16384; 

const TInt KDefaultInputSampleRate = 44100;
const TInt KDefaultInputChannels = 2;
const TInt KDefaultInputBitsPerSample = 16;
const OMX_NUMERICALDATATYPE KDefaultInputDataType = OMX_NumericalDataSigned;
const TInt KDefaultOutputBitRate = 128000;

_LIT(KVorbisEncoder, "VorbisEncoder");
							
TInt ProcessingThread(TAny* aComponent)
	{
	// get our class
	CCodecProcessor* codecprocessor = static_cast<CCodecProcessor*>(aComponent);

	// run the thread
	TRAPD(err, codecprocessor->RunThreadL());
	// thread has exited or failed to start so return error to the client. 
	return err;
	}

TInt COmxVorbisEncoder::CreateComponent(OMX_HANDLETYPE hComponent)
	{
	COmxVorbisEncoder* self = new COmxVorbisEncoder(hComponent);
	if (self==NULL)
		return KErrNoMemory;
	TRAPD(err, self->ConstructL());
	return err;
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::GetComponentVersion(
       OMX_STRING /*pComponentName*/,
       OMX_VERSIONTYPE* /*pComponentVersion*/,
       OMX_VERSIONTYPE* /*pSpecVersion*/,
       OMX_UUIDTYPE* /*pComponentUUID*/)
	{
// to be implemented
	return OMX_ErrorNone;
	}
	
void COmxVorbisEncoder::ConstructL()
	{
	iCodecProcessor = CCodecProcessor::NewL(*this);	
	iState = OMX_StateLoaded;
	}

COmxVorbisEncoder::COmxVorbisEncoder(OMX_HANDLETYPE hComponent)
	:COmxComponentImpl(hComponent)
	{
	}
	
COmxVorbisEncoder::~COmxVorbisEncoder()
	{
	if (iState == OMX_StateExecuting)
		{
		iCodecProcessor->Stop();
		iState = OMX_StateIdle;
		}

	if (iCreatedThread)
		{
		iProcessingThread.Kill(KErrNone);
		iProcessingThread.Close();
		}
	delete iCodecProcessor;
	}

OMX_ERRORTYPE COmxVorbisEncoder::SendCommand(
       OMX_COMMANDTYPE Cmd,
       TUint32 nParam1,
       TAny* /*pCmdData*/)
	{
	OMX_ERRORTYPE error = OMX_ErrorNone;
	switch (Cmd)
		{
	case OMX_CommandStateSet:
		OMX_STATETYPE state = (OMX_STATETYPE)nParam1;
		if (state == iState)
			{
			error = OMX_ErrorSameState;
			}
		else
			{
			// notify client of the state change
			switch (state)
				{
			case OMX_StateIdle:
				{
				if (iState == OMX_StateExecuting)
					{
					iCodecProcessor->Stop();
					}
				break;
				}
			case OMX_StateExecuting:
				StartExecution();
				break;
				};
	
			iState = state;
			
			EventHandlerCallback(
				OMX_EventCmdComplete,
				OMX_CommandStateSet,
				iState,
				NULL);	
			break;
			}
		};	
	return error;
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::GetParameter(
       OMX_INDEXTYPE nParamIndex,  
       TAny* ComponentParameterStructure)
	{
	switch (nParamIndex)
		{
	case OMX_IndexParamAudioInit :
		{
		OMX_PORT_PARAM_TYPE* param = static_cast<OMX_PORT_PARAM_TYPE*>(ComponentParameterStructure);
		param->nPorts = 2;
		}
		break;
	case OMX_IndexParamPortDefinition:
		{
		OMX_PARAM_PORTDEFINITIONTYPE* portDef = static_cast<OMX_PARAM_PORTDEFINITIONTYPE*>(ComponentParameterStructure);
		if (portDef->nPortIndex==0)	
			{
			portDef->eDir = OMX_DirInput;	
			portDef->nBufferSize = KVorbisEncoderInputBufferSize;
			}
		else
			{
			portDef->eDir = OMX_DirOutput;
			portDef->nBufferSize = KVorbisEncoderOutputBufferSize;
			}
		}
		break;
	case OMX_IndexParamAudioVorbis:
		{
		// to get the bitrate
		OMX_AUDIO_PARAM_VORBISTYPE* param = static_cast<OMX_AUDIO_PARAM_VORBISTYPE*>(ComponentParameterStructure);
		param->nBitRate = iCodecProcessor->OutputBitRate();
		}
		break;
	default:
		return OMX_ErrorUnsupportedIndex;
		}
	return OMX_ErrorNone;
	}

OMX_ERRORTYPE COmxVorbisEncoder::SetParameter(
       OMX_INDEXTYPE nIndex,
       TAny* ComponentParameterStructure)
	{
	ASSERT(iState == OMX_StateLoaded);
	switch (nIndex)
		{
		case OMX_IndexParamAudioPcm:
			{
			OMX_AUDIO_PARAM_PCMMODETYPE* param = static_cast<OMX_AUDIO_PARAM_PCMMODETYPE*>(ComponentParameterStructure);
			switch(param->nPortIndex)
				{
				case 0: // Input port = PCM
					{
					iCodecProcessor->SetInputSampleRate(param->nSamplingRate);
					iCodecProcessor->SetInputChannels(param->nChannels);
					iCodecProcessor->SetInputBitsPerSample(param->nBitPerSample);
					iCodecProcessor->SetInputDataType(param->eNumData);
					
					// in order to configure the vorbis encoder we must do this -
					// the encoder will then set up its ogg headers
					iCodecProcessor->ConfigureInput();
					
					return OMX_ErrorNone;
					}			
				case 1: // Output port
				default:
					{
					return OMX_ErrorUnsupportedIndex;	
					}
				};
			}
		case OMX_IndexParamAudioVorbis:
			{
			OMX_AUDIO_PARAM_VORBISTYPE* param = static_cast<OMX_AUDIO_PARAM_VORBISTYPE*>(ComponentParameterStructure);
			switch(param->nPortIndex)
				{
				case 1: // Output port = Vorbis
					{
					// this will setthe bit rate into the encoder itself
					iCodecProcessor->SetOutputBitRate(param->nBitRate);
					return OMX_ErrorNone;
					}
				case 0: // Input port
				default:
					{
					return OMX_ErrorUnsupportedIndex;	
					}
				};
			}
		default:
			{
			return OMX_ErrorUnsupportedIndex;
			}
		};		
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::GetConfig(
       OMX_INDEXTYPE /*nIndex*/, 
       TAny* /*value*/)
	{
	return OMX_ErrorUnsupportedIndex;
	}

OMX_ERRORTYPE COmxVorbisEncoder::SetConfig(
       OMX_INDEXTYPE /*nIndex*/, 
       TAny* /*value*/)
	{
	return OMX_ErrorUnsupportedIndex;
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::GetExtensionIndex(
       OMX_STRING /*ParameterName*/,
       OMX_INDEXTYPE* /*pIndexType*/)
	{
	return OMX_ErrorNotImplemented;
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::GetState(
       OMX_STATETYPE* pState)
	{
	*pState = iState;
	return OMX_ErrorNone;
	}
	
// To be implemented for DM4
OMX_ERRORTYPE COmxVorbisEncoder::ComponentTunnelRequest(
		OMX_HANDLETYPE /*hInput*/,
		TUint32 /*nInputPort*/,
		OMX_HANDLETYPE /*hOutput*/,
		TUint32 /*nOutputPort*/,
		OMX_TUNNELSETUPTYPE* /*pTunnelSetup*/)
	{
	return OMX_ErrorNotImplemented;
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::UseBuffer(
       OMX_BUFFERHEADERTYPE** ppBufferHeader,
       TUint32 nPortIndex,
       TAny* pAppPrivate,
       TUint32 nSizeBytes,
       TUint8* pBuffer)
	{
	ASSERT(iState == OMX_StateLoaded);
	*ppBufferHeader = new OMX_BUFFERHEADERTYPE;
	if (*ppBufferHeader != NULL)
		{
		(*ppBufferHeader)->pBuffer = pBuffer;
		(*ppBufferHeader)->pAppPrivate = pAppPrivate;
		(*ppBufferHeader)->nAllocLen = nSizeBytes;
		(*ppBufferHeader)->nFilledLen = 0;
		(*ppBufferHeader)->nFlags = 0;
		(*ppBufferHeader)->pInputPortPrivate = NULL;
		(*ppBufferHeader)->pOutputPortPrivate = NULL;
		}
		
	if (*ppBufferHeader)
		{
		TPtr8 ptr(pBuffer,nSizeBytes);
		CMMFBuffer* buffer = NULL;
		TRAPD(err, buffer = CMMFPtrBuffer::NewL(ptr));
		if (err != KErrNone)
			{
			return OMX_ErrorInsufficientResources;
			}
		switch (nPortIndex)
			{
			case KIndexInputPort:
				{
				(*ppBufferHeader)->pInputPortPrivate = buffer;
				}
				break;
			case KIndexOutputPort:
				{
				(*ppBufferHeader)->pOutputPortPrivate = buffer;	
				}
				break;	
			}
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorInsufficientResources;
		}
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::AllocateBuffer(
		OMX_BUFFERHEADERTYPE** pBuffer,
		TUint32 nPortIndex,
		TAny* pAppData,
		TUint32 nSizeBytes)
	{
	ASSERT(iState == OMX_StateLoaded);
	
	*pBuffer = new OMX_BUFFERHEADERTYPE;
	if (*pBuffer != NULL)
		{
		CMMFDescriptorBuffer* buffer = NULL;
		TRAPD(err, buffer = CMMFDescriptorBuffer::NewL(nSizeBytes));
		if (err != KErrNone)
			{
			return OMX_ErrorInsufficientResources;
			}
		(*pBuffer)->pBuffer = const_cast<TUint8*>(buffer->Data().Ptr());
		// store our allocated memory in component's private store
		switch (nPortIndex)
			{
		case KIndexInputPort:
			(*pBuffer)->pInputPortPrivate = buffer;
			(*pBuffer)->pOutputPortPrivate = NULL;
			break;
		case KIndexOutputPort:
			(*pBuffer)->pOutputPortPrivate = buffer;
			(*pBuffer)->pInputPortPrivate = NULL;
			break;
			};
		
		
		(*pBuffer)->nAllocLen = nSizeBytes;
		(*pBuffer)->nFilledLen = 0;
		(*pBuffer)->pAppPrivate = pAppData;
		}
		
	if (*pBuffer && (*pBuffer)->pBuffer)
		{
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorInsufficientResources;
		}
	}

OMX_ERRORTYPE COmxVorbisEncoder::FreeBuffer(
		TUint32 nPortIndex,
       OMX_BUFFERHEADERTYPE* pBuffer)
	{
	switch (nPortIndex) 
		{		
		case KIndexInputPort:
			{
			delete (static_cast<CMMFBuffer*>(pBuffer->pInputPortPrivate));
			pBuffer->pInputPortPrivate = NULL;
			break;
			}
		case KIndexOutputPort:
			delete (static_cast<CMMFBuffer*>(pBuffer->pOutputPortPrivate));
			pBuffer->pOutputPortPrivate = NULL;
			break;	
			
		}
	delete pBuffer;
	return OMX_ErrorNone;
	}
OMX_ERRORTYPE COmxVorbisEncoder::EmptyThisBuffer(
       OMX_BUFFERHEADERTYPE* pBuffer)
	{
	ASSERT(iState == OMX_StateExecuting ||
			iState == OMX_StateIdle ||
			iState == OMX_StatePause);
	return iCodecProcessor->EmptyThisBuffer(pBuffer);
	}
OMX_ERRORTYPE COmxVorbisEncoder::FillThisBuffer(
           OMX_BUFFERHEADERTYPE* pBuffer)
	{
	ASSERT(iState == OMX_StateExecuting ||
			iState == OMX_StateIdle ||
			iState == OMX_StatePause);
	return iCodecProcessor->FillThisBuffer(pBuffer);	
	}
	
OMX_ERRORTYPE COmxVorbisEncoder::SetCallbacks(
           OMX_CALLBACKTYPE* pCallbacks, 
           TAny* pAppData)
	{
	iCallback = pCallbacks;
	iAppData = pAppData;
	return OMX_ErrorNone;
	}
	

//////////////////////////////////
	
CCodecProcessor::CCodecProcessor(COmxVorbisEncoder& aParent) 
	: iParent(&aParent),
	  iCodec(NULL)
	{
	}

void CCodecProcessor::RunThreadL()
	{
	iQueueStatus = KRequestPending;
	iMessageQueue.NotifyDataAvailable(iQueueStatus);
	
	for (;;)
		{
		User::WaitForRequest(iQueueStatus);
		TCodecMessage msg;
		
		TBool exit = EFalse;
		
		while (iMessageQueue.Receive(msg)==KErrNone)
			{
			switch (msg.iType)
				{
				case EStopProcessing:
					iStarted = EFalse;
					break;
				case EExit:
					exit = ETrue;
					break;
				case EInputBuffer:
					iBuffersToEmpty.Append(msg.iBuffer); 
					break;
				case EOutputBuffer:
					iBuffersToFill.Append(msg.iBuffer);
					break;
				}
			}
			
		if (exit)
			{
			break;
			}
		else
			{
			// process all available buffers
			ProcessAvailableBuffers();	
			
			// request notification of further queue events
			iQueueStatus = KRequestPending;
			iMessageQueue.NotifyDataAvailable(iQueueStatus);
			}
		}
	}

CCodecProcessor* CCodecProcessor::NewL(COmxVorbisEncoder& aParent) 
	{
	CCodecProcessor* self = new (ELeave) CCodecProcessor(aParent);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop(self);
	return self;
	}	
	
	
void CCodecProcessor::ConstructL()
	{
	User::LeaveIfError(iMessageQueue.CreateLocal(10));
	
	// set the default case
	// input = PCM16, output = Vorbis
	iInputSampleRate = KDefaultInputSampleRate;
	iInputChannels = KDefaultInputChannels;
	iInputBitsPerSample = KDefaultInputBitsPerSample;
	iInputDataType = KDefaultInputDataType;
	iOutputBitRate = KDefaultOutputBitRate;

	// create the Vorbis codec
	iCodec = CVorbisProcessor::NewL();	
	}
	
OMX_ERRORTYPE CCodecProcessor::EmptyThisBuffer( 
		OMX_BUFFERHEADERTYPE* pBuffer) 
	{
	TCodecMessage message;
	message.iType = EInputBuffer;
	message.iBuffer = pBuffer;
	if (iMessageQueue.Send(message) == KErrNone)
		{
		return OMX_ErrorNone;	
		}
	else
		{
		return OMX_ErrorUndefined;
		}
	}
	
void CCodecProcessor::Stop()
	{
	TCodecMessage message;
	message.iType = EStopProcessing;
	message.iBuffer = NULL;
	iMessageQueue.Send(message);
	}
	
void CCodecProcessor::Exit()
	{
	TCodecMessage message;
	message.iType = EExit;
	message.iBuffer = NULL;
	iMessageQueue.Send(message);
	}
	
OMX_ERRORTYPE CCodecProcessor::FillThisBuffer(
									OMX_BUFFERHEADERTYPE* pBuffer) 
	{
	TCodecMessage message;
	message.iType = EOutputBuffer;
	message.iBuffer = pBuffer;
	if (iMessageQueue.Send(message)== KErrNone)
		{
		return OMX_ErrorNone;
		}
	else
		{
		return OMX_ErrorUndefined;
		}
	}

// input = PCM16, output = Vorbis

void CCodecProcessor::SetInputSampleRate(TInt aInputSampleRate)
	{
	iInputSampleRate = aInputSampleRate;
	}
	
void CCodecProcessor::SetInputChannels(TInt aInputChannels)
	{
	iInputChannels = aInputChannels;
	}

void CCodecProcessor::SetInputBitsPerSample(TInt aInputBitsPerSample)
	{
	iInputBitsPerSample = aInputBitsPerSample;
	}
	
void CCodecProcessor::SetInputDataType(OMX_NUMERICALDATATYPE aType)
	{
	iInputDataType = aType;
	}

TInt CCodecProcessor::ConfigureInput()
	{
	TRAPD(err, iCodec->ConfigureL(iInputSampleRate, iInputChannels));
	return err;
	}

void CCodecProcessor::SetOutputBitRate(TInt aBitRate)
	{
	TRAPD(err, iCodec->SetBitRateL(aBitRate));
	if(!err) 
		{
		iOutputBitRate = aBitRate;
		}
	}

// so that it can be retrieved by the PU
TInt CCodecProcessor::OutputBitRate()
	{
	return iOutputBitRate;
	}

void CCodecProcessor::ProcessAvailableBuffers()
	{
	// Setup wait for data in queue
	while (iBuffersToFill.Count()>0 && iBuffersToEmpty.Count() > 0)
		{
		TBool lastBuffer = EFalse;
		if (!iStarted)
			{
			iStarted = ETrue;
			}
		
		OMX_BUFFERHEADERTYPE* srcBuffer = iBuffersToEmpty[0];
		OMX_BUFFERHEADERTYPE* destBuffer = iBuffersToFill[0];
		if (srcBuffer->nFlags & OMX_BUFFERFLAG_EOS)
			{
			lastBuffer = ETrue;
			}
		
		// the buffer contains raw PCM
		
		// set up CMMFDataBuffers from the source and dest
		CMMFDataBuffer* mmfSrcBuffer = static_cast<CMMFDataBuffer*>(srcBuffer->pInputPortPrivate);
		mmfSrcBuffer->Data().SetLength(srcBuffer->nFilledLen);
		CMMFDataBuffer* mmfDestBuffer = static_cast<CMMFDataBuffer*>(destBuffer->pOutputPortPrivate);
		mmfDestBuffer->Data().SetLength(destBuffer->nFilledLen);
		
		CVorbisProcessor::TProcessResult processResult;
		TUint bytesRead = 0;
		TUint bytesWritten = 0;		
		TRAPD(err, iCodec->ProcessL(*mmfSrcBuffer,
									*mmfDestBuffer, 
									processResult,
									bytesRead,
									bytesWritten) );
		if(err)  
			{
			// we couldn't process the buffer
			// TODO : set error condition?
			User::Leave(err);
			}
			
		destBuffer->nFilledLen = bytesWritten;
		srcBuffer->nFilledLen = 0;
		iBuffersToEmpty.Remove(0);
		iParent->EmptyBufferDoneCallback(srcBuffer);			
			
		if (lastBuffer)
			{
			destBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
			// propagate the EOS flag
			iParent->EventHandlerCallback(
						OMX_EventBufferFlag,
						0,
						destBuffer->nFlags,
						NULL);	
			}

		// return the buffer even if it is empty
		if (processResult == CVorbisProcessor::EComplete || lastBuffer)
			{
			iBuffersToFill.Remove(0);
			iParent->FillBufferDoneCallback(destBuffer);			
			}
		}
	}

CCodecProcessor::~CCodecProcessor()
	{
	iBuffersToEmpty.Close();
	iBuffersToFill.Close();
	iMessageQueue.Close();
	
	// delete the codec
	if(iCodec) 
		{
		delete iCodec;
		}
	}
	
///////////////////////////////////////////////////
	
TInt COmxVorbisEncoder::StartExecution()
	{
	// create thread with current thread's heap
	// we can thus allocate and free memory across threads
	if (!iCreatedThread)
		{
		// create thread with unique name, as two encoders may
		// exist at once
		TTime threadTime;
		threadTime.HomeTime();
        TName threadName;
        threadName.Copy(KVorbisEncoder);
        threadName.AppendNum(threadTime.Int64(), EHex);

		TInt err = iProcessingThread.Create(threadName, 
							&ProcessingThread, 
							KThreadStackSize, 
							&User::Heap(),
							iCodecProcessor);
							
		if (err!=KErrNone)
			{
			return err;
			}
		iCreatedThread = ETrue;
		iThreadDeath = KRequestPending;
		iProcessingThread.Resume();
		}

	return KErrNone;						
	}

// Callbacks for the Vorbis encoder
void COmxVorbisEncoder::EventHandlerCallback( 
        			OMX_OUT OMX_EVENTTYPE eEvent, 
        			OMX_OUT TUint32 nData1,
        			OMX_OUT TUint32 nData2,
        			OMX_OUT OMX_STRING cExtraInfo)
	{
	iCallback->EventHandler(
			this,
			iAppData,
			eEvent,
			nData1,
			nData2,
			cExtraInfo);	
	}
	
	
void COmxVorbisEncoder::FillBufferDoneCallback(OMX_BUFFERHEADERTYPE* aBuffer)
	{
	iCallback->FillBufferDone(
		*this,
		iAppData,
		aBuffer);
	}
	
void COmxVorbisEncoder::EmptyBufferDoneCallback(OMX_BUFFERHEADERTYPE* aBuffer)
	{
	iCallback->EmptyBufferDone(
		*this,
		iAppData,
		aBuffer);		
	}
	
// Component Entry Point
OMX_ERRORTYPE OMX_ComponentInit(OMX_HANDLETYPE hComponent)
	{
	TInt err = COmxVorbisEncoder::CreateComponent(hComponent);
	if (err == KErrNone)
		return OMX_ErrorNone;
	else 
		{
		// return some problem
		return OMX_ErrorInsufficientResources;
		
		}
	}

///////////////////////////////////////////////////
