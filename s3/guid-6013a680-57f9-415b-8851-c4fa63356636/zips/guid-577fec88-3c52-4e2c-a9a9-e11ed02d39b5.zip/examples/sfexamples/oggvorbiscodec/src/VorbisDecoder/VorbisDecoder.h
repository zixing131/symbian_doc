// VorbisDecoder.h
//
// Copyright (c) Symbian Software Ltd 2005-2007.  All rights reserved.
//

#ifndef VORBISDECODER_H
#define VORBISDECODER_H

#include "ivorbiscodec.h"

/*
 Central decoding class - talks to the Xiph vorbis libraries. It is responsible to convert the 
 errors returned by these library method calls into Symbian error codes.
 */
class CVorbisDecoder : public CBase
    {
public:
    static CVorbisDecoder* NewL();
    virtual ~CVorbisDecoder();
    void PacketInL(ogg_packet aPacket);
    void PcmOutL(TDes8& aBuf);   
    void DecoderL(const CMMFDataBuffer& aBuf,TDes8& aDstBuf);
    void Reset();
    TBool IsLastPage(CMMFDataBuffer& aBuf);
private:
    CVorbisDecoder();
    void ConstructL();
private:
    enum TState
        {
        EInitializing,
        EReady,
        ENotVorbis, // not vorbis data
        EBadStream  // corrupt stream
        };
    TState iState;
    TInt iPacketCount;
    vorbis_info iInfo;
    vorbis_comment iComment;
    vorbis_dsp_state iDspState;
    vorbis_block iBlock;
    ogg_sync_state* iSyncState;
    ogg_stream_state* iStreamState;
    ogg_page iPage;
    ogg_packet iPacket;
    TInt iPageNumber;
    };

/*
 This class is responsible for decoding the vorbis data obtained from the CVorbisEncoderPlugInWrapper into
 pcm data. It also returns the result of the operation.
 */
class CVorbisDecoderProcessor : public CBase
    {
public:
    enum TProcessResult
        {
        EComplete,
        EIncomplete,
        EDestNotFilled
        };

    static CVorbisDecoderProcessor* NewL();
    virtual ~CVorbisDecoderProcessor();

    void ProcessL(const CMMFBuffer& aSource,
                           CMMFBuffer& aDest,
                           TProcessResult& aRes,
                           TUint& aSourceUsed,
                           TUint& aDestWritten);
private:
    CVorbisDecoderProcessor();
    void ConstructL();
private:
    CVorbisDecoder* iDecoder;
    TUint iLastFrame; //lastframenumber
#ifdef SYMBIAN_SEP_HEAP    
    RHeap* iDefaultHeap;
    RHeap* iVorbisHeap;
    RChunk iVorbisChunk;
#endif
    };
#endif //VORBISDECODER_H
