// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <IRDevice.rsg>

#include "IRDeviceAppUi.h"
#include "IRDeviceMainView.h"
#include "IRDevice.hrh"
#include <es_sock.h>

void CIRDeviceAppUi::SearchIrDevicesL()
	{
	RSocketServ ss;
	TProtocolDesc pInfo;
	User::LeaveIfError(ss.Connect());
	CleanupClosePushL(ss);

	_LIT(KTinyTP,"IrTinyTP");
	TProtocolName protocolName(KTinyTP);	
	User::LeaveIfError(ss.FindProtocol(protocolName,pInfo));

	RHostResolver hr;
	User::LeaveIfError(hr.Open(ss,pInfo.iAddrFamily,pInfo.iProtocol));
	CleanupClosePushL(hr);

	TNameEntry log;
	_LIT(KMask, "*");
	THostName name(KMask);

	TInt ret = hr.GetByName(name, log);
	if (ret!=KErrNone)
		{
		// No devices discovered - may be none present
		CEikonEnv::Static()->InfoWinL(
						R_IRDEVICE_CAPTION, R_IRDEVICE_CAPTION);
		CleanupStack::PopAndDestroy(2);		
		}
	// Call RHostResolver::Next() on 9.2 here
	else
		{
		while (hr.Next(log) == KErrNone)
			{
			CEikonEnv::Static()->InfoWinL(name,KNullDesC);
			}
		}
	CleanupStack::PopAndDestroy(2); // ss, hr	
	}
// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
void CIRDeviceAppUi::ConstructL()
	{
	BaseConstructL(EAknEnableSkin);
	
	iMainView = CIRDeviceMainView::NewL(ClientRect());
	}
	
// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CIRDeviceAppUi::~CIRDeviceAppUi()
    {
    if (iMainView)
        {
        delete iMainView;
        iMainView = NULL;
        }
    }

// --------------------------------------------------------------------------
// Handles user command.
// --------------------------------------------------------------------------
void CIRDeviceAppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{

		// For S60, we need to handle this event, which is normally
		// an event from the right soft key.
		case EAknSoftkeyExit:

		case EEikCmdExit:
			{
			Exit();
			break;
			}
		
		case EIRDeviceCommand1:
			{			
			SearchIrDevicesL();
			break;
			}
		
		default:
			// Do nothing
			break;
		}
	}


// --------------------------------------------------------------------------
// Handles screen resolution/size changes.
// --------------------------------------------------------------------------
void CIRDeviceAppUi::HandleResourceChangeL(TInt aType)
	{
	CAknAppUi::HandleResourceChangeL(aType);
	iMainView->SetRect(ClientRect());
	}


// End of File
