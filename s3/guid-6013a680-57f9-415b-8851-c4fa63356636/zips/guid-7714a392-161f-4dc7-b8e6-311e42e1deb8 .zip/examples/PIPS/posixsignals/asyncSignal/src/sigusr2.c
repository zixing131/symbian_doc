/*
Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: The source file for sigusr2 process.
*/


#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <e32def.h>

/**
 The variable used in waiting for a signal iteration.
 */
int gVal = TRUE;

/**
 The custom handler function for SIGUSR2. 
 @param signum The signal number
 */
void SIGUSR2_handler(int signum)
    {
    if(signum == SIGUSR2)
        {
        printf("Received the SIGUSR2 signal from the sigusr1 process after reading the file.\n");
        gVal = FALSE;
        }
    }

/**
 Entry point for sigusr2 process.
 The sigusr2 process assigns a custom handler for the SIGUSR2 signal.
 It sends SIGUSR1 to the sigusr1 process by accepting a key press event from the user.
 Then it waits for the reception of a SIGUSR2 signal from the sigusr1 process.
 The process exits after the SIGUSR2 signal is obtained.
 */
int main(int argc,char **argv)
    {
    pid_t asyProcsID;
    char ch;
    int ret;
    if(argc < 2)
        {
        printf("Please pass the correct arguments\n");
        return EXIT_FAILURE;
        }
    asyProcsID = atoi(argv[1]);  //The variable holding the sigusr1 process PID.
    // Setup the custom handler for SIGUSR2.
    signal(SIGUSR2, SIGUSR2_handler);
    printf("******************** In the sigusr2 process ********************\n");
    
    printf("\nPress the Enter key to send the SIGUSR1 signal to the sigusr1 process\n");
    getchar();
    ret = kill(asyProcsID,SIGUSR1);
    if(ret)
        {
        printf("kill() failed to send signal, errno=%d\n",errno);
        gVal = FALSE;
        }
    
    /* 
     Waiting until a SIGUSR2 signal is obtained from the sigusr1 process.
     This signal is sent after the aynscFile.txt file has been
     read and its content written to the console.
    */
    while(gVal)
        {
        sleep(0);   //Initiates signal handling.
        }
    printf("\nPress 'e'+Enter to exit from the sigusr2 process\n");
    while((ch = getchar())!= 'e')
        {
        if(ch == '\n')
            continue;
        else
            printf("The wrong option was selected, please try again!!!\n");
        }
    return EXIT_SUCCESS;
    }
