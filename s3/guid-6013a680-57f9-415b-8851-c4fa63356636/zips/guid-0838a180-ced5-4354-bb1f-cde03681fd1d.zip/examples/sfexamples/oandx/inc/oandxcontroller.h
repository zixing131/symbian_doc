// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDXCONTROLLER_H
#define OANDXCONTROLLER_H

#include <coecntrl.h>
#include <coemain.h>

#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikenv.h>
#include <eikon.hrh>

class COandXEngine;

#define MaxInfoNoteTextLen 40

class COandXController : public CBase
/**
	This controller uses instructions from the user to update the
	engine (board.) 
 */
	{
public:
	static COandXController* NewL();
	virtual ~COandXController();

	// game control
	void Reset();
	TBool HitSquareL(TInt aIndex);
	void SwitchTurn();

	// state
	enum TState
		{
		ENewGame, EPlaying, EFinished
		};

	inline TBool IsNewGame() const;
	inline TBool IsCrossTurn() const;

	// stream persistence
	void ExternalizeL(RWriteStream& aStream) const;
	void InternalizeL(RReadStream& aStream);
	
private:
	void ConstructL();
	
private:
	// private persistent state
	TState iState;
	TBool iCrossTurn;
	};

// state inlines
inline TBool COandXController::IsNewGame() const { return iState==ENewGame; }
inline TBool COandXController::IsCrossTurn() const { return (iCrossTurn); }
	
#endif // OANDXCONTROLLER_H
