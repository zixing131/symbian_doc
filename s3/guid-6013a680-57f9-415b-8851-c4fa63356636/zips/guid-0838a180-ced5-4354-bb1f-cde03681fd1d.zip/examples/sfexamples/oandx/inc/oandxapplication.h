// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#ifndef OANDXAPPLICATION_H
#define OANDXAPPLICATION_H

#include <aknapp.h>

/** Application UID should correspond to UID3 (SECUREID) in the MMP file. */
const TUid KUidOandXApp = {0xE04E4143};		// 0e 'N' 'A' 'C'

class COandXApplication : public CAknApplication
/**
	Standard application class tells the application framework
	this app's UID and creates the document object.
 */
	{
public:
	// From CApaApplication
	TUid AppDllUid() const;

protected:
	// From CEikApplication
	CApaDocument* CreateDocumentL();
	};

#endif // OANDXAPPLICATION_H
