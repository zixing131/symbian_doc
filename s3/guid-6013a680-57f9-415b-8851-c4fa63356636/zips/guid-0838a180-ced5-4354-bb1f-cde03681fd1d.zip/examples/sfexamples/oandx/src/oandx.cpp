// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikstart.h>

#include "OandXApplication.h"


EXPORT_C CApaApplication* NewApplication()
/**
	Standard exported function creates new instance of application object.
	
	@return					New instance of application object, NULL
							if not enough memory.  The returned object
							is only CBase initialized, i.e. the heap
							space is allocated and zeroed, and the constructor
							is run.  No secondary initialization is
							performed.
 */
	{
	return new COandXApplication;
	}

GLDEF_C TInt E32Main()
/**
	Standard entrypoint function for UI applications.
	
	@return					Return code from EikStart::RunApplication.
 */
	{
	return EikStart::RunApplication( NewApplication );
	}
