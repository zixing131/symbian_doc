// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

#include <eikenv.h>
#include <eiklabel.h>
#include <s32mem.h>

#include "oandxcontroller.h"
#include "oandxengine.h"
#include "oandxappui.h"
#include "oandxdefs.h"

COandXController* COandXController::NewL()
/**
	Factory function allocates new instance of COandXController.
	
	@return					New, initialized instance of COandXController.
							This object is owned by the caller.
 */
	{
	COandXController* self=new(ELeave) COandXController;
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
	}

void COandXController::ConstructL()
/**
	Run secondary initialization, clearing the board.
 */
	{
	Reset();
	}

COandXController::~COandXController()
/**
	Destructor is defined here to ensure only one
	instance is generated.
 */
	{
	// empty.
	}

// persistence

void COandXController::ExternalizeL(RWriteStream& aStream) const
/**
	Persist the controller's state to the supplied stream.
	Specifically, writes out the state, whose turn it is,
	and which symbol the local player is using.
	
	@param	aStream			Stream to which the controller's state will be
							written.
	@see InternalizeL
 */
	{
	aStream.WriteUint8L(iState);
	aStream.WriteInt8L(iCrossTurn);
	}

void COandXController::InternalizeL(RReadStream& aStream)
/**
	Standard stream store internalization function, restores
	state, whose turn, and which symbol the local player is using.
	
	@param	aStream			Stream which contains externalized state.
	@see ExternalizeL
 */
	{
	iState = static_cast<TState>(aStream.ReadUint8L());
	iCrossTurn = static_cast<TBool>(aStream.ReadInt8L());
	}

void COandXController::Reset()
/**
	Cancel the current game, clearing the board and setting
	noughts as the current player.
 */
	{
	Engine().Reset();
	iState = ENewGame;
	if (IsCrossTurn())
		{
		SwitchTurn();
		}
	}

TBool COandXController::HitSquareL(TInt aIndex)
	{
	// For Comms, replace this with another function, called
	// when a tile is selected. It should refuse to accept
	// the hit if it is not my move.
	// Add another function, called when the opponent makes a
	// move, and both can call this funtion (renamed from
	// HitSquareL) The logic will need to be modified to handle 
	// the additional comms states and to report which of the
	// two players wins the game (or when the game is drawn).
	if (iState == EFinished)
		{
		return EFalse;
		}
	if (iState == ENewGame)
		{
		iState = EPlaying;
		}
	if (Engine().TryMakeMove(aIndex,IsCrossTurn()))
		{
		SwitchTurn();
		TInt winner = Engine().GameWonBy();
		if (winner)
			{
			iState = EFinished;
			OandXAppUi()->ReportWinnerL(winner);
			}
		return ETrue;
		}
	return EFalse;
	}

void COandXController::SwitchTurn()
	{
	iCrossTurn = !iCrossTurn;
	OandXAppUi()->ReportWhoseTurn();
	}

