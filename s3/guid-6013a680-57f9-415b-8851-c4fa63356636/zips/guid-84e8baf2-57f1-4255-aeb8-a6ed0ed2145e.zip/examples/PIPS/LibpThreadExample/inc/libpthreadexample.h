// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// License: "Symbian Foundation License v1.0" to Symbian Foundation
// members and "Symbian Foundation End User License Agreement v1.0"
// to non-members�at the URL
// "http://www.symbianfoundation.org/legal/licencesv10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __LIBPTHREADEXAMPLE_H__
#define __LIBPTHREADEXAMPLE_H__

//  Include Files

#include <e32base.h>
void* TestFunction1L(void*);  
void* TestFunction2L(void*);  
void* TestFunction3L(void*);  
int CreateThreadL(void);


//  Function Prototypes

GLDEF_C TInt E32Main();

#endif  // __LIBPTHREADEXAMPLE_H__

