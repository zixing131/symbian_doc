/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#include "ClockExample.h"

// Second phase constructor of the application UI class.
// It creates and owns a single view.
void CExampleAppUi::ConstructL()
	{
	BaseConstructL();
	iAppView = CExampleAppView::NewL(ClientRect());
	}

// The application UI class owns one view, and is responsible
// for destroying it. 
CExampleAppUi::~CExampleAppUi()
	{
	delete iAppView;
	}

// Called by the UI framework when a command has been issued.
void CExampleAppUi::HandleCommandL( TInt aCommand )
	{
	
	switch (aCommand)
		{
	// Digital clock commands	
	case ETestDo0:
	case ETestDo1:
	case ETestDo2:
	case ETestDo3:
	case ETestDo4:
	case ETestDo5:
	case ETestDo6:
	case ETestDo7:
	case ETestDo8:
	case ETestDo9:
	case ETestDoA:
	case ETestDoB:
	case ETestDoC:
	case ETestDoD:
	case ETestDoE:
	case ETestDoF:	
	iAppView->DoExperimentL( aCommand );
	break;	
	
	// Analogue	clock commands
	case ETestDo10:
	case ETestDo11:
	case ETestDo12:
	case ETestDo13:
	case ETestDo14:
	case ETestDo15:
	case ETestDo16:
	case ETestDo17:
	case ETestDo18:
	case ETestDo19:
	case ETestDo1A:
	case ETestDo1B:
	case ETestDo1C:
	case ETestDo1D:
	case ETestDo1E:
	case ETestDo1F:
	iAppView->DoExperimentL( aCommand );
	break;			 

	case EEikCmdExit: 
		Exit();
		break;
		}
		
	}

