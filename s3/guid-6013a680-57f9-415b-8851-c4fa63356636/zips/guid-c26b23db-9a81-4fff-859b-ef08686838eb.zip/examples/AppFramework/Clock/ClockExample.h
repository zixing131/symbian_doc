/*
Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/


#ifndef __CLOCKEXAMPLE_H__
#define __CLOCKEXAMPLE_H__


#include <coeccntx.h>

#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikmenup.h>

#include <eikstart.h> 

#include <clock.h>

#include <clockexample.rsg>
#include "ClockExample.hrh"

#include <mymbs0.mbg>

_LIT(KMyMBS,"z:\\system\\data\\MYMBS0.MBM");

#define CLOCK 0  
#define CLOCKMSK 1 

enum TTimezoneOffset
	{
	EUTOffsetOneHour = ( 60 * 60 ),
	EUTOffsetHalfHour = ( 30 * 60 ),
	EUTOffsetQuarterHour = ( 15 * 60 ),
	EUTOffsetTenMinutes = ( 10 * 60 ),
	EUTOffsetFiveMinutes = ( 5 * 60 ),
	EUTOffsetOneMinute = ( 1 * 60 ),
	EUTOffsetThirtySeconds = ( 30 ),
	EUTOffsetFifteenSeconds = ( 15 ),
	EUTOffsetTenSeconds = ( 10 ),
	EUTOffsetFiveSeconds = ( 5 ),
	EUTOffsetOneSecond = ( 1 ),

	EUTOffsetLondon = 0,
	EUTOffsetLondonSummer = EUTOffsetLondon + EUTOffsetOneHour,
	EUTOffsetBangalore = 5 * EUTOffsetOneHour + EUTOffsetHalfHour		
	};

// Destructable font for Digital clock
class CDestructableFont : public CBase
	{
public:
	CDestructableFont(CWsScreenDevice* aScreenDevice);
	void ConstructL(const TFontSpec& aFontSpec);
	virtual ~CDestructableFont();
	TInt Handle() const;
private:
	CWsScreenDevice* iScreenDevice; // not owned by this pointer
	CFbsFont* iFont;
	};
	
		
// Application class	
class CExampleApplication : public CEikApplication
	{
private: 
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};

// View class
class CExampleAppView : public CCoeControl
    {
public:
	static CExampleAppView* NewL( const TRect& aRect );
	CExampleAppView();
	~CExampleAppView();
	void ConstructL( const TRect& aRect );
    
	void DoExperimentL( TInt aCommand );
	void ConstructAnalogClockL();
	void ConstructDigitalClockL();

private:
	void Draw(const TRect& /*aRect*/) const;

private:
	HBufC*  iTextBuffer;
	RAnalogClock* iAnalogClock;
	RDigitalClock* iDigitalClock;
	TPoint iDigitalClockPosition;
	TPoint iAnalogClockPosition;
	TSize iDigitalClockSize;
	TSize iAnalogClockSize;
	TInt iDigitalClockUniversalTimeOffset;
	TInt iAnalogClockUniversalTimeOffset;
	RAnimDll iAnimDll;
	
	TRgb iBackgroundColor;
	CFbsFont* iFont;
    };

// Application UI class
class CExampleAppUi : public CEikAppUi
    {
public:
	void ConstructL();
	~CExampleAppUi();

private:
	void HandleCommandL(TInt aCommand);

private:
	CExampleAppView* iAppView;
	};

// Document class
class CExampleDocument : public CEikDocument
	{
public:
	static CExampleDocument* NewL(CEikApplication& aApp);
	CExampleDocument(CEikApplication& aApp);
	void ConstructL();
private: 
	CEikAppUi* CreateAppUiL();
	};

#endif // __CLOCKEXAMPLE_H__
