/*
 * Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#ifndef CTZLOCALIZERENGINE_H
#define CTZLOCALIZERENGINE_H

#include <tz.h>
#include <TzLocalizer.h>
#include <TzLocalizationDataTypes.h>

class CTZLocalizerEngine : public CBase  
    {
    public:

        static CTZLocalizerEngine* NewL();
        static CTZLocalizerEngine* NewLC();

        /**
         * Destructor.
         */
        ~CTZLocalizerEngine();

    private:    // Constructors
        CTZLocalizerEngine();
        
// ---------------------------------------------------------
//  CTZLocalizerEngine::ConstructL()
//  Connect to Time Zone server. 
// ---------------------------------------------------------
        void ConstructL();

    public:     // Methods

// ---------------------------------------------------------
//  CTZLocalizerEngine::ListCitiesL()
//  Fills aCityListReturn with the names of the cities of
//  whose name match to aSearchPattern.
// ---------------------------------------------------------
    void ListCitiesL( const TDesC& aSearchPattern, 
            CDesC16ArrayFlat* aCityListReturn );

// ---------------------------------------------------------
// CTZLocalizerEngine::RemoveCityL()
// Removes a city from the user defined city collection 
// ---------------------------------------------------------
    void RemoveCityL(const TDesC& aCityName );

// ---------------------------------------------------------
// TPtrC CTZLocalizerEngine::GetCityName(CTzLocalizedCity *aLocalizedCity)
// Get current city name.
// ---------------------------------------------------------
    TPtrC GetCityName(CTzLocalizedCity *aLocalizedCity);

// ---------------------------------------------------------
// CTZLocalizerEngine::GetCityTimeZoneId(CTzLocalizedCity *aLocalizedCity)
// Get current city time zone id.
// ---------------------------------------------------------    
    TUint16 GetCityTimeZoneId(CTzLocalizedCity *aLocalizedCity);

// ---------------------------------------------------------
// CTZLocalizerEngine::GetCityGroupId(CTzLocalizedCity *aLocalizedCity)
// Get current city group id.
// ---------------------------------------------------------
    TUint8 GetCityGroupId(CTzLocalizedCity *aLocalizedCity);

// ---------------------------------------------------------
// CTZLocalizerEngine::GetCityLocalTime()
// Convert universal time to local time.
// ---------------------------------------------------------    
    HBufC* GetCityLocalTimeL(CTzLocalizedCity *aLocalizedCity);

// ---------------------------------------------------------
// CTZLocalizerEngine::FindCitiesInGroupL()
// Find the cities with same group id.
// ---------------------------------------------------------
    CDesC16ArrayFlat* FindCitiesInGroupL( TInt aGroupID);

// ---------------------------------------------------------
//  CTZLocalizerEngine::AddCityL()
//  Add a new city to the database.
// ---------------------------------------------------------    
    CTzLocalizedCity* AddCityL(TInt aTimeZoneId, const TDesC &aCityName, TInt aGroupId=0);

// ---------------------------------------------------------
// CTZLocalizerEngine::FindCityL()
// Find the specific city.
// ---------------------------------------------------------    
    CTzLocalizedCity* FindCityL(const TDesC& aCityName);
    
// ---------------------------------------------------------
//  CTZLocalizerEngine::GetAllTimeZonesL()
//  Fetch the localized time zone ID's
// ---------------------------------------------------------
    CDesC16ArrayFlat* GetAllTimeZonesL();

// ---------------------------------------------------------
// CTZLocalizerEngine::GetAllGroupID()
// Fetch the localized city group ID's
// ---------------------------------------------------------    
    CDesC16ArrayFlat* GetAllGroupIDL();
    
// ---------------------------------------------------------
// CDesC16ArrayFlat* CTZLocalizerEngine::GetAllCitiesL()
// Fetch the localized cities
// ---------------------------------------------------------    
    CDesC16ArrayFlat* GetAllCitiesL();

    private:    // Data

};

#endif

// End of File

