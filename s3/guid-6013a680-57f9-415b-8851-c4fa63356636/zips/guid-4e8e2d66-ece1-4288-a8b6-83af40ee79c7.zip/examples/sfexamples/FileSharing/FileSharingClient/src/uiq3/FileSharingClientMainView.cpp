// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:
// 

// INCLUDES
#include <QikCommand.h>
#include <eiklabel.h>
#include <FileSharingClient.rsg>

#include "FileSharingClientExternalInterface.h"
#include "FileSharingClientAppUi.h"
#include "FileSharingClientMainView.h"
#include "FileSharingClient.hrh"

// MEMBER FUNCTIONS

// --------------------------------------------------------------------------
// Two-phase constructor
// --------------------------------------------------------------------------
CFileSharingClientMainView* CFileSharingClientMainView::NewLC(CQikAppUi& aAppUi)
	{
	CFileSharingClientMainView* self = new (ELeave) CFileSharingClientMainView(aAppUi);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// --------------------------------------------------------------------------
// Default constructor
// --------------------------------------------------------------------------
CFileSharingClientMainView::CFileSharingClientMainView(CQikAppUi& aAppUi) 
	: CQikViewBase(aAppUi, KNullViewId)
	{
	}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
CFileSharingClientMainView::~CFileSharingClientMainView()
	{
	}

// --------------------------------------------------------------------------
// Second phase constructor
// --------------------------------------------------------------------------
void CFileSharingClientMainView::ConstructL()
	{
	BaseConstructL();
	}
	
// --------------------------------------------------------------------------
// Called when this view is first time activated.
// --------------------------------------------------------------------------
void CFileSharingClientMainView::ViewConstructL()
	{
	ViewConstructFromResourceL(R_FILESHARINGCLIENT_UI_CONFIGURATIONS);	
	iEikLabel = LocateControlByUniqueHandle<CEikLabel> (EFileSharingClientLabelCtrl);
	}

// --------------------------------------------------------------------------
// Returns the identifier of this view.
// --------------------------------------------------------------------------
TVwsViewId CFileSharingClientMainView::ViewId()const
	{
	return TVwsViewId(KUidFileSharingClientApp, KUidFileSharingClientMainView);
	}

// --------------------------------------------------------------------------
// Handles user command.
// In this example, all commands are sent to AppUi because
// we want to have the same code with S60.
// --------------------------------------------------------------------------
void CFileSharingClientMainView::HandleCommandL(CQikCommand& aCommand)
	{
	iQikAppUi.HandleCommandL(aCommand.Id());
	CQikViewBase::HandleCommandL(aCommand);
	}

// --------------------------------------------------------------------------
// Sets the text to be displayed on this control.
// --------------------------------------------------------------------------
void CFileSharingClientMainView::SetTextL(const TDesC& aText)
	{
	if (iEikLabel)
		{
		iEikLabel->SetTextL(aText);
		DrawDeferred();
		}
	}

// --------------------------------------------------------------------------
// Called when the size/resolution of this control has been
// changed. If this happens, the size of the label has to be
// adjusted as well.
// --------------------------------------------------------------------------
void CFileSharingClientMainView::SizeChanged()
    {
	if (iEikLabel)
		{
		TRect rect(Rect());
		iEikLabel->SetExtent(
			TPoint(0, 0),
			TSize(rect.Width(), rect.Height()));
		}
	}
	
// End of File
