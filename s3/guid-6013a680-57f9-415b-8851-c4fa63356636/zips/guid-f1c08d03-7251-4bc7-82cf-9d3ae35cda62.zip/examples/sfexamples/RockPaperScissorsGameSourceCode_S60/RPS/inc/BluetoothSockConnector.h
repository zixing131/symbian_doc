/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CBluetoothSockConnector is responsible for connecting to the remote device on a given
                   BT device address and on a given RFCOMM's port using the BT socket layer

*/ 

#ifndef __BLUETOOTHSOCKCONNECTOR_H__
#define __BLUETOOTHSOCKCONNECTOR_H__

// INCLUDES
#include <bt_sock.h>
#include <btmanclient.h>
#include <btsdp.h>
#include "BluetoothConnector.h"

// CLASS DECLARATION
/**
* CBluetoothSockConnector
* Connects to a remote device on a given BT device address and on a given RFCOMM's port using the BT socket layer
*/
class CBluetoothSockConnector : public CActive
    {
public:
	/**
	* Constructor
	* @param aBtSocket		Client endpoint to the RFCOMM protocol	
	* @param aSockConnObs	Interface to notify the status of the connection
	* @param aSocketServer	A handle to an existing session on the socket server (ESock). 
	*/
    static CBluetoothSockConnector* NewL(RSocket& aBtSocket, MSocketConnectorObserver& aSockConnObs, RSocketServ& aSocketServer);
    
	/**
	* Destructor
	*/
    ~CBluetoothSockConnector();
    
	/**
	* Connects to the remote BT device
	* @param aDevAddr	The remote BT device address	
	* @param aPort		The RFCOMM's port	
	*/
	void ConnectToRemoteBtDeviceL(const TBTDevAddr& aDevAddr, TInt aPort);

private:
	/**
	* Constructor
	* @param aBtSocket		Client endpoint to the RFCOMM protocol	
	* @param aSockConnObs	Interface to notify the status of the connection
	* @param aSocketServer	A handle to an existing session on the socket server (ESock). 
	*/
    CBluetoothSockConnector(RSocket& aBtSocket, MSocketConnectorObserver& aSockConnObs, RSocketServ& aSocketServer);

	/**
	* Second phase constructor 
	*/
    void ConstructL();

	// from CSocketConnector
	/**
	* Handles CBluetoothConnector's state machine completion events
	*/
	virtual void RunL();
	
	/**
	* Cancels all outstanding BT socket operations
	*/
	virtual void DoCancel();
	
	/**
	* Handles a leave occurring in the request completion event handler RunL()
	* @param aError	 The leave code
	* @return TInt	 The default implementation returns aError.A derived class implementation should return KErrNone,
	*				 if it handles the leave; otherwise it should return any suitable value to cause the handling
	*				 of the error to be propagated back to the active scheduler.
	*/
	virtual TInt RunError(TInt aError);
	
private:
	/**
	* Client endpoint to the RFCOMM protocol
	*/
	RSocket& iBtSocket;
	
	/**
	* Interface to notify the status of the connection
	*/
	MSocketConnectorObserver& iSockConnObs;
	
	/**
	* A handle to an existing session on the socket server (ESock)
	*/
	RSocketServ& iSocketServer;

	/**
	* The remote BT device address
	*/
	TBTSockAddr iBtDevAddr;
    };

#endif //__BLUETOOTHSOCKCONNECTOR_H__
