/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

// INCLUDE FILES

#include "BluetoothSocketWriterReader.h"
#include "common.hrh"
/*
============================================================================
CSocketReader's constructor
============================================================================
*/
CSocketReader::CSocketReader(RSocket& aBtSocket, MSocketWriterReaderObserver& aObserver) :
	CActive(CActive::EPriorityStandard), iBtSocket(aBtSocket), iObserver(aObserver)
    {
	CActiveScheduler::Add(this);
	}

/*
============================================================================
CSocketReader's destructor
============================================================================
*/
CSocketReader::~CSocketReader()
    {
    Cancel();
    }

/*
============================================================================
DoCancel is called as part of the active object's Cancel().
Cancels an outstanding BT socket read operation.
============================================================================
*/
void CSocketReader::DoCancel()
    {
	iBtSocket.CancelRead();
    }

/*
============================================================================
Handles the active object's reading data completion event.
On completion it calls the callback function MSocketWriterReaderObserver::ReportData
to pass to the caller the data received.
============================================================================
*/
void CSocketReader::RunL()
    {
	iObserver.ReportData(iBuffer, iStatus.Int());
    }	

/*
============================================================================
Asynchronous call to wait for incoming data
============================================================================
*/
void CSocketReader::ReadData()
    {
	if (!IsActive())
		{
		iBuffer.Zero();
		iBtSocket.RecvOneOrMore(iBuffer, 0, iStatus, iLen);
	    SetActive();
		}
    }

/*
============================================================================
Handles a leave occurring in the request completion event handler RunL().
============================================================================
*/
TInt CSocketReader::RunError(TInt aError)
	{
	iObserver.ReportData(iBuffer, aError);
	return KErrNone;
	}

///////////////////////////////////////////////////////////////////////////////////

/*
============================================================================
CSocketWriter's constructor
============================================================================
*/
CSocketWriter::CSocketWriter(RSocket& aBtSocket, MSocketWriterReaderObserver& aObserver) :
	CActive(CActive::EPriorityStandard), iBtSocket(aBtSocket), iObserver(aObserver) 
    {
	CActiveScheduler::Add(this);
	}

/*
============================================================================
CSocketWriter's destructor
============================================================================
*/
CSocketWriter::~CSocketWriter()
    {
    Cancel();
    }

/*
============================================================================
DoCancel is called as part of the active object's Cancel().
Cancels an outstanding BT socket write operation.
============================================================================
*/
void CSocketWriter::DoCancel()
    {
	iBtSocket.CancelWrite();
    }

/*
============================================================================
Handles the active object's writing data completion event.
On completion it calls the callback function MSocketWriterReaderObserver::WriteComplete
to notify the caller if the write was succesful
============================================================================
*/
void CSocketWriter::RunL()
	{
	iObserver.WriteComplete(iStatus.Int());
    }

/*
============================================================================
Asynchronous call to send data to the remote device.
Note that we handle only one event at a time. Data to write to the remote device
is not queued if an outstanding write operation is already in progress.
============================================================================
*/
TInt CSocketWriter::Write(const TDesC8& aBuf)
    {
	TInt err = KErrNone;

	if (!IsActive())
		{
		iBtSocket.Write(aBuf,iStatus);
		SetActive();
		}
	else
		{
		err = KErrInUse;
		}
	return(err);
    }

/*
============================================================================
Handles a leave occurring in the request completion event handler RunL().
============================================================================
*/
TInt CSocketWriter::RunError(TInt aError)
	{
	iObserver.WriteComplete(aError);
	return KErrNone;
	}
