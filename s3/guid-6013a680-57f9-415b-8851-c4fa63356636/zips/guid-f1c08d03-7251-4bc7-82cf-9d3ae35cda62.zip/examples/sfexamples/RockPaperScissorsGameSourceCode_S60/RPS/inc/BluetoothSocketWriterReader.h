/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CSocketReader is an active object responsible for listening for incoming data from
                    a remote BT device and notifying when the data arrives along with any connection error.
                    
                    CSocketWriter is an active object responsible for sending data to a remote BT device
                    and notifying when the sending data is completed along with any connection error.

*/ 
 


#ifndef __BLUETOOTHSOCKETWRITERREADER_H__
#define __BLUETOOTHSOCKETWRITERREADER_H__

// INCLUDES
#include <es_sock.h>
#include <in_sock.h>
#include "CommonInterfaces.h"


///////////////////////////////////////////////////////////////////////////////////
const TInt KReadBufferSize = 128;

// CLASS DECLARATION
/**
* CSocketReader
* Listens for incoming data
*/
class CSocketReader  : public CActive
	{
public:
	/**
	* Constructor
	* @aparam aBtSocket Client endpoint to the RFCOMM protocol
	* @aparam aObserver Interface to notify when data arrives
	*/
	CSocketReader(RSocket& aBtSocket, MSocketWriterReaderObserver& aObserver);
	
	/**
	* Destructor
	*/
	~CSocketReader();
	
	/**
	* Waits for incoming data
	*/
	void ReadData();
	
private: // from CActive
	/**
	* Cancels an outstanding BT socket read operation
	*/
	void DoCancel();
	
	/**
	* Called when data arrives
	*/
	void RunL();
	
	/**
	* Handles a leave occurring in the request completion event handler RunL()
	* @param aError	 The leave code
	* @return TInt	 The default implementation returns aError.A derived class implementation should return KErrNone,
	*				 if it handles the leave; otherwise it should return any suitable value to cause the handling
	*				 of the error to be propagated back to the active scheduler.
	*/
	virtual TInt RunError(TInt aError);

private:
	/**
	* Reference to the client endpoint of the RFCOMM protocol
	*/
	RSocket& iBtSocket;
	
	/**
	* Interface to notify when data arrives
	*/
	MSocketWriterReaderObserver& iObserver;
	
	/**
	* A length indicating how much data was read
	*/
    TSockXfrLength iLen;
    
	/**
	* Description containing the data arrived from the remote BT device 
	*/
	TBuf8<KReadBufferSize> iBuffer;
	};

///////////////////////////////////////////////////////////////////////////////////
// CLASS DECLARATION
/**
* CSocketWriter
* Send data to a remote BT device and wait for completion
*/
class CSocketWriter : public CActive
	{
public:
	/**
	* Constructor
	* @aparam aBtSocket Client endpoint to the RFCOMM protocol
	* @aparam aObserver Interface to notify when data arrives
	*/
	CSocketWriter(RSocket& aBtSocket, MSocketWriterReaderObserver& aObserver);
	
	/**
	* Destructor
	*/
	~CSocketWriter();
	
	/**
	* Writes data to a remote Bluetooth device
	*/
	TInt Write(const TDesC8& aBuf);
	

private: // from CActive
	/**
	* Cancels an outstanding BT socket write operation
	*/
	void DoCancel();
	
	/**
	* Handles sending data completion
	*/
	void RunL();
	
	/**
	* Handles a leave occurring in the request completion event handler RunL()
	* @param aError	 The leave code
	* @return TInt	 The default implementation returns aError.A derived class implementation should return KErrNone,
	*				 if it handles the leave; otherwise it should return any suitable value to cause the handling
	*				 of the error to be propagated back to the active scheduler.
	*/
	virtual TInt RunError(TInt aError);

private:
	/**
	* Reference to the client endpoint of the RFCOMM protocol
	*/
	RSocket& iBtSocket;
	
	/**
	* Interface to notify when sending data is completed
	*/
	MSocketWriterReaderObserver& iObserver;
	};

#endif  // __BLUETOOTHSOCKETWRITERREADER_H__
