/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 


// INCLUDE FILES

#include "BluetoothSockConnector.h"
#include "common.hrh"
/*
============================================================================
CBluetoothSockConnector's two stage constructor
============================================================================
*/
CBluetoothSockConnector* CBluetoothSockConnector::NewL(RSocket& aBtSocket, MSocketConnectorObserver& aSockConnObs, RSocketServ& aSocketServer)
	{
    CBluetoothSockConnector* self = new (ELeave) CBluetoothSockConnector(aBtSocket, aSockConnObs, aSocketServer);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop();
    return self;
	}

/*
============================================================================
CBluetoothSockConnector's costructor
============================================================================
*/
CBluetoothSockConnector::CBluetoothSockConnector(RSocket& aBtSocket, MSocketConnectorObserver& aSockConnObs, RSocketServ& aSocketServer)
	:CActive(CActive::EPriorityStandard), iBtSocket(aBtSocket), iSockConnObs(aSockConnObs), iSocketServer(aSocketServer)
	{
	CActiveScheduler::Add(this);
	}

/*
============================================================================
CBluetoothSockConnector's second phase constructor 
============================================================================
*/
void CBluetoothSockConnector::ConstructL()
	{	
	/*
	============================================================================
	Using the Socket Server we need to load the RFCOMM communication protocol.
	First of all we need to see if BT RFCOMM is supported.
	============================================================================
	*/
	TProtocolDesc pdesc;
	User::LeaveIfError(iSocketServer.FindProtocol(KBTRFCOMM(), pdesc));

	/*
	============================================================================
	Open the socket using BT RFCOMM
	============================================================================
	*/
	User::LeaveIfError(iBtSocket.Open(iSocketServer, KBTRFCOMM));
	}

/*
============================================================================
CBluetoothSockConnector's destructor
============================================================================
*/
CBluetoothSockConnector::~CBluetoothSockConnector()
	{
	Cancel();
	}

/*
============================================================================
DoCancel is called as part of the active object's Cancel().
Outstanding operations for a BT socket include: read, write, Ioctl, connect,
accept, shutdown and the Baseband event notifier. All of these operations will
be completed by this call
============================================================================
*/
void CBluetoothSockConnector::DoCancel()
	{
	iBtSocket.CancelAll();
	}

/*
============================================================================
Handles the active object's socket connection completion event 
============================================================================
*/
void CBluetoothSockConnector::RunL()
	{
	iSockConnObs.OnSockConnectionComplete(iStatus.Int());
	}

/*
============================================================================
Connect to the remote BT device on a given BT device address and on a given RFCOMM service's port
============================================================================
*/
void CBluetoothSockConnector::ConnectToRemoteBtDeviceL(const TBTDevAddr& aDevAddr, TInt aPort)
	{
	/*
	============================================================================
	Set the remote device address and service port using TBTSockAddr
	============================================================================
	*/
	iBtDevAddr.SetBTAddr(aDevAddr);
	iBtDevAddr.SetPort(aPort);
	
	/*
	============================================================================
	Connect the BT socket to the remote device.
	============================================================================
	*/
	iBtSocket.Connect(iBtDevAddr, iStatus);
	SetActive();
	}
	
/*
============================================================================
Handles a leave occurring in the request completion event handler RunL().
============================================================================
*/
TInt CBluetoothSockConnector::RunError(TInt aError)
	{
	iSockConnObs.OnSockConnectionComplete(aError);
	return KErrNone;
	}
