/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 


// INCLUDE FILES
#include <btextnotifiers.h>
#include "BluetoothDeviceDiscoverer.h"
#include "common.hrh"
/*
============================================================================
CBluetoothDeviceDiscoverer's two stage constructor
============================================================================
*/
CBluetoothDeviceDiscoverer* CBluetoothDeviceDiscoverer::NewL(MBluetoothDeviceDiscovererObserver& aObs)
	{
    CBluetoothDeviceDiscoverer* self = new (ELeave) CBluetoothDeviceDiscoverer(aObs);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop();
    return self;
	}

/*
============================================================================
CBluetoothDeviceDiscoverer's second phase constructor 
============================================================================
*/
void CBluetoothDeviceDiscoverer::ConstructL()
	{
	//Create an RNotifier object, and connect it with RNotifier::Connect()
	User::LeaveIfError(iBTDevicesNotifier.Connect()); 	
	}

/*
============================================================================
CBluetoothDeviceDiscoverer's constructor 
============================================================================
*/
CBluetoothDeviceDiscoverer::CBluetoothDeviceDiscoverer(MBluetoothDeviceDiscovererObserver& aObs) :
	CActive(CActive::EPriorityStandard), iObserver(aObs)
	{
	CActiveScheduler::Add(this);
	}

/*
============================================================================
CBluetoothDeviceDiscoverer's destructor
============================================================================
*/
CBluetoothDeviceDiscoverer::~CBluetoothDeviceDiscoverer()
	{
	Cancel();
	//After using a RNotifier object we need to close it.	
	iBTDevicesNotifier.Close();
	}
	
/*
============================================================================
DoCancel is called as part of the active object's Cancel().
Cancel the notifier.
============================================================================
*/
void CBluetoothDeviceDiscoverer::DoCancel()
	{
	//If the user dismisses the RNotifier's dialog without selecting any devices then we call
	//RNotifier::CancelNotifier with the same dialog UID (KDeviceSelectionNotifierUid) we used
	//in RNotifier::StartNotifierAndGetResponse.
	iBTDevicesNotifier.CancelNotifier(KDeviceSelectionNotifierUid);
	}


/*
============================================================================
Displays the BT devices in range for the player to choose from
============================================================================
*/
void CBluetoothDeviceDiscoverer::DiscoverAndSelectDeviceL(const TBTDeviceSelectionParamsPckg& aSelectionFilter)
	{
	if(IsActive())
		{	
		User::Leave(KErrInUse);
		}
	else
		{		
		//We ask RNotifier to start the search for other BT devices in range. Seraching for BT devices is done
		//asynchronously by calling RNotifier::StartNotifierAndGetResponse. Application can filter the search
		//of BT devices by passing a TBTDeviceSelectionParams wrapped in a TBTDeviceSelectionParamsPckg
		//pckg buffer. In our example we passed the UID of the authorisation plug-in (KDeviceSelectionNotifierUid)
		//that invokes the BT device selection dialog, the device and/or service classes by which to filter
		//suitable remote devices (RPS's service class KRPS_BTServiceID), a Bluetooth address object
		//that on completion of the dialog will hold information about the device the user selected in
		//a packaged TBTDeviceResponseParams.
		iBTDevicesNotifier.StartNotifierAndGetResponse(iStatus, KDeviceSelectionNotifierUid, aSelectionFilter, iResponse);
		SetActive();
		}
	}

/*
============================================================================
Handles CBluetoothConnector's completion events
============================================================================
*/
void CBluetoothDeviceDiscoverer::RunL()
	{
	//We pass on to the engine the BT device address the user selected otherwise we pass on the error
	if(iStatus.Int() == KErrNone)
		{
		iObserver.OnDeviceDiscoveryComplete(iResponse);
		}
	else
		{	
		iObserver.OnDeviceDiscoveryErr(iStatus.Int());	
		}
	}

/*
============================================================================
Handles a leave occurring in the request completion event handler RunL().
Reports the error to the observer
============================================================================
*/
TInt CBluetoothDeviceDiscoverer::RunError(TInt aError)
	{
	iObserver.OnDeviceDiscoveryErr(aError);
	return KErrNone;
	}
