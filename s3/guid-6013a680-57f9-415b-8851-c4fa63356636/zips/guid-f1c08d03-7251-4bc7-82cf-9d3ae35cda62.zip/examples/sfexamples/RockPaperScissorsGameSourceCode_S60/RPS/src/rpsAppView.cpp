/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

// INCLUDE FILES
#include <coemain.h>
#include "rpsAppView.h"
#include "common.hrh"
#include "rpsgamescreens.h"


// -----------------------------------------------------------------------------
// CRpsAppView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CRpsAppView* CRpsAppView::NewL(MAppViewObserver& aObs, const TRect& aRect)
	{
	CRpsAppView* self = CRpsAppView::NewLC(aObs, aRect);
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CRpsAppView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CRpsAppView* CRpsAppView::NewLC(MAppViewObserver& aObs, const TRect& aRect)
	{
	CRpsAppView* self = new ( ELeave ) CRpsAppView(aObs);
	CleanupStack::PushL( self );
	self->ConstructL(aRect);
	return self;
	}

// -----------------------------------------------------------------------------
// CRpsAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CRpsAppView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();

	SetRect( aRect );
	
	// Activate the window, which makes it ready to be drawn and starts the heartbeat
	ActivateL();
	}


// -----------------------------------------------------------------------------
// CRpsAppView::CRpsAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CRpsAppView::CRpsAppView(MAppViewObserver& aObs): iObs(aObs)
	{
	// No implementation required
	}


// -----------------------------------------------------------------------------
// CRpsAppView::~CRpsAppView()
// Destructor.
// -----------------------------------------------------------------------------
CRpsAppView::~CRpsAppView()
	{
	}

// -----------------------------------------------------------------------------
// CRpsAppView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CRpsAppView::SizeChanged()
	{  
	TRect rect(Rect());
	gScreenWidth = rect.Width();
	gScreenHeight = rect.Height();
	
	DrawNow();
	}

// --------------------------------------------------------------------------
// FocusChanged
// --------------------------------------------------------------------------
void CRpsAppView::FocusChanged(TDrawNow aDrawNow)
	{
	iObs.FocusChanged(IsFocused());
	
	if(aDrawNow)
		DrawNow();
	}


TKeyResponse CRpsAppView::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
	{
	TKeyResponse response = EKeyWasConsumed;
	TUint input = 0x00000000;

	switch (aKeyEvent.iScanCode)
		{
		case EStdKeyUpArrow: 	
			input = KControllerUp;
			break;
		case EStdKeyDownArrow: 
			input = KControllerDown;
			break;
		case EStdKeyDevice3:  
			input = KControllerCentre;
			break;
		case '5': 
			input = KKey5;
			break;
		default:
			response = EKeyWasNotConsumed;// Keypress was not handled
			break;
		}
	
	if (EEventKeyDown == aType)
		{
		iKeyState |= input; // set bitmask
		}
	else if (EEventKeyUp == aType)
		{
		iKeyState &= ~input; // clear bitmask
		}
	
	iObs.KeyEvent(iKeyState);
	
    return (response);
	}

// -----------------------------------------------------------------------------
// CRpsAppView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
void CRpsAppView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	gc.Clear( Rect() );
	
	iObs.DrawGameScreen();
	}


// End of File
