/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#include "rpsgameengine.h"
#include "common.hrh"

const TInt KPeriod = KOneSecondInMicroSeconds/30; 
const TTimeIntervalSeconds KInactivityTimeout = 30; // 30 seconds user inactivity timeout

class CInactivityTimer : public CTimer
	{
public:
	static CInactivityTimer* NewL(CRpsGameEngine& aGameEngine);
	void StartInactivityMonitor(TTimeIntervalSeconds aSeconds);
protected:
	CInactivityTimer(CRpsGameEngine& aRpsGameEngine);
	virtual void RunL();
private:
	CRpsGameEngine& iGameEngine;
	TTimeIntervalSeconds iTimeout;
	};
	
CInactivityTimer::CInactivityTimer(CRpsGameEngine& aRpsGameEngine)
: CTimer(EPriorityLow), iGameEngine(aRpsGameEngine)
	{
	CActiveScheduler::Add(this);
	}

CInactivityTimer* CInactivityTimer::NewL(CRpsGameEngine& aRpsGameEngine)
	{
	CInactivityTimer* me = new (ELeave) CInactivityTimer(aRpsGameEngine);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (me);
	}

void CInactivityTimer::StartInactivityMonitor(TTimeIntervalSeconds aSeconds)
	{
	if (!IsActive())
		{
		iTimeout = aSeconds;
		Inactivity(iTimeout);
		}
	}

void CInactivityTimer::RunL()
	{// Game has been inactive - no user input for iTimeout seconds
	iGameEngine.StopHeartbeat(ETrue); // Stops the game loop
	}


// ============================================================================
// CRpsGameEngine
// ============================================================================
CRpsGameEngine* CRpsGameEngine::NewL(MEngineObserver& aObs)
	{
	CRpsGameEngine* me = new (ELeave) CRpsGameEngine(aObs);
	CleanupStack::PushL(me);
	me->ConstructL();
	CleanupStack::Pop(me);
	return (me);
	}

/*
============================================================================
CRpsGameEngine's second phase constructor 
============================================================================
*/
void CRpsGameEngine::ConstructL()
	{
	// Game screen manager
	iGameScreenMgr = CGameScreenManager::NewL(*this);	
	// Create timer for game loop.
	iPeriodicTimer = CPeriodic::NewL(CActive::EPriorityStandard);
	// Create the inactivity timer
	iInactivity = CInactivityTimer::NewL(*this);
   	}

/*
============================================================================
CRpsGameEngine's constructor 
============================================================================
*/
CRpsGameEngine::CRpsGameEngine(MEngineObserver& aObs)
: 	iObs(aObs)
	{}

/*
============================================================================
CRpsGameEngine's destructor
============================================================================
*/
CRpsGameEngine::~CRpsGameEngine()
	{
	StopHeartbeat();
	delete iPeriodicTimer;
	
	if (iInactivity)
		{
		iInactivity->Cancel();
		delete iInactivity;
		}
	
	delete iGameScreenMgr;
	}

/*
============================================================================
Redraw the view every KPeriod and start monitoring the player inactivity.
============================================================================
*/
void CRpsGameEngine::StartHeartbeat()
	{
	if (!iPeriodicTimer->IsActive())
		iPeriodicTimer->Start(KPeriod, KPeriod, TCallBack(CRpsGameEngine::Tick, this));		
		
	iInactivity->StartInactivityMonitor(KInactivityTimeout); // Notify if inactive for KInactivityTimeout	
	}

/*
============================================================================
Called when the game loses focus, closes or inactivity timeout occurs
Called by the CRpsDestructor, so iPeriodicTimer pointer must be verified before use
============================================================================
*/
void CRpsGameEngine::StopHeartbeat(TBool aTimedOut /*=EFalse*/)
	{
	if (aTimedOut) 	// Only pause the game if a timeout 
		{	
		PauseGame(); // Pause the game
		}
	
	if (iPeriodicTimer)
		{
		if (iPeriodicTimer->IsActive())
			{
			iPeriodicTimer->Cancel();
			}
		}
	}

/*
============================================================================
Called by framework when application focus changes
============================================================================
*/
void CRpsGameEngine::FocusChanged(TBool aFocus)
	{
	if (aFocus)
		{// Focus gained
		StartHeartbeat();
		}
	else
		{// Focus lost
		StopHeartbeat();
		}
	}

/*
============================================================================
Handles key events
============================================================================
*/
void CRpsGameEngine::KeyEvent(TUint& aKeyState)
	{
	CGameScreen* gameScreen = iGameScreenMgr->GameScreen();
	ASSERT(gameScreen);
	gameScreen->ProcessInput(aKeyState);		
	}

/*
============================================================================
Kick off the drawing of the current screen
============================================================================
*/
void CRpsGameEngine::DrawGameScreen()
	{
	CGameScreen* gameScreen = iGameScreenMgr->GameScreen(); 
	ASSERT(gameScreen);
	gameScreen->DrawGameScreen();
	}
	
/*
============================================================================
Pause the game. The pause screen is displayed
============================================================================
*/
void CRpsGameEngine::PauseGame()
	{
	iGameScreenMgr->SetGameState(CGameScreenManager::EPausedScreen); // Switch on the pause screen
	iGameScreenMgr->GameData().iRpsError = KErrTimedOut;
	iObs.UpdateScreen();		
	}

/*
============================================================================
Restart the game after a pause
============================================================================
*/
void CRpsGameEngine::UnpauseGame()
	{// Start the game ticking again
	StartHeartbeat();
	}

// --------------------------------------------------------------------------
// Tick(TAny *aPtr)
// --------------------------------------------------------------------------
TInt CRpsGameEngine::Tick(TAny* aCallback)
	{
	ASSERT(aCallback);
	static_cast<CRpsGameEngine*>(aCallback)->GameLoop();

	// Returning a value of ETrue indicates the callback should be done again.
	return ETrue;
	}

// --------------------------------------------------------------------------
// GameLoop()
// --------------------------------------------------------------------------
void CRpsGameEngine::GameLoop()
	{
	iObs.UpdateScreen();
	}
