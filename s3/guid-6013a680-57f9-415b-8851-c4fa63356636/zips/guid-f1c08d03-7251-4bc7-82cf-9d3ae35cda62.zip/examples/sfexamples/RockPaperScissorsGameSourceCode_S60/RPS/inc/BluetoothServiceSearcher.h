/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CBluetoothServiceSearcher is responsible for finding out if a remote device supports
                    a specific BT service.
*/ 


#ifndef __BLUETOOTHSERVICESEARCHER_H__
#define __BLUETOOTHSERVICESEARCHER_H__

// INCLUDES
#include <e32base.h>
#include <bttypes.h>
#include <bt_sock.h>
#include <btsdp.h>
#include "BluetoothConnector.h"
#include "CommonInterfaces.h"


// CLASS DECLARATION
/**
* CBluetoothServiceSearcher
* Search for the presence of a specific BT service on a remote BT device
*/
class CBluetoothServiceSearcher : public CBase, public MSdpAgentNotifier, public MSdpAttributeValueVisitor
    {
public:
	/**
	* Constructor
	* @param aObs	Interface to report to the caller the service search status
	*/
    CBluetoothServiceSearcher(MBluetoothServiceSearcherObserver& aObs);
    
	/**
	* Destructor
	*/
	~CBluetoothServiceSearcher();
	
	/**
	* Retrives from a remote device a SDP's service record. On completion call NextRecordRequestComplete()
	* @param aTarget	The remote BT device address	
	* @param aUUID		The BT's service UUID (RPS's service UUID) 
	*/
	void FindServiceByUUIDL(const TBTDevAddr& aTarget,const TUUID& aUUID);

private:
	// from MSdpAgentNotifier
	/**
	* Called when a service record request (CSdpAgent::NextRecordRequestComplete()) operation completes
	* @param aError		KErrNone if successful; KErrEof if there are no more SDP records left to be read; or an SDP error			
	* @param aHandle	Service record for which the query was made				
	* @param aTotalRecordsCount		Total number of matching records 		
	*/
	virtual void NextRecordRequestComplete(TInt aError, TSdpServRecordHandle aHandle, TInt aTotalRecordsCount);
	
	/**
	* Called when an attribute request (CSdpAgent::AttributeRequestL()) wants to pass up a result
	* @param aHandle 	Service record for which the query was made	
	* @param aAttrID	ID of the attribute obtained
	* @param aAttrValue	Attribute value obtained
	*/
	virtual void AttributeRequestResult(TSdpServRecordHandle aHandle, TSdpAttributeID aAttrID, CSdpAttrValue* aAttrValue);
	
	/**
	* Called when an attribute request (CSdpAgent::AttributeRequestL()) wants to signal the completion of an attribute request
	* @param aHandle	Service record for which the query was made	
	* @param aError		An error	
	*/
	virtual void AttributeRequestComplete(TSdpServRecordHandle aHandle, TInt aError);
	
	//From MSdpAttributeValueVisitor
	/**
	* Called to pass an attribute value
	* @param aValue Attribute value
	* @param aType Value type
	*/
    void VisitAttributeValueL(CSdpAttrValue& aValue, TSdpElementType aType);
    
	/**
	* Called to indicate the start of a list of attribute values
	* @param aList Attribute value list
	*/
    void StartListL(CSdpAttrValueList& aList);
    
	/**
	* Called to indicate the end of a list of attribute values
	*/
    void EndListL();
    
private:
	/**
	* A reference to the Service Searcher Observer
	*/
	MBluetoothServiceSearcherObserver&	iObserver;
	
	/**
	* Makes Bluetooth service discovery protocol (SDP) requests to a remote BT device
	*/
	CSdpAgent* iAgent;
	
	/**
	* Holds a list of Universal Unique Identifiers (UUIDs), to be matched in SDP Service Search Requests
	*/
	CSdpSearchPattern* iSdpSearchPattern;
		
	/**
	* RFCOMM's port
	*/
	TInt iPort;
	
	/**
	* True if the record contains the RFCOMM attribute
	*/
	TBool iFoundRfcommProtocol;
	};


#endif //__BLUETOOTHSERVICESEARCHER_H__

