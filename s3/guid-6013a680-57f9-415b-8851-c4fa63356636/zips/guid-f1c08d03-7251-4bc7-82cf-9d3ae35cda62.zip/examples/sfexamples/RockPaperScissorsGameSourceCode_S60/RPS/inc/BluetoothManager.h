/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CRpsGameEngine is responsible for managing the Bluetooth piconet, updating the view,
             and controlling the logic of the game. CRpsGameEngine acts either as a Master or Slave.
             The connection between a Master and a Slave is represented by the CBluetoothConnector
             class while the Slave is represented by the CBluetoothResponder class.  

*/ 

#ifndef __RPSBLUETOOTHMANAGER_H__
#define __RPSBLUETOOTHMANAGER_H__

// INCLUDES
#include <bttypes.h> 
#include <es_sock.h>
#include <btdevice.h>
#include <bt_sock.h>
#include <btsdp.h>
#include <btmanclient.h>
#include <btextnotifiers.h>
#include "commoninterfaces.h"
#include "BluetoothResponder.h"

class CBluetoothDeviceDiscoverer;
class CBluetoothConnector;

class CBluetoothManager : public CBase, public MBluetoothDeviceDiscovererObserver,
										public MBluetoothObserver
	{
public:
	static CBluetoothManager* NewL(CGameScreenManager& aGameScreenMgr);
	~CBluetoothManager();
public:
	/**
	 * Called if the player has decided to control the game (Master role)
	 */
	void StartBtMaster();
	
	/**
	 * Called if the player has decided to wait for incoming connection (Slave role)
	 */
	void StartBtSlave();
	
	/**
	 * Send the player choice to the remote BT device
	 * @aparam aElement RPS's element
	 */
	void SendData(TRoshambo::TElement aElement);
	
	/**
	 * Quit the game
	 * @aparam aError KErrNone if the player decided to quit the game otherwise one of the system error
	 */
	void QuitMultiplayerGame();
	
	/**
	 * Called when the player that controls the game (Master role) decide to start the game
	 */
	void StartGame();
	
	/**
	 * Called when the player that controls the game (Master role) decide to start play again
	 */
	void ReplayGame();
	
	/**
	 * Query to see if the Connector/Responder are connected to the remote BT device
	 * @return ETrue if connected
	 */
	TBool Connected();
		
public:	//From MBluetoothDeviceDiscovererObserver,
	/**
	 * Callback from CBluetoothDeviceDiscoverer if an error occur during device discovering
	 * @param aError An error	 
	 */
	void OnDeviceDiscoveryErr(const TInt aError);
	
	/**
	 * RNotifier's callback
	 * aResponse Pckgbuf to retrieve the response from the device selection dialog via the Notifier framework
	 */
	void OnDeviceDiscoveryComplete(const TBTDeviceResponseParamsPckg& aResponse);
	
public:	//From MBluetoothObserver,
	/**
	 * Callback either from the Connector or Responder to report a connection error
	 * @param aConnHandle 	The handle of the Connector/Responder
	 * @param aError	An error		 
	 */
	void ConnectionErr(const TInt aConnHandle, const TInt aError);
	
	/**
	 * Callback either from the Connector or Responder to report incoming data from the remote BT device
	 * @param aConnHandle The handle of the Connector/Responder
	 * @param aData Description containing the data arrived from the remote BT device 
	 */
	void DataReceived(const TInt aConnHandle, const TDesC8& aData);
	
	/**
	 * Callback either from the Connector or Responder to report the sending data completion
	 * @param aConnHandle The handle of the Connector/Responder	
	 */
	void SendDataComplete(const TInt aConnHandle);

private:
	/**
	 * Utility function to display the RPS error to the player
	 */
	void DisplayError(const TInt aError);
	
	/**
	 * Creates and starts the bluetooth connection
	 */ 
	void StartConnectorL();
private: // Construction	
	
	CBluetoothManager(CGameScreenManager& aGameScreenMgr);
	
	void ConstructL();

private:
	/**
	* ETrue if the Connector/Responder are connected to the remote BT device 
	*/
	TBool iConnected;
	
	/**
	* Displays to the player the BT device in range to choose from
	*/
	CBluetoothDeviceDiscoverer* iBtDeviceDiscoverer;
	
	/**
	* The remote BT device address
	*/
	TBTDevAddr iBtDevAddr;
	
	/**
	* Class to allow parameters to be sent to the device selection dialog via the RNotifier API
	*/
	TBTDeviceSelectionParams iDevSelFilter;
	
	/**
	* A handle to an existing session on the socket server (ESock)
	*/
	RSocketServ iSocketServer;	
	
	/**
	* Connector/Responder base class pointer
	*/
	CBluetoothConnectionBase* iBtConnBase;
	
	/**
	* Game screen manager to call to update the screens
	*/
	CGameScreenManager& iGameScreenMgr;
	
	/**
	* Array of CBluetoothConnectionBase pointers. Not used in this example.
	* To be used in a multiplayer game with more then two players
	
	//RPointerArray<CBluetoothConnectionBase> iBtConnBaseArray;
	
	For example:
	TInt index = KErrNotFound;
	for(TInt i=0; i<iBtConnBaseArray.Count();i++)
	    {
	    if(iBtConnBaseArray[i]->Handle() == aConnHandle)
	        {
	        index = i;
	        }
	    }

	After executing the loop, if index is different to KErrNotFound, 
	we know that it was one of the connectors that called the callback 
	(if not, it was the Responder's handle). 
	
	When scaling the code for more than two players, it is important to note 
	the game should have a class that manages all the Connectors (i.e. CConnectionManager). 
	The CBluetoothManager class should own the CConnectionManager class.
	*/
	};

#endif // __RPSBLUETOOTHMANAGER_H__

// End of File
