/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 

#ifndef __COMMOMINTERFACES_H__
#define __COMMOMINTERFACES_H__

#include <e32cmn.h>
#include <bttypes.h>
#include <btextnotifiers.h>
#include <es_sock.h>
#include <bt_sock.h>


//INTERFACE DECLARATIONS

//===================================================================================
/**
* CBluetoothConnectionBase
* Virtual base class that wraps the common Connector/Responder's functionality
*/
class CBluetoothConnectionBase: public CActive
	{
public:
	/**
	* Destructor
	*/
	virtual ~CBluetoothConnectionBase();
	
	/**
	* Send the data to the remote BT device
	* @param aData	A descriptor for the data being sent to the remote BT device
	*/
	virtual void SendData(const TDesC8& aData)=0;
	
	/**
	* Kick off the state machine of the Connector/Responder
	*/
	virtual void StartL()=0;
	
	/**
	* Return the object handle
	* @return The object's handle
	*/
	inline TInt Handle() const {return iHandle;};
	
	/**
	* Query to find out if CBluetoothConnectionBase is either a Master or Slave
	* @return  Etrue if Master
	*/
	inline TBool Master() const {return iMaster;};
	
protected:
	/**
	* Constructor
	* @param aMaster ETrue if the derived class is a Connector
	*/
	CBluetoothConnectionBase(TBool aMaster);
	
protected:
	/**
	* Flag for querying if the object is a Master
	*/
	TBool iMaster;
	
	/**
	* Object's handle
	*/
	TInt iHandle;
	};

//===================================================================================

/**
* MBluetoothServiceSearcherObserver
* Interface for notifying service search events
*/
class MBluetoothServiceSearcherObserver
	{
public:
	/**
	* Callback to notify the caller the completion of the service search.
	* @param aPort	 On succesfull return the RFCOMM's port to use
	* @param aError	 KErrNone if succesfull, otherwise one of the system errors
	*/
	virtual void OnServiceSearchComplete(TInt aPort, TInt aError)=0;
	};

//===================================================================================

/**
* MSocketConnectorObserver
* Iterface for notifying connection event
*/
class MSocketConnectorObserver
	{
public:
	/**
	* Callback to notify the caller the completion of the connection to the remote BT device
	* @param aError	 KErrNone if succesfull, otherwise one of the system errors
	*/
	virtual void OnSockConnectionComplete(TInt aError)=0;
	};

//===================================================================================
	
/**
* MBluetoothConnectorObserver
* Interface for notifying to the status of the connection to the remote BT device
* and to notify incoming/sending data completion 
*/
class MBluetoothObserver
	{
public:
	/**
	* Report any connection error
	* @param aConnHandle 	The handle of the Connector/Responder
	* @param aError	 An error
	*/
	virtual void ConnectionErr(const TInt aConnHandle, const TInt aError)=0;
	
	/**
	* Notify when data arrives from the remote BT device
	* @param aConnHandle The handle of the Connector/Responder
	* @param aData Description containing the data arrived from the remote BT device 
	*/
	virtual void DataReceived(const TInt aConnHandle, const TDesC8& aData)=0;
	
	/**
	* Notify when the sending data to the remote BT device is succesfull
	* @param aConnHandle The handle of the Connector/Responder	
	*/
	virtual void SendDataComplete(const TInt aConnHandle)=0;
	};

//===================================================================================

/**
* MBluetoothDeviceDiscovererObserver
* Interface for notifying the remote BT device's address selected by the user using the RNotifier
*/
class MBluetoothDeviceDiscovererObserver
	{
public:
	/**
	* Notify any error during device discovering
	* @param aError An error
	*/
	virtual void OnDeviceDiscoveryErr(const TInt aError)=0;
	
	/**
	* Call when the user selects a BT device in range
	* @param aResponse Pckgbuf to retrieve the response from the device selection dialog via the Notifier framework
	*/
	virtual void OnDeviceDiscoveryComplete(const TBTDeviceResponseParamsPckg& aResponse)=0;
	};

//===================================================================================

/**
* MBluetoothServiceAdvertiserObserver
* Interface for notifying when a service advertising is completed
*/
class MBluetoothServiceAdvertiserObserver
	{
public:
	/**
	* Report any error during service advertising
	* @param aError An error
	*/
	virtual void ReportAdvertiserErr(TInt aError)=0;
	
	/**
	* Service advertising completed succesfully
	*/
	virtual void AdvertiserComplete()=0;
	};

//===================================================================================

/**
* MSocketWriterReaderObserver
* Interface for sending/receiveing data completion
*/
class MSocketWriterReaderObserver
	{
public:
	/**
	* Sending data completed
	* @param aError An error
	*/
	virtual void WriteComplete(TInt aError)=0;
	
	/**
	* Notify the data arrived from the remote BT device 
	* @param aData A descriptor for the data being received from the remote BT device
	* @param aError An error
	*/
	virtual void ReportData(const TDesC8& aData, TInt aError)=0;
	};

//===================================================================================
#endif // __COMMOMINTERFACES_H__
