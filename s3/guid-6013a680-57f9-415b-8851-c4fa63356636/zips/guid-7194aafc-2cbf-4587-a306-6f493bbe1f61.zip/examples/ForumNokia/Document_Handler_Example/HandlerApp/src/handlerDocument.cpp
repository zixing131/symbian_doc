/*
 * Copyright (c) 2005-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
 *    
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of Nokia Corporation nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *    
 *    Description:  
 */

#include "handlerAppUi.h"
#include "handlerDocument.h"
#include "Common.h"

#include <f32file.h>
#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>
#include <apparc.h>
#include <eikproc.H>
#include <apgwgnam.h> //Link against: apgrfx.lib
#include <avkon.hrh>
#include <aknnotewrappers.h>

CHandlerDocument* CHandlerDocument::NewL(CEikApplication& aApp)
    {
    CHandlerDocument* self = NewLC(aApp);
    CleanupStack::Pop(self);
    return self;
    }

CHandlerDocument* CHandlerDocument::NewLC(CEikApplication& aApp)
    {
    CHandlerDocument* self = new (ELeave) CHandlerDocument(aApp);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

void CHandlerDocument::ConstructL()
    {
    // no implementation required
    }

CHandlerDocument::CHandlerDocument(CEikApplication& aApp) : CAknDocument(aApp)
    {
    // no implementation required
    }

CHandlerDocument::~CHandlerDocument()
    {
    // no implementation required
    }

CEikAppUi* CHandlerDocument::CreateAppUiL()
    {
    // Create the application user interface, and return a pointer to it,
    // the framework takes ownership of this object
    iAppUi = new (ELeave) CHandlerAppUi;
    return iAppUi;
    }

CFileStore* CHandlerDocument::OpenFileL( TBool aDoOpen, const TDesC& aFilename, RFs& aFs )
    {
    if (aDoOpen)
        {
        TFileName name = aFilename;
        if( iFileName == name ) //The same file, do nothing
            {
            return NULL;   
            }
        iFileName = name;
        CHandlerAppUi *appui = static_cast<CHandlerAppUi *> (iAppUi);
        TBuf8<KTextLengthToRead> buf;

        RFile file;
        
        TInt err = file.Open(aFs, aFilename, EFileRead|EFileShareAny); 
        if( err == KErrNone )
            {
            CleanupClosePushL(file);
            User::LeaveIfError( file.Read(buf,KTextLengthToRead) );
            CleanupStack::PopAndDestroy();//file
            }
        appui->SetFileData(iFileName, buf);
        }
    
    return NULL;
    }

void CHandlerDocument::OpenFileL(CFileStore*& aFileStore, RFile& aFile)
    {
    aFileStore = NULL; //So the other OpenFileL version is not called

    TFileName name;
    #ifdef __SERIES60_3X__
        aFile.Name(name);
        //aFile.FullName(name); //If the location is required
    #endif
    //This function is never used in 1st or 2nd edition,
    //so the RFile::Name function is always executed.
    //That way we know that name variable contains aFile name.
    if( iFileName == name)
        {
        return;
        }
    iFileName = name;
    
    TBuf8<KTextLengthToRead> buf;
    User::LeaveIfError( aFile.Read(buf,KTextLengthToRead) );
    CHandlerAppUi *appui = static_cast<CHandlerAppUi *> (iAppUi);
    appui->SetFileData(iFileName, buf);
    }
