/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� CGfxWorkbenchAppUi implementation
*/


// INCLUDE FILES
#include <avkon.hrh>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <GfxWorkbench.rsg>
#include <f32file.h>
#include <s32file.h>

#include "GfxWorkbench.pan"
#include "GfxWorkbenchAppUi.h"
#include "GfxWorkbenchAppView.h"
#include "GfxWorkbench.hrh"
#include "GfxVideoPlayer.h"
#include "GfxDirectScreenView.h"
#include "GfxDirectScreenBitmapView.h"
#include "GfxBitBlitView.h"
#include "GfxIclview.h"

_LIT( KFileName, "C:\\private\\E2E23815\\GfxWorkbench.txt" );
_LIT( KText, "GFX Demo");

// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// CGfxWorkbenchAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CGfxWorkbenchAppUi::ConstructL()
	{
	// Initialise app UI with standard value.
	BaseConstructL(CAknAppUi::EAknEnableSkin);

	// Create view object
	iAppView = CGfxWorkbenchAppView::NewL( ClientRect() );
	}
// -----------------------------------------------------------------------------
// CGfxWorkbenchAppUi::CGfxWorkbenchAppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CGfxWorkbenchAppUi::CGfxWorkbenchAppUi()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CGfxWorkbenchAppUi::~CGfxWorkbenchAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CGfxWorkbenchAppUi::~CGfxWorkbenchAppUi()
	{
	ClearView();
	
	delete iAppView,iAppView = NULL;

	}

// -----------------------------------------------------------------------------
// CGfxWorkbenchAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CGfxWorkbenchAppUi::HandleCommandL( TInt aCommand )
	{
	switch( aCommand )
		{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;

		case ECommand1:
			{
			CmdDirectScreenL();
			}
			break;
		case ECommand2:
			{
			CmdDirectScreenBitmapL();
			}
			break;
		case ECommand3:
			{
			CmdPlayVideoL();
			}
			break;
		case ECommand4:
			CmdProfileBitBlitL();
			break;
		case ECommand5:
			CmdIclL();
			break;
		case ECommand6:
			CmdDirectScreenGcL();
			break;
			
		default:
			Panic( EGfxWorkbenchUi );
			break;
		}
	}

void CGfxWorkbenchAppUi::CmdPlayVideoL()
	{
	SetOrientationL(CAknAppUi::EAppUiOrientationLandscape);
	      
	ClearView();
	iVideoControl = CVideoPlayerControl::NewL(ClientRect());
	iVideoControl->StartL();
	}

void CGfxWorkbenchAppUi::CmdDirectScreenL()
	{
	ClearView();
	iDirectScreenView = CGfxDirectScreenView::NewL(ClientRect());
	iDirectScreenView->StartL(EFalse);
	}

void CGfxWorkbenchAppUi::CmdDirectScreenGcL()
	{
	ClearView();
	iDirectScreenView = CGfxDirectScreenView::NewL(ClientRect());
	iDirectScreenView->StartL(ETrue);
	}

void CGfxWorkbenchAppUi::CmdDirectScreenBitmapL()
	{
	ClearView();
	iDirectBitmapView = CGfxDirectScreenBitmapView::NewL(ClientRect());
	iDirectBitmapView->StartL();
	}

void CGfxWorkbenchAppUi::ClearView()
	{
	delete iDirectBitmapView,iDirectBitmapView=NULL;
	delete iDirectScreenView, iDirectScreenView=NULL;
	delete iVideoControl, iVideoControl=NULL;
	delete iBitBlitView, iBitBlitView=NULL;
	delete iIclView, iIclView=NULL;
	}

void CGfxWorkbenchAppUi::CmdProfileBitBlitL()
	{
	ClearView();
	iBitBlitView = CGfxBitBlitView::NewL(ClientRect());
	iBitBlitView->StartL();
	}

void CGfxWorkbenchAppUi::CmdIclL()
	{
	ClearView();
	iIclView = CGfxIclView::NewL(ClientRect());
	iIclView->StartL();
	}
	

// -----------------------------------------------------------------------------
//  Called by the framework when the application status pane
//  size is changed.  Passes the new client rectangle to the
//  AppView
// -----------------------------------------------------------------------------
//
void CGfxWorkbenchAppUi::HandleStatusPaneSizeChange()
	{
	iAppView->SetRect( ClientRect() );
	} 

// End of File
