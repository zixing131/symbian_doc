/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 
#include "CGfxDirectAccess.h"
#include <coemain.h>
#include <cdsb.h>
#include <hal.h>
#include <hal_data.h>

const TInt KFrameIntervalInMicroSecs = 1000000/60; // 1 second divided by desired frame rate

CGfxDirectAccess::CGfxDirectAccess(RWsSession& aClient, 
        RWindow& aWindow, const TRect& aDsaRect, TBool aGcDrawMode):
        CTimer(CActive::EPriorityStandard),
        iClient(aClient),
        iWindow(aWindow),
        iDsaRect(aDsaRect), iGcDrawMode(aGcDrawMode)
	{
	}


/*
 * SetupScreenDataL - Populate the iScreenData with direct screen buffer access
 * informaton from RHardwareBitmap(if supported on handset) or from HAL otherwise
 * */
void CGfxDirectAccess::SetupScreenDataL()
	{
	Mem::FillZ(&iScreenData, sizeof(iScreenData));	
	
	RHardwareBitmap hwBmp = iDirectScreenAccess->ScreenDevice()->HardwareBitmap();
	TAcceleratedBitmapInfo bmpInfo;
	hwBmp.GetInfo(bmpInfo);
	
	// If the platform supports s/w accessable hardware bitmap for the screen then use it
	// othewise get the values directly from the HAL
	if(hwBmp.iHandle && (bmpInfo.iSize.iWidth!=0) )
		{
		iScreenData.iDisplayMemoryAddress = (int)bmpInfo.iAddress;
		iScreenData.iDisplayOffsetToFirstPixel = 0;
		iScreenData.iDisplayXPixels = bmpInfo.iSize.iWidth;
		iScreenData.iDisplayYPixels = bmpInfo.iSize.iHeight;
		iScreenData.iDisplayBitsPerPixel = 1 << bmpInfo.iPixelShift;
		iScreenData.iDisplayOffsetBetweenLines = bmpInfo.iLinePitch;
		}
	else
		{		
		// When calling HAL::Get() The Displaymode much be set as the incoming paramater for
		// all other values to return correct figures
		// The display mode is used to retrieve all the other params 
		
		TInt err=0;
		err = HAL::Get(HALData::EDisplayMode, iScreenData.iDisplayMode);
		User::LeaveIfError(err);
		
		iScreenData.iDisplayOffsetToFirstPixel = iScreenData.iDisplayMemoryAddress = iScreenData.iDisplayXPixels = iScreenData.iDisplayYPixels = iScreenData.iDisplayOffsetBetweenLines = iScreenData.iDisplayBitsPerPixel = iScreenData.iDisplayMode;
		User::LeaveIfError( HAL::Get(HALData::EDisplayMemoryAddress, iScreenData.iDisplayMemoryAddress));
		User::LeaveIfError( HAL::Get(HALData::EDisplayOffsetToFirstPixel, iScreenData.iDisplayOffsetToFirstPixel));
		iScreenData.iDisplayMemoryAddress+=iScreenData.iDisplayOffsetToFirstPixel;
		
		User::LeaveIfError( HAL::Get(HALData::EDisplayXPixels, iScreenData.iDisplayXPixels));
		User::LeaveIfError( HAL::Get(HALData::EDisplayYPixels, iScreenData.iDisplayYPixels));
		User::LeaveIfError( HAL::Get(HALData::EDisplayOffsetBetweenLines, iScreenData.iDisplayOffsetBetweenLines));
		User::LeaveIfError( HAL::Get(HALData::EDisplayBitsPerPixel, iScreenData.iDisplayBitsPerPixel));    
		User::LeaveIfError( HAL::Get(HALData::EDisplayIsPixelOrderLandscape, iScreenData.iDisplayIsPixelOrderLandscape));    
		}
	
	}

void CGfxDirectAccess::ConstructL()
    {
    CTimer::ConstructL();
    // Create the DSA object
    iDirectScreenAccess = CDirectScreenAccess::NewL(
        iClient,                // WS session
        *(CCoeEnv::Static()->ScreenDevice()),        // CWsScreenDevice
        iWindow,                // RWindowBase
        *this                   // MDirectScreenAccess
        );

    CActiveScheduler::Add(this);
    }

CGfxDirectAccess::~CGfxDirectAccess()
	{
	Cancel();
	delete iDirectScreenAccess;
	}

	
   // Implement MDirectScreenAccess
void CGfxDirectAccess::Restart(RDirectScreenAccess::TTerminationReasons /*aReason*/)
	{
	/* Restart only if we are drawing in a mode which supports clipping */
	if(iGcDrawMode)
		{
		TRAPD(err, StartL());
		}
	}

void CGfxDirectAccess::AbortNow(RDirectScreenAccess::TTerminationReasons /*aReason*/)
	{
	Cancel();
	}

/*
 * ProcessFrameWritePixels - Draw animated red horizontal bars using screen buffer
 */
void CGfxDirectAccess::ProcessFrameWritePixels()
	{
	
	TUint32* screenAddress = (TUint32*)(iScreenData.iDisplayMemoryAddress);
	
	const TInt limitX = iDsaRect.Width();
	const TInt limitY = iDsaRect.Height();

	const TInt rowWidthInBytes = iScreenData.iDisplayOffsetBetweenLines;
	const TInt strideInWords = rowWidthInBytes/4;
	
	TUint32* lineAddress = screenAddress;
	lineAddress += (strideInWords*iDsaRect.iTl.iY);

	for(TInt y=0; y<limitY ; y++)
		{
		TUint32* p = lineAddress + iDsaRect.iTl.iX;
		for(TInt x=0; x<limitX; x++)
			{
			TRgb rgb((y+iFrameCounter)%64 << 2,0,0); /* Vary the Red component paramater */
			*(p++)=rgb._Color16MU();
			}
		lineAddress += strideInWords;
		}	
	}

/*
 * ProcessFrameGc - Draw animated green vertical bars using screen GC
 */
void CGfxDirectAccess::ProcessFrameGc()
	{
	CBitmapContext* gc = iDirectScreenAccess->Gc();
	TPoint p1(0,0);
	TPoint p2(0,iDsaRect.Height());
	
	for(TInt x=0; x<=iDsaRect.Width(); x++)
		{
		TRgb penColor(0,(x+iFrameCounter)%64 << 2,0);
		gc->SetPenColor(penColor);
		gc->DrawLine(p1,p2);
		p1+=TPoint(1,0);
		p2+=TPoint(1,0);
		}
	}

void CGfxDirectAccess::RunL()
	{	
	if(iGcDrawMode)
		ProcessFrameGc();
	else
		{
		ProcessFrameWritePixels();
		}
	EndDraw();
	
	iFrameCounter++;
	
    After(TTimeIntervalMicroSeconds32(KFrameIntervalInMicroSecs));
	}

void CGfxDirectAccess::DoCancel()
	{
    // Cancel timer
    CTimer::DoCancel();
    // Cancel DSA
    iDirectScreenAccess->Cancel();	
	}

void CGfxDirectAccess::EndDraw()
	{
	TRect rect(iDsaRect);
	
	// On older Nokia phones (e.g E61) The update region needs to be flipped if this flag is set
	if(iScreenData.iDisplayIsPixelOrderLandscape)
		rect.SetRect(TPoint(iDsaRect.iTl.iY,iDsaRect.iTl.iX), TPoint(iDsaRect.iBr.iY,iDsaRect.iBr.iX)  );
	
	TRegionFix<1> reg(rect);
	iDirectScreenAccess->ScreenDevice()->Update(reg);
    iClient.Flush();
	}

/*
 * LogCapsL - Debug function to write the graphics capabilities of a handset to a file
 * Logs information about DSA session, HAL attributes and RHarwareBitmap
 */
void CGfxDirectAccess::LogCapsL()
	{
	
	RFs session;
	User::LeaveIfError(session.Connect());
	CleanupClosePushL(session);

	RFile file;
	TBuf8<255> out;
	(void)session.MkDirAll(_L("c:\\data\\other\\"));
	User::LeaveIfError(file.Replace(session, _L("c:\\data\\other\\DSA.txt"),EFileWrite ));
	file.Write(_L8("DSA\n"));
    
	SScreenData sd;
	Mem::FillZ(&sd,sizeof(sd));

	TInt err = 0;  
  	
	err = HAL::Get(HALData::EDisplayMode, sd.iDisplayMode);
	out.Format(_L8("%D\tEDisplayMode\t%D\n"), err,sd.iDisplayMode);
	file.Write(out);
	
	sd.iDisplayMemoryAddress = sd.iDisplayMode;
    err = HAL::Get(HALData::EDisplayMemoryAddress, sd.iDisplayMemoryAddress);
	out.Format(_L8("%D\tEDisplayMemoryAddress\t%D\n"), err,sd.iDisplayMemoryAddress);
	User::LeaveIfError(file.Write(out));
	
	sd.iDisplayOffsetToFirstPixel = sd.iDisplayMode;
    err = HAL::Get(HALData::EDisplayOffsetToFirstPixel, sd.iDisplayOffsetToFirstPixel);
	out.Format(_L8("%D\tEDisplayOffsetToFirstPixel\t%D\n"), err,sd.iDisplayOffsetToFirstPixel);
	User::LeaveIfError(file.Write(out));

    err = HAL::Get(HALData::EDisplayXPixels, sd.iDisplayXPixels);
	out.Format(_L8("%D\tEDisplayXPixels\t%D\n"), err,sd.iDisplayXPixels);
	User::LeaveIfError(file.Write(out));

    err = HAL::Get(HALData::EDisplayYPixels, sd.iDisplayYPixels);
	out.Format(_L8("%D\tEDisplayYPixels\t%D\n"), err,sd.iDisplayYPixels);
	User::LeaveIfError(file.Write(out));

	sd.iDisplayOffsetBetweenLines = sd.iDisplayMode;
    err = HAL::Get(HALData::EDisplayOffsetBetweenLines, sd.iDisplayOffsetBetweenLines);
	out.Format(_L8("%D\tEDisplayOffsetBetweenLines\t%D\n"), err,sd.iDisplayOffsetBetweenLines);
	User::LeaveIfError(file.Write(out));

	sd.iDisplayBitsPerPixel = sd.iDisplayMode;
    err = HAL::Get(HALData::EDisplayBitsPerPixel, sd.iDisplayBitsPerPixel);    
	out.Format(_L8("%D\tEDisplayBitsPerPixel\t%D\n"), err,sd.iDisplayBitsPerPixel);
	User::LeaveIfError(file.Write(out));

	TInt numScreens;
    err = HAL::Get(HALData::EDisplayNumberOfScreens, numScreens);    
	out.Format(_L8("%D\tEDisplayNumberOfScreens\t%D\n"), err,numScreens);
	User::LeaveIfError(file.Write(out));
	
	TInt rgbOrder;
    err = HAL::Get(HALData::EDisplayIsPixelOrderRGB, rgbOrder);    
	out.Format(_L8("%D\tEDisplayIsPixelOrderRGB\t%D\n"), err,rgbOrder);
	User::LeaveIfError(file.Write(out));

	TInt lanscape;
    err = HAL::Get(HALData::EDisplayIsPixelOrderLandscape, lanscape);    
	out.Format(_L8("%D\tDisplayIsPixelOrderLandscape\t%D\n"), err,lanscape);
	User::LeaveIfError(file.Write(out));

	out.Format(_L8("DSA RECT\t(%D,%D,%D,%D)\n"), 
			iDsaRect.iTl.iX,
			iDsaRect.iTl.iY,
			iDsaRect.iBr.iX,
			iDsaRect.iBr.iY);
	
	User::LeaveIfError(file.Write(out));
	
	RHardwareBitmap hwBmp = iDirectScreenAccess->ScreenDevice()->HardwareBitmap();
	
	out.Format(_L8("RHardwareBitmap handle = \t%D\n"), hwBmp.iHandle);
	User::LeaveIfError(file.Write(out));
	if(hwBmp.iHandle)
		{
		TAcceleratedBitmapInfo bmpInfo;
		hwBmp.GetInfo(bmpInfo);
		
		out = _L8("RHardwareBitmap\n");
		
		out.Format(_L8("RHardwareBitmap\t%D\n"), bmpInfo.iAddress);
		User::LeaveIfError(file.Write(out));

		out.Format(_L8("RHardwareBitmap Size\t%D,%D\n"), bmpInfo.iSize.iWidth, bmpInfo.iSize.iHeight);
		User::LeaveIfError(file.Write(out));
	
		out.Format(_L8("RHardwareBitmap Line Pitch\t%D\n"),bmpInfo.iLinePitch);
		User::LeaveIfError(file.Write(out));

		out.Format(_L8("RHardwareBitmap Pixel Shift\t%D\n"),bmpInfo.iPixelShift);
		User::LeaveIfError(file.Write(out));
		}
	
	file.Flush();
	file.Close();

	CleanupStack::PopAndDestroy(&session);
	}

void CGfxDirectAccess::StartL()
    {
    // Initialise DSA
    iDirectScreenAccess -> StartL();
    
    // This example is hard coded for 24bpp display
    if(iDirectScreenAccess->ScreenDevice()->DisplayMode16M()==ENone)
    	{
    	User::LeaveIfError(KErrNotSupported);
    	}
    
    // The following is very useful for debugging different hardware
    LogCapsL();
    
    //
	SetupScreenDataL();
	
	After(TTimeIntervalMicroSeconds32(KFrameIntervalInMicroSecs));
    }

