/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� Application view implementation
*/


// INCLUDE FILES
#include <GDI.H>
#include <coemain.h>
#include <EIKENV.H>
#include "GfxIclView.h"
#include <ImageConversion.h>



class CGfxImageDecoder : public CActive
	{
public:
	CGfxImageDecoder(CFbsBitmap* aBitmap, CFbsBitmap* aMask, MGfxImageDecoderHandler& aHandler);
	~CGfxImageDecoder();

	void LoadImageL(const TDesC& aFilename);
	void RunL()	;
	void DoCancel();

private:	
	CImageDecoder* iDecoder; 
	CFbsBitmap*		iBitmap;
	MGfxImageDecoderHandler& iHandler;
	RFs iFs;
	};
	
// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CGfxIclView* CGfxIclView::NewL( const TRect& aRect )
	{
	CGfxIclView* self = CGfxIclView::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CGfxIclView* CGfxIclView::NewLC( const TRect& aRect )
	{
	CGfxIclView* self = new ( ELeave ) CGfxIclView;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CGfxIclView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();

	// Set the windows size
	SetRect( aRect );


	// Activate the window, which makes it ready to be drawn
	ActivateL();
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::CGfxDirectScreenBitmapView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CGfxIclView::CGfxIclView()
	{
	// No implementation required
	}


// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::~CGfxDirectScreenBitmapView()
// Destructor.
// -----------------------------------------------------------------------------
//
CGfxIclView::~CGfxIclView()
	{
	delete iImageDecoder;
	delete iLoadingBmp;
	delete iBitmap;
	}


// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CGfxIclView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();

	// Gets the control's extent
	TRect drawRect( Rect());

	// Clears the screen
	gc.Clear( drawRect );

	// If the bitmap has fully loaded, then draw it
	if(iBitmap)
		{
		gc.BitBlt(TPoint(0,0), iBitmap);
		}
	
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CGfxIclView::SizeChanged()
	{  
	DrawNow();
	}
// End of File




CGfxImageDecoder::CGfxImageDecoder(CFbsBitmap* aBitmap, CFbsBitmap* /*aMask*/, MGfxImageDecoderHandler& aHandler):
	CActive(0),
	iBitmap(aBitmap),
	iHandler(aHandler)
	{
	CActiveScheduler::Add(this);
	}

CGfxImageDecoder::~CGfxImageDecoder()
	{
	Cancel();
	iFs.Close();
	delete iDecoder;
	}


void CGfxImageDecoder::RunL()
	{
	iHandler.GfxImageLoadedCallBack(iStatus.Int());
	}	

void CGfxImageDecoder::DoCancel()
	{
	iDecoder->Cancel();
	}	

void CGfxImageDecoder::LoadImageL(const TDesC& aFilename)
	{

	User::LeaveIfError(iFs.Connect());
	
	iDecoder = CImageDecoder::FileNewL(iFs, aFilename);
	TFrameInfo info = iDecoder->FrameInfo();
	
	User::LeaveIfError( iBitmap->Create(info.iOverallSizeInPixels, info.iFrameDisplayMode) );

	iDecoder->Convert(&iStatus, *iBitmap);
	SetActive();
	}
	

void CGfxIclView::GfxImageLoadedCallBack(TInt /*aError*/)
	{
	iBitmap = iLoadingBmp;
	iLoadingBmp = NULL;
	
	DrawNow();
	}

void CGfxIclView::StartL()
	{
	iLoadingBmp = new(ELeave) CFbsBitmap();
	iImageDecoder = new(ELeave) CGfxImageDecoder(iLoadingBmp, NULL, *this);
	iImageDecoder->LoadImageL(_L("c:\\data\\images\\robot.bmp"));
	}
	
void CGfxIclView::StopL()
	{
	}
