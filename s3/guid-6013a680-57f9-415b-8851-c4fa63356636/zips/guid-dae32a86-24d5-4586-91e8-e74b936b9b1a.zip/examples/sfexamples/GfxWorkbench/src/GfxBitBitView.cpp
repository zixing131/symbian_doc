/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� Application view implementation
*/ 


// INCLUDE FILES
#include <GDI.H>
#include <coemain.h>
#include <EIKENV.H>
#include "GfxBitBlitView.h"
#include "GfxVideoPlayer.h"
#include "hal.h"
#include "CGfxTimer.h"

const TInt KNumberOfTests = 12;
const TInt KNumOfBlits = 1000;
const TTimeIntervalMicroSeconds32 KProfileYieldInMicroSeconds = 1000000/20;

_LIT(KLogFileDir, "c:\\data\\other\\");
_LIT(KLogFileName, "c:\\data\\other\\bitblit.txt");

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CGfxBitBlitView* CGfxBitBlitView::NewL( const TRect& aRect )
	{
	CGfxBitBlitView* self = CGfxBitBlitView::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CGfxBitBlitView* CGfxBitBlitView::NewLC( const TRect& aRect )
	{
	CGfxBitBlitView* self = new ( ELeave ) CGfxBitBlitView;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CGfxBitBlitView::ConstructL( const TRect& aRect )
	{
	// Create a window for this application view
	CreateWindowL();

	// Set the windows size
	SetRect( aRect );

	iTimer = new(ELeave) CGfxTimer(*this, 0);
	iTimer->ConstructL();
	
	// Activate the window, which makes it ready to be drawn
	ActivateL();
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::CGfxDirectScreenBitmapView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CGfxBitBlitView::CGfxBitBlitView()
	{
	}


// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::~CGfxDirectScreenBitmapView()
// Destructor.
// -----------------------------------------------------------------------------
//
CGfxBitBlitView::~CGfxBitBlitView()
	{
	delete iTimer;
	CloseLogFile();
	}


// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CGfxBitBlitView::Draw( const TRect& /*aRect*/ ) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();

	// Gets the control's extent
	TRect drawRect( Rect());

	// Clears the screen
	gc.Clear( drawRect );
	}

// -----------------------------------------------------------------------------
// CGfxDirectScreenBitmapView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CGfxBitBlitView::SizeChanged()
	{  
	DrawNow();
	}
// End of File

CFbsBitmap* BitmapForDepthL(TDisplayMode aDisplayMode, TSize aSize)
	{
	CFbsBitmap* offScreenBitmap = new (ELeave) CFbsBitmap();
	CleanupStack::PushL(offScreenBitmap);
	User::LeaveIfError(offScreenBitmap->Create(aSize,aDisplayMode));
	
	// create an off-screen device and context
	CGraphicsContext* bitmapContext=NULL;
	CFbsBitmapDevice* bitmapDevice = CFbsBitmapDevice::NewL(offScreenBitmap);
	CleanupStack::PushL(bitmapDevice);
	User::LeaveIfError(bitmapDevice->CreateContext(bitmapContext));
	CleanupStack::PushL(bitmapContext);
	
	bitmapContext->SetBrushColor(KRgbRed);
	bitmapContext->SetBrushStyle(CGraphicsContext::ESolidBrush);
	//bitmapContext->Clear();
	
	CleanupStack::PopAndDestroy(2);
	CleanupStack::Pop(offScreenBitmap);
	return offScreenBitmap;
	}

void CGfxBitBlitView::StartL()
	{
	iCurrentTest = 0;
	CreateLogFileL();
	iTimer->Start(KProfileYieldInMicroSeconds);
	}

void CGfxBitBlitView::GfxTimerFiredL(TInt /*aId*/)
	{
	ProfileBitBlitL(iCurrentTest);
	
	iCurrentTest++;
	if(iCurrentTest<KNumberOfTests)
		{
		iTimer->Start(KProfileYieldInMicroSeconds);
		}
	else
		{
		iEikonEnv->AlertWin(_L("Log Complete"), KLogFileName);
		CloseLogFile();
		}
	}

void CGfxBitBlitView::CreateLogFileL()
	{
	const TDisplayMode defaultDisplayMode = iEikonEnv->DefaultDisplayMode();
	
	(void)iEikonEnv->FsSession().MkDirAll(KLogFileDir);
	User::LeaveIfError(iLogFile.Replace(iEikonEnv->FsSession(), KLogFileName,EFileWrite ));
	User::LeaveIfError( iLogFile.Write(_L8("Bitblit test results\n")) );
	TBuf8<255> out;
	out.Format(_L8("Default Display Mode %D\n\n"), static_cast<TInt>(defaultDisplayMode) );
	User::LeaveIfError(iLogFile.Write(out));
	out.Format(_L8("Width: %D, Height: %D,\n\n"), Size().iWidth, Size().iHeight);
	iLogFile.Write(out);
	
	TInt nanokernel_tick_period;
	HAL::Get(HAL::ENanoTickPeriod, nanokernel_tick_period);
	out.Format(_L8("Nano tick period: %D\n\n"), nanokernel_tick_period);
	User::LeaveIfError(iLogFile.Write(out));;
	
	iLogFile.Flush();
	}
void CGfxBitBlitView::CloseLogFile()
	{
	iLogFile.Close();
	}

void CGfxBitBlitView::ProfileBitBlitL(TInt aTestNo)
	{
	
	// create a bitmap to be used off-screen
	TDisplayMode tests[KNumberOfTests]={
			/** Monochrome display mode (1 bpp) */
			EGray2,
			/** Four grayscales display mode (2 bpp) */
			EGray4,
			/** 16 grayscales display mode (4 bpp) */
			EGray16,
			/** 256 grayscales display mode (8 bpp) */
			EGray256,
			/** Low colour EGA 16 colour display mode (4 bpp) */
			EColor16,
			/** 256 colour display mode (8 bpp) */
			EColor256,
			/** 64,000 colour display mode (16 bpp) */
			EColor64K,
			/** True colour display mode (24 bpp) */
			EColor16M,
			/** (Not an actual display mode used for moving buffers containing bitmaps) */
			ERgb,
			/** 4096 colour display (12 bpp). */
			EColor4K,
			/** True colour display mode (32 bpp, but top byte is unused and unspecified) */
			EColor16MU,
			/** Display mode with alpha (24bpp colour plus 8bpp alpha) */
			EColor16MA};


	TBuf8<255> out;

	CFbsBitmap* bmp = NULL;
	TRAPD(err, bmp=BitmapForDepthL(tests[aTestNo], Size()));
	if(err)
		{
		RDebug::Print(_L("BITBLIT: ERROR, %D"), err);
		_LIT8(KFormat, "BITBLIT: %D ERROR, %D\n\r");
		out.Format(KFormat, aTestNo, err);
		}
	else
		{
		CleanupStack::PushL(bmp);
		TUint32 startTick = User::NTickCount();

		ActivateGc();
		CWindowGc& gc = SystemGc();

		for(TInt l=0; l<KNumOfBlits; l++)
			{
			gc.BitBlt(TPoint(0,0), bmp);
			}
		
		DeactivateGc();

		TUint32 endTick = User::NTickCount();
		TInt mils = endTick-startTick;
		RDebug::Print(_L("BITBLIT: %D, %D"), aTestNo, mils);
		_LIT8(KFormat, "BITBLIT: %D, %D\n\r");
		out.Format(KFormat, aTestNo, mils);	
		CleanupStack::PopAndDestroy(bmp);
		}
	
	User::LeaveIfError(iLogFile.Write(out));
	iLogFile.Flush();
	}
	
void CGfxBitBlitView::StopL()
	{
	iTimer->Cancel();
	}

