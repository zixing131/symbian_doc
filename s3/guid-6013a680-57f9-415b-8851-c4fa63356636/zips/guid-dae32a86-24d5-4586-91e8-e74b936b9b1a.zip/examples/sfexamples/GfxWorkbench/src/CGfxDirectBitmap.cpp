/*
Copyright (c) 2002-2011 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description:� 
*/ 
#include "CGfxDirectScreenBitmap.h"
#include <coemain.h>
#include <cdsb.h>


CGfxDirectScreenBitmap::CGfxDirectScreenBitmap(RWsSession& aClient, 
        RWindow& aWindow):
        CActive(CActive::EPriorityStandard),
        iClient(aClient),
        iWindow(aWindow)
{
}

void CGfxDirectScreenBitmap::ConstructL()
    {
    
	iDSBitmap =CDirectScreenBitmap::NewL();
	
    // Create the DSA object
    iDirectScreenAccess = CDirectScreenAccess::NewL(
        iClient,                // WS session
        *(CCoeEnv::Static()->ScreenDevice()),        // CWsScreenDevice
        iWindow,                // RWindowBase
        *this                   // MDirectScreenAccess
        );

    CActiveScheduler::Add(this);
    }

CGfxDirectScreenBitmap::~CGfxDirectScreenBitmap()
	{
	Cancel();
	delete iDirectScreenAccess;
	delete iDSBitmap;
	}

	
   // Implement MDirectScreenAccess
void CGfxDirectScreenBitmap::Restart(RDirectScreenAccess::TTerminationReasons /*aReason*/)
	{
	// Do not attempt to restart
	}

void CGfxDirectScreenBitmap::AbortNow(RDirectScreenAccess::TTerminationReasons /*aReason*/)
	{
	Cancel();
	}

void CGfxDirectScreenBitmap::RunL()
	{	
	ProcessFrame();
	}

void CGfxDirectScreenBitmap::DoCancel()
	{
    // Cancel timer
    // Cancel DSA
    iDirectScreenAccess->Cancel();	
    iDSBitmap->Close();
	}

TAcceleratedBitmapInfo CGfxDirectScreenBitmap::BeginDraw()
	{
	TAcceleratedBitmapInfo bitmapInfo;
	iDSBitmap->BeginUpdate(bitmapInfo);
	return bitmapInfo;
	}
/*
 * EndDraw - Signal completion of drawing to the offscreen screen buffer.
 * Let the screen controller copy it to the LCD and notify completion via iStatus
 */
void CGfxDirectScreenBitmap::EndDraw()
	{
	if(IsActive())
		{
		Cancel();
		}
	iDSBitmap->EndUpdate(iStatus);
	SetActive();
	}
/*
 * ProcessFrame - Fill the offscreen screen buffer with a animated image
 */
void CGfxDirectScreenBitmap::ProcessFrame()
	{
	TAcceleratedBitmapInfo bmpInfo = BeginDraw();
	TUint8* screenAddress = bmpInfo.iAddress;
	TUint8* p = screenAddress;
	
	TInt width = bmpInfo.iSize.iWidth;
	TInt height = bmpInfo.iSize.iHeight;
	
	TInt byteShift = (1<< bmpInfo.iPixelShift)/8;
	if( bmpInfo.iPixelShift == 32 ) // work around bug in older Nokia firmware (Search for KIS000575 on Forum Nokia Knowledge base)
		byteShift = 4;
	
	const TInt padding = byteShift -3;
	const TInt rowWidthInBytes = bmpInfo.iLinePitch;

	TInt y=height;
	while(--y)
		{
		TUint8* b=p;
		for(TInt x=0; x<width; x++)
			{
			(*b++) = 255;							// red
			(*b++) = (x+iFrameCounter)%64 * 4;		// green
			(*b++) = (y+(iFrameCounter/2))%64 * 4;	// blue
			b+=padding;								// pad
			}
		p += rowWidthInBytes;	//  reset to start of row in case of
		}
	
	iFrameCounter++;	
	EndDraw();

	}

void CGfxDirectScreenBitmap::StartL(TRect &aRect)
    {
    iControlScreenRect = aRect;
    User::LeaveIfError(
    		iDSBitmap->Create(iControlScreenRect, CDirectScreenBitmap::EDoubleBuffer));
    
    // Initialise DSA
    iDirectScreenAccess -> StartL();
    // Get graphics context for it
    iGc = iDirectScreenAccess -> Gc();
    iGc -> SetBrushStyle(CGraphicsContext::ESolidBrush);
    // Get region that DSA can draw in
    iRegion = iDirectScreenAccess -> DrawingRegion();
    // Set the display to clip to this region
    iGc -> SetClippingRegion(iRegion); 

    ProcessFrame();
    }

void CGfxDirectScreenBitmap::StopL()
	{
	Cancel();
	}

