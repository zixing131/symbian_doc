// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Class to animate the pool ball on the pool table.
// 
// 


#include "moveball.h"

const TInt KGenerationInterval = 10000;


CMoveBall* CMoveBall::NewL(MUpdateContainer& aUpdater)
	{
	CMoveBall* self = new (ELeave) CMoveBall(aUpdater);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
	}

CMoveBall::CMoveBall(MUpdateContainer& aUpdater) : 
								CTimer(CActive::EPriorityStandard),
								iUpdater(aUpdater)
	{	
	}
	
CMoveBall::~CMoveBall()
	{
    if(IsActive())
	    Cancel();
	}
	
void CMoveBall::ConstructL()
	{
	// Contruct the timer and add this class to the active schedular to
	// manage its asynchronous behavior.
	CTimer::ConstructL();
	CActiveScheduler::Add(this);	
	}

/**
 * Initiate the animation of the ball
 */
void CMoveBall::StartMovingBall()
	{
	// Give a 10 millisecond interval between consecutive screen updates
	After(TTimeIntervalMicroSeconds32(0));
	}

/**
 * Stops the ball animation
 */
void CMoveBall::StopMoveBall()
	{
	// Check if the animation is active and running via the timer
	if(IsActive())
		{
		CTimer::Cancel();	
		Cancel();	
		}
	}
	
void CMoveBall::RunL()
	{
	// Give a 10 millisecond interval between consecutive screen updates
	After(TTimeIntervalMicroSeconds32(KGenerationInterval));
	// A callback to update the screen in the view class
	iUpdater.UpdateScreen();
	}

void CMoveBall::DoCancel()
	{
	CTimer::DoCancel();	
	}
