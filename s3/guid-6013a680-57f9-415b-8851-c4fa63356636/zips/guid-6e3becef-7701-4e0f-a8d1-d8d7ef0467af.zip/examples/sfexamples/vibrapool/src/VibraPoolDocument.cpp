// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  CVibraPoolDocument implementation
// 
// 



// INCLUDE FILES
#include "VibraPoolAppUi.h"
#include "VibraPoolDocument.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CVibraPoolDocument::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CVibraPoolDocument* CVibraPoolDocument::NewL( CEikApplication& aApp )
	{
	CVibraPoolDocument* self = NewLC( aApp );
	CleanupStack::Pop( self );
	return self;
	}

// -----------------------------------------------------------------------------
// CVibraPoolDocument::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CVibraPoolDocument* CVibraPoolDocument::NewLC( CEikApplication& aApp )
	{
	CVibraPoolDocument* self =
		new ( ELeave ) CVibraPoolDocument( aApp );

	CleanupStack::PushL( self );
	self->ConstructL();
	return self;
	}

// -----------------------------------------------------------------------------
// CVibraPoolDocument::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CVibraPoolDocument::ConstructL()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CVibraPoolDocument::CVibraPoolDocument()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CVibraPoolDocument::CVibraPoolDocument( CEikApplication& aApp )
	: CAknDocument( aApp )
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CVibraPoolDocument::~CVibraPoolDocument()
// Destructor.
// ---------------------------------------------------------------------------
//
CVibraPoolDocument::~CVibraPoolDocument()
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CVibraPoolDocument::CreateAppUiL()
// Constructs CreateAppUi.
// ---------------------------------------------------------------------------
//
CEikAppUi* CVibraPoolDocument::CreateAppUiL()
	{
	// Create the application user interface, and return a pointer to it;
	// the framework takes ownership of this object
	return ( static_cast <CEikAppUi*> ( new ( ELeave )
										CVibraPoolAppUi ) );
	}

// End of File
