// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declares view class for application.
// 
// 


#ifndef __VIBRAPOOLAPPVIEW_h__
#define __VIBRAPOOLAPPVIEW_h__

// INCLUDES
#include <coecntrl.h>
#include <hwrmvibra.h>	// Vibration API
#include "moveball.h"	// Our asynchronous class to move the ball

// CLASS DECLARATION
class CVibraPoolAppView : public CCoeControl, MUpdateContainer
	{
	public: // New methods

		/**
		* NewL.
		* Two-phased constructor.
		* Create a CVibraPoolAppView object, which will draw itself to aRect.
		* @param aRect The rectangle this view will be drawn to.
		* @return a pointer to the created instance of CVibraPoolAppView.
		*/
		static CVibraPoolAppView* NewL( const TRect& aRect );

		/**
		* NewLC.
		* Two-phased constructor.
		* Create a CVibraPoolAppView object, which will draw itself
		* to aRect.
		* @param aRect Rectangle this view will be drawn to.
		* @return A pointer to the created instance of CVibraPoolAppView.
		*/
		static CVibraPoolAppView* NewLC( const TRect& aRect );

		/**
		* ~CVibraPoolAppView
		* Virtual Destructor.
		*/
		virtual ~CVibraPoolAppView();

	public:  // Functions from base classes

		/**
		* From CCoeControl, Draw
		* Draw this CVibraPoolAppView to the screen.
		* @param aRect the rectangle of this view that needs updating
		*/
		void Draw( const TRect& aRect ) const;

		/**
		* From CoeControl, SizeChanged.
		* Called by framework when the view size is changed.
		*/
		virtual void SizeChanged();

	private: // Constructors

		/**
		* ConstructL
		* 2nd phase constructor.
		* Perform the second phase construction of a
		* CVibraPoolAppView object.
		* @param aRect The rectangle this view will be drawn to.
		*/
		void ConstructL(const TRect& aRect);

		/**
		* CVibraPoolAppView.
		* C++ default constructor.
		*/
		CVibraPoolAppView();

	private:	// Functions specific to our example
		
		/**
		 * Detects the existance of a wall whilst the ball is moving
		 */
		void WallsDetection();
		
		/**
		 * Detects the existance of a hole whilst the ball is moving
		 */
		TBool HolesDetection();
		
		/**
		 * Callback function from MUpdateContainer to update the view 
		 * with the new position of the ball
		 */
		void UpdateScreen();
	
	public: 	// Functions specific to our example
		
	    /**
	     * Basic starting operations
	     */
		void ReStartGame();
	    void StopGame();
		
	private:	// Member variables
	
		CHWRMVibra* iVibra;
		CMoveBall*  iMove;
		TPoint 		iBallLoc;
		TInt 		iMoveX;
		TInt 		iMoveY;
		TBool 		iDrawBall;
	};

#endif // __VIBRAPOOLAPPVIEW_h__

// End of File
