// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Class to animate the pool ball on the pool table.
// 
// 


#ifndef __MOVEBALL_H__
#define __MOVEBALL_H__

#include <e32base.h>
#include <coecntrl.h>

// Observer class to update the screen container
class MUpdateContainer
	{
	public:
		virtual void UpdateScreen() = 0;
	};
	
// Asynchronous class based on a timer to facilitate the animation of the ball.
class CMoveBall : public CTimer
	{
	// Constructors
	public:
		static CMoveBall* NewL(MUpdateContainer&);
		CMoveBall(MUpdateContainer&);
		~CMoveBall();
	private:	
		void ConstructL();
	
	// Animation controlers.
	public:
		void StartMovingBall();
		void StopMoveBall();
	
	// Pure virtual functions from CTImer
	private:
		void RunL();
		void DoCancel();
	
	// Member variables
	private:
		TPoint iLoc;					// Ball location on screen
		MUpdateContainer& iUpdater;		// Screen call back controller
	};
	
#endif
	
