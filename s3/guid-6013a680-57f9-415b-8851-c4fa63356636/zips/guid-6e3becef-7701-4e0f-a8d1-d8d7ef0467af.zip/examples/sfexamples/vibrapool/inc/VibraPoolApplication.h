// 
// Copyright (c) 2002-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
// 
// Initial Contributors:
// Nokia Corporation - initial contribution.
// 
// Contributors:
// 
// Description:  Declares main application class.
// 
// 


#ifndef __VIBRAPOOLAPPLICATION_H__
#define __VIBRAPOOLAPPLICATION_H__

// INCLUDES
#include <aknapp.h>
#include "VibraPool.hrh"


// UID for the application;
// this should correspond to the uid defined in the mmp file
const TUid KUidVibraPoolApp = { _UID3 };


// CLASS DECLARATION

/**
* CVibraPoolApplication application class.
* Provides factory to create concrete document object.
* An instance of CVibraPoolApplication is the application part of the
* AVKON application framework for the VibraPool example application.
*/
class CVibraPoolApplication : public CAknApplication
	{
	public: // Functions from base classes

		/**
		* From CApaApplication, AppDllUid.
		* @return Application's UID (KUidVibraPoolApp).
		*/
		TUid AppDllUid() const;

	protected: // Functions from base classes

		/**
		* From CApaApplication, CreateDocumentL.
		* Creates CVibraPoolDocument document object. The returned
		* pointer in not owned by the CVibraPoolApplication object.
		* @return A pointer to the created document object.
		*/
		CApaDocument* CreateDocumentL();
	};

#endif // __VIBRAPOOLAPPLICATION_H__

// End of File
