/*
Copyright (c) 2008-2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
� list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
� this list of conditions and the following disclaimer in the documentation
� and/or other materials provided with the distribution.
* Neither the name of Nokia Corporation nor the names of its contributors
� may be used to endorse or promote products derived from this software
� without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: Defines the CSubtractor class.� 
*/



/**
 @file
*/
#ifndef __SUBTRACTOR_H__
#define __SUBTRACTOR_H__

#include "sharedmem.h"

/**
The subtractor class.
This class opens the global chunk and periodically subtracts random values from it.
The condition variable ensures that the value of the chunk is always greater than 0.
*/
class CSubtractor : public CActive
	{
public:
	static CSubtractor* NewL(CConsoleBase* aConsole);
	void RunL();
	void DoCancel();
	~CSubtractor();
	void StartTimer();
	void StopTimer();
	void ReadFunction();
	static TInt SubtractFunction(TAny* aPtr);
	void Subtract();
private:
	CSubtractor();
	void ConstructL(CConsoleBase* aConsole);
private:
	/**
	The global condition variable.
	It ensures that the value of the shared chunk is always greater than 0.
	*/
	RCondVar iCondVar;
	/**
	The mutex variable.
	*/
	RMutex iMutex;
	/**
	The global chunk shared between the adder and the subtractor processes.
	@see CAdder.
	*/
	RChunk iChunk;
	/**
	The timer object.
	It periodically invokes the SubtractFunction() function.
	*/
	CPeriodic* iPeriodic;
	/**
	The user console.
	*/
	CConsoleBase* iConsole;
	};
	
#endif
